# mcs-orders

Микросервис заказов

[![pipeline status](https://gitlab.utair.ru/digital/ms/mcs-orders/badges/master/pipeline.svg)](https://gitlab.utair.ru/digital/ms/mcs-orders/commits/master)
[![coverage report](https://gitlab.utair.ru/digital/ms/mcs-orders/badges/master/coverage.svg)](https://gitlab.utair.ru/digital/ms/mcs-orders/commits/master)

