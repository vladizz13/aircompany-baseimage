import json
from pymongo import MongoClient
from itertools import islice, chain
import time
import socket

print('Import libs, done')


def chunks(iterable, size=500):
    iterator = iter(iterable)
    for first in iterator:
        yield chain([first], islice(iterator, size - 1))


print('Import chunks, done')


def check_remote_port_with_retry(host, port, max_attempts=100, delay_between_attempts=2):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2)  # Timeout if the port is not responding
    print('Creating connection to db, done')

    for attempt in range(1, max_attempts + 1):
        try:
            result = sock.connect_ex((host, port))
            sock.close()
            print(f'Socket  connect_ex, done, {result}')
            if result == 0:  # The port is open
                print(f'Successfully connected to port {port} on {host}.')
                return True
            else:
                print(f'Attempt {attempt} failed. Retrying...')
                time.sleep(delay_between_attempts)
        except socket.error:
            print(f'Attempt {attempt} failed due to socket error. Retrying...')
            time.sleep(delay_between_attempts)

    print(f'Failed to connect to port {port} on {host} after {max_attempts} attempts.')
    return False


host = 'mongodb'
port = 27017
print(f'Running check port function with {host} and port {port}')
check_remote_port_with_retry(host, port)

# Create a client that connects to a     MongoDB instance running on your local machine
client = MongoClient("mongodb://utair:55807c4aa255a7c199209d33668d0aed46a3fd539c623db96c3fd5c04a3a@mongodb:27017/admin")
print(f'Creating connection with {host} and port {port}')

dbnames = client.list_database_names()
if "orders" in dbnames:
    print("Orders exist")
    quit()

# Select a database
db = client["orders"]

# Select a observer collection within the database
collection_observer = db["observer"]

# Load observer data from the file
with open('/code/opt/db/data/orders.observer.json', 'r', encoding="utf-8") as file:
    data = json.loads(file.read())
    for row in data:
        del row["_id"]

# Insert the documents into the collection
insert_result = collection_observer.insert_many(data)
print("Observer insert done")

# Select a prorates collection within the database
collection_prorates = db["prorates"]

# Load prorates data from the file
with open('/code/opt/db/data/prorates.json', 'r') as file:
    lines = filter(None, (line.rstrip() for line in file))

    for _chunk in chunks(lines):
        data = [json.loads(line) for line in _chunk]
        for row in data:
            del row["_id"]

# Insert the documents into the collection
insert_result = collection_prorates.insert_many(data)
print("Prorates insert done")

# Select a currency_rates collection within the database
collection_currency_rates = db["currency_rates"]

# Load prorates data from the file
with open('/code/opt/db/data/currency_rates.json', 'r') as file:
    data = json.load(file)
# Insert the documents into the collection
insert_result = collection_currency_rates.insert_one(data)
print("Currency insert done")
