db.orders.createIndex({'data.order_uuid': 1},{'background': 1, 'unique': 1});
db.orders.createIndex({'data.rloc': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.departure_end_timestamp': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.host_rloc': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.departure_end_timestamp': 1, 'data.tickets.ticket': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.rloc': 1, 'data.departure_end_timestamp': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.segments.arrival_city_code': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.segments.departure_city_code': 1},{'background': 1, 'unique': 0});
db.orders.createIndex({'data.segments.departure_timestamp': 1},{'background': 1, 'unique': 0});


db.prorates.createIndex({'departure': 1},{'background': 1, 'unique': 0});
db.prorates.createIndex({'arrival': 1},{'background': 1, 'unique': 0});
db.prorates.createIndex({'arrival': 1, 'departure': 1},{'background': 1, 'unique': 0});
db.prorates.createIndex({'date_from': 1},{'background': 1, 'unique': 0});
db.prorates.createIndex({'date_to': 1},{'background': 1, 'unique': 0});
db.prorates.createIndex({'date_to': 1, 'date_from': 1},{'background': 1, 'unique': 0});

db.exchanges.createIndexes({'exchange_uuid': 1}, {'background': 1, 'unique': 0});
db.exchanges.createIndexes({'order_uuid': 1}, {'background': 1, 'unique': 0});
