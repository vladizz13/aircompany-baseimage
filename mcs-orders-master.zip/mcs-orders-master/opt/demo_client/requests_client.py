import requests
from requests.auth import HTTPBasicAuth # noqa


rpc_api_host = 'https://128.199.155.226/jsonrpcapi'


ping_response = requests.post(
    rpc_api_host,
    json={"method": "sys.ping", "id": 1},
    verify=False
)
print(ping_response.json())
#  {'id': 1, 'jsonrpc': '2.0', 'result': 'pong'}
