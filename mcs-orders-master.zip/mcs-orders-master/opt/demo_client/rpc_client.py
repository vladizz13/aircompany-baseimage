from jsonrpcclient.clients.http_client import HTTPClient


client = HTTPClient("http://127.0.0.1:5000/jsonrpcapi")
response = client.request("sys.ping")
print(response.data.result)

# pong
