#!/usr/bin/env bash
#Set environment variable APP=actions to run another app from one base image, you can add more that one conditions, for run multiple containers from one entrypoint
set -e

role=${APP:-app}

if [ "$role" = "app" ]; then
	echo "Run index updater"
	  # Выключен, так как вызывается в роли приложения и приложение не стартанет пока не накатится индекс
    # /usr/local/bin/python3 -m cli.utils.index_updater --roll
    echo "Run App"
    # NB: Max requests - нужно учитывать, что в продакшене /health запрашивается очень часто, 2 запроса параллельно (readiness/liveness) раз в 10 сек. (720 в час только на /health)
    # Реальных запросов около ~500, из расчета (700+~500)/3 = ~400 запросов на конкретного воркера в час = max_requests=1000 - рестарт раз в ~2 часа
    gunicorn rest.applications.rpc_app.application --bind 0.0.0.0:5000 --name=gunicorn --workers=3 --threads=6 --worker-class=gthread --worker-connections=1000 --backlog=500 --log-level=debug --timeout=30 --max-requests=500 --max-requests-jitter=50 --access-logfile - --error-logfile -
elif [ "$role" = "celery-worker" ]; then
    celery -A rest.applications.celery_app.application worker -l error --logfile=/code/var/log/celery-worker.log --uid deploy

elif [ "$role" = "celery-flower" ]; then
    celery -A rest.applications.celery_app.application flower --logging=error --log-file-prefix=/code/var/log/celery-flower.log --xheaders --address=0.0.0.0 --port=8888 --basic_auth=utair:utair --uid deploy

elif [ "$role" = "celery-beat" ]; then
    celery -A rest.applications.celery_app.application beat -l error --logfile=/code/var/log/celery-beat.log --schedule=/code/var/celery-beat.db --pid=/code/var/celery-beat.pid --uid deploy

elif [ "$role" = "kafka-pub" ]; then
    python -m rest.applications.kafka_app.producer

elif [ "$role" = "kafka-sub" ]; then
    python -m rest.applications.kafka_app.consumer

elif [ "$role" = "sirena-rmq-listener" ]; then
    python -m rest.applications.rmq_listener.sirena.listen --queue=V1

elif [ "$role" = "sirena-rmq-listener-v2" ]; then
    python -m rest.applications.rmq_listener.sirena.listen --queue=V2

elif [ "$role" = "test" ]; then
    bash || sh

else
    echo "Could not match the container role \"$role\""
    exit 1
fi
