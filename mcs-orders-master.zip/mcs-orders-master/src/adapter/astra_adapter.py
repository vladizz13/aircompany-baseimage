import re
from typing import Union, Dict, List
from astra_soap_client import CheckInAdapter
from rest.settings.settings import ASTRA_CONF
from libs.db_gateway import get_db_gateway
from base.adapter import BaseAdapter


class AstraInternalAdapter(BaseAdapter):
    """
    Адаптер для работы с астрой
    """
    # Регулярка для разделение на цифры (group(1)) и буквы (group(2))
    flight_symbols_group_rgx = re.compile("([0-9]+)([a-zA-Z]+)")

    def __init__(self, cached_session: bool = True):
        """
        :param cached_session: Использовать redis в качестве кэша авторизации
        """
        self.__cached_session__ = cached_session
        self.__client__ = None

    @property
    def client(self):
        if self.__client__ is None:
            if self.__cached_session__:
                self.__client__ = CheckInAdapter(ASTRA_CONF, get_db_gateway('redis'))
            else:
                self.__client__ = CheckInAdapter(ASTRA_CONF)
        return self.__client__

    def search_flight(self, **kwargs) -> Union[Dict, List]:
        flight = kwargs.get('flight_number')
        if flight:
            groups = self.flight_symbols_group_rgx.match(flight)
            if not groups:
                kwargs["flight_number"] = flight
            else:
                kwargs['flight_number'] = groups.group(1)
                kwargs['flight_litera'] = groups.group(2)

        return self.client.get_search_flight(**kwargs)

    def load_pnr(self, **kwargs) -> dict:
        return self.client.get_load_pnr(**kwargs)

    def seat_map(self, **kwargs) -> dict:
        return self.client.get_seat_map(**kwargs)
