import boto3
from io import BytesIO
from boto3.s3.transfer import TransferConfig
from botocore.client import Config
from typing import Union

from base.adapter import BaseAdapter


class FileStorageAdapter(BaseAdapter):
    """
    Адаптер для работы с файловым хранилищем.
    """

    def __init__(
        self,
        bucket: str,
        access_key_id: str,
        secret_key_id: str,
        endpoint: str,
        directory: str,
        signed_link_expires_in: int,
        connect_timeout: Union[float, int] = 5,
        read_timeout: Union[float, int] = 5,
        max_attempts: int = 2,
        verify: bool = True,
    ):
        self.__client__ = None
        self.bucket = bucket
        self.access = access_key_id
        self.secret = secret_key_id
        self.endpoint = endpoint
        self.session = boto3.session.Session()
        self.verify = verify
        self.directory = f"{directory}/" if directory else ""
        self.expires_in = signed_link_expires_in
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_attempts = max_attempts

    @property
    def client(self):
        """
        Создать клиент файлового хранилища.
        :return:
        """
        if self.__client__ is None:
            self.__client__ = boto3.client(
                "s3",
                verify=self.verify,
                endpoint_url=self.endpoint,
                aws_access_key_id=self.access,
                aws_secret_access_key=self.secret,
                config=Config(
                    connect_timeout=self.connect_timeout,
                    read_timeout=self.read_timeout,
                    retries={
                        'max_attempts': self.max_attempts
                    }
                )
            )
        return self.__client__

    def upload_binary_file(self, data: BytesIO, file_name: str) -> bool:
        """
        Загрузить файл в хранилище.
        :param data:
        :param file_name:
        :return: upload successful
        """
        client_response = self.client.upload_fileobj(
            data, self.bucket, file_name, ExtraArgs={"Expires": 600},
            Config=TransferConfig(
                use_threads=False
            )
        )
        return client_response

    def get_download_url(self, file_name) -> str:
        """
        Сгенерировать линк для скачивания файла.
        :param file_name: название файла
        :return: url
        """
        download_link = self.client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": file_name},
            ExpiresIn=600,
        )
        return download_link
