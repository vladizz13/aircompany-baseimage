from base.exception import ApplicationError


class AirportNotFoundError(ApplicationError):
    """Аэропорт не найден"""
    code = 40403
    message = "Airport not found"


class CityNotFoundError(ApplicationError):
    """Город не найден"""
    code = 40404
    message = "City not found"


class UserNotFoundError(ApplicationError):
    """Пользователь не найден"""
    code = 40405
    message = "User not found"


class BonusAccountNotFoundError(ApplicationError):
    """Пользователь не найден в бонусной системе"""
    code = 40406
    message = "Bonus account not found"


class CardDoesNotExist(ApplicationError):
    """
    Карта не найдена
    """
    code = 40408
    message = "Сard does not exist"


class CardBelongsToDifferentUserError(ApplicationError):
    """
    Карта принаджежит другому пользователю
    """
    code = 40409
    message = "Card belongs to different user"


class InvalidInitialsError(ApplicationError):
    """
    Неверное имя или фамилия
    """
    code = 40016
    message = "Wrong name or lastname"
    status = 400


class UserIsNotCompletelyRegisteredError(ApplicationError):
    """
    Пользователь не прошел до конца регистрацию
    """
    code = 40009
    message = "User is not completely registered error"


class SendVerificationCodeError(ApplicationError):
    """
    Не удалось отправить код пользователю
    """
    error_code = 40088
    message = "Failed to send verification code"
    status = 400
