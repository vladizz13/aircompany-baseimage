import logging
import time
from typing import Dict, Optional

from mcs_oauth_client.domain.user import DomainUser
from domain.types import CodeDispatchType

from libs.cache.request_cache import RequestCache
from libs.rpc_client.base import BaseRPCService
from rest.settings.settings import MONO_APP_JSONRPC
from use_cases.shared.exceptions import OrderConfirmAttemptsCountExceededError
from .exceptions import (
    CityNotFoundError,
    AirportNotFoundError,
    CardDoesNotExist,
    BonusAccountNotFoundError,
    UserNotFoundError,
    CardBelongsToDifferentUserError,
    InvalidInitialsError,
    SendVerificationCodeError,
    UserIsNotCompletelyRegisteredError
)

logger = logging.getLogger('monoapp_geo_adapter')


class MonoAppAdapter(BaseRPCService):
    """
    Класс для работы с JSON-RPC с моноапп приложением
    """

    service_errors: dict = {
        40403: AirportNotFoundError,
        40404: CityNotFoundError,
        40405: UserNotFoundError,
        # Loyalty Errors
        40406: BonusAccountNotFoundError,
        40408: CardDoesNotExist,
        40301: CardBelongsToDifferentUserError,
        40009: UserIsNotCompletelyRegisteredError,
        40016: InvalidInitialsError,

        # SMSC
        40088: SendVerificationCodeError,
        40320: OrderConfirmAttemptsCountExceededError
    }

    cache_ttl: int = 60 * 60 * 24 * 3  # 3ое-суток

    def __init__(self):
        super().__init__(**MONO_APP_JSONRPC)

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def find_city_by_iata(self, iata_code: str) -> dict:
        try:
            city = self.request(method='geo.find_city_by_iata.v1', request_id=int(time.time()), iata=iata_code)
        except CityNotFoundError as e:
            logger.exception(e, extra={'tags': {'city': iata_code}})
            raise
        return city

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def extended_find_airport_by_iata(self, iata_code) -> dict:
        try:
            airport = self.request(method='geo.find_airport_by_iata.v1', request_id=int(time.time()), iata=iata_code)
        except AirportNotFoundError as e:
            logger.exception(e, extra={'tags': {'airport': iata_code}})
            raise
        return airport

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def extended_find_city_by_iata(self, iata_code: str) -> dict:
        try:
            city = self.request(method='geo.extended_find_city_by_iata.v1', request_id=int(time.time()), iata=iata_code)
        except CityNotFoundError as e:
            logger.exception(e, extra={'tags': {'city': iata_code}})
            raise
        return city

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def get_airport_full_name_by_iata(self, iata_code: str, lang: str = None) -> str:
        try:
            airport = self.request(
                method='geo.find_airport_full_name.v1', request_id=int(time.time()), iata=iata_code, lang=lang
            )
        except AirportNotFoundError as e:
            logger.exception(e, extra={'tags': {'airport': iata_code}})
            raise
        return airport

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def get_city_full_name_by_iata(self, iata_code: str, lang: str = None) -> str:
        try:
            city = self.request(
                method='geo.find_city_full_name.v1', request_id=int(time.time()), iata=iata_code, lang=lang
            )
        except CityNotFoundError as e:
            logger.exception(e, extra={'tags': {'city': iata_code}})
            raise
        return city

    def get_city_iata_by_airport(self, airport_iata: str) -> str:
        airport = self.extended_find_airport_by_iata(airport_iata)
        return airport['city_code']

    def verify_level_status(self, login: str, login_type: str, first_name: str, last_name: str, birthday: str) -> dict:
        """
        Проверяет принадлежность переданного логина (карта Status, email, phone) к пользователю
        и возвращает статус пользователю в бонусной системе
        Может зарейзить
        >>> CardDoesNotExist, BonusAccountNotFoundError, CardBelongsToDifferentUserError, InvalidInitialsError
        """
        response = self.request(
            method='bonus.verify.v1',
            request_id=int(time.time()),
            login=login,
            login_type=login_type,
            first_name=first_name,
            last_name=last_name,
            birthday=birthday,
        )
        return response

    def get_user_by_user_id(self, user_id: str) -> DomainUser:
        """
        Поиск пользователя по user_id
        Может зарейзить
        >>> UserNotFoundError
        """
        if not user_id:
            raise UserNotFoundError()
        response = self.request(method='users.findById.v1', request_id=int(time.time()), user_id=user_id)
        user = DomainUser.deserialize(response)
        return user

    def send_verification_code(
            self,
            phone_number: str,
            type_of_dispatch: CodeDispatchType = CodeDispatchType.CALL,
            operation_type: Optional[str] = None,
            salt: Optional[str] = None
    ) -> Dict:
        """
        Отправить пользователю код для верификации

        :param phone_number: номер телефона
        :param type_of_dispatch: тип отправки (звонком/по смс)
        :param operation_type: тип операции
        :param salt: соль для кэширования кода
        :return:
        """
        response = self.request(
            method='verification.send_code.v1',
            request_id=int(time.time()),
            phone_number=phone_number,
            type_of_dispatch=type_of_dispatch.value,
            operation_type=operation_type,
            salt=salt
        )
        return response

    def create_payment(
        self,
        payment_id: str,
        rloc: str,
        amount: int,
        currency: str,
        payment_type: str = 'change_pd',
        order_item_type: str = 'airticket',
        host: str = 'sirena',
        shop: str = 'shop_31',
        success_url: str = None,
        failure_url: str = None,
        payload: Dict = {},
        customer: Optional[Dict] = None,
    ) -> Dict:
        """
        Создание платежа

        :param payment_id: уникальный идентификатор платежа
        :param rloc: уникальный идентификатор брони
        :param amount: сумма платежа
        :param currency: тип валюты
        :param payment_type: категория оплачиваемой услуги
        :param order_item_type: принадлежность оплачиваемой услуги
        :param host: интеграция со сторонней системой
        :param shop: шоп, через который будет происходить оплата
        :param success_url: url для редиректа, в случае успешной оплаты
        :param failure_url: url для редиректа, в случае безуспешной оплаты
        :param payload:
        :param customer: Информация о плательщике
        customer {
            phone: x,
            email: x,
            initials: {
                international: {
                    name: x,
                    surname: x
                }
            }
        }
        """
        response = self.request(
            method='payment.create.v1',
            request_id=int(time.time()),
            payment_id=payment_id,
            payment_parts=[
                {
                    'amount': {'amount': amount, 'currency': currency},
                    'ref': '0',
                    'type': 'card',
                    'id': {'@xsi:nil': 'true'},
                }
            ],
            order_items=[
                {
                    'clearing': None,
                    'amount': {'amount': amount, 'currency': currency},
                    'number': rloc,
                    'typename': order_item_type,
                    'host': host,
                    'ref': '0',
                }
            ],
            payment_type=payment_type,
            shop_config=shop,
            success_url=success_url,
            failure_url=failure_url,
            payload=payload,
            customer=customer
        )
        self.__check_error__(response)
        return response

    def get_payment_status(
        self,
        payment_id: str,
        shop: str = 'shop_31'
    ) -> Dict:
        """
        Запрос статуса платежа

        :param payment_id: уникальный идентификатор платежа
        :param shop: шоп, через который будет происходить оплата
        :return:
        """
        response = self.request(
            method='payment.status.v1',
            request_id=int(time.time()),
            payment_id=payment_id,
            shop_config=shop,
        )
        if not isinstance(response.get('error', {}).get('code'), int):
            response.pop('error')
        self.__check_error__(response)
        return response.get('status')

    def emarsys_send(
        self,
        type_code: str,
        email_address: str,
        data: Dict[str, str]
    ) -> Dict:
        """
        Запрос отправки письма
        """
        response = self.request(
            method='messages.emarsys.send.v1',
            request_id=int(time.time()),
            type_code=type_code,
            email_address=email_address,
            data=data
        )
        return response
