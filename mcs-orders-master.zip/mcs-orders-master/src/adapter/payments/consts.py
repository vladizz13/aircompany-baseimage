from mcs_payments_client.payment_types import PaymentFlow

FLOW = PaymentFlow.REDIRECT
