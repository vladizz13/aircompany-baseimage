import logging
from datetime import timedelta

from typing import Optional, List, Union
from requests.utils import requote_uri
from uuid import UUID

from mcs_payments_client.base.model import TReq, TRes
from mcs_payments_client import (
    PaymentClient,
    HoldFundsRequest, HoldFundsResponse, HoldFundsMoneyPart, HoldFundsBonusPart,
    GetPaymentRequest, GetPaymentResponse,
    ConfirmRequest, ConfirmResponse,
    VoidRequest, VoidResponse,
    RequestCustomer, RequestSaleItem, RequestFlight,
)
from mcs_payments_client.payment_types import OperationTypes, Currency, PaymentProvider

from base.adapter import BaseAdapter

from rest.settings.settings import MCS_PAYMENTS

from .consts import FLOW

from mcs_payments_client.exceptions import BaseClientException


class PaymentsInternalAdapter(BaseAdapter):
    """
    Адаптер МКС Payments
    """
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def hold(
        self,
        operation_type: OperationTypes,
        customer: RequestCustomer,
        amount: float,
        currency: Currency,
        success_url: str,
        failure_url: str,
        description: str,
        provider: PaymentProvider,
        bonus_parts: Optional[List[HoldFundsBonusPart]] = None,
        free_data: Optional[dict] = None,
        payment_ttl: Optional[timedelta] = None,
        confirm_ttl: Optional[timedelta] = None,
        request_id: Optional[UUID] = None,
    ) -> HoldFundsResponse:
        """Холдирование средств"""

        request = HoldFundsRequest(
            topic='utair.payments.orders.exchange.v1',
            description=description,
            operation_type=operation_type,
            customer=customer,
            money_part=HoldFundsMoneyPart(
                provider=provider,
                payment_flow=FLOW,
                amount=amount,
                currency=currency,
            ),
            success_url=requote_uri(success_url),
            failure_url=requote_uri(failure_url),
            free_data=free_data,
            payment_ttl=payment_ttl,
            confirm_ttl=confirm_ttl,
        )
        if bonus_parts:
            request.add_bonus(bonus_parts)

        return self.__do_request(request, request_id=request_id)

    def get(self, uuid: Union[str, UUID]) -> GetPaymentResponse:
        request = GetPaymentRequest(transaction_uuid=uuid)

        return self.__do_request(request)

    def confirm(
            self,
            uuid: Union[str, UUID],
            sale_parts: Optional[List[RequestSaleItem]] = None,
            exchange_income_parts: Optional[List[RequestSaleItem]] = None,
            exchange_refund_parts: Optional[List[RequestSaleItem]] = None,
            flight: Optional[RequestFlight] = None,
            request_id: Optional[UUID] = None,
    ) -> ConfirmResponse:
        request = ConfirmRequest(
            transaction_uuid=uuid,
            sale_parts=sale_parts,
            exchange_income_parts=exchange_income_parts,
            exchange_refund_parts=exchange_refund_parts,
            flight=flight,
        )
        return self.__do_request(request, request_id=request_id)

    def void(self, uuid: Union[str, UUID]) -> VoidResponse:
        request = VoidRequest(transaction_uuid=uuid)

        return self.__do_request(request)

    def __do_request(self, request: TReq, request_id: Optional[UUID] = None) -> TRes:
        """
        Выполнение запроса к АПШ
        @param request: Объект запроса
        @param request_id: Ключ идемпотентности запроса
        @return: Ответ
        """
        with PaymentClient(MCS_PAYMENTS) as client:
            try:
                return client.make_request(request=request, request_id=request_id)
            except BaseClientException:
                raise
            except Exception as ex:
                self.logger.exception(ex)
                raise

    def get_request_id(self) -> UUID:
        """
        Получение ключа идемпотентности
        """
        with PaymentClient(MCS_PAYMENTS) as client:
            return client.request_id()
