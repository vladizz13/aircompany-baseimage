import logging
import time
from typing import Dict, List, Union
from libs.rpc_client.base import BaseRPCService
from libs.rpc_client.exceptions import RPCServiceError
from libs.cache.request_cache import RequestCache
from rest.settings.settings import SERVICE_AGENT_APP_JSONRPC

from domain.service_agent import DomainAdditionalService

logger = logging.getLogger('service_agent_adapter')


class ServiceAgentAdapter(BaseRPCService):
    """
    Класс для работы с JSON-RPC с сервис агента
    """

    cache_ttl: int = 60 * 60 * 24  # сутки

    def __init__(self):
        super().__init__(**SERVICE_AGENT_APP_JSONRPC)

    @RequestCache.class_method_wrapper(ttl=cache_ttl)
    def __get_all_services(self) -> List[Dict]:
        """
        Получение всех доступных услуг от service_agent'a
        """
        try:
            services = self.request(
                method="enricher.get.v1",
                request_id=int(time.time()),
            )
            if services:
                return services
            raise RPCServiceError(
                message=f"Unable to fetch response from ServiceAgent with {self.__timeout__} sec timeout"
            )
        except RPCServiceError as e:
            logger.exception(e)
            raise

    def get_service_by_guid(self, guid: str) -> Union[DomainAdditionalService, None]:
        """
        Поиск услуги по guid
        """
        if guid is None:
            return None
        services = self.__get_all_services()
        for service in services:
            if service.get('guid', None) == guid:
                return DomainAdditionalService.deserialize(service)
        return None

    def get_service_by_rfisc(self, rfisc: str) -> Union[DomainAdditionalService, None]:
        """
        Поиск услуги по rfisc
        """
        if rfisc is None:
            return None
        services = self.__get_all_services()
        for service in services:
            if service.get('sirena_key', {}).get('@rfisc', None) == rfisc:
                return DomainAdditionalService.deserialize(service)
        return None
