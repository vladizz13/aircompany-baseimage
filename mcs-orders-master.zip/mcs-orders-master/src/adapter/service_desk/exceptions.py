from base.exception import ApplicationError


class JiraSDBadRequestError(ApplicationError):
    """Ошибка при обращении Jira Service Desk"""
    status = 400
    code = 11001
    message = "Jira Bad Request"


class JiraSDBadRefundRequestError(ApplicationError):
    """Ошибка при создании заявки в Jira Service Desk"""
    status = 421
    code = 117
    message = "JIRA couldn't handle order refund request"


class JiraSDUnavailableError(ApplicationError):
    """Jira Service Desk недоступен"""
    code = 11002
    message = "Jira Service Desk unavailable"


class JiraSDBaseError(ApplicationError):
    status = 400
    code = 11014
    message = "Jira Bad Request"
