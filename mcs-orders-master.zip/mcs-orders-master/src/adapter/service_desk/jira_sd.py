from typing import Dict, List, Type, Optional
import requests
from requests.auth import HTTPBasicAuth
import logging
from base.adapter import BaseAdapter
from domain.types import JiraLabels
from .exceptions import JiraSDBadRequestError, JiraSDUnavailableError, JiraSDBadRefundRequestError

logger = logging.getLogger('JiraSDRefundLogging')


class JiraServiceDeskAdapter(BaseAdapter):

    def __init__(
            self,
            username: str,
            password: str,
            host: str,
            refund_project_id: str,
            refund_issue_type: str,
            timeout: int = 10
    ):
        self._host = host
        self._auth = HTTPBasicAuth(
            username=username,
            password=password
        )

        self._refund_project_id = refund_project_id
        self._refund_issue_type = refund_issue_type
        self._timeout = timeout

    def apply_for_refund(
            self,
            order_uuid: str,
            is_involuntary: bool,
            labels: Optional[List[Type[JiraLabels]]] = None
    ) -> Dict:
        """
        Оформить заявку на возврат в ServiceDesk
        :param order_uuid: order_uuid брони
        :param is_involuntary: флаг вынужденного возврата
        :param labels: Доп поля, которые отображаются в админке jira
        """

        request: Dict = dict(
            fields=dict(
                project=dict(
                    id=self._refund_project_id
                ),
                summary="Возврат",                    # Тема заявки.
                issuetype=dict(
                    id=self._refund_issue_type        # Тип заявки - Возврат Бронь
                ),
                customfield_12801=order_uuid,
                customfield_12308=dict(
                    value="Вынужденный" if is_involuntary else "Добровольный"
                )
            )
        )
        if labels:
            request["fields"].update(labels=labels)

        try:
            response = requests.post(
                url=f'{self._host}api/2/issue/', auth=self._auth, json=request, timeout=self._timeout
            )
        except OSError as e:
            raise JiraSDUnavailableError(inner_exception=e)

        logger.info(f'JiraSD request: {str(request)} JiraSD response: {str(response.text)}')
        try:
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            logger.info(f'Unable to create refund request in ServiceDesk : {str(e)}')
            if 400 <= response.status_code <= 499:
                raise JiraSDBadRefundRequestError()
            raise JiraSDUnavailableError(inner_exception=e)
        return response.json()

    def find_refund_by_uuid(
            self,
            order_uuid: str
    ) -> Dict:
        """
        Проверяем наличие заявки в ServiceDesk
        :param order_uuid: uuid брони
        """
        _host = f'{self._host}scriptrunner/latest/custom/findRefund?order_uuid={order_uuid}'

        response = requests.get(
            url=_host, timeout=self._timeout
        )
        logger.info(f'JiraSD request: {str(_host)} JiraSD response: {str(response.text)}')
        try:
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            if response.status_code == 400:
                raise JiraSDBadRequestError(message=response.json()["error"])
            raise JiraSDUnavailableError(inner_exception=e)
        return response.json()
