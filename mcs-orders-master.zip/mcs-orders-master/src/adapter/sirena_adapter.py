import logging

from typing import Dict, Union, List
from datetime import datetime

from sirena_xml_client.exceptions import (
    BaseSirenaError,
    SirenaMessageTimedOutError,
    SirenaResponseError,
    SirenaPnrAndSurnameDontMatch,
    SirenaPnrAlreadyUnArchived,
    SirenaDuplicateSvc,
    SirenaPnrWaitingForPaymentConfirmationError,
    SirenaPnrBusyError,
    SirenaEmptyResponse,
    SirenaPassengersTitleNotFoundError,
    SirenaDuplicateSsr,
)
from sirena_xml_client.gds_adapter import SirenaAdapter
from sirena_xml_client.types import (
    PassengerForAddFFInfo, ServiceForAdd, SsrForAdd, PassengersForReleaseSeats, PaymentDocument, PaymentCost,
    ExchangePassenger, ExchangeSegments, SegmentsForReleaseSeats, ExchangeMethod, PaymentPassenger
)
from utair.clients.external.sirena.requests.common import ExchangeSegments as UtairExchangeSegments

from base.adapter import BaseAdapter
from base.exception import ApplicationError
from libs.db_gateway import get_db_gateway
from rest.settings.settings import SIRENA_APC

logger = logging.getLogger('SirenaInternalAdapter')


def timeout_handler(func: callable):
    def wrap(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (
                ConnectionError,
                TimeoutError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse,
                SirenaResponseError,
        ) as e:
            log_message = f"Sirena request timeout. SirenaAdapter.{str(func.__name__)}," \
                          f" for request with args: {args}, kwargs: {kwargs}"
            logger.info(log_message)
            # TODO
            #   Изменить на ошибку от сирены (SirenaPNRIsBusy)
            #   Проверить все места, где ловится ApplicationError во время работы с сиреной
            raise ApplicationError(
                message=f"Sirena {str(func.__name__)} request timeout.",
                inner_exception=e, code=40501, status=408
            )

    return wrap


class SirenaInternalAdapter(BaseAdapter):
    """
    Адаптер для работы с SirenaGRS
    """

    def __init__(self):
        self.__client__ = None

    @staticmethod
    def format_string(string: str):
        """
        Подготавливает строку для запроса в сирену
        Подменяет символы, с которыми сирена не умеет работать
        :param string:
        :return:
        """
        sub_map = {
            'ё': 'е',
            'Ё': 'Е',
            '-': '',
            'ъ': 'ь',
            'Ъ': 'ь',
        }
        if not string:
            return string
        for k, v in sub_map.items():
            string = string.replace(k, v)
        return string

    @property
    def client(self):
        if self.__client__ is None:
            self.__client__ = SirenaAdapter(
                config=SIRENA_APC,
                cache_client=get_db_gateway(
                    label="redis"
                )
            )
        return self.__client__

    @staticmethod
    def __sanitize_rloc__(rloc: str) -> str:
        if '/' in rloc:
            rloc = rloc.split('/')[0]
        return rloc

    @timeout_handler
    def svc_emd_issue_query(
            self,
            rloc: str,
            service_ids: List[int],
            payment_document: PaymentDocument
    ):
        """
        Оценка услуг
        :param rloc: рлок заказа
        :param service_ids: список id услгу из сирены
        :param payment_document: параметры платежа
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            response = self.client.svc_emd_issue_query(
                regnum=rloc,
                payment_document=payment_document,
                service_ids=service_ids,
            )
            return response
        except SirenaPnrWaitingForPaymentConfirmationError:
            return None

    @timeout_handler
    def svc_emd_issue_confirm(
            self,
            rloc: str,
            payment_document: PaymentDocument,
            payment_cost: PaymentCost
    ) -> List[Dict]:
        """
        Подтверждение услуг
        :param rloc:
        :param payment_document: параметры платежа
        :param payment_cost: цена
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            response = self.client.svc_emd_issue_confirm(
                regnum=rloc,
                payment_document=payment_document,
                payment_cost=payment_cost

            )
            services = response.get("answer", {}).get("svc_emd_issue_confirm", {}).get("svcs", {}).get("svc", [])
            if isinstance(services, dict):
                services: List[Dict] = [services]
            return services
        except (
            SirenaMessageTimedOutError,
            SirenaResponseError,
            SirenaMessageTimedOutError,
            SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return list()

    @timeout_handler
    def add_services(
            self,
            rloc: str,
            services: List[ServiceForAdd],
            version: Union[str, int] = 'ignore'
    ) -> Union[Dict, None]:
        """
        Добавление сервисов в заказ
        :param rloc: Рлок заказа
        :param services: Сервисы
        :param version: Версия заказа
        :return:
        :raises SirenaDuplicateSvc
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            return self.client.add_services(
                regnum=rloc,
                services=services,
                version=version
            )
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise
        except SirenaDuplicateSvc:
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def delete_services(
            self,
            rloc: str,
            services_ids: List[int],
            version: Union[str, int] = 'ignore'
    ) -> Union[Dict, None]:
        """
        Удаление сервисов из заказа
        :param rloc: Рлок заказа
        :param services_ids: Сервисы
        :param version: Версия заказа
        :return:
        :raises SirenaDuplicateSvc
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            return self.client.remove_services(
                regnum=rloc,
                version=version,
                service_ids=services_ids,
            )
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def remove_segments(
            self,
            rloc: str,
            last_name: str,
            segment_ids: List[str],
            version: Union[str, int] = 'ignore'
    ):
        """
            Удаление сегментов из заказа
            :param rloc: Рлок заказа
            :param last_name: Фамилия пассажира
            :param segment_ids: Идентификаторы сегментов
            :param version: Версия заказа
            :return:
            :raises BaseSirenaError
            """
        rloc: str = self.__sanitize_rloc__(rloc)
        response = self.client.remove_segments(
            regnum=rloc,
            surname=last_name,
            version=version,
            segments=segment_ids,
        )
        return response.get('answer', {})

    @timeout_handler
    def get_eticket(
            self,
            ticket_number: str,
            show_passenger: bool = False,
            lang: str = 'ru'
    ) -> Union[Dict, None]:
        """
        Запрос метода eticket_display в сирене
        :param ticket_number: Номер билета
        :param show_passenger: Возвращать данные пассажира
        :param lang: Язык ответа
        :return:
        """
        try:
            response = self.client.get_eticket(ticket_number, show_passenger, lang)
            return response.get('answer', {})
        except (
            SirenaMessageTimedOutError,
            SirenaResponseError,
            SirenaMessageTimedOutError,
            SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def search_order(
            self,
            rloc,
            last_name,
            show_svc=False,
            add_ssr=True,
            add_remarks=True,
            tickinfo=True,
            show_tickinfo_agency=True,
            add_remote_recloc=True,
            add_common_status=True,
            add_paycode=True,
            show_insurance_info=True,
            show_originator: bool = False,
            lang='en',
            **kwargs
    ) -> Union[Dict, None]:
        """
        Просмотр PNR (order) в sirenaGRS
        :param rloc: Номер PNR
        :param last_name: Фамилия любого из пассажиров
        :param tickinfo: Добавлять в ответ информацию о статусе билетов
        :param show_tickinfo_agency: Добавлять в ответ информацию об агентстве
        :param add_common_status: Добавлять в ответ информацию о "максимальном" статусе сегментов
        :param add_remarks: Добавлять в ответ информацию о ремарках в PNR
        :param add_ssr: Добавлять в ответ информацию об SSR в PNR
        :param add_paycode: Добавлять в ответ код оплаты для оплаты в системах приема платежей
        :param show_insurance_info: Добавлять в ответ информацию о страховках в PNR
        :param add_remote_recloc: Добавлять в данные сегментов PNR информацию о номерах инвенторных PNR
        :param show_svc: Добавлять в ответ информацию о доступных услугах
        :param show_originator: показать владельца
        :param kwargs: остальные ключи
        :param lang: язык ответа
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            response = self.client.get_order(
                regnum=rloc,
                surname=last_name,
                show_svc=show_svc,
                add_ssr=add_ssr,
                add_remarks=add_remarks,
                tickinfo=tickinfo,
                show_tickinfo_agency=show_tickinfo_agency,
                add_remote_recloc=add_remote_recloc,
                add_common_status=add_common_status,
                add_paycode=add_paycode,
                show_insurance_info=show_insurance_info,
                show_originator=show_originator,
                lang=lang,
                **kwargs
            )
            return response.get('answer', {})
        except SirenaPnrAndSurnameDontMatch:
            raise
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def add_ff_info(
            self,
            rloc: str,
            last_name: str,
            passengers: List[PassengerForAddFFInfo]
    ) -> Union[dict, None]:
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            response = self.client.add_ff_info(
                regnum=rloc,
                surname=last_name,
                passengers=passengers
            )
            return response.get('answer', {})
        except (
            SirenaMessageTimedOutError,
            SirenaResponseError,
            SirenaMessageTimedOutError,
            SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def un_archive_order(
            self,
            rloc: str
    ) -> bool:
        """
        Разархивировать заказ
        Вернет True, если заказ был разархивирован успешно, либо разархивация не требуется,
        в противном случае вернет False
        :param rloc: уникальный идентификатор заказа
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        try:
            response = self.client.un_archive_order(
                regnum=rloc
            )
            response = response.get('answer', {}).get('unarchive_pnr')
            if 'ok' in response:
                return True
            return False
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise
        except SirenaPnrAlreadyUnArchived:
            return True
        except BaseSirenaError:
            return False

    @timeout_handler
    def get_itinerary_receipt(self, rloc: str = None, last_name: str = None):
        """
        Получить маршрутную квитанцию.
        :param rloc:
        :param last_name:
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        response = self.client.get_receipts_pdf(rloc_without_gds=rloc, surname=last_name)
        return response.get('answer', {}).get('get_itin_receipts', {}).get('receipts', {}).get('text')

    @timeout_handler
    def get_currency_rates(
            self, currency_one: str, currency_two: str, owner: str = 'IATA'
    ) -> Union[Dict, None]:
        """
        Вызов метода get_currency_rates в сирене
        :param currency_one: Код валюты
        :param currency_two: Код валюты
        :param owner: Источник курса
        :return:
        """
        try:
            response = self.client.get_currency_rates(currency_one, currency_two, owner)
            return response.get('answer', {}).get('get_currency_rates', {}).get('value', [])
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def get_modified_orders(self, offset: datetime) -> List[Dict]:
        """
        Получить список измененных заказов с определенного времени (offset)
        :param offset: Дата с которой нужно отобразить измененные заказы
        :return:
        """
        _default = self.client.client.read_timeout
        try:
            self.client.client.read_timeout = 60 * 3
            response = self.client.get_modified_orders(offset)
            self.client.client.read_timeout = _default
            return response.get('answer', {}).get('modified_orders', {}).get('order', [])
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            self.client.client.read_timeout = _default
            raise
        except BaseSirenaError:
            self.client.client.read_timeout = _default
            return list()

    @timeout_handler
    def get_bl_pricing(self, rloc: str, version: str, last_name: str, passenger_data: Dict, payment_info: Dict):
        """
        Проверка возможности изменения данных пассажира и
        переоформления его электронных билетов, а также для получения стоимости такой операции.
        На вход запрос получает:
        - Номер и актуальную версию PNR;
        - Фамилию любого из пассажиров PNR;
        - Идентификатор пассажира и его новые данные — ФИО, пол, дату рождения,
        данные документа, удостоверяющего личность;
        - Форму оплаты, по которой при необходимости будет осуществляться доплата.
        :param rloc: уникальный идентификатор заказа
        :param version: актуальная версия заказа
        :param last_name: фамилия пассажира
        :param passenger_data: новые данные пассажира
        :param payment_info: инфо об оплате
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)

        try:
            response = self.client.get_bl_pricing(
                regnum=rloc,
                pnr_version=version,
                passenger_last_name=last_name,
                passenger_data=passenger_data,
                payment_info=payment_info,
            )
            return response.get('answer', {}).get('bl_pricing', {}).get('cost', {})
        except SirenaPnrWaitingForPaymentConfirmationError:
            raise
        except (
                SirenaMessageTimedOutError,
                SirenaResponseError,
                SirenaMessageTimedOutError,
                SirenaEmptyResponse
        ):
            raise

    @timeout_handler
    def add_ssr_to_order(
            self,
            rloc: str,
            last_name: str,
            ssrs: List[Dict],
    ):
        """
        Запрос используется для добавления в заказ информации о запросах на спецобслуживание (SSR).
        :param rloc: rloc заказа
        :param last_name: фамилия пассажира
        :param ssrs: данные о добавляемых ssr
        """

        rloc: str = self.__sanitize_rloc__(rloc)
        ssr_list = [SsrForAdd(**ssr) for ssr in ssrs]
        try:
            response = self.client.add_ssr(
                regnum=rloc,
                surname=last_name,
                ssrs=ssr_list
            )
            return response.get('answer', {}).get('add_ssr', {})
        except (
            SirenaMessageTimedOutError,
            SirenaResponseError,
            SirenaEmptyResponse,
            SirenaPnrAndSurnameDontMatch,
            SirenaPassengersTitleNotFoundError,
            SirenaDuplicateSsr

        ):
            raise
        except SirenaPnrBusyError:
            raise
        except BaseSirenaError:
            return None

    @timeout_handler
    def prepare_order_for_change_pd(
            self, rloc: str, version: str, last_name: str, passenger_data: Dict, payment_info: Dict
    ):
        """
        Запрос используется для подготовки PNR к изменению данных пассажира и переоформлению его билетов.
        На вход запрос получает такие же параметры, что и запрос оценки стоимости изменения данных пассажира:
        - Номер и актуальную версию PNR;
        - Фамилию любого из пассажиров PNR;
        - Идентификатор пассажира и его новые данные — ФИО, пол, дату рождения, данные документа, удост. личность;
        - Форму оплаты, по которой при необходимости будет осуществляться доплата.
        Новые данные пассажира передаются в таком же формате, как в в запрос бронирования (booking).

        :param rloc: уникальный идентификатор заказа
        :param version: актуальная версия заказа
        :param last_name: фамилия пассажира
        :param passenger_data: новые данные пассажира
        :param payment_info: инфо об оплате
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)

        response = self.client.prepare_order_for_change_pd(
            regnum=rloc,
            pnr_version=version,
            passenger_last_name=last_name,
            passenger_data=passenger_data,
            payment_info=payment_info,
        )
        return response.get('answer', {}).get('bl_query', {})

    @timeout_handler
    def claim(self, ticket_number: str, flight_number: str):
        """
        Выполнение захвата брони нашей Gds

        :param ticket_number: Номер билета
        :param flight_number: номер рейса
        :return:
        """
        response = self.client.claim_pnr(ticket_number, flight_number)
        return {'rloc': response.rloc, 'last_name': response.last_name}

    @timeout_handler
    def release_seats(
            self,
            rloc: str,
            surname: str,
            passengers: List[PassengersForReleaseSeats],
            segments: List[SegmentsForReleaseSeats] = None
    ):
        """
        Метод используется для аннулирования мест.

        :param rloc: уникальный идентификатор заказа
        :param surname: фамилия пассажира
        :param passengers: массив пассажиров в брони, чьи билеты аннулируем
        :param segments: массив сегментов в брони, чьи билеты аннулируем
        :return:
        """
        rloc: str = self.__sanitize_rloc__(rloc)
        response = self.client.release_seats(
            regnum=rloc,
            surname=surname,
            passenger=passengers,
            segments=segments
        )
        return response.get('answer', {}).get('release_seats', {})

    @timeout_handler
    def divide_order(
            self, rloc: str, surname: str, passengers: List[PaymentPassenger]
    ):
        """
        Запрос используется для отделения части пассажиров из PNR при осуществлении операций
        возврата/отмены части выпущенных билетов.

        :param rloc: уникальный идентификатор заказа
        :param surname: фамилия пассажира
        :param passengers: массив пассажиров в брони, чьи билеты аннулируем
        :return:
        """
        response = self.client.divide_order(
            regnum=self.__sanitize_rloc__(rloc),
            surname=surname,
            passengers=passengers,
        )
        return response.get('answer', {}).get('divide_order', {})

    @timeout_handler
    def exchange_pricing(
        self,
        rloc: str,
        passengers: List[ExchangePassenger],
        segments: List[Union[ExchangeSegments, UtairExchangeSegments]],
    ):
        if not passengers:
            raise ValueError('Passengers required')
        if segments and isinstance(segments[0], UtairExchangeSegments):
            segments = [UtairExchangeSegments._remove_empty_values(x.build()) for x in segments]
        response = self.client.do_exchange(
            method=ExchangeMethod.PRICING,
            regnum=self.__sanitize_rloc__(rloc),
            surname=passengers[0].last_name,
            payment_documents=PaymentDocument(payment_form='KI'),
            passengers=passengers,
            segments=segments,
            involuntary=False,
            lang='en',
        )

        return response.get('answer', {}).get('exchange_pricing', {})

    def change_status_coupon(self, doc_type: str, doc_number: str, coupon_number: str, coupon_status: str):
        """
        Изменяет статус купона

        :param doc_type: тип документа
        :param doc_number: номер документа
        :param coupon_number: номер купона
        :param coupon_status: новый статус купона
        """
        response = self.client.change_coupon_status(
            doc_type=doc_type,
            doc_number=doc_number,
            coupon_number=coupon_number,
            coupon_status=coupon_status
        )

        return response.get('answer', {}).get('change_edoc_stat', {})

    @timeout_handler
    def start_exchange(
        self,
        rloc: str,
        passengers: List[ExchangePassenger],
        segments: List[Union[ExchangeSegments, UtairExchangeSegments]],
        payment: PaymentDocument,
    ):
        if not passengers:
            raise ValueError('Passengers required')
        if segments and isinstance(segments[0], UtairExchangeSegments):
            segments = [UtairExchangeSegments._remove_empty_values(x.build()) for x in segments]
        response = self.client.do_exchange(
            method=ExchangeMethod.START,
            regnum=self.__sanitize_rloc__(rloc),
            surname=passengers[0].last_name,
            payment_documents=payment,
            passengers=passengers,
            segments=segments,
            involuntary=False,
            lang='en',
        )

        return response.get('answer', {}).get('exchange_start', {})

    @timeout_handler
    def confirm_exchange(
        self,
        rloc: str,
        last_name: str,
        cost: PaymentCost,
        payment: PaymentDocument,
    ):
        response = self.client.confirm_exchange(
            regnum=self.__sanitize_rloc__(rloc),
            surname=last_name,
            cost=cost,
            payment_documents=payment,
            lang='en',
        )
        return response.get('answer', {}).get('exchange_confirm', {})

    @timeout_handler
    def cancel_exchange(
        self,
        rloc: str,
        last_name: str,
    ):
        response = self.client.cancel_exchange(
            regnum=self.__sanitize_rloc__(rloc),
            surname=last_name,
            lang='en',
        )

        return response.get('answer', {}).get('exchange_cancel', {})

    @timeout_handler
    def get_flown_status(
        self,
        rloc: str,
        last_name: str,
    ):
        response = self.client.get_flown_status(
            regnum=self.__sanitize_rloc__(rloc),
            surname=last_name,
            lang='en',
        )

        return response.get('answer', {}).get('view_flown_status', {})

    @timeout_handler
    def start_services_refund(
        self,
        rloc: str,
        services: List[str],
        involuntary: bool = False,
    ):
        response = self.client.query_refund_services(
            regnum=self.__sanitize_rloc__(rloc),
            version='ignore',
            service_ids=services,
            involuntary=involuntary,
            lang='en',
        )

        return response.get('answer', {}).get('svc_emd_refund_query', {})

    @timeout_handler
    def confirm_services_refund(
        self,
        rloc: str,
        services: List[str],
        cost: PaymentCost,
        involuntary: bool = False,
    ):
        response = self.client.confirm_refund_services(
            regnum=self.__sanitize_rloc__(rloc),
            version='ignore',
            service_ids=services,
            payment_cost=cost,
            involuntary=involuntary,
            lang='en',
        )

        return response.get('answer', {}).get('svc_emd_refund_confirm', {})

    @timeout_handler
    def get_receipts_data(self, rloc: str, last_name: str):
        response = self.client.get_receipts_data(
            regnum=self.__sanitize_rloc__(rloc),
            surname=last_name,
        )
        return response.get('answer', {}).get('get_itin_receipts_data', {})
