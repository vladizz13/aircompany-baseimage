import base64
from typing import List, Optional

from utair.clients.external.sirena.base.models.base_client_request import RequestModelABC
from utair.clients.external.sirena.base.models.base_client_response import ResponseModelABC

from base.adapter import BaseAdapter

from utair.clients.external.sirena.config import SirenaClientConfig
from utair.clients.external.sirena.sync_client import SirenaClient

from libs.db_gateway.redis.connection_string import RedisConnectionString
from rest.settings.settings import SIRENA_APC, DATABASE


class SirenaAdapter(BaseAdapter):
    def __init__(self):
        self.__client: Optional[SirenaClient] = None

    @property
    def client(self):
        if self.__client is None:
            # Для обратной совместимости, конвертим сертификат от старого клиента в base64 под новый клиент
            private_key = SIRENA_APC.get('private_key')
            if private_key and private_key.startswith('-----'):
                private_key = base64.b64encode(bytes(private_key, 'utf-8'))
            config = SirenaClientConfig(
                host=SIRENA_APC['host'],
                port=SIRENA_APC['port'],
                client_id=SIRENA_APC['clientid'],
                private_key=private_key,
                private_key_path=SIRENA_APC.get('private_key_path'),
                redis_url=RedisConnectionString(**DATABASE['redis']).connection_url
            )
            self.__client = SirenaClient(config)
        return self.__client

    def send_request(self, request: RequestModelABC) -> ResponseModelABC:
        with self.client as session:
            return session.query(request)

    def send_batch_request(self, requests_: List[RequestModelABC]) -> List[ResponseModelABC]:
        with self.client as session:
            return session.batch_query(requests_)
