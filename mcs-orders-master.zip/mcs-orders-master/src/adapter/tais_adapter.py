from typing import Union, Optional, List, Dict
import logging

from tais_xml_client.exceptions.api_exceptions import NotFoundError, ConnectionResponseError
from tais_xml_client.exceptions.exceptions import TAISConnectionError, BaseTAISError
from tais_xml_client.gds_adapter import TaisAdapter

from base.adapter import BaseAdapter
from domain.types import GDS
from rest.settings.settings import TAIS_CONFIG


class TaisInternalAdapter(BaseAdapter):
    """
    Адаптер для работы с таисом
    """

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.__client__ = None

    @property
    def client(self):
        if self.__client__ is None:
            self.__client__ = TaisAdapter(TAIS_CONFIG, timeout=25)
        return self.__client__

    def search_orders(
            self,
            rloc: str,
            last_name: str,
            sirena_sync: Optional[bool] = False,
            check_booking: Optional[bool] = False
    ) -> List[Dict]:
        """
        Поиск заказов в таис по рлоку и фамилии
        (может вернутся несколько заказов после обменов/сплитов etc)
        """
        if len(rloc) == 6 and '/' not in rloc:
            rloc = '{}/{}'.format(rloc, GDS.SIRENA.value)
        try:
            response = self.client.get_order_list(
                self.client.start_session(),
                user_last_name=last_name,
                rloc=rloc,
                sync_order=sirena_sync,
                check_booking=check_booking
            )
        except (NotFoundError, ConnectionResponseError, TAISConnectionError):
            return list()
        except BaseTAISError as e:
            self.logger.info(
                f"Unable to request tais method get_order_list: rloc: [{rloc}] {e.message}, {e.error_code}"
            )
            return list()
        return response.get('orders', {}).get('GetOrderListOrder', []) or list()

    def search_order(
            self,
            order_id: str,
            last_name: Optional[str] = None,
            sirena_sync: Optional[bool] = False,
            check_booking: Optional[bool] = False
    ) -> Union[dict, None]:
        """
        Поиск заказа в tais по фамилии и order_id
        """
        try:
            response = self.client.get_order_list(
                self.client.start_session(),
                order_id=order_id,
                user_last_name=last_name,
                sync_order=sirena_sync,
                check_booking=check_booking
            )
        except (NotFoundError, ConnectionResponseError, TAISConnectionError):
            return None
        except BaseTAISError as e:
            self.logger.info(
                f"Unable to request tais method get_order_list: order_id: [{order_id}] {e.message}, {e.error_code}"
            )
            return None
        try:
            tais_order = response.get('orders', {}).get('GetOrderListOrder', [])[0]
        except IndexError:
            return None
        return tais_order

    def get_ticket(self, order_id):
        """
        Возвращает данные о билетах и маршрутах.
        :param order_id: идентификатор брони/заказа
        :return:
        """
        try:
            response = self.client.ticket(self.client.start_session(), order_id=order_id)
        except (NotFoundError, ConnectionResponseError, TAISConnectionError):
            return None

        return response

    def confirm_refund(self, order_id: str, passenger_ids: List[str], involuntary: bool = True):
        """
        Создать заявку на возврат.
        :param order_id: идентификатор брони/заказа
        :param passenger_ids: идентификаторы пассажиров
        :param involuntary: возможен только вынужденный возврат
            (True - доступен только вынужденный, False - доступен добровольный)
        :return: order_refund_id
        """
        self.logger.info(f"Refund request: order_id: [{order_id}] / "
                         f"passengers_ids: [{passenger_ids}], "
                         f"involuntary: [{involuntary}]")
        try:
            response = self.client.confirm_refund(
                self.client.start_session(),
                order_id,
                passenger_ids,
                involuntary
            )
            self.logger.info(f"Refund response: {response}")
        except (NotFoundError, ConnectionResponseError, TAISConnectionError):
            return None
        except BaseTAISError as e:
            self.logger.info(
                f"Unable to request tais method confirm_refund: order_id: [{order_id}] {e.message}, {e.error_code}"
            )
            return None

        return response['new_order_id']
