import json

from flask import Response

from base.exception import ApplicationError
from rest.applications.rpc_app.utils.response_serializer import serialize


class BaseAdapter(object):
    @classmethod
    def _create_flask_response(cls, response) -> Response:
        """
        Создаем ответ, вытягиваем ошибку если есть
        """
        if bool(response):
            return Response(
                response=json.dumps(serialize(response)),
                status=200,
                mimetype='application/json',
            )
        else:
            error = response.errors[0]
            return cls.build_from_application_error(error)

    @classmethod
    def build_from_application_error(cls, e: ApplicationError):
        return Response(
            response=json.dumps(
                {
                    'meta': {
                        'error_code': e.code,
                        'error_message': str(e.message),
                        'error_type': e.error_type,
                        'error_data': e.data,
                    }
                }
            ),
            status=getattr(e, 'status', None) or 500,
            mimetype='application/json',
        )
