import json


class BaseDomain(object):

    def serialize(self) -> dict:
        raise NotImplementedError()

    @classmethod
    def deserialize(cls, adict: dict) -> 'BaseDomain':
        raise NotImplementedError()

    def __eq__(self, other: 'BaseDomain'):
        return self.serialize() == other.serialize()

    def __iter__(self):
        for attr, value in self.__dict__.items():
            yield attr, value

    def __bytes__(self) -> bytes:
        return json.dumps(self.serialize(), ensure_ascii=False).encode('utf-8')

    @classmethod
    def from_bytes(cls, b: bytes) -> 'BaseDomain':
        body: dict = json.loads(b, encoding='utf-8')
        return cls.deserialize(body)
