from flask_jsonrpc.exceptions import Error


class ApplicationError(Error):
    """Базовый класс ошибки приложения"""

    def __init__(
            self,
            code: int = None,
            message: str = None,
            data: object = None,
            status: int = None,
            inner_exception: Exception = None
    ):

        if code:
            self.code = code
        if message:
            self.message = message
        if data:
            self.data = data
        if status:
            self.status = status
        if inner_exception:
            self.inner_exception = inner_exception

    def __str__(self):
        return f"Error: {self.message}, {self.code}, {self.status}, inner exception: {str(self.inner_exception)}"

    def __repr__(self):
        return str(self)

    code = 1
    message = None
    data = None
    status = 500
    inner_exception = None
    error_type = 'internal'
