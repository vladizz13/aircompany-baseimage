
class BaseRepository(object):

    def __init__(
            self,
            gateway,
    ):
        self.gateway = gateway

    def create(self, *args, **kwargs):
        raise NotImplementedError()

    def delete(self, *args, **kwargs):
        raise NotImplementedError()

    def update(self, *args, **kwargs):
        raise NotImplementedError()

    def list(self, *args, **kwargs):
        raise NotImplementedError()

    def get_single(self, *args, **kwargs):
        raise NotImplementedError()
