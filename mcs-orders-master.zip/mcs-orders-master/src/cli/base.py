import argparse
from abc import abstractmethod


class BaseCLIUtil(object):

    cli_util_name = None

    def __init__(self):
        self.parser = argparse.ArgumentParser(self.cli_util_name)
        self.init_args()
        self.args = self.parser.parse_args()

    @abstractmethod
    def init_args(self):
        raise NotImplementedError()

    @abstractmethod
    def do_work(self):
        raise NotImplementedError()
