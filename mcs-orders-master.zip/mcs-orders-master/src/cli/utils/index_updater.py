from cli.base import BaseCLIUtil

from repositories.index_updater.indexes.orders import OrdersMongoIndexUpdater
from repositories.index_updater.indexes.prorate import ProrateMongoIndexUpdater
from repositories.index_updater.indexes.origin_transactions import OriginTransactionsMongoIndexUpdater


class IndexUpdaterCLI(BaseCLIUtil):

    cli_util_name = "Утилита накатки индексов"

    def init_args(self):
        self.parser.add_argument(
            "-r",
            "--roll",
            default=True,
            action='store_true',
            help="Накатить индексы на базу",
        )
        self.parser.add_argument(
            "-p",
            "--print",
            default=False,
            action='store_true',
            help="Представить нативные команды для базы данных в консоли",
        )

    def do_work(self):
        updaters = [
            OrdersMongoIndexUpdater,
            ProrateMongoIndexUpdater,
            OriginTransactionsMongoIndexUpdater
        ]
        for u in updaters:
            if self.args.print:
                u().represent_indexes_as_native_command()
            elif self.args.roll:
                u().roll_indexes()
                u().ensure_indexes()


if __name__ == '__main__':
    """
    Usage:

    python -m cli.utils.index_updater --print
    python -m cli.utils.index_updater --roll
    """
    cli = IndexUpdaterCLI()
    cli.do_work()
