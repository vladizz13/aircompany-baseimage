import logging
from base.exception import ApplicationError
from repositories.query_builders.order import OrdersQueryBuilder, QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from domain import DomainOrder
from libs.db_gateway import get_db_gateway
from tqdm import tqdm


class OrderRemapper(object):

    logger: logging.Logger

    def __init__(
            self,
            departure_start_time: int = None
    ):
        self.internal_adapter = InternalOrderAdapter()
        self.order_repo: GenericMongoRepository = GenericMongoRepository(
            instance=DomainOrder,
            gateway=get_db_gateway()
        )
        self.departure_start_time = departure_start_time
        if self.departure_start_time is None:
            raise Exception("Неверная departure_start_time")

        self.__init_log__()

    def get_order_ids(self) -> str:
        spec: QueryUnit = OrdersQueryBuilder.get_by_departure_start_timestamp_gte(self.departure_start_time)
        order_repo: GenericMongoRepository = GenericMongoRepository(
            instance=DomainOrder,
            gateway=get_db_gateway()
        )
        limit = 100
        count = order_repo.count(spec)
        skip = 0
        orders_remapped = 0
        while orders_remapped <= count:
            transactions = order_repo.list(spec, limit=100, skip=skip)
            if not transactions:
                return None
            for transaction in transactions:
                orders_remapped += 1
                yield str(transaction.data.order_uuid)
            skip += limit
        return None

    def remap(self, log: bool = False):
        adapter: InternalOrderAdapter = InternalOrderAdapter()

        spec: QueryUnit = OrdersQueryBuilder.get_by_departure_start_timestamp_gte(self.departure_start_time)
        total_orders = self.order_repo.count(spec)

        with tqdm(total=total_orders, unit='orders', dynamic_ncols=True) as bar:

            bar.set_description("Remapping: ")

            for order_uuid in self.get_order_ids():
                if order_uuid is None:
                    if log:
                        self.logger.info("Done")
                    return None
                try:
                    response = adapter.re_save_order(
                        force=False,
                        order_uuid=order_uuid,
                        providers=[],
                        return_full_response=True
                    )
                    if response.errors and log:
                        self.logger.error(f"ERROR: {order_uuid} -- {response.errors[0]}")
                    elif response and log:
                        self.logger.info(f"OK: {response.value.get('order_uuid')}")
                except ApplicationError as e:
                    if log:
                        self.logger.error(str(e))
                bar.update(1)

    def __init_log__(self):
        self.logger = logging.getLogger('order_remapper')
        self.logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler('../var/log/order_remap.log')
        ch = logging.StreamHandler()
        fh.setLevel(logging.INFO)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)
