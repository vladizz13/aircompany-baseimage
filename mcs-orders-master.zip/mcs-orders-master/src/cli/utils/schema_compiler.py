from cli.base import BaseCLIUtil
from libs.validators import SchemaCompiler


class JsonSchemaCompilerCLI(BaseCLIUtil):

    cli_util_name = "Утилита компиляции схем в код"

    def init_args(self):
        self.parser.add_argument(
            "-c",
            "--compile",
            default=True,
            action='store_true',
            help="Скомпилировать схему в код",
        )

    def do_work(self):
        SchemaCompiler().compile()


if __name__ == '__main__':
    """
    Usage:

    python -m cli.utils.schema_compiler --compile
    """
    cli = JsonSchemaCompilerCLI()
    cli.do_work()
