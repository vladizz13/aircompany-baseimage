from decimal import Decimal, ROUND_DOWN
from typing import Union

from base.domain import BaseDomain


class DomainCurrencyRates(BaseDomain):
    """
    Доменная модель курса валют
    """
    def __init__(
            self,
            disclaimer: str = None,
            license: str = None,
            timestamp: str = None,
            base: str = None,
            rates: dict = None

    ):
        self.disclaimer = disclaimer
        self.licence = license
        self.timestamp = timestamp
        self.base = base
        self.rates = rates if rates else {}

    def serialize(self) -> dict:
        return {
            'disclaimer': self.disclaimer,
            'license': self.licence,
            'timestamp': self.timestamp,
            'base': self.base,
            'rates': self.rates,
        }

    @classmethod
    def deserialize(cls, adict: dict):
        return cls(
            disclaimer=adict.get('disclaimer', None),
            license=adict.get('license', None),
            timestamp=adict.get('timestamp', None),
            base=adict.get('base', None),
            rates=adict.get('rates', None),
        )

    def calc_amount(self, currency_from: str, currency_to: str, value: Union[int, float, Decimal]) -> Decimal:
        price_from = Decimal(str(self.rates[currency_from]))
        price_to = Decimal(str(self.rates[currency_to]))
        price = price_to / price_from
        return (price * Decimal(str(value))).quantize(Decimal('.00'), rounding=ROUND_DOWN)
