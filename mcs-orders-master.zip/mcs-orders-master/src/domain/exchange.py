import uuid
from datetime import date
from typing import List, Optional

from mcs_payments_client import RequestSaleItem
from utair_money import Money

from base.domain import BaseDomain
from domain.receipts_data import DomainReceiptsData
from domain.types import ExchangeStatus, ExchangeOrderState, ExchangeFlow, RefundServiceStatus


class DomainExchangeLanding(BaseDomain):
    """Доменная модель трамвайного перелета сегмента"""
    def __init__(
        self,
        id: str,
        city: str,
        time: str,
        airport: str,
    ):
        self.id = id
        self.city = city
        self.time = time
        self.airport = airport

    def serialize(self) -> dict:
        data = {
            'id': self.id,
            'city': self.city,
            'time': self.time,
            'airport': self.airport,
        }

        return data

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeLanding':
        return cls(
            id=adict['id'],
            city=adict['city'],
            time=adict['time'],
            airport=adict['airport'],
        )


class DomainExchangeSegment(BaseDomain):
    """Доменная модель нового сегмента для обмена"""
    def __init__(
        self,
        airline: str,
        flight_number: str,
        flight_date: date,
        departure_airport: str,
        arrival_airport: str,
        duration: Optional[int] = None,
        departure_city: Optional[str] = None,
        arrival_city: Optional[str] = None,
        departure_local: Optional[str] = None,
        arrival_local: Optional[str] = None,
        subclass: Optional[str] = None,
        landings: Optional[List[DomainExchangeLanding]] = []
    ):
        self.airline = airline
        self.flight_number = flight_number
        self.flight_date = flight_date
        self.duration = duration
        self.departure_airport = departure_airport
        self.arrival_airport = arrival_airport
        self.departure_city = departure_city
        self.arrival_city = arrival_city
        self.subclass = subclass
        self.arrival_local = arrival_local
        self.departure_local = departure_local
        self.landings = landings

    @property
    def key(self) -> str:
        return str(hash(
            self.airline
            + self.flight_number
            + self.flight_date.isoformat()
            + self.departure_airport
            + self.arrival_airport
        ))

    def serialize(self) -> dict:
        data = {
            'airline': self.airline,
            'flight_number': self.flight_number,
            'flight_date': self.flight_date.isoformat(),
            'departure_airport': self.departure_airport,
            'arrival_airport': self.arrival_airport,
            'departure_city': self.departure_city,
            'arrival_city': self.arrival_city,
            'duration': self.duration,
            'landings': [s.serialize() for s in self.landings],
        }

        if self.subclass:
            data['subclass'] = self.subclass
        if self.arrival_local:
            data['arrival_local'] = self.arrival_local
        if self.departure_local:
            data['departure_local'] = self.departure_local

        return data

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeSegment':
        return cls(
            airline=adict['airline'],
            flight_number=adict['flight_number'],
            flight_date=date.fromisoformat(adict['flight_date']),
            departure_airport=adict['departure_airport'],
            arrival_airport=adict['arrival_airport'],
            departure_city=adict.get('departure_city'),
            arrival_city=adict.get('arrival_city'),
            duration=adict.get('duration'),
            subclass=adict.get('subclass'),
            arrival_local=adict.get('arrival_local'),
            departure_local=adict.get('departure_local'),
            landings=[DomainExchangeLanding.deserialize(s) for s in adict.get('landings') or []],
        )


class DomainExchangeFlight(BaseDomain):
    """Доменная модель обмена сегментов"""

    def __init__(
        self, flight_id: int, segments: List[str], exchange: List[DomainExchangeSegment]
    ):
        self.flight_id = flight_id
        self.segments = segments
        self.exchange = exchange

    @property
    def key(self) -> str:
        return str(hash(
            str(self.flight_id)
            + ''.join(self.segments)
            + ''.join([e.key for e in self.exchange])
        ))

    def serialize(self) -> dict:
        return {
            'flight_id': self.flight_id,
            'segments': self.segments,
            'exchange': [s.serialize() for s in self.exchange],
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeFlight':
        return cls(
            flight_id=adict['flight_id'],
            segments=adict['segments'],
            exchange=[DomainExchangeSegment.deserialize(s) for s in adict['exchange']],
        )


class DomainExchangeBuyer(BaseDomain):
    """Доменная модель данных платежа для обмена"""

    def __init__(self, mail: Optional[str] = None, phone: Optional[str] = None):
        self.mail = mail
        self.phone = phone

    def serialize(self) -> dict:
        data = {}

        if self.mail:
            data.update(mail=self.mail)

        if self.phone:
            data.update(phone=self.phone)

        return data

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeBuyer':
        return cls(
            mail=adict.get('mail'),
            phone=adict.get('phone'),
        )


class DomainExchangePrice(BaseDomain):
    """Доменная модель стоимости платежа для обмена"""

    def __init__(self, amount: float, currency: str):
        self.amount = amount
        self.currency = currency

    def serialize(self) -> dict:
        return {
            'amount': self.amount,
            'currency': self.currency,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangePrice':
        return cls(
            amount=adict['amount'],
            currency=adict['currency'],
        )

    def __eq__(self, other: 'DomainExchangePrice') -> bool:
        return self.amount == other.amount and self.currency == other.currency

    def __gt__(self, other: 'DomainExchangePrice') -> bool:
        return self.amount > other.amount and self.currency == other.currency


class DomainExchangePaymentMeta(BaseDomain):
    def __init__(
        self,
        provider_code: str,
        first_six: str,
        last_four: str,
        auth_code: str,
        acquiring_bank: str,
    ):
        self.provider_code = provider_code
        self.first_six = first_six
        self.last_four = last_four
        self.auth_code = auth_code
        self.acquiring_bank = acquiring_bank

    def serialize(self) -> dict:
        return {
            'provider_code': self.provider_code,
            'first_six': self.first_six,
            'last_four': self.last_four,
            'auth_code': self.auth_code,
            'acquiring_bank': self.acquiring_bank,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangePaymentMeta':
        return cls(
            provider_code=adict['provider_code'],
            first_six=adict['first_six'],
            last_four=adict['last_four'],
            auth_code=adict['auth_code'],
            acquiring_bank=adict['acquiring_bank'],
        )


class DomainExchangePayment(BaseDomain):
    """Доменная модель данных платежа для обмена"""

    def __init__(
        self,
        state: str,
        invoice: str,
        transaction: str,
        payment_url: str,
        success_url: str,
        fail_url: str,
        hold_request_id: Optional[str],
        confirm_request_id: Optional[str],
        meta: Optional[DomainExchangePaymentMeta] = None,
        sale_parts: Optional[List[RequestSaleItem]] = None,
        exchange_income_parts: Optional[List[RequestSaleItem]] = None,
        exchange_refund_parts: Optional[List[RequestSaleItem]] = None,
    ):
        self.state = state
        self.invoice = invoice
        self.transaction = transaction
        self.payment_url = payment_url
        self.success_url = success_url
        self.fail_url = fail_url
        self.hold_request_id = hold_request_id
        self.confirm_request_id = confirm_request_id
        self.meta = meta
        self.sale_parts = sale_parts
        self.exchange_income_parts = exchange_income_parts
        self.exchange_refund_parts = exchange_refund_parts

    def serialize(self) -> dict:
        data = {
            'state': self.state,
            'invoice': self.invoice,
            'transaction': self.transaction,
            'payment_url': self.payment_url,
            'success_url': self.success_url,
            'fail_url': self.fail_url,
            'hold_request_id': self.hold_request_id,
            'confirm_request_id': self.confirm_request_id,
            'sale_parts': [x.serialize() for x in self.sale_parts] if self.sale_parts else None,
            'exchange_income_parts': [
                x.serialize() for x in self.exchange_income_parts
            ] if self.exchange_income_parts else None,
            'exchange_refund_parts': [
                x.serialize() for x in self.exchange_refund_parts
            ] if self.exchange_refund_parts else None,
        }
        if self.meta:
            data['meta'] = self.meta.serialize()

        return data

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangePayment':
        return cls(
            state=adict['state'],
            invoice=adict['invoice'],
            transaction=adict['transaction'],
            payment_url=adict['payment_url'],
            success_url=adict['success_url'],
            fail_url=adict['fail_url'],
            hold_request_id=adict.get('hold_request_id'),
            confirm_request_id=adict.get('confirm_request_id'),
            sale_parts=cls._deserialize_sale_part(adict.get('sale_parts')),
            exchange_income_parts=cls._deserialize_sale_part(adict.get('exchange_income_parts')),
            exchange_refund_parts=cls._deserialize_sale_part(adict.get('exchange_refund_parts')),
            meta=DomainExchangePaymentMeta.deserialize(adict['meta']) if adict.get('meta') else None,
        )

    @classmethod
    def _deserialize_sale_part(cls, items: Optional[List[dict]]):
        if not items:
            return None
        return [RequestSaleItem.deserialize(x) for x in items]

    @property
    def number(self) -> str:
        if not self.meta:
            return ''

        return f'{self.meta.provider_code}{self.meta.first_six}{self.meta.auth_code}{self.invoice}' \
               f'{self.meta.acquiring_bank}{self.meta.last_four}'


class DomainExchangeOrder(BaseDomain):
    """Доменная модель данных платежа для обмена"""

    def __init__(self, locator: str, surname: str, state: ExchangeOrderState):
        self.locator = locator
        self.surname = surname
        self.state = state

    def serialize(self) -> dict:
        return {
            'locator': self.locator,
            'surname': self.surname,
            'state': str(self.state),
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeOrder':
        return cls(
            locator=adict['locator'],
            surname=adict['surname'],
            state=ExchangeOrderState(adict['state']),
        )


class DomainExchangeRefundedService(BaseDomain):
    """Доменная модель возвращенной после обмена услуги"""

    def __init__(
            self, guid: str, rfisc: str, count: int, description: str, passenger_id: str, segment_id: str, type_: str
    ):
        self.guid = guid
        self.rfisc = rfisc
        self.count = count
        self.description = description
        self.passenger_id = passenger_id
        self.segment_id = segment_id
        self.type = type_

    def serialize(self) -> dict:
        return {
            'guid': self.guid,
            'rfisc': self.rfisc,
            'count': self.count,
            'description': self.description,
            'passenger_id': self.passenger_id,
            'segment_id': self.segment_id,
            'type': self.type,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeRefundedService':
        return cls(
            guid=adict['guid'],
            rfisc=adict['rfisc'],
            count=adict['count'],
            description=adict['description'],
            passenger_id=adict['passenger_id'],
            segment_id=adict['segment_id'],
            type_=adict['type'],
        )


class DomainExchangeRefundedServices(BaseDomain):
    """Доменная модель возвращенных после обмена услуг"""

    def __init__(self, services: List[DomainExchangeRefundedService], price: Optional[DomainExchangePrice] = None):
        self.services = services
        self.price = price

    def serialize(self) -> dict:
        return {
            'services': [s.serialize() for s in self.services],
            'price': self.price.serialize() if self.price else None,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchangeRefundedServices':
        return cls(
            services=[DomainExchangeRefundedService.deserialize(s) for s in adict['services']],
            price=DomainExchangePrice.deserialize(adict['price']) if adict.get('price') else None,
        )


class DomainSSRUnit(BaseDomain):

    def __init__(
            self,
            name: str,
            surname: str,
            company: str,
            flight: str,
            departure: str,
            arrival: str,
            date: str,
    ):
        self.name = name
        self.surname = surname
        self.company = company
        self.flight = flight
        self.departure = departure
        self.arrival = arrival
        self.date = date

    def serialize(self) -> dict:
        return {
            'name': self.name,
            'surname': self.surname,
            'company': self.company,
            'flight': self.flight,
            'departure': self.departure,
            'arrival': self.arrival,
            'date': self.date,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainSSRUnit':
        return cls(
            name=adict['name'],
            surname=adict['surname'],
            company=adict['company'],
            flight=adict['flight'],
            departure=adict['departure'],
            arrival=adict['arrival'],
            date=adict['date'],
        )


class DomainSSRRequest(BaseDomain):

    def __init__(
            self,
            ssr_type: str,
            text: str,
            units: List[DomainSSRUnit],
    ):
        self.ssr_type = ssr_type
        self.text = text
        self.units = units

    def serialize(self) -> dict:
        return {
            'ssr_type': self.ssr_type,
            'text': self.text,
            'units': [unit.serialize() for unit in self.units],
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainSSRRequest':
        return cls(
            ssr_type=adict['ssr_type'],
            text=adict['text'],
            units=[DomainSSRUnit.deserialize(unit) for unit in adict['units']],
        )


class DomainExchange(BaseDomain):
    """
    Доменная модель транзакции обмена
    """
    def __init__(
        self,
        exchange_uuid: str,
        status: ExchangeStatus,
        order_uuid: str,
        buyer: DomainExchangeBuyer,
        passengers: List[str],
        flights: List[DomainExchangeFlight],
        flow: ExchangeFlow,
        price: DomainExchangePrice,
        payment: Optional[DomainExchangePayment] = None,
        order: Optional[DomainExchangeOrder] = None,
        normalized_coupons: Optional[List[dict]] = None,
        refunded_services: Optional[DomainExchangeRefundedServices] = None,
        refunded_services_status: RefundServiceStatus = RefundServiceStatus.WAITING,
        divided_order_uuid: Optional[str] = None,
        error: Optional[str] = None,
        ssr_requests: Optional[List[DomainSSRRequest]] = None,
        old_receipts_data: Optional[DomainReceiptsData] = None,
    ):
        self.exchange_uuid = exchange_uuid
        self.__status = status
        self.order_uuid = order_uuid
        self.buyer = buyer
        self.passengers = passengers
        self.flights = flights
        self.flow = flow
        self.price = price
        self.payment = payment
        self.order = order
        self.normalized_coupons = normalized_coupons
        self.refunded_services = refunded_services
        self.refunded_services_status = refunded_services_status
        self.divided_order_uuid = divided_order_uuid
        self.error = error
        self.ssr_requests = ssr_requests
        self.old_receipts_data = old_receipts_data

    @property
    def key(self) -> str:
        return str(hash(
            self.order_uuid
            + ''.join(self.passengers)
            + ''.join(f.key for f in self.flights)
        ))

    @property
    def status(self) -> ExchangeStatus:
        return self.__status

    @status.setter
    def status(self, value: ExchangeStatus):
        if not self.__status.allowed(value):
            raise ValueError(f'Invalid status change: {self.__status} -> {value}')
        self.__status = value

    def serialize(self) -> dict:
        data = {
            'exchange_uuid': self.exchange_uuid,
            'status': str(self.__status),
            'order_uuid': self.order_uuid,
            'buyer': self.buyer.serialize(),
            'passengers': self.passengers,
            'flights': [f.serialize() for f in self.flights],
            'flow': str(self.flow),
            'price': self.price.serialize(),
            'refunded_services_status': str(self.refunded_services_status),
        }
        if self.ssr_requests:
            data['ssr_requests'] = [x.serialize() for x in self.ssr_requests]

        if self.payment:
            data['payment'] = self.payment.serialize()

        if self.order:
            data['order'] = self.order.serialize()

        if self.normalized_coupons:
            data['normalized_coupons'] = self.normalized_coupons

        if self.refunded_services:
            data['refunded_services'] = self.refunded_services.serialize()

        if self.divided_order_uuid:
            data['divided_order_uuid'] = self.divided_order_uuid

        if self.error:
            data['error'] = self.error

        if self.old_receipts_data:
            data['old_receipts_data'] = self.old_receipts_data.serialize()

        return data

    def set_error(self, error: Exception) -> None:
        if not self.status == ExchangeStatus.ERROR:
            return

        err_text = str(error)
        err_text = f'{error.__class__.__name__}: {err_text}' if err_text else err_text
        self.error = err_text

    @classmethod
    def create(
        cls,
        order_uuid: str,
        buyer: DomainExchangeBuyer,
        passengers: List[str],
        flights: List[DomainExchangeFlight],
        flow: ExchangeFlow,
        price: DomainExchangePrice,
    ) -> 'DomainExchange':
        return cls(
            exchange_uuid=str(uuid.uuid4()),
            status=ExchangeStatus.NEW,
            order_uuid=order_uuid,
            buyer=buyer,
            passengers=passengers,
            flights=flights,
            flow=flow,
            price=price,
        )

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainExchange':
        ssr_requests = adict.get('ssr_requests')

        return cls(
            exchange_uuid=adict['exchange_uuid'],
            status=ExchangeStatus(adict['status']),
            order_uuid=adict['order_uuid'],
            buyer=DomainExchangeBuyer.deserialize(adict['buyer']),
            passengers=adict['passengers'],
            flights=[DomainExchangeFlight.deserialize(f) for f in adict['flights']],
            flow=ExchangeFlow(adict['flow']),
            price=DomainExchangePrice.deserialize(adict['price']),
            payment=DomainExchangePayment.deserialize(adict['payment']) if 'payment' in adict else None,
            order=DomainExchangeOrder.deserialize(adict['order']) if 'order' in adict else None,
            normalized_coupons=adict.get('normalized_coupons'),
            refunded_services=DomainExchangeRefundedServices.deserialize(adict.get('refunded_services'))
            if 'refunded_services' in adict else None,
            refunded_services_status=adict.get('refunded_services_status', RefundServiceStatus.WAITING),
            divided_order_uuid=adict.get('divided_order_uuid'),
            error=adict.get('error'),
            ssr_requests=[DomainSSRRequest.deserialize(x) for x in ssr_requests] if ssr_requests else None,
            old_receipts_data=DomainReceiptsData.deserialize(
                adict['old_receipts_data']
            ) if adict.get('old_receipts_data') else None,
        )

    def valid_confirm_price(self):
        confirm_price: Money = sum([
            payment.amount
            for part in self.payment.sale_parts
            for payment in part.payments
        ]) or Money(0)
        return Money(self.price.amount) == confirm_price


class DomainFlightOptionError(BaseDomain):

    def __init__(
            self,
            flight_id: str,
            flight_date: date,
            departure: str,
            arrival: str,
    ) -> None:
        super().__init__()
        self.flight_id = flight_id
        self.flight_date = flight_date
        self.departure = departure
        self.arrival = arrival

    @classmethod
    def deserialize(cls, adict: dict) -> 'BaseDomain':
        return cls(
            flight_id=adict['flight_id'],
            flight_date=adict['flight_date'],
            departure=adict['departure'],
            arrival=adict['arrival'],
        )

    def serialize(self) -> dict:
        return dict(
            flight_id=self.flight_id,
            flight_date=str(self.flight_date),
            departure=self.departure,
            arrival=self.arrival,
        )
