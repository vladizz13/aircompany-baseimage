from base.domain import BaseDomain


class BaseDomainOrder(BaseDomain):

    def serialize(self) -> dict:
        raise NotImplementedError()

    @classmethod
    def deserialize(cls, adict: dict) -> 'BaseDomainOrder':
        raise NotImplementedError()
