from typing import Optional, Union
from ..base import BaseDomainOrder


class DomainUTM(BaseDomainOrder):

    def __init__(
            self,
            source: Optional[str] = None,
            campaign: Optional[Union[str, list]] = None,
            medium: Optional[str] = None,
            term: Optional[Union[str, list]] = None,
            content: Optional[Union[str, list]] = None
    ):
        self.source = source
        self.campaign = campaign
        self.medium = medium
        self.term = term
        self.content = content

    def serialize(self) -> dict:
        return {
            'source': self.source,
            'campaign': self.campaign,
            'medium': self.medium,
            'term': self.term,
            'content': self.content,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainUTM':
        return cls(
            source=adict.get('source'),
            campaign=adict.get('campaign'),
            medium=adict.get('medium'),
            term=adict.get('term'),
            content=adict.get('content'),
        )


class DomainAnalyticsData(BaseDomainOrder):

    def __init__(
            self,
            payment_id: Optional[str] = None,
            partner_id: Optional[str] = None,
            partner_data: Optional[str] = None,
            partner_data_ex: Optional[str] = None,
            pay_method_id: Optional[str] = None,
            pay_method_code: Optional[str] = None,
            first_segment_booking_time: Optional[int] = None,
            device_token: Optional[str] = None,
            platform: Optional[str] = None,
            utm: Optional[DomainUTM] = None,
            created: Optional[int] = None
    ):
        self.payment_id = payment_id
        self.partner_id = partner_id
        self.partner_data = partner_data
        self.partner_data_ex = partner_data_ex
        self.pay_method_id = pay_method_id
        self.pay_method_code = pay_method_code
        self.first_segment_booking_time = first_segment_booking_time
        self.device_token = device_token
        self.platform = platform
        self.utm = utm if utm else DomainUTM()
        self.created = created

    def serialize(self) -> dict:
        return {
            'payment_id': self.payment_id,
            'partner_id': self.partner_id,
            'partner_data': self.partner_data,
            'partner_data_ex': self.partner_data_ex,
            'pay_method_id': self.pay_method_id,
            'pay_method_code': self.pay_method_code,
            'first_segment_booking_time': self.first_segment_booking_time,
            'device_token': self.device_token,
            'platform': self.platform,
            'utm': self.utm.serialize(),
            'created': self.created
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainAnalyticsData':
        return cls(
            payment_id=adict.get('payment_id', None),
            partner_id=adict.get('partner_id', None),
            partner_data=adict.get('partner_data', None),
            partner_data_ex=adict.get('partner_data_ex', None),
            pay_method_id=adict.get('pay_method_id', None),
            pay_method_code=adict.get('pay_method_code', None),
            first_segment_booking_time=adict.get('first_segment_booking_time', None),
            device_token=adict.get('device_token', None),
            platform=adict.get('platform', None),
            utm=DomainUTM.deserialize(adict.get('utm', dict())),
            created=adict.get('created', None)
        )
