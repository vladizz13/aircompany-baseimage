from ..base import BaseDomainOrder


class DomainAvailableActions(BaseDomainOrder):

    def __init__(
            self,
            can_change: bool = False,
            can_purchase_services: bool = False,
            can_return: bool = False,
            can_return_deposit: bool = False,
            can_print_mk: bool = False,
            can_pay_order: bool = False,
            can_check_in: bool = False,
            can_release: bool = False,
            can_change_personal_data: bool = False,
    ):
        self.can_change: bool = can_change
        self.can_purchase_services: bool = can_purchase_services
        self.can_return: bool = can_return
        self.can_return_deposit: bool = can_return_deposit
        self.can_print_mk: bool = can_print_mk
        self.can_pay_order: bool = can_pay_order
        self.can_check_in: bool = can_check_in
        self.can_release: bool = can_release
        self.can_change_personal_data: bool = can_change_personal_data

    def serialize(self) -> dict:
        return {
            'can_change': self.can_change,
            'can_purchase_services': self.can_purchase_services,
            'can_return': self.can_return,
            'can_return_deposit': self.can_return_deposit,
            'can_print_mk': self.can_print_mk,
            'can_pay_order': self.can_pay_order,
            'can_check_in': self.can_check_in,
            'can_release': self.can_release,
            'can_change_personal_data': self.can_change_personal_data
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainAvailableActions':
        return cls(
            can_change=adict.get('can_change', False),
            can_purchase_services=adict.get('can_purchase_services', False),
            can_return=adict.get('can_return', False),
            # Для старых заказов после реализации https://jira.utair.ru/browse/UTBCKN-3024
            # дефолтные значения всех новых дополнительный действий с броней - False
            can_return_deposit=adict.get('can_return_deposit', False),
            can_print_mk=adict.get('can_print_mk', False),
            can_pay_order=adict.get('can_pay_order', False),
            can_check_in=adict.get('can_check_in', False),
            can_release=adict.get('can_release', False),
            can_change_personal_data=adict.get('can_change_personal_data', False),
        )
