from typing import Optional
from domain.types import MatchTypes
from ..base import BaseDomainOrder


class DomainContact(BaseDomainOrder):

    def __init__(
            self,
            contact: str = None,
            type: str = None,
            sirena_type: str = None,
            match_type: str = MatchTypes.MANUAL.value,
            confirmed: Optional[bool] = False,
            hide: Optional[bool] = False,
            created: float = None
    ):
        self.contact = contact
        self.type = type
        self.sirena_type = sirena_type
        self.match_type = match_type
        self.confirmed = confirmed
        self.hide = hide
        self.created = created

    def serialize(self) -> dict:
        return {
            'contact': self.contact,
            'type': self.type,
            'sirena_type': self.sirena_type,
            'match_type': self.match_type,
            'confirmed': self.confirmed,
            'hide': self.hide,
            'created': self.created
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainContact':
        return cls(
            contact=adict.get('contact', None),
            type=adict.get('type', None),
            sirena_type=adict.get('sirena_type', None),
            match_type=adict.get('match_type', None),
            confirmed=adict.get('confirmed', False) or False,
            hide=adict.get('hide', False),
            created=adict.get('created', None)
        )

    def __eq__(self, other: 'DomainContact') -> bool:
        return all([
            self.contact == other.contact,
            self.type == other.type,
        ])

    def __repr__(self):
        return f'DomainContact(type={self.type}, contact={self.contact}, sirena_type={self.sirena_type})'
