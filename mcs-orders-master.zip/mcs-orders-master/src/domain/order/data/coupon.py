from ..base import BaseDomainOrder
from base.exception import ApplicationError
from typing import List, Union
import time


class DomainCouponMoney(BaseDomainOrder):

    def __init__(
            self,
            fare=None,
            tax=None,
            discount=None,
    ):

        self.fare = fare
        self.tax = tax
        self.discount = discount

    def serialize(self) -> dict:
        return {
            'fare': self.fare,
            'tax': self.tax,
            'discount': self.discount
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainCouponMoney':
        return cls(
            fare=adict.get('fare', None),
            tax=adict.get('tax', None),
            discount=adict.get('discount', None),
        )


class DomainCouponUpdated(BaseDomainOrder):

    def __init__(
            self,
            status: str = None,
            date: Union[int, float] = None
    ):
        self.status = status
        self.date = date if date else int(time.time())

    def serialize(self) -> dict:
        return {
            'status': self.status,
            'date': self.date
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainCouponUpdated':
        return cls(
            status=adict.get('status', None),
            date=adict.get('date', None)
        )

    def __eq__(self, other: "DomainCouponUpdated"):
        return self.status == other.status


class DomainCouponFlights(BaseDomainOrder):

    def __init__(
        self,
        marketing: str = None,
        operating: str = None,
        departure_local_iso: int = None,
        departure_airport_code: str = None,
        arrival_airport_code: str = None,
        rbd: str = None,
        booking_timestamp: int = None,
        created: int = None,
    ):
        self.marketing = marketing
        self.operating = operating
        self.departure_local_iso = departure_local_iso
        self.departure_airport_code = departure_airport_code
        self.arrival_airport_code = arrival_airport_code
        self.rbd = rbd
        self.booking_timestamp = booking_timestamp
        self.created = created if created else int(time.time())

    def serialize(self) -> dict:
        return {
            'marketing': self.marketing,
            'operating': self.operating,
            'departure_local_iso': self.departure_local_iso,
            'departure_airport_code': self.departure_airport_code,
            'arrival_airport_code': self.arrival_airport_code,
            'rbd': self.rbd,
            'booking_timestamp': self.booking_timestamp,
            'created': self.created
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainCouponFlights':
        return cls(
            marketing=adict.get('marketing', None),
            operating=adict.get('operating', None),
            departure_local_iso=adict.get('departure_local_iso', None),
            departure_airport_code=adict.get('departure_airport_code', None),
            arrival_airport_code=adict.get('arrival_airport_code', None),
            rbd=adict.get('rbd', None),
            booking_timestamp=adict.get('booking_timestamp', None),
            created=adict.get('created', None),
        )

    def __eq__(self, other: "DomainCouponFlights"):
        if not isinstance(other, self.__class__):
            raise ApplicationError(message='Unable to compare: Incorrect class instance')

        return all([
            self.marketing == other.marketing,
            self.operating == other.operating,
            self.departure_local_iso == other.departure_local_iso,
            self.departure_airport_code == other.departure_airport_code,
            self.arrival_airport_code == other.arrival_airport_code,
            self.rbd == other.rbd,
        ])


class DomainCoupon(BaseDomainOrder):

    def __init__(
            self,
            number: int = None,
            ticket: str = None,
            passenger_id: str = None,
            segment_id: str = None,
            status: str = None,
            sac: str = None,
            fare_code: str = None,
            flights: List[DomainCouponFlights] = None,
            updated: List[DomainCouponUpdated] = None,
            coupon_money: DomainCouponMoney = None,
            op_comment: str = None,
    ):

        self.number = number
        self.ticket = ticket
        self.passenger_id = passenger_id
        self.segment_id = segment_id
        self.status = status
        self.sac = sac
        self.fare_code = fare_code
        self.op_comment = op_comment
        self.updated = updated if updated else []
        self.flights: List[DomainCouponFlights] = flights if flights else []
        self.coupon_money: DomainCouponMoney = coupon_money if coupon_money else DomainCouponMoney()

    def __repr__(self):
        return f"DomainCoupon(status={self.status}, segment_id={self.segment_id})"

    def serialize(self):
        return {
            'number': self.number,
            'ticket': self.ticket,
            'passenger_id': self.passenger_id,
            'segment_id': self.segment_id,
            'status': self.status,
            'sac': self.sac,
            'fare_code': self.fare_code,
            'updated': [u.serialize() for u in self.updated],
            'flights': [f.serialize() for f in self.flights],
            'coupon_money': self.coupon_money.serialize(),
            'op_comment': self.op_comment
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainCoupon':
        return cls(
            number=adict.get('number', None),
            ticket=adict.get('ticket', None),
            passenger_id=adict.get('passenger_id', None),
            segment_id=adict.get('segment_id', None),
            status=adict.get('status', None),
            sac=adict.get('sac', None),
            fare_code=adict.get('fare_code', None),
            updated=[DomainCouponUpdated.deserialize(u) for u in adict.get('updated', [])],
            flights=[DomainCouponFlights.deserialize(f) for f in adict.get('flights', [])],
            coupon_money=DomainCouponMoney.deserialize(adict.get('coupon_money', {})),
            op_comment=adict.get('op_comment', None),
        )

    def get_hash(self) -> str:
        return str(
            hash(
                str(self.passenger_id) +
                str(self.ticket) +
                str(self.number) +
                str(self.ticket)
            )
        )

    def __eq__(self, other: "DomainCoupon") -> bool:
        return all([
            self.ticket == other.ticket,
            self.segment_id == other.segment_id,
            self.passenger_id == other.passenger_id
        ])
