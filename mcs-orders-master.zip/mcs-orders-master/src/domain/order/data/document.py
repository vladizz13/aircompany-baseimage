from ..base import BaseDomainOrder


class DomainDocument(BaseDomainOrder):

    def __init__(
            self,
            passenger_id: str = None,
            birthday: str = None,
            doccountry: str = None,
            docexpiration: str = None,
            docnumber: str = None,
            doctype: str = None,
    ):

        self.passenger_id = passenger_id
        self.birthday = birthday
        self.doccountry = doccountry
        self.docexpiration = docexpiration
        self.docnumber = docnumber
        self.doctype = doctype

    def __repr__(self):
        return f'DomainDocument(passenger_id={self.passenger_id }, doctype={self.doctype}, docnumber={self.docnumber})'

    def serialize(self) -> dict:
        return {
            'passenger_id': self.passenger_id,
            'birthday': self.birthday,
            'doccountry': self.doccountry,
            'docexpiration': self.docexpiration,
            'docnumber': self.docnumber,
            'doctype': self.doctype
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainDocument':
        return cls(
            passenger_id=adict.get('passenger_id', None),
            birthday=adict.get('birthday', None),
            doccountry=adict.get('doccountry', None),
            docexpiration=adict.get('docexpiration', None),
            docnumber=adict.get('docnumber', None),
            doctype=adict.get('doctype', None),
        )
