from base.exception import ApplicationError
from ..base import BaseDomainOrder


class DomainFop(BaseDomainOrder):

    def __init__(
            self,
            fops_id: int = None,
            ticket: str = None,
            coupon_id: str = None,
            emd: str = None,
            indicator: int = None,
            code: str = None,
            amount: int = None,
            vendor: str = None,
            account_num: str = None,
            app_code: str = None,
            exp_date: str = None,
            auth_center: str = None,
            free_text: str = None,
    ):

        self.fops_id = fops_id
        self.ticket = ticket
        self.coupon_id = coupon_id
        self.emd = emd
        self.indicator = indicator
        self.code = code
        self.amount = amount
        self.vendor = vendor
        self.account_num = account_num
        self.app_code = app_code
        self.exp_date = exp_date
        self.auth_center = auth_center
        self.free_text = free_text

    def serialize(self) -> dict:
        return {
            'fops_id': self.fops_id,
            'ticket': self.ticket,
            'coupon_id': self.coupon_id,
            'emd': self.emd,
            'indicator': self.indicator,
            'code': self.code,
            'amount': self.amount,
            'vendor': self.vendor,
            'account_num': self.account_num,
            'app_code': self.app_code,
            'auth_center': self.auth_center,
            'exp_date': self.exp_date,
            'free_text': self.free_text,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainFop':
        return cls(
            fops_id=adict.get('fops_id', None),
            ticket=adict.get('ticket', None),
            coupon_id=adict.get('coupon_id', None),
            emd=adict.get('emd', None),
            indicator=adict.get('indicator', None),
            code=adict.get('code', None),
            amount=adict.get('amount', None),
            vendor=adict.get('vendor', None),
            account_num=adict.get('account_num', None),
            app_code=adict.get('app_code', None),
            auth_center=adict.get('auth_center', None),
            exp_date=adict.get('exp_date', None),
            free_text=adict.get('free_text', None),
        )

    def get_hash(self) -> str:
        """
        Уникальный идентификатор fops для сравнения
        """
        return str(
            hash(
                str(self.ticket or self.emd) +
                str(self.coupon_id) +
                str(self.code) +
                str(self.account_num)
            )
        )

    def __eq__(self, other: "DomainFop"):
        if not isinstance(other, self.__class__):
            raise ApplicationError(message='Unable to compare: Incorrect class instance')
        return self.get_hash() == other.get_hash()
