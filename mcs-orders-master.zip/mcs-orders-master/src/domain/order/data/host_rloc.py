from base.exception import ApplicationError
from ..base import BaseDomainOrder


class DomainHostRloc(BaseDomainOrder):

    def __init__(
            self,
            created: int = None,
            value: str = None
    ):

        self.created = created
        self.value = value

    def serialize(self):
        return {
            'created': self.created,
            'value': self.value
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainHostRloc':
        return cls(
            created=adict.get('created', None),
            value=adict.get('value', None),
        )

    def __eq__(self, other: 'DomainHostRloc'):
        """
        При сравнение учитываем только значение value
        """
        if not isinstance(other, self.__class__):
            raise ApplicationError(message='Unable to compare: Incorrect class instance')

        return self.value == other.value
