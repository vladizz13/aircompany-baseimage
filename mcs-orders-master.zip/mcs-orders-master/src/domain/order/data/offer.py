from ..base import BaseDomainOrder


class DomainOffer(BaseDomainOrder):

    def __init__(
            self,
            segment_id: str = None,
            brand_code: str = None,
            brand_name: str = None,
            fare_code: str = None,
    ):

        self.segment_id = segment_id
        self.brand_code = brand_code
        self.brand_name = brand_name
        self.fare_code = fare_code

    def __repr__(self):
        return f'DomainOffer(brand_name="{self.brand_name}", ' \
               f'segment_id="{self.segment_id}", fare_code="{self.fare_code}")'

    def serialize(self) -> dict:
        return {
            'segment_id': self.segment_id,
            'brand_code': self.brand_code,
            'brand_name': self.brand_name,
            'fare_code': self.fare_code,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainOffer':
        return cls(
            segment_id=adict.get('segment_id', None),
            brand_code=adict.get('brand_code', None),
            brand_name=adict.get('brand_name', None),
            fare_code=adict.get('fare_code', None),
        )
