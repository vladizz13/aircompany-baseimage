from base.exception import ApplicationError
from ..base import BaseDomainOrder


class DomainPassenger(BaseDomainOrder):

    def __init__(
            self,
            passenger_id: str = None,
            parent_id: str = None,
            tais_passenger_id: str = None,
            first_name: str = None,
            last_name: str = None,
            second_name: str = None,
            loyalty_cardnumber: str = None,
            type: str = None,
            gender: str = None,
            category: str = None,
            title: str = None,
    ):
        self.passenger_id = passenger_id
        self.parent_id = parent_id
        self.tais_passenger_id = tais_passenger_id
        self.first_name = first_name
        self.last_name = last_name
        self.second_name = second_name
        self.loyalty_cardnumber = loyalty_cardnumber
        self.type = type
        self.gender = gender
        self.category = category
        self.title = title

    def __repr__(self):
        return f'DomainPassenger(id={self.passenger_id}, ' \
               f'tais={self.tais_passenger_id}, ' \
               f'type={self.type}) ' \
               f'first_name={self.first_name} ' \
               f'last_name={self.last_name}'

    def __eq__(self, other: 'DomainPassenger'):
        """
        При сравнении не учитываем номер карты и айдишники
        """
        if not isinstance(other, self.__class__):
            raise ApplicationError(message='Unable to compare: Incorrect class instance')

        return all([
            self.type == other.type,
            self.first_name == other.first_name,
            self.last_name == other.last_name,
            self.second_name == other.second_name,
            self.gender == other.gender,
            ])

    def serialize(self) -> dict:
        return {
            'passenger_id': self.passenger_id,
            'parent_id': self.parent_id,
            'tais_passenger_id': self.tais_passenger_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'second_name': self.second_name,
            'loyalty_cardnumber': self.loyalty_cardnumber,
            'type': self.type,
            'gender': self.gender,
            'category':  self.category,
            'title':  self.title,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainPassenger':
        return cls(
            passenger_id=adict.get('passenger_id', None),
            parent_id=adict.get('parent_id', None),
            tais_passenger_id=adict.get('tais_passenger_id', None),
            first_name=adict.get('first_name', None),
            last_name=adict.get('last_name', None),
            second_name=adict.get('second_name', None),
            loyalty_cardnumber=adict.get('loyalty_cardnumber', None),
            type=adict.get('type', None),
            gender=adict.get('gender', None),
            category=adict.get('category', None),
            title=adict.get('title', None),
        )

    def is_infant(self):
        return self.type == 'INFANT'

    def get_fio(self):
        return ' '.join(
            [
                name
                for name in [self.last_name, self.first_name, self.second_name]
                if name
            ]
        )
