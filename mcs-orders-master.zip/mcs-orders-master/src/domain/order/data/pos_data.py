from ..base import BaseDomainOrder
from typing import List


class DomainAdditionalData(BaseDomainOrder):

    def __init__(
            self,
            profile_card_number: str = None,
            pay_token: str = None,
    ):
        self.profile_card_number = profile_card_number
        self.pay_token = pay_token

    def serialize(self) -> dict:
        return {
            'profile_card_number': self.profile_card_number,
            'pay_token': self.pay_token,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainAdditionalData':
        if adict is None:
            # Изменение структуры заказа (https://jira.utair.ru/browse/UTBCKN-1553)
            # ранние заказы имеют не вложенную структуру
            return cls()
        return cls(
            profile_card_number=adict.get('profile_card_number', None),
            pay_token=adict.get('pay_token', None),
        )


class DomainGDS(BaseDomainOrder):

    def __init__(
            self,
            created: int = None,
            value: str = None
    ):
        self.created = created
        self.value = value

    def serialize(self):
        return {
            'created': self.created,
            'value': self.value
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainGDS':
        return cls(
            created=adict.get('created', None),
            value=adict.get('value', None),
        )


class DomainTermID(BaseDomainOrder):
    def __init__(
            self,
            created: int = None,
            value: str = None
    ):
        self.created = created
        self.value = value

    def serialize(self):
        return {
            'created': self.created,
            'value': self.value
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainTermID':
        return cls(
            created=adict.get('created', None),
            value=adict.get('value', None),
        )


class DomainPosData(BaseDomainOrder):

    def __init__(
            self,
            timelimit: str = None,
            pos_id: str = None,
            agency: str = None,
            create_time: int = None,
            term_id: List[DomainTermID] = None,
            additional_data: DomainAdditionalData = None,
            gds: DomainGDS = None,
    ):
        self.timelimit = timelimit
        self.pos_id = pos_id
        self.agency = agency
        self.create_time = create_time
        self.term_id = term_id if term_id else []
        self.additional_data = additional_data if additional_data else DomainAdditionalData()
        self.gds = gds if gds else DomainGDS()

    def serialize(self) -> dict:
        return {
            'timelimit': self.timelimit,
            'pos_id': self.pos_id,
            'agency': self.agency,
            'create_time': self.create_time,
            'term_id': [ti.serialize() for ti in self.term_id],
            'additional_data': self.additional_data.serialize(),
            'gds': self.gds.serialize()
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainPosData':
        return cls(
            timelimit=adict.get('timelimit', None),
            pos_id=adict.get('pos_id', None),
            agency=adict.get('agency', None),
            create_time=adict.get('create_time', None),
            term_id=[DomainTermID.deserialize(i) for i in adict.get('term_id', [])],
            additional_data=DomainAdditionalData.deserialize(adict.get('additional_data', {})),
            gds=DomainGDS.deserialize(adict.get('gds', {})),
        )
