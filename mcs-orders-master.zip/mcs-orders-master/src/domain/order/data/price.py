from typing import List
from ...types import DiscountCodeTypes
from ..base import BaseDomainOrder


class DomainDiscount(BaseDomainOrder):

    def __init__(
            self,
            amount: int = None,
            type_: str = None,
            code: str = None,
            card_number: str = None
    ):

        self.amount = amount
        self.type = DiscountCodeTypes.map_code(type_)
        self.code = code
        self.card_number = card_number
        if isinstance(self.code, str):
            self.code = self.code.upper()

    def serialize(self) -> dict:
        return {
            'amount': self.amount,
            'type': self.type,
            'code': self.code,
            'card_number': self.card_number
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainDiscount':
        return cls(
            amount=adict.get('amount', None),
            type_=adict.get('type', None),
            code=adict.get('code', None),
            card_number=adict.get('card_number', None)
        )


class DomainVoucher(BaseDomainOrder):

    def __init__(
            self,
            id_: str = None,
            amount: int = None
    ):
        self.id = id_
        self.amount = amount

    def serialize(self) -> dict:
        return {
            'id': self.id,
            'amount': self.amount
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainVoucher':
        return cls(
            id_=adict.get('id', None),
            amount=adict.get('amount', None)
        )


class DomainPrice(BaseDomainOrder):

    def __init__(
            self,
            full_price: int = None,
            tickets_price: int = None,
            currency: str = None,
            discount: List[DomainDiscount] = None,
            voucher: DomainVoucher = None
    ):

        self.full_price = full_price
        self.tickets_price = tickets_price
        self.currency = currency
        self.discount = discount if discount else []
        self.voucher = voucher if voucher else DomainVoucher()

    def serialize(self) -> dict:
        return {
            'full_price': self.full_price,
            'tickets_price': self.tickets_price,
            'currency': self.currency,
            'discount': [d.serialize() for d in self.discount],
            'voucher': self.voucher.serialize()
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainPrice':
        return cls(
            full_price=adict.get('full_price', None),
            tickets_price=adict.get('tickets_price', None),
            currency=adict.get('currency', None),
            discount=[DomainDiscount.deserialize(d) for d in adict.get('discount', [])],
            voucher=DomainVoucher.deserialize(adict.get('voucher', {}))
        )
