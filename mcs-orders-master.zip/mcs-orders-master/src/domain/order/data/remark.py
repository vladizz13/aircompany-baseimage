from ..base import BaseDomainOrder


class DomainRemark(BaseDomainOrder):

    def __init__(
            self,
            remark_id: str = None,
            carrier: str = None,
            text: str = None
    ):

        self.remark_id = remark_id
        self.carrier = carrier
        self.text = text

    def __repr__(self):
        return f'DomainRemark(text="{self.text}")'

    def serialize(self) -> dict:
        return {
            'remark_id': self.remark_id,
            'carrier': self.carrier,
            'text': self.text
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainRemark':
        return cls(
            remark_id=adict.get('remark_id', None),
            carrier=adict.get('carrier', None),
            text=adict.get('text', None)
        )

    @property
    def is_split(self) -> bool:
        if not self.text:
            return False
        return '->' in self.text or '<-' in self.text
