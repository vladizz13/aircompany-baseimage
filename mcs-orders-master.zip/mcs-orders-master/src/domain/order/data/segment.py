import re
from datetime import datetime
from base.exception import ApplicationError

from ..base import BaseDomainOrder


class DomainMarketingTags(BaseDomainOrder):

    def __init__(
            self,
            times_of_day: str = None,
            baby: bool = None,
            party: bool = None,
            pair: bool = None,
    ):
        self.times_of_day = times_of_day
        self.baby = baby
        self.party = party
        self.pair = pair

    def serialize(self) -> dict:
        return {
            'times_of_day': self.times_of_day,
            'baby': self.baby,
            'party': self.party,
            'pair': self.pair
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainMarketingTags':
        return cls(
            times_of_day=adict.get('times_of_day', None),
            baby=adict.get('baby', None),
            party=adict.get('party', None),
            pair=adict.get('pair', None)
        )


class DomainSegment(BaseDomainOrder):
    flight_re = re.compile(r'^[0-9]{3,4}')

    def __init__(
            self,
            segment_id: str = None,
            tais_segment_id: str = None,
            ak: str = None,
            ak_full_name: str = None,
            oak: str = None,
            oak_full_name: str = None,
            arrival_city_code: str = None,
            arrival_airport_code: str = None,
            departure_city_code: str = None,
            departure_airport_code: str = None,
            class_: str = None,
            rbd: str = None,
            standby: bool = None,
            direction: str = None,
            duration: str = None,
            flight_number: str = None,
            layover_time: int = None,
            plane_type: str = None,
            plane_type_name: str = None,
            status: str = None,
            status_visual: str = None,
            seg_type: str = None,
            ns: int = None,
            arrival_local_iso: str = None,
            arrival_timestamp: int = None,
            departure_local_iso: str = None,
            departure_timestamp: int = None,
            booking_timestamp: int = None,
            marketing_tags: DomainMarketingTags = None,
            gds_active: bool = True
    ):
        self.segment_id = segment_id
        self.tais_segment_id = tais_segment_id
        self.ak = ak
        self.ak_full_name = ak_full_name
        self.oak = oak
        self.oak_full_name = oak_full_name
        self.arrival_city_code = arrival_city_code
        self.arrival_airport_code = arrival_airport_code
        self.departure_city_code = departure_city_code
        self.departure_airport_code = departure_airport_code
        self.class_ = class_
        self.rbd = rbd
        self.standby = standby
        self.direction = direction
        self.duration = duration
        self.flight_number = flight_number
        self.layover_time = layover_time
        self.plane_type = plane_type
        self.plane_type_name = plane_type_name
        self.status = status
        self.status_visual = status_visual
        self.seg_type = seg_type
        self.ns = ns
        self.arrival_local_iso = arrival_local_iso
        self.arrival_timestamp = arrival_timestamp
        self.departure_local_iso = departure_local_iso
        self.departure_timestamp = departure_timestamp
        self.booking_timestamp = booking_timestamp
        self.marketing_tags = marketing_tags if marketing_tags else DomainMarketingTags()
        self.gds_active = gds_active

    def __repr__(self):
        return f"DomainSegment(segment_id={self.segment_id}, tais_segment_id={self.tais_segment_id}, " \
               f"departure_timestamp={self.departure_timestamp}, departure_iso={self.departure_local_iso}), " \
               f"arrival_iso={self.arrival_local_iso}"

    def serialize(self) -> dict:
        return {
            'segment_id': self.segment_id,
            'tais_segment_id': self.tais_segment_id,
            'ak': self.ak,
            'ak_full_name': self.ak_full_name,
            'oak': self.oak,
            'oak_full_name': self.oak_full_name,
            'arrival_city_code': self.arrival_city_code,
            'arrival_airport_code': self.arrival_airport_code,
            'departure_city_code': self.departure_city_code,
            'departure_airport_code': self.departure_airport_code,
            'class': self.class_,
            'rbd': self.rbd,
            'standby': self.standby,
            'direction': self.direction,
            'duration': self.duration,
            'flight_number': self.flight_number,
            'layover_time': self.layover_time,
            'plane_type': self.plane_type,
            'plane_type_name': self.plane_type_name,
            'status': self.status,
            'status_visual': self.status_visual,
            'seg_type': self.seg_type,
            'ns': self.ns,
            'arrival_local_iso': self.arrival_local_iso,
            'arrival_timestamp': self.arrival_timestamp,
            'departure_local_iso': self.departure_local_iso,
            'departure_timestamp': self.departure_timestamp,
            'booking_timestamp': self.booking_timestamp,
            'marketing_tags': self.marketing_tags.serialize(),
            'gds_active': self.gds_active
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainSegment':
        return cls(
            segment_id=adict.get('segment_id', None),
            tais_segment_id=adict.get('tais_segment_id', None),
            ak=adict.get('ak', None),
            ak_full_name=adict.get('ak_full_name', None),
            oak=adict.get('oak', None),
            oak_full_name=adict.get('oak_full_name', None),
            arrival_city_code=adict.get('arrival_city_code', None),
            arrival_airport_code=adict.get('arrival_airport_code', None),
            departure_city_code=adict.get('departure_city_code', None),
            departure_airport_code=adict.get('departure_airport_code', None),
            class_=adict.get('class', None),
            rbd=adict.get('rbd', None),
            standby=adict.get('standby', None),
            direction=adict.get('direction', None),
            duration=adict.get('duration', None),
            flight_number=adict.get('flight_number', None),
            layover_time=adict.get('layover_time', None),
            plane_type=adict.get('plane_type', None),
            plane_type_name=adict.get('plane_type_name', None),
            status=adict.get('status', None),
            status_visual=adict.get('status_visual', None),
            seg_type=adict.get('seg_type', None),
            ns=adict.get('ns', None),
            arrival_local_iso=adict.get('arrival_local_iso', None),
            arrival_timestamp=adict.get('arrival_timestamp', None),
            departure_local_iso=adict.get('departure_local_iso', None),
            departure_timestamp=adict.get('departure_timestamp', None),
            booking_timestamp=adict.get('booking_timestamp', None),
            marketing_tags=DomainMarketingTags.deserialize(adict.get('marketing_tags', {})),
            gds_active=adict.get('gds_active', True),
        )

    @property
    def normalized_flight_number(self) -> str:
        if not self.flight_number:
            return None

        match_obj = self.flight_re.match(self.flight_number)
        if match_obj:
            return match_obj.group()

        return self.flight_number

    def get_hash(self, use_rbd: bool = True) -> str:
        """
        Сгенерировать уникальный идентификатор сегмента для сравнения сегментов
        """
        departure_date = (datetime.fromisoformat(self.departure_local_iso).strftime("%Y-%m-%d")
                          if self.departure_local_iso else str(self.departure_local_iso))

        rbd = self.rbd if use_rbd else " "

        return str(
            hash(
                self.arrival_airport_code +
                self.departure_airport_code +
                departure_date +
                self.flight_number +
                rbd
            )
        )

    def __eq__(self, other: "DomainSegment"):
        if not isinstance(other, self.__class__):
            raise ApplicationError(message='Unable to compare: Incorrect class instance')
        return self.get_hash() == other.get_hash()
