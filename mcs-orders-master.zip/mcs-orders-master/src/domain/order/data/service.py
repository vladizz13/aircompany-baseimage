from ..base import BaseDomainOrder


class DomainService(BaseDomainOrder):

    def __init__(
            self,
            guid: str = None,
            emd: str = None,
            emd_type: str = None,
            count: int = None,
            description: str = None,
            tais_id: str = None,
            link: str = None,
            pdf_link: str = None,
            ins_num: str = None,
            ins_id: str = None,
            exchangeable: bool = None,
            passenger_id: str = None,
            segment_id: str = None,
            status: str = None,
            type: str = None,
            add_method: str = None,
            rfisc: str = None,
            provider: str = None,
            price: int = None,
    ):

        self.guid = guid
        self.emd = emd
        self.emd_type = emd_type
        self.count = count
        self.description = description
        self.tais_id = tais_id
        self.link = link
        self.pdf_link = pdf_link
        self.ins_num = ins_num
        self.ins_id = ins_id
        self.exchangeable = exchangeable
        self.passenger_id = passenger_id
        self.segment_id = segment_id
        self.status = status
        self.type = type
        self.add_method = add_method
        self.rfisc = rfisc
        self.provider = provider
        self.price = price

    def __repr__(self):
        return f'DomainService(rfisc="{self.rfisc}", ' \
               f'passenger_id="{self.passenger_id}", ' \
               f'segment_id="{self.segment_id}, ' \
               f'type="{self.type}", ' \
               f'status="{self.status}")'

    def serialize(self) -> dict:
        return {
            "guid": self.guid,
            "emd": self.emd,
            "emd_type": self.emd_type,
            "count": self.count,
            "description": self.description,
            "tais_id": self.tais_id,
            "link": self.link,
            "pdf_link": self.pdf_link,
            "ins_num": self.ins_num,
            "ins_id": self.ins_id,
            "exchangeable": self.exchangeable,
            "passenger_id": self.passenger_id,
            "segment_id": self.segment_id,
            "status": self.status,
            "type": self.type,
            "add_method": self.add_method,
            "rfisc": self.rfisc,
            "provider": self.provider,
            "price": self.price
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainService':
        return cls(
            guid=adict.get("guid", None),
            emd=adict.get("emd", None),
            emd_type=adict.get("emd_type", None),
            count=adict.get("count", None),
            description=adict.get("description", None),
            tais_id=adict.get("tais_id", None),
            link=adict.get("link", None),
            pdf_link=adict.get("pdf_link", None),
            ins_num=adict.get("ins_num", None),
            ins_id=adict.get("ins_id", None),
            exchangeable=adict.get("exchangeable", None),
            passenger_id=adict.get("passenger_id", None),
            segment_id=adict.get("segment_id", None),
            status=adict.get("status", None),
            type=adict.get("type", None),
            add_method=adict.get("add_method", None),
            rfisc=adict.get("rfisc", None),
            provider=adict.get("provider", None),
            price=adict.get("price", None)
        )
