from ..base import BaseDomainOrder


class DomainServiceMoney(BaseDomainOrder):

    def __init__(
            self,
            emd: str = None,
            amount: int = None,
            amount_rub: int = None,
            currency: str = None,
    ):
        self.emd = emd
        self.amount = amount
        self.amount_rub = amount_rub
        self.currency = currency

    def serialize(self) -> dict:
        return {
            'emd': self.emd,
            'amount': self.amount,
            'amount_rub': self.amount_rub,
            'currency': self.currency
        }

    def __repr__(self):
        return f'DomainServiceMoney(emd="{self.emd}", amount={self.amount}, amount_rub={self.amount_rub})'

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainServiceMoney':
        return cls(
            emd=adict.get('emd', None),
            amount=adict.get('amount', None),
            amount_rub=adict.get('amount_rub', None),
            currency=adict.get('currency', None)
        )
