from ..base import BaseDomainOrder


class DomainSSR(BaseDomainOrder):

    def __init__(
            self,
            airline: str = None,
            passenger_id: str = None,
            segment_id: str = None,
            count: str = None,
            ssr: str = None,
            status: str = None,
            text: str = None,
    ):

        self.airline = airline
        self.passenger_id = passenger_id
        self.segment_id = segment_id
        self.count = count
        self.ssr = ssr
        self.status = status
        self.text = text

    def __repr__(self):
        return f'DomainSSR(ssr="{self.ssr}", status="{self.status}", ' \
               f'passenger_id="{self.passenger_id}", segment_id="{self.segment_id}")'

    def serialize(self) -> dict:
        return {
            'airline': self.airline,
            'passenger_id': self.passenger_id,
            'segment_id': self.segment_id,
            'count': self.count,
            'ssr': self.ssr,
            'status': self.status,
            'text': self.text
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainSSR':
        return cls(
            airline=adict.get('airline', None),
            passenger_id=adict.get('passenger_id', None),
            segment_id=adict.get('segment_id', None),
            count=adict.get('count', None),
            ssr=adict.get('ssr', None),
            status=adict.get('status', None),
            text=adict.get('text', None)
        )

    def __eq__(self, other: "DomainSSR"):
        # По статусу не сравниваем, так как он может меняться
        return all([
            self.segment_id == other.segment_id,
            self.passenger_id == other.passenger_id,
            self.text == other.text,
            self.ssr == other.ssr
        ])
