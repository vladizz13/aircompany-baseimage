import time
from ..base import BaseDomainOrder


class DomainOrderStatusUpdated(BaseDomainOrder):

    def __init__(
            self,
            status: str = None,
            date: float = None
    ):
        self.status = status
        self.date = date if date else time.time()

    def serialize(self) -> dict:
        return {
            'status': self.status,
            'date': self.date
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainOrderStatusUpdated':
        return cls(
            status=adict.get('status', None),
            date=adict.get('date', None)
        )

    def __eq__(self, other: "DomainOrderStatusUpdated"):
        return self.status == other.status
