from ..base import BaseDomainOrder
from typing import List


class DomainTaxes(BaseDomainOrder):

    def __init__(
            self,
            coupon_id: str = None,
            code: str = None,
            amount: int = None,
            amount_rub: int = None,
            category: str = None,
            owner: str = None,
    ):
        self.coupon_id = coupon_id
        self.code = code
        self.amount = amount
        self.amount_rub = amount_rub
        self.category = category
        self.owner = owner

    def serialize(self) -> dict:
        return {
            'coupon_id': self.coupon_id,
            'code': self.code,
            'amount': self.amount,
            'amount_rub': self.amount_rub,
            'category': self.category,
            'owner': self.owner
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainTaxes':
        return cls(
            coupon_id=adict.get('coupon_id', None),
            code=adict.get('code', None),
            amount=adict.get('amount', None),
            amount_rub=adict.get('amount_rub', None),
            category=adict.get('category', None),
            owner=adict.get('owner', None)
        )


class DomainMonetaryInfo(BaseDomainOrder):

    def __init__(
            self,
            coupon_id: str = None,
            code: str = None,
            amount: int = None,
            amount_rub: int = None,
            currency: str = None
    ):
        self.coupon_id = coupon_id
        self.code = code
        self.amount = amount
        self.amount_rub = amount_rub
        self.currency = currency

    def serialize(self) -> dict:
        return {
            'coupon_id': self.coupon_id,
            'code': self.code,
            'amount': self.amount,
            'amount_rub': self.amount_rub,
            'currency': self.currency
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainMonetaryInfo':
        return cls(
            coupon_id=adict.get('coupon_id', None),
            code=adict.get('code', None),
            amount=adict.get('amount', None),
            amount_rub=adict.get('amount_rub', None),
            currency=adict.get('currency', None)
        )


class DomainTicket(BaseDomainOrder):

    def __init__(
            self,
            ticket: str = None,
            passenger_id: str = None,
            fare_calc: str = None,
            issue_datetime: int = None,
            monetary_info: List[DomainMonetaryInfo] = None,
            taxes: List[DomainTaxes] = None
    ):
        self.ticket = ticket
        self.passenger_id = passenger_id
        self.fare_calc = fare_calc
        self.issue_datetime = issue_datetime
        self.monetary_info = monetary_info if monetary_info else []
        self.taxes = taxes if taxes else []

    def serialize(self) -> dict:
        return {
            'ticket': self.ticket,
            'passenger_id': self.passenger_id,
            'fare_calc': self.fare_calc,
            'issue_datetime': self.issue_datetime,
            'monetary_info': [mi.serialize() for mi in self.monetary_info],
            'taxes': [tx.serialize() for tx in self.taxes]
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainTicket':
        monetary_info_list = adict.get('monetary_info', {}) or {}
        taxes_list = adict.get('taxes', {}) or {}
        return cls(
            ticket=adict.get('ticket', None),
            passenger_id=adict.get('passenger_id', None),
            fare_calc=adict.get('fare_calc', None),
            issue_datetime=adict.get('issue_datetime', None),
            monetary_info=[DomainMonetaryInfo.deserialize(mi) for mi in monetary_info_list],
            taxes=[DomainTaxes.deserialize(t) for t in taxes_list]
        )
