from fastjsonschema.exceptions import JsonSchemaException
from typing import List
import uuid

from ..base import BaseDomainOrder

from .host_rloc import DomainHostRloc
from .status_updated import DomainOrderStatusUpdated
from .coupon import DomainCoupon
from .fop import DomainFop
from .remark import DomainRemark
from .passenger import DomainPassenger
from .service import DomainService
from .service_money import DomainServiceMoney
from .ticket import DomainTicket
from .segment import DomainSegment
from .ssr import DomainSSR
from .document import DomainDocument
from .contacts import DomainContact
from .pos_data import DomainPosData
from .price import DomainPrice
from .offer import DomainOffer
from .available_actions import DomainAvailableActions
from .analytics_data import DomainAnalyticsData

try:
    from libs.validators.compiled_schemas.airline_transaction_schema import validate_airline_transaction
except ImportError:
    # Скомпилируем на лету один раз
    from cli.utils.schema_compiler import SchemaCompiler
    SchemaCompiler().compile()
    from libs.validators.compiled_schemas.airline_transaction_schema import validate_airline_transaction  # noqa


class DomainTransaction(BaseDomainOrder):
    """
    Доменная модель транзакции авиаперелета
    Находится внутри order[data]
    """
    def __init__(
            self,
            rloc: str = None,
            order_id: str = None,
            order_key: str = None,
            order_uuid: str = None,
            sirena_id: str = None,
            rloc_host: List[DomainHostRloc] = None,
            rloc_parent_gds: str = None,
            status: str = None,
            status_updated: List[DomainOrderStatusUpdated] = None,
            waiting_for_refund: bool = None,
            owrt: str = None,
            departure_point: str = None,
            arrival_point: str = None,
            segment_count: int = None,
            passenger_count: int = None,
            group: bool = None,
            departure_start_timestamp: int = None,
            departure_end_timestamp: int = None,
            remarks: List[DomainRemark] = None,
            contacts: List[DomainContact] = None,
            passengers: List[DomainPassenger] = None,
            tickets: List[DomainTicket] = None,
            offers: List[DomainOffer] = None,
            coupons: List[DomainCoupon] = None,
            services: List[DomainService] = None,
            service_money: List[DomainServiceMoney] = None,
            fops: List[DomainFop] = None,
            segments: List[DomainSegment] = None,
            ssrs: List[DomainSSR] = None,
            documents: List[DomainDocument] = None,
            pos_data: DomainPosData = None,
            price: DomainPrice = None,
            available_actions: DomainAvailableActions = None,
            analytics_data: DomainAnalyticsData = None,
    ):

        self.rloc = rloc
        self.order_id = order_id
        self.order_key = order_key
        self.order_uuid = order_uuid if order_uuid else str(uuid.uuid4())
        self.sirena_id = sirena_id
        self.rloc_host: List[DomainHostRloc] = rloc_host if rloc_host else []
        self.rloc_parent_gds = rloc_parent_gds
        self.status = status
        self.status_updated = status_updated if status_updated else []
        self.waiting_for_refund = waiting_for_refund
        self.owrt = owrt
        self.departure_point = departure_point
        self.arrival_point = arrival_point
        self.segment_count = segment_count
        self.passenger_count = passenger_count
        self.group = group
        self.departure_start_timestamp = departure_start_timestamp
        self.departure_end_timestamp = departure_end_timestamp
        self.remarks: List[DomainRemark] = remarks if remarks else []
        self.passengers: List[DomainPassenger] = passengers if passengers else []
        self.tickets: List[DomainTicket] = tickets if tickets else []
        self.coupons: List[DomainCoupon] = coupons if coupons else []
        self.offers: List[DomainOffer] = offers if offers else []
        self.services: List[DomainService] = services if services else []
        self.service_money: List[DomainServiceMoney] = service_money if service_money else []
        self.fops: List[DomainFop] = fops if fops else []
        self.segments: List[DomainSegment] = segments if segments else []
        self.ssrs: List[DomainSSR] = ssrs if ssrs else []
        self.documents: List[DomainDocument] = documents if documents else []
        self.pos_data: DomainPosData = pos_data if pos_data else DomainPosData()
        self.price: DomainPrice = price if price else DomainPrice()
        self.contacts: List[DomainContact] = contacts if contacts else []
        self.available_actions: DomainAvailableActions = available_actions \
            if available_actions else DomainAvailableActions()
        self.analytics_data: DomainAnalyticsData = analytics_data if analytics_data else DomainAnalyticsData()

        self.count_nested_fields()

    def count_nested_fields(self):
        self.segment_count = len(self.segments)
        self.passenger_count = len(self.passengers)

    @property
    def is_valid(self) -> bool:
        try:
            self.validate()
            return True
        except JsonSchemaException:
            return False

    def validate(self):
        """
        При ошибочной валидации кинет fastjsonschema.exceptions.JsonSchemaException
        """
        return validate_airline_transaction(self.serialize())

    def serialize(self) -> dict:
        return {
            'rloc': self.rloc,
            'order_id': self.order_id,
            'order_key': self.order_key,
            'order_uuid': self.order_uuid,
            'sirena_id': self.sirena_id,
            'rloc_host': [hi.serialize() for hi in self.rloc_host],
            'rloc_parent_gds': self.rloc_parent_gds,
            'status': self.status,
            'status_updated': [su.serialize() for su in self.status_updated],
            'waiting_for_refund': self.waiting_for_refund,
            'owrt': self.owrt,
            'departure_point': self.departure_point,
            'arrival_point': self.arrival_point,
            'segment_count': self.segment_count,
            'passenger_count': self.passenger_count,
            'group': self.group,
            'departure_start_timestamp': self.departure_start_timestamp,
            'departure_end_timestamp': self.departure_end_timestamp,
            'remarks': [r.serialize() for r in self.remarks],
            'passengers': [p.serialize() for p in self.passengers],
            'tickets': [t.serialize() for t in self.tickets],
            'coupons': [c.serialize() for c in self.coupons],
            'offers': [o.serialize() for o in self.offers],
            'services': [s.serialize() for s in self.services],
            'service_money': [sm.serialize() for sm in self.service_money],
            'fops': [f.serialize() for f in self.fops],
            'segments': [s.serialize() for s in self.segments],
            'ssrs': [ssr.serialize() for ssr in self.ssrs],
            'documents': [doc.serialize() for doc in self.documents],
            'pos_data': self.pos_data.serialize(),
            'price': self.price.serialize(),
            'contacts': [c.serialize() for c in self.contacts],
            'available_actions': self.available_actions.serialize(),
            'analytics_data': self.analytics_data.serialize()
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainTransaction':
        return cls(
            rloc=adict.get('rloc', None),
            order_id=adict.get('order_id', None),
            order_key=adict.get('order_key', None),
            order_uuid=adict.get('order_uuid', None),
            sirena_id=adict.get('sirena_id', None),
            rloc_host=[DomainHostRloc.deserialize(hi) for hi in adict.get('rloc_host', [])],
            rloc_parent_gds=adict.get('rloc_parent_gds', None),
            status=adict.get('status', None),
            status_updated=[DomainOrderStatusUpdated.deserialize(su) for su in adict.get('status_updated', [])],
            waiting_for_refund=adict.get('waiting_for_refund', None),
            owrt=adict.get('owrt', None),
            departure_point=adict.get('departure_point', None),
            arrival_point=adict.get('arrival_point', None),
            segment_count=adict.get('segment_count', None),
            passenger_count=adict.get('passenger_count', None),
            group=adict.get('group', None),
            departure_start_timestamp=adict.get('departure_start_timestamp', None),
            departure_end_timestamp=adict.get('departure_end_timestamp', None),
            remarks=[DomainRemark.deserialize(r) for r in adict.get('remarks', [])],
            passengers=[DomainPassenger.deserialize(p) for p in adict.get('passengers', [])],
            tickets=[DomainTicket.deserialize(t) for t in adict.get('tickets', [])],
            coupons=[DomainCoupon.deserialize(c) for c in adict.get('coupons', [])],
            offers=[DomainOffer.deserialize(o) for o in adict.get('offers', [])],
            services=[DomainService.deserialize(s) for s in adict.get('services', [])],
            service_money=[DomainServiceMoney.deserialize(sm) for sm in adict.get('service_money', [])],
            fops=[DomainFop.deserialize(f) for f in adict.get('fops', [])],
            segments=[DomainSegment.deserialize(seg) for seg in adict.get('segments', [])],
            ssrs=[DomainSSR.deserialize(ssr) for ssr in adict.get('ssrs', [])],
            documents=[DomainDocument.deserialize(doc) for doc in adict.get('documents', [])],
            pos_data=DomainPosData.deserialize(adict.get('pos_data', {})),
            price=DomainPrice.deserialize(adict.get('price', {})),
            contacts=[DomainContact.deserialize(c) for c in adict.get('contacts', [])],
            available_actions=DomainAvailableActions.deserialize(adict.get('available_actions', {})),
            analytics_data=DomainAnalyticsData.deserialize(adict.get('analytics_data', {}))
        )
