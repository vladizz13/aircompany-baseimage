from ..base import BaseDomainOrder


class DomainIsHiddenFor(BaseDomainOrder):

    def __init__(
            self,
            userId: str = None,
            timestamp: int = None,
            is_admin_panel: bool = False,
    ):
        self.userId = userId
        self.timestamp = timestamp
        self.is_admin_panel = is_admin_panel

    def serialize(self) -> dict:
        return {
            'userId': self.userId,
            'timestamp': self.timestamp,
            'is_admin_panel': self.is_admin_panel,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainIsHiddenFor':
        return cls(
            userId=adict.get('userId', None),
            timestamp=adict.get('timestamp', None),
            is_admin_panel=adict.get('is_admin_panel', False),
        )

    def __eq__(self, other: "DomainIsHiddenFor") -> bool:
        return self.userId == other.userId
