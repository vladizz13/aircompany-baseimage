from typing import List

from ..base import BaseDomainOrder

from .meta_additional_data import DomainMetaAdditionalData
from .sub_owner import DomainSubOwner
from .transaction_source import DomainTransactionSource
from .is_hidden_for import DomainIsHiddenFor


class DomainMeta(BaseDomainOrder):

    def __init__(
            self,
            created: DomainTransactionSource = None,
            updated: List[DomainTransactionSource] = None,
            sub_owners: List[DomainSubOwner] = None,
            is_hidden_for: List[DomainIsHiddenFor] = None,
            additional_data: DomainMetaAdditionalData = None
    ):
        self.created: DomainTransactionSource = created if created else DomainTransactionSource()
        self.updated: List[DomainTransactionSource] = updated if updated else []
        self.sub_owners: List[DomainSubOwner] = sub_owners if sub_owners else []
        self.is_hidden_for: List[DomainIsHiddenFor] = is_hidden_for if is_hidden_for else []
        self.additional_data: DomainMetaAdditionalData = additional_data \
            if additional_data else DomainMetaAdditionalData()

    def serialize(self) -> dict:
        return {
            'created': self.created.serialize(),
            'updated': [u.serialize() for u in self.updated],
            'sub_owners': [su.serialize() for su in self.sub_owners],
            'is_hidden_for': [isf.serialize() for isf in self.is_hidden_for],
            'additional_data': self.additional_data.serialize()
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainMeta':
        return cls(
            created=DomainTransactionSource.deserialize(adict.get('created', {})),
            updated=[DomainTransactionSource.deserialize(u) for u in adict.get('updated', [])],
            sub_owners=[DomainSubOwner.deserialize(so) for so in adict.get('sub_owners', [])],
            is_hidden_for=[DomainIsHiddenFor.deserialize(isf) for isf in adict.get('is_hidden_for', [])],
            additional_data=DomainMetaAdditionalData.deserialize(adict.get('additional_data', {}))
        )

    @property
    def all_order_updates(self) -> List[DomainTransactionSource]:
        _data = [self.created]
        _data.extend(self.updated)
        return _data
