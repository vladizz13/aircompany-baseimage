from ..base import BaseDomainOrder


class DomainMetaAdditionalData(BaseDomainOrder):

    def __init__(
            self,
            data: str = None,
            loader: str = None,
    ):
        self.data = data
        self.loader = loader

    def serialize(self) -> dict:
        return {
            'data': self.data,
            'loader': self.loader
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainMetaAdditionalData':
        return cls(
            data=adict.get('data', None),
            loader=adict.get('loader', None)
        )
