from ..base import BaseDomainOrder


class DomainSubOwner(BaseDomainOrder):

    def __init__(
            self,
            match_type: str = None,
            userId: str = None,
            timestamp: int = None,
            contact_email: str = None,
            contact_phone: str = None
    ):
        self.match_type = match_type
        self.userId = userId
        self.timestamp = timestamp
        self.contact_email = contact_email
        self.contact_phone = contact_phone

    def serialize(self) -> dict:
        return {
            'match_type': self.match_type,
            'userId': self.userId,
            'timestamp': self.timestamp,
            'contact_email': self.contact_email,
            'contact_phone': self.contact_phone
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainSubOwner':
        return cls(
            match_type=adict.get('match_type', None),
            userId=adict.get('userId', None),
            timestamp=adict.get('timestamp', None),
            contact_email=adict.get('contact_email', None),
            contact_phone=adict.get('contact_phone', None),
        )

    def __eq__(self, other: "DomainSubOwner") -> bool:
        return other.userId == self.userId
