from ..base import BaseDomainOrder


class DomainTransactionSource(BaseDomainOrder):

    def __init__(
            self,
            date: float = None,
            provider: str = None,
            message_id: str = None,
    ):
        self.date: float = date
        self.provider: str = provider
        self.message_id: str = message_id

    def serialize(self) -> dict:
        return {
            'date': self.date,
            'provider': self.provider,
            'message_id': self.message_id
        }

    def __repr__(self):
        return f"<provider={self.provider}, date={self.date} message_id={self.message_id}>"

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainTransactionSource':
        return cls(
            date=adict.get('date', None),
            provider=adict.get('provider', None),
            message_id=adict.get('message_id', None)
        )
