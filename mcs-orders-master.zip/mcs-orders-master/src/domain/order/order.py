"""
Доменная модель заказа

Для расширения любой из моделей нужно добавить переменную в init,
в serialize и deserialize функции.
У переменной *должно* быть дефолтное значение, для того, чтобы
подтягивать его при отсутсвии значения в словаре из которого десериализуется модель.

Все вложенные структуры выполнены в форме похожих доменных моеделей.

Полную структуру модели можно посмотреть в test/common_fixtures/order.json

После добавления нового поля в модель, нужно продублировать изменения в этой фикстуре
"""
from typing import Dict

from fastjsonschema.exceptions import JsonSchemaException

from .base import BaseDomainOrder
from .data import DomainPassenger
from .data.transaction import DomainTransaction
from .meta.meta import DomainMeta

try:
    from libs.validators.compiled_schemas.order_schema import validate_order
except ImportError:
    # Скомпилируем на лету один раз
    from cli.utils.schema_compiler import SchemaCompiler

    SchemaCompiler().compile()
    from libs.validators.compiled_schemas.order_schema import validate_order  # noqa


class DomainOrder(BaseDomainOrder):
    """
    Верхнеуровневая доменная модель всего заказа
    """

    def __init__(
        self,
        data=None,
        meta=None,
        actions=None,
    ):

        self.data: DomainTransaction = data if data else DomainTransaction()
        self.meta: DomainMeta = meta if meta else DomainMeta()
        self.actions = actions

    def __repr__(self):
        return f'DomainOrder(rloc="{self.data.rloc}", order_uuid="{self.data.order_uuid}")'

    @property
    def is_valid(self) -> bool:
        try:
            self.validate()
            return True
        except JsonSchemaException:
            return False

    def validate(self):
        """
        При ошибочной валидации кинет fastjsonschema.exceptions.JsonSchemaException
        """
        return validate_order(self.serialize())

    def serialize(self):
        return {
            'data': self.data.serialize(),
            'meta': self.meta.serialize(),
            'actions': self.actions,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainOrder':
        return cls(
            data=DomainTransaction.deserialize(adict.get('data', {})),
            meta=DomainMeta.deserialize(adict.get('meta', {})),
            actions=adict.get('actions', {}),
        )

    def get_pax_by_ticket_mapper(self) -> Dict[str, DomainPassenger]:
        pax_by_pax_id = {pax.passenger_id: pax for pax in self.data.passengers}
        return {
            coupon.ticket: pax_by_pax_id[coupon.passenger_id]
            for coupon in self.data.coupons
            if coupon.passenger_id in pax_by_pax_id
        }
