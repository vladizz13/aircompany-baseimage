from base.domain import BaseDomain


class DomainOriginTransaction(BaseDomain):
    """
    Доменная модель оригинальной транзакции от провайдера
    """
    def __init__(
            self,
            message_uuid: str = None,
            provider: str = None,
            created: int = None,
            raw: dict = None
    ):

        self.message_uuid = message_uuid
        self.provider = provider
        self.created = created
        self.raw = raw

    def __repr__(self):
        return f"DomainOriginTransaction(message_uuid={self.message_uuid}, provider={self.provider})"

    def serialize(self):
        return {
            'message_uuid': self.message_uuid,
            'provider': self.provider,
            'created': self.created,
            'raw': self.raw
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainOriginTransaction':
        return cls(
            message_uuid=adict.get('message_uuid', None),
            provider=adict.get('provider', None),
            created=adict.get('created', None),
            raw=adict.get('raw', None)
        )
