from typing import Dict

from base.domain import BaseDomain


class DomainCost(BaseDomain):
    """
    Доменная модель данных о цене услуги
    """

    def __init__(self, price: str = None, currency: str = None):
        self.price = price
        self.currency = currency

    def serialize(self) -> Dict:
        return {'price': self.price, 'currency': self.currency}

    @classmethod
    def deserialize(cls, adict: Dict) -> 'DomainCost':
        return cls(price=adict.get('price', None), currency=adict.get('currency', None))


class DomainDocument(BaseDomain):
    """
    Доменная модель данных о документах
    """

    def __init__(self, docnumber: str = None, docexpiration: str = None, doccountry: str = None, doctype: str = None):
        self.docnumber = docnumber
        self.docexpiration = docexpiration
        self.doccountry = doccountry
        self.doctype = doctype

    def serialize(self) -> Dict:
        return {
            'docnumber': self.docnumber,
            'docexpiration': self.docexpiration,
            'doccountry': self.doccountry,
            'doctype': self.doctype,
        }

    @classmethod
    def deserialize(cls, adict: Dict) -> 'DomainDocument':
        return cls(
            docnumber=adict.get('docnumber', None),
            docexpiration=adict.get('docexpiration', None),
            doccountry=adict.get('doccountry', None),
            doctype=adict.get('doctype', None),
        )


class DomainPassengerPD(BaseDomain):
    """
    Доменная модель с информацией о предыдущей версии перс. данных клиента
    """
    def __init__(
            self,
            last_name: str = None,
            first_name: str = None,
            second_name: str = None,
            gender: str = None,
            type: str = None,
            birthday: str = None,
            document: DomainDocument = None,
            clean_second_name: bool = False,
    ):
        self.last_name = last_name
        self.first_name = first_name
        self.second_name = second_name
        self.gender = gender
        self.type = type
        self.birthday = birthday
        self.document = document
        self.clean_second_name = clean_second_name

    def serialize(self):
        return {
            'last_name': self.last_name,
            'first_name': self.first_name,
            'second_name': self.second_name,
            'gender': self.gender,
            'type': self.type,
            'birthday': self.birthday,
            'document': self.document.serialize(),
            'clean_second_name': self.clean_second_name,
        }

    @classmethod
    def deserialize(cls, adict: Dict) -> 'DomainPassengerPD':
        return cls(
            last_name=adict.get('last_name', None),
            first_name=adict.get('first_name', None),
            second_name=adict.get('second_name', None),
            gender=adict.get('gender', None),
            type=adict.get('type', None),
            birthday=adict.get('birthday', None),
            document=DomainDocument.deserialize(adict.get('document', dict())),
            clean_second_name=adict.get('clean_second_name', False),
        )


class DomainPDChanges(BaseDomain):
    """
    Доменная модель данных о пассажире в заявке на возврат
    """

    def __init__(
            self,
            order_uuid: str = None,
            rloc: str = None,
            passenger_id: str = None,
            previous_pd: DomainPassengerPD = None,
            new_pd: DomainPassengerPD = None,
            datetime: int = None,
            status: str = None,
            contact: str = None,
            payment_id: str = None,
            cost: DomainCost = None,
            payments_deadline_utc: int = None,
    ):
        self.order_uuid = order_uuid
        self.rloc = rloc
        self.passenger_id = passenger_id
        self.previous_pd = previous_pd
        self.new_pd = new_pd
        self.datetime = datetime
        self.status = status
        self.contact = contact
        self.payment_id = payment_id
        self.cost = cost
        self.payments_deadline_utc = payments_deadline_utc

    def serialize(self):
        return {
            'order_uuid': self.order_uuid,
            'rloc': self.rloc,
            'passenger_id': self.passenger_id,
            'previous_pd': self.previous_pd.serialize(),
            'new_pd': self.new_pd.serialize(),
            'status': self.status,
            'datetime': self.datetime,
            'contact': self.contact,
            'payment_id': self.payment_id,
            'cost': self.cost.serialize(),
            'payments_deadline_utc': self.payments_deadline_utc,
        }

    @classmethod
    def deserialize(cls, adict: Dict) -> 'DomainPDChanges':
        return cls(
            order_uuid=adict.get('order_uuid', None),
            rloc=adict.get('rloc', None),
            passenger_id=adict.get('passenger_id', None),
            previous_pd=DomainPassengerPD.deserialize(adict.get('previous_pd', dict())),
            new_pd=DomainPassengerPD.deserialize(adict.get('new_pd', dict())),
            status=adict.get('status', None),
            datetime=adict.get('datetime', None),
            contact=adict.get('contact', None),
            payment_id=adict.get('payment_id', None),
            cost=DomainCost.deserialize(adict.get('cost', dict())),
            payments_deadline_utc=adict.get('payments_deadline_utc', None)
        )
