from base.domain import BaseDomain


class DomainProrate(BaseDomain):
    """
    Доменная модель прорейта
    """
    def __init__(
            self,
            departure: str = None,
            arrival: str = None,
            date_from: str = None,
            date_to: str = None,
            range: int = None,
            factor: int = None
    ):

        self.departure = departure
        self.arrival = arrival
        self.date_from = date_from
        self.date_to = date_to
        self.range = range
        self.factor = factor

    def serialize(self):
        return {
            'departure': self.departure,
            'arrival': self.arrival,
            'date_from': self.date_from,
            'date_to': self.date_to,
            'range': self.range,
            'factor': self.factor
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainProrate':
        return cls(
            departure=adict.get('departure', None),
            arrival=adict.get('arrival', None),
            date_from=adict.get('date_from', None),
            date_to=adict.get('date_to', None),
            range=adict.get('range', None),
            factor=adict.get('factor', None)
        )
