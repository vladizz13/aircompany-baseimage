from typing import List, Optional, Dict, Tuple

from base.domain import BaseDomain


class TicketForm(BaseDomain):
    def __init__(
            self,
            passenger_id: str = '',
            new_ticket: str = '',
            old_ticket: str = '',
    ) -> None:
        super().__init__()
        self.passenger_id = passenger_id
        self.new_ticket = new_ticket
        self.old_ticket = old_ticket

    def serialize(self) -> dict:
        return {
            'passenger_id': self.passenger_id,
            'new_ticket': self.new_ticket,
            'old_ticket': self.old_ticket,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'TicketForm':
        return cls(
            passenger_id=adict.get('passenger_id', ''),
            new_ticket=adict.get('new_ticket', ''),
            old_ticket=adict.get('old_ticket', ''),
        )


class YoForm(BaseDomain):
    def __init__(
            self,
            passenger_id: str = '',
            emd: str = '',
            value: float = 0,
            rfic: Optional[str] = None,
            fop: str = '',
    ) -> None:
        super().__init__()
        self.passenger_id = passenger_id
        self.emd = emd
        self.value = float(value)
        self.rfic = rfic
        self.fop = fop

    def serialize(self) -> dict:
        return {
            'passenger_id': self.passenger_id,
            'emd': self.emd,
            'value': self.value,
            'rfic': self.rfic,
            'fop': self.fop,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'YoForm':
        return cls(
            passenger_id=adict.get('passenger_id', ''),
            emd=adict.get('emd', ''),
            value=adict.get('value', 0),
            rfic=adict.get('rfic'),
            fop=adict.get('fop', ''),
        )


class PenaltyForm(YoForm):
    pass


class DomainReceiptsData(BaseDomain):
    def __init__(
            self,
            ticket_forms: List[TicketForm] = None,
            yo_forms: List[YoForm] = None,
            penalty_forms: List[PenaltyForm] = None,
            any_forms: List[dict] = None,
    ) -> None:
        super().__init__()
        self.ticket_forms = ticket_forms or []
        self.yo_forms = yo_forms or []
        self.penalty_forms = penalty_forms or []
        self.any_forms = any_forms or []

    def serialize(self) -> dict:
        return {
            'ticket_forms': [x.serialize() for x in self.ticket_forms],
            'yo_forms': [x.serialize() for x in self.yo_forms],
            'penalty_forms': [x.serialize() for x in self.penalty_forms],
            'any_forms': self.any_forms,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainReceiptsData':
        return cls(
            ticket_forms=[TicketForm.deserialize(x) for x in adict.get('ticket_forms', [])],
            yo_forms=[YoForm.deserialize(x) for x in adict.get('yo_forms', [])],
            penalty_forms=[PenaltyForm.deserialize(x) for x in adict.get('penalty_forms', [])],
            any_forms=adict.get('any_forms', []),
        )

    @classmethod
    def deserialize_by_raw(cls, raw: dict) -> 'DomainReceiptsData':
        """
        Сериализация из сырого сообщения сирены
        """
        ticket_forms: List[TicketForm] = []
        yo_forms: List[YoForm] = []
        penalty_forms: List[PenaltyForm] = []
        any_forms = []
        forms = raw['receipts']['ticket_form']
        if not isinstance(forms, list):
            forms = [forms]
        for form in forms:
            if 'form_and_serial_number' in form:
                ticket_forms.append(
                    TicketForm(
                        new_ticket=form['form_and_serial_number'],
                        old_ticket=form['last_issue'],
                        passenger_id=form['@pass_id'],
                    )
                )
            elif 'value' in form and form.get('rfic') == 'D':
                yo_forms.append(
                    YoForm(
                        passenger_id=form['@pass_id'],
                        emd=form['emd_num'].replace(' ', ''),
                        value=form['value'],
                        rfic=form.get('rfic'),
                        fop=form.get('fop') or '',
                    )
                )
            elif 'value' in form and form.get('rfic') is None:
                penalty_forms.append(
                    PenaltyForm(
                        passenger_id=form['@pass_id'],
                        emd=form['emd_num'].replace(' ', ''),
                        value=form['value'],
                        rfic=form.get('rfic'),
                        fop=form.get('fop') or '',
                    )
                )
            else:
                any_forms.append(form)
        return cls(
            ticket_forms=ticket_forms,
            yo_forms=yo_forms,
            penalty_forms=penalty_forms,
            any_forms=any_forms,
        )

    def get_all_tickets(self):
        all_tickets = []
        for form in self.ticket_forms:
            all_tickets.append(form.new_ticket)
            all_tickets.append(form.old_ticket)
        return all_tickets

    def get_all_emds(self):
        emds = [form.emd for form in self.yo_forms]
        emds.extend([form.emd for form in self.penalty_forms])
        return emds

    def get_tickets_by_pax(self) -> Dict[str, Tuple[str, str]]:
        return {
            form.passenger_id: (form.new_ticket, form.old_ticket)
            for form in self.ticket_forms
        }

    def get_yo_numbers_by_pax(self) -> Dict[str, Dict[float, List[str]]]:
        result = {}
        for form in self.yo_forms:
            result.setdefault(form.passenger_id, {}).setdefault(form.value, []).append(form.emd)
        return result

    def get_penalty_numbers_by_pax(self) -> Dict[str, Dict[float, List[str]]]:
        result = {}
        for form in self.penalty_forms:
            result.setdefault(form.passenger_id, {}).setdefault(form.value, []).append(form.emd)
        return result

    def mutate_by_old_data(self, old_receipts_data: 'DomainReceiptsData'):
        """
        Отсеиваем старые данные
        """
        old_tickets = old_receipts_data.get_all_tickets()
        self.ticket_forms = [form for form in self.ticket_forms if form.new_ticket not in old_tickets]
        old_yo_emds = [form.emd for form in old_receipts_data.yo_forms]
        self.yo_forms = [form for form in self.yo_forms if form.emd not in old_yo_emds]
        old_penalty_emds = [form.emd for form in old_receipts_data.penalty_forms]
        self.penalty_forms = [form for form in self.penalty_forms if form.emd not in old_penalty_emds]
