from typing import List

from base.domain import BaseDomain


class DomainRefundPassengerData(BaseDomain):
    """
    Доменная модель данных о пассажире в заявке на возврат
    """
    def __init__(
            self,
            passenger_id: str = None,
            first_name: str = None,
            last_name: str = None,
            second_name: str = None,
            type: str = None,
    ):
        self.passenger_id = passenger_id
        self.first_name = first_name
        self.last_name = last_name
        self.second_name = second_name
        self.type = type

    def serialize(self):
        return {
            'passenger_id': self.passenger_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'second_name': self.second_name,
            'type': self.type,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainRefundPassengerData':
        return cls(
            passenger_id=adict.get('passenger_id', None),
            first_name=adict.get('first_name', None),
            last_name=adict.get('last_name', None),
            second_name=adict.get('second_name', None),
            type=adict.get('type', None),
        )


class DomainRefund(BaseDomain):
    """
    Доменная модель возврата заказа
    """
    def __init__(
            self,
            order_uuid: str = None,
            passengers: List[DomainRefundPassengerData] = None,
            contact: str = None,
            involuntary: str = None,
            datetime_utc: str = None,
            order_refund_id: str = None
    ):
        self.order_uuid = order_uuid
        self.passengers: List[DomainRefundPassengerData] = passengers if passengers else []
        self.contact = contact
        self.involuntary = involuntary
        self.datetime_utc = datetime_utc
        self.order_refund_id = order_refund_id

    def serialize(self):
        return {
            'order_uuid': self.order_uuid,
            'passengers': [p.serialize() for p in self.passengers],
            'contact': self.contact,
            'involuntary': self.involuntary,
            'datetime_utc': self.datetime_utc,
            'order_refund_id': self.order_refund_id
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainRefund':
        return cls(
            order_uuid=adict.get('order_uuid', None),
            passengers=[DomainRefundPassengerData.deserialize(p) for p in adict.get('passengers', [])],
            contact=adict.get('contact', None),
            involuntary=adict.get('involuntary', None),
            datetime_utc=adict.get('datetime_utc', None),
            order_refund_id=adict.get('order_refund_id', None)
        )
