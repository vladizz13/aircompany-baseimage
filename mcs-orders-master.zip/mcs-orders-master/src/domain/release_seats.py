from typing import List, Optional

from base.domain import BaseDomain


class DomainReleaseSeatsPassengerData(BaseDomain):
    """
    Доменная модель данных о пассажире в заявке на аннулирование мест
    """
    def __init__(
            self,
            passenger_id: str = None,
            first_name: str = None,
            last_name: str = None,
            second_name: str = None,
            type: str = None,
    ):
        self.passenger_id = passenger_id
        self.first_name = first_name
        self.last_name = last_name
        self.second_name = second_name
        self.type = type

    def serialize(self):
        return {
            'passenger_id': self.passenger_id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'second_name': self.second_name,
            'type': self.type,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainReleaseSeatsPassengerData':
        return cls(
            passenger_id=adict.get('passenger_id', None),
            first_name=adict.get('first_name', None),
            last_name=adict.get('last_name', None),
            second_name=adict.get('second_name', None),
            type=adict.get('type', None),
        )


class DomainReleaseSeatsSegmentsData(BaseDomain):
    """
    Доменная модель данных о сегменте в заявке на аннулирование мест
    """
    def __init__(
            self,
            arrival_airport_code: str = None,
            departure_airport_code: str = None,
            departure_local_iso: str = None,
            ak: str = None,
            flight_number: str = None,
    ):
        self.arrival_airport_code = arrival_airport_code
        self.departure_airport_code = departure_airport_code
        self.departure_local_iso = departure_local_iso
        self.ak = ak
        self.flight_number = flight_number

    def serialize(self):
        return {
            'arrival_airport_code': self.arrival_airport_code,
            'departure_airport_code': self.departure_airport_code,
            'departure_local_iso': self.departure_local_iso,
            'ak': self.ak,
            'flight_number': self.flight_number,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainReleaseSeatsSegmentsData':
        return cls(
            arrival_airport_code=adict.get('arrival_airport_code', None),
            departure_airport_code=adict.get('departure_airport_code', None),
            departure_local_iso=adict.get('departure_local_iso', None),
            ak=adict.get('ak', None),
            flight_number=adict.get('flight_number', None),
        )


class DomainReleaseSeats(BaseDomain):
    """
    Доменная модель аннулирования мест
    """
    def __init__(
            self,
            rloc: str = None,
            order_uuid: str = None,
            passengers: List[DomainReleaseSeatsPassengerData] = None,
            segments: List[DomainReleaseSeatsSegmentsData] = None,
            datetime_utc: str = None,
            reason: Optional[str] = None
    ):
        self.rloc = rloc
        self.order_uuid = order_uuid
        self.passengers: List[DomainReleaseSeatsPassengerData] = passengers if passengers else []
        self.segments: List[DomainReleaseSeatsSegmentsData] = segments if segments else []
        self.datetime_utc = datetime_utc
        self.reason = reason

    def serialize(self):
        return {
            'rloc': self.rloc,
            'order_uuid': self.order_uuid,
            'passengers': [p.serialize() for p in self.passengers],
            'segments': [s.serialize() for s in self.segments],
            'datetime_utc': self.datetime_utc,
            'reason': self.reason,
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainReleaseSeats':
        return cls(
            rloc=adict.get('rloc', None),
            order_uuid=adict.get('order_uuid', None),
            passengers=[DomainReleaseSeatsPassengerData.deserialize(p) for p in adict.get('passengers', [])],
            segments=[DomainReleaseSeatsSegmentsData.deserialize(s) for s in adict.get('segments', [])],
            datetime_utc=adict.get('datetime_utc', None),
            reason=adict.get('reason', None),
        )
