from base.domain import BaseDomain


class DomainServiceAdditionalFields(BaseDomain):
    def __init__(
            self,
            image_url: str = None,
            service_type: str = None
    ):
        self.image_url = image_url
        self.service_type = service_type

    def serialize(self) -> dict:
        return {
            'image_url': self.image_url,
            'service_type': self.service_type
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainServiceAdditionalFields':
        return cls(
            image_url=adict.get('image_url', None),
            service_type=adict.get('service_type', None)
        )


class DomainServiceSirenaRequestFields(BaseDomain):
    def __init__(
            self,
            emd: str = None,
            group: str = None,
            rfic: str = None,
            service_type: str = None
    ):
        self.emd = emd
        self.group = group
        self.rfic = rfic
        self.service_type = service_type

    def serialize(self) -> dict:
        return {
            '@emd': self.emd,
            '@group': self.group,
            '@rfic': self.rfic,
            '@service_type': self.service_type
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainServiceSirenaRequestFields':
        return cls(
            emd=adict.get('@emd', None),
            group=adict.get('@group', None),
            rfic=adict.get('@rfic', None),
            service_type=adict.get('@service_type', None)
        )


class DomainServiceTranslation(BaseDomain):
    def __init__(
            self,
            en: str = None,
            ru: str = None
    ):
        self.en = en
        self.ru = ru

    def serialize(self):
        return {
            'en': self.en,
            'ru': self.ru
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainServiceTranslation':
        return cls(
            en=adict.get('en', None),
            ru=adict.get('ru', None)
        )


class DomainAdditionalService(BaseDomain):
    """
    Доменная модель ответа услуг от сервис агента
    """
    def __init__(
            self,
            enabled: bool = None,
            guid: str = None,
            service_type: str = None,
            rfisc: str = None,
            additional_fields: DomainServiceAdditionalFields = None,
            description: DomainServiceTranslation = None,
            name: DomainServiceTranslation = None,
            sirena_request_fields: DomainServiceSirenaRequestFields = None,

    ):
        self.enabled = enabled if enabled else False
        self.guid = guid
        self.service_type = service_type
        self.rfisc = rfisc
        self.additional_fields = additional_fields or DomainServiceAdditionalFields()
        self.description = description or DomainServiceTranslation()
        self.name = name or DomainServiceTranslation()
        self.sirena_request_fields = sirena_request_fields or DomainServiceSirenaRequestFields()

    def serialize(self):
        return {
            'enabled': self.enabled,
            'guid': self.guid,
            'service_type': self.service_type,
            'rfisc': self.rfisc,
            'additional_fields': self.additional_fields.serialize(),
            'description': self.description.serialize(),
            'name': self.name.serialize(),
            'sirena_request_fields': self.sirena_request_fields.serialize()
        }

    @classmethod
    def deserialize(cls, adict: dict) -> 'DomainAdditionalService':
        return cls(
            enabled=adict.get('enabled', None),
            guid=adict.get('guid', None),
            service_type=adict.get('service_type', None),
            rfisc=adict.get('sirena_key', {}).get('@rfisc', None) or adict.get('rfisc', None),
            additional_fields=DomainServiceAdditionalFields.deserialize(adict.get('additional_fields', {})),
            description=DomainServiceTranslation.deserialize(adict.get('description', None)),
            name=DomainServiceTranslation.deserialize(adict.get('name', None)),
            sirena_request_fields=DomainServiceSirenaRequestFields.deserialize(adict.get('sirena_request_fields', {}))
        )
