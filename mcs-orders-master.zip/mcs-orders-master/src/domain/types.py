from typing import Optional, List
from enum import Enum


class TicketIdentifier(Enum):
    """
    Перечисление идентификаторов билетов авиакомпаний
    """
    UTAIR = '298'  # Наши билеты начинаются с 298


class ContactType(Enum):
    """
    Перечисление типов контактов
    """
    MAIL = 'mail'
    PHONE = 'phone'
    OTHER = 'other'  # нераспознанный контакт


class CodeDispatchType(Enum):
    """
    Тип отправки сообщения клиенту
    """
    CALL = 'call'
    SMS = 'sms'


class SirenaContactType(Enum):
    """
    Перечисление типов контактов от сирены
    """
    MAIL = 'EMAIL'
    PHONE = 'MOBILE_PHONE'
    AGENT_CONTACT = ('AGENT_CONTACT', 'agency')


class MatchTypes(Enum):
    """
    Перечисление типов добавления заказа пользователю
    """
    MANUAL = 'manual'   # Добавление через админку
    AUTO = 'auto'       # Добавление через маппинг


class OAK(Enum):
    """
    Перечисление OAK кодов авиакомпаний
    """
    UT = 'UT'
    R7 = '7R'


class Direction(Enum):
    """
    Перечисление направлений
    """
    TO = "TO"
    BACK = "BACK"


class Currency(Enum):
    """
    Перечисление валют
    """
    RUB = 'RUB'
    USD = 'USD'
    EUR = 'EUR'


class CompanyPPR(Enum):
    """
    ППР (платежный терминал, PosID) - номер платежного терминала,
    через который были приняты или возвращены денежные средства.
    """
    WEBSITE = "29828326"                    # Сайт/ТАИС Sirena#441
    VOICE_IVR = "29834733"                  # Голосовая оплата только картой в сеансе ЮТ
    WEBSITE_AND_CALLCENTER = "92308716"     # Сайт + КоллЦентр в сеансе ТКП
    CONTACT_CENTER = "29801936"             # Отдел сопровождения продаж
    WEBSITE_AVIASALES = "29843203"          # Сайт, пассажиры, пришедшие с Aviasales
    WEBSITE_SKYSCANNER = "29843553"         # Сайт, пассажиры, пришедшие со SkyScanner
    SIRENA_CLIENT444 = "29837533"           # Краснодарский ППР Sirena#444
    TARIFICATION_EXPERIMENTS = "29845631"   # ППР созданный для экспериментов с тарификацией (Client_id 450)


class TicketMonetaryCode(Enum):
    """
    Перечисление кодов оплаты билетов
    """
    TOTAL = 'T'
    BASE = 'B'


class TransactionSource(Enum):
    """
    Перечисление провайдеров транзакций
    """
    SIRENA = 'sirena'           # поток заказов на сохранение
    SIRENA_GRS = 'sirena_grs'   # запросы к SirenaGrs через адаптер
    TAIS = 'tais'
    ARCHIVED = 'archived'       # Бронь была архивирована и переведена в статус X нашей таской
    REMAPPED = 'remapped'       # Действие, обозначающее, что заказ был перемаплен заново
    SIRENA_V2 = 'sirena_v2'     # поток заказов на сохранение, вторая версия


class SaveOrderEdgeCases(Enum):
    """
    Перечисление edge-case'ов сохранения заказа
    """
    SIRENA_GRS_RETURNED_ORDER = 'sirena_grs_returned_order'  # Возвращенный заказ


class GDS(Enum):
    """
    Суффикс GDS
    """
    SIRENA = '1H'
    SIRENA_V2 = '15'
    AMADEUS = '1A'
    SABRE = '1S'
    GALILEO = '1G'


class Gender(Enum):
    """
    Перечисление, указывающее на пол
    """
    MALE = "M"
    FEMALE = "F"


class TimesOfDay(Enum):
    """
    Перечисления времени суток
    """
    NIGHT = 'NIGHT'
    MORNING = 'MORNING'
    AFTERNOON = 'AFTERNOON'
    EVENING = 'EVENING'


class StringBoolRepresentation(Enum):
    """
    Представление булевых значений строкой
    """
    TRUE = 'Y'
    FALSE = 'N'


class SegmentStatusVisual(Enum):
    """
    Перечисление отображения видимых статусов сегмента
    """
    ACTIVE = 'active'               # активен
    CANCELED = 'canceled'           # отменён
    RETURNED = 'returned'           # выполнен возврат
    NOT_PAYED = 'not_payed'         # не оплачен
    FLOWN = 'flown'                 # сегмент пролётан
    REGISTERED = 'registered'       # зарегистрирован
    TRANSFER = 'transfer'           # пересадка
    DISABLED = 'disabled'           # не активен
    CONTROL = 'control'             # на контроле
    RELEASED = 'released'           # место аннулировано
    EXCHANGED = 'exchanged'         # выполнен обмен
    VOID = 'void'                   # (-) прочерк (да, это описание статуса)
    UNAVAILABLE = 'unavailable'     # недоступен
    NO_DATA = 'no_data'             # нет данных по купонам чужих сегментов выписанных на бланках не "298...".
    PROCESSING = 'processing'       # в обработке

    UNDEFINED = None                # дефолтный статус, не определён


class CouponStatus(Enum):
    """
    Перечисление статусов купонов
    """
    A = 'A'     # Airport Control (Аэропортовый контроль)
    C = 'C'     # Checked in (Прошел регистрацию)
    E = 'E'     # Exchanged/reissued (Обменен/ переоформлен)
    F = 'F'     # Flown/Used (Использован)
    G = 'G'     # Exchanged/FIM
    R = 'R'     # Refunded (Произведен возврат денег)
    P = 'P'     # Printed (Распечатан)
    L = 'L'     # Boarded (Посадка произведена)
    V = 'V'     # Void (Аннулирован)
    O = 'O'     # Open for Use # noqa
    X = 'X'     # Print Exchange
    Z = 'Z'     # Closed
    I = 'I'     # Irregular operations (Неординарные операции) # noqa
    N = 'N'     # Coupon notification Индикатор «чужих» купонов
    S = 'S'     # Suspended (Приостановлен)
    T = 'T'     # Paper Ticket (Бумажный билет)
    U = 'U'     # Unavailable (Недоступен для использования)

    # Терминальные стадии / окончательные
    TERMINAL_LIST = (
        'R', 'E', 'F', 'P', 'X', 'V', 'T', 'G', 'Z'
    )

    # Доступные статусы для регистрации
    AVAILABLE_FOR_REGISTRATION = (
        'O', 'C', 'A',
    )

    @classmethod
    def terminal_values(cls) -> List["CouponStatus"]:
        """ Терминальные стадии / окончательные в виде членов перечисления"""
        return [
            cls.R,  cls.X,
            cls.E,  cls.V,
            cls.F,  cls.T,
            cls.P,  cls.G,
            cls.Z
        ]

    @classmethod
    def non_terminal_values(cls) -> List["CouponStatus"]:
        """ Не терминальные стадии"""
        return [
            e for e in cls if e not in cls.terminal_values()
        ]


class SsrPassengerType(Enum):
    # инвалиды и пассажиры, их сопровождающие
    DISABLED_PASSENGERS = (
        'ATTN', 'BBR', 'BLND',
        'BUGY', 'CRTC', 'CRTS',
        'DEAF', 'DPNA', 'LEGB',
        'LEGL', 'LEGR', 'MAAS',
        'MEDA', 'SVAN', 'WCBD',
        'WCBW', 'WCHC', 'WCHR',
        'WCHS', 'WCLB', 'WCMP', 'WCOB'
    )

    # Не допущенные к въезду пассажиры
    INADMISSIBLE_PASSENGERS = ('INAD',)

    # Депортированные лица
    DEPORTED_PASSENGERS = ('DEPA', 'DEPU')

    # Несопровождаемые дети
    UNACCOMPANIED_PASSENGERS = ('UMNR', )

    # Сотрудники федеральных органов
    FEDERAL_PASSENGERS = ('FELD', 'SPSV')

    # Дополнительное место для багажа/животного в салоне
    BAGGAGE = ("CBBG", )

    # Пассажир на носилках
    STRETCHER_PASSENGER = ("STCR", )

    SPECIAL_SERVICE_PASSENGERS = ("MAAS", )


class SegmentStatus(Enum):
    """
    Перечисление статусов сегментов
    """
    HK = 'HK'   # confirmed (успешно добавлен в бронирование)
    TK = 'TK'   # confirmed (успешно добавлен в бронирование) (SIRENA only)
    XX = 'XX'   # canceled
    UN = 'UN'   # unable (нет возможности выписать место или место было аннулировано)
    HN = 'HN'   # requested
    LL = 'LL'   # waitlist requested (добавлен в лист ожидания, но еще не подтвержден)
    HL = 'HL'   # waitlisted (добавлен в лист ожидания и подтвержден)
    SA = 'SA'   # standby
    NC = 'NC'   # not controlled
    UC = 'UC'   # rejected

    CONFIRMED_LIST = ('HK', 'TK')


class ServiceStatus(Enum):
    """
    Перечисление статусов услуг
    """
    XX = 'XX'   # canceled
    HI = 'HI'   # active
    HD = 'HD'   # добавлена, не оплачена
    UN = 'UN'   # Услуга не подтверждена
    HK = 'HK'   # HK - добавлена, ждет подтверждения, сначала запрос в АК и если АК соглашается (переводит услугу в HD)
    HN = 'HN'   # requested


class SsrStatus(Enum):
    """
    Перечисление статусов сср
    """
    UN = 'UN'
    HK = 'HK'
    HN = 'HN'
    NN = 'NN'


class FopsCode(Enum):
    CC = "CC"   # банковская карта
    CA = "CA"   # наличные средства
    FF = "FF"   # мили / промокод
    PK = "PK"   # платежное поручение ПП, ПП\ПК
    IN = "IN"   # платежное поручение(invoice)
    VZ = "VZ"   # взаиморасчёт или Ваучер


class SpecialServiceStatus(Enum):
    """
    Перечисление статусов специальных услуг
    """
    HK = 'HK'
    TK = 'TK'
    XX = 'XX'
    UN = 'UN'
    UC = 'UC'
    NO = 'NO'

    # Терминальные стадии / окончательные
    TERMINAL_LIST = (
        'XX', 'UN', 'UC', 'NO'
    )


class OrderStatus(Enum):
    """Перечисление статусов заказа"""
    S = 'S'  # Этот статус заказа проставляется, если никакой другой не подошел, такие заказы будут скипнуты
    X = 'X'  # Заказ отменен (не оплачен).В заказе есть истекший таймлимит, нет билетов, купонов, данных о формах оплаты
    B = 'B'  # Заказ забронирован. В заказе есть неистекший таймлимит, в заказе нет билетов, купонов, данных о оплаты
    T = 'T'  # Заказ оплачен и активен(тикетирован). При этом в заказе есть купоны не в терминальных статусах.
    A = 'A'  # Заказ оплачен и не активен(в архиве). В заказе все купоны в терминальных статусах.


class OWRT(Enum):
    RT = 'RT'   # туда-обратно
    OW = 'OW'   # В одну сторону
    TR = 'TR'   # Трансферный


class PassengerCategory(Enum):
    ADULT = 'ADULT'
    CHILD = 'CHILD'
    INFANT = 'INFANT'
    TEENAGER = 'TEENAGER'


class FareCode(Enum):
    """
    Коды тарифов, по которым можно определить brand_code и brand_name
    """
    MINIMUM = 'LT'        # бывший LIGHT
    OPTIMUM = "STD"       # бывший STANDARD
    OPTIMUM_PLUS = "STR"  # бывший STANDARD
    PREMIUM = 'FL'        # бывший FLEX
    PREMIUM_PLUS = 'PP'
    BUSINESS = 'COMF'     # Евробизнес
    CHARTER = 'CHARTER'
    KINTER = 'KINTER'
    STANDBY = 'SA'
    SUBSIDIZED = 'LTB'   # Субсидированный тариф минимум
    REG = 'REG'          # Вертолет

    TRANSFER = '/TR'
    CORPORATE = '/ZZM'


class BrandCode(Enum):
    """
    Перечисление наименований тарифов
    """
    STANDBY = 'Подсадка'
    OPTIMUM_NEW = 'Оптимум эконом'
    OPTIMUM_CORP = 'Оптимум корпоративный'
    OPTIMUM_PLUS = 'Оптимум эконом'
    MINIMUM_NEW = 'Минимум эконом'
    MINIMUM_CORP = 'Минимум корпоративный'
    MINIMUM_PLUS = 'Минимум эконом'
    PREMIUM_NEW = 'Премиум эконом'
    PREMIUM_CORP = 'Премиум корпоративный'
    PREMIUM_PLUS = 'Премиум плюс'
    PREMIUM_HELI = 'Премиум вертолёт'
    BUSINESS_NEW = 'Бизнес'
    BUSINESS_CORP = 'Бизнес корпоративный'
    COMFORT = 'Комфорт'

    UNKNOWN = 'Неизвестный'


class BrandName(Enum):
    BUSINESS = 'BUSINESS'
    BUSINESS_FLEX = 'BUSINESS_FLEX'
    STANDARD = 'STANDARD'  # Дублирование, нужна ревизия
    STANDART = 'STANDART'  # - = -
    LIGHT = 'LIGHT'
    LIGHT_SA = 'LIGHT_SA'
    COMFORT = 'COMFORT'
    PREFERENTIAL = 'PREFERENTIAL'
    MINIMUM_NEW = 'MINIMUM_NEW'
    MINIMUM_CORP = 'MINIMUM_CORP'
    MINIMUM_PLUS = 'MINIMUM_PLUS'
    OPTIMUM_NEW = 'OPTIMUM_NEW'
    OPTIMUM_CORP = 'OPTIMUM_CORP'
    OPTIMUM_PLUS = 'OPTIMUM_PLUS'
    PREMIUM_NEW = 'PREMIUM_NEW'
    PREMIUM_CORP = 'PREMIUM_CORP'
    PREMIUM_PLUS = 'PREMIUM_PLUS'
    PREMIUM_HELI = 'PREMIUM_HELI'
    BUSINESS_NEW = 'BUSINESS_NEW'   # евро бизнес
    BUSINESS_CORP = 'BUSINESS_CORP'
    STANDBY = 'STANDBY'
    UTAIR = 'UTAIR'

    UNKNOWN = 'UNKNOWN'


class UtairCabinClass(Enum):
    # Наши коды классов мест посадки
    ECONOMY = "Y"
    BUSINESS = "C"


class ExternalCabinClassCodes(Enum):
    """
    Эконом:
    "Y" - код из SIRENA
    "E" - код из TAIS
    "F" - код из SIRENA и TAIS
    Бизнес:
    "B" - код из TAIS
    "C" - код из SIRENA
    """
    ECONOMY = ("Y", "E", "F")
    BUSINESS = ("B", "C")


class DocTypes(Enum):
    """
    Типы документов(могут быть как у пользователя, так и у пассажира)
    """
    cyrillic_types_map = {
        'БП': 'BP',     # "ПАСПОРТ ПРИ РЕГИСТРАЦИИ"
        'КН': 'CN',
        'ПС': 'PS',     # "ПАСПОРТ"
        'ПСП': 'PSP',   # "ЗАГРАНИЧНЫЙ ПАСПОРТ ГРАЖДАНИНА РФ"
        'СПУ': 'SPU',   # "ВРЕМЕННОЕ УДОСТ ЛИЧНОСТИ ПРИ УТРАТЕ ИЛИ ЗАМЕНЕ ПС"
        'СР': 'SR',     # "СВИДЕТЕЛЬСТВО О РОЖДЕНИИ"
        'УД': 'UD',     # "УДОСТОВЕРЕН ДЕПУТАТА СОВЕТА ФЕДЕРАЦИЙ ИЛИ ГОС ДУМЫ"
        'УДЛ': 'UDL',   # "УДОСТОВЕРЕНИЕ ЛИЧНОСТИ ОФИЦЕРА ПРАПОРЩИКА МИЧМАНА"
        'ВБ': 'VB',     # "ВОЕННЫЙ БИЛЕТ ДЛЯ ПРОХОДЯЩ СЛУЖБУ ИЛИ ПО КОНТРАКТУ
        'ВЖ': 'VV',     # "ВИД НА ЖИТЕЛЬСТВО"
        'ВЖН': 'VZN',   # "ВИД НА ЖИТЕЛЬСТВО"
        'ЗА': 'ZA',     # "ЗАГРАН ПАСПОРТ ГРАЖДАНИНА ЛЮБОЙ СТРАНЫ  КРОМЕ РФ"
        'НП': 'NP',     # "НАЦИОНАЛЬНЫЙ ПАСПОРТ"
        'СП': 'SP',     # "СЛУЖЕБНЫЙ ПАСПОРТ"
        'ДП': 'DP',     # "ДИПЛОМАТИЧЕСКИЙ ПАСПОРТ"
        'ПМ': 'PM',     # "ПАСПОРТ МОРЯКА УДОСТОВЕРЕНИЕ ЛИЧНОСТИ МОРЯКА"
        'СВВ': 'CVV',   # "СВИДЕТЕЛЬСТВО НА ВОЗВРАЩЕНИЕ В СТРАНЫ СНГ"
        'SVV': 'SVV',   # "СВИДЕТЕЛЬСТВО НА ВОЗВРАЩЕНИЕ В СТРАНЫ СНГ Latin"
        'СПО': 'SPO',   # "СПРАВКА ОБ ОСВОБОЖДЕНИИ ДЛЯ ОСВОБОДИВШИХСЯ ЛИЦ"
        'ВУЛ': 'VUL',   # "ВРЕМЕННОЕ УДОСТОВЕРЕНИЕ ЛИЧНОСТИ"
        'МС': 'MS',     # "МЕДИЦИНСКОЕ СВИДЕТЕЛЬСТВО О РОЖДЕНИИ"
        'БГ': 'BG',     # "УДОСТОВЕРЕНИЕ ЛИЧНОСТИ ЛИЦА БЕЗ ГРАЖДАНСТВА"
        'ПР': 'PR',     # "ПАСПОРТ ФОРМЫ СССР"
        'УП': 'UP',     # "ПАСПОРТ ГРАЖДАНИНА УКРАИНЫ"
        'ЗС': 'ZC',     # "ЗАГРАНИЧНЫЙ ПАСПОРТ"
        'ЗБ': 'ZB',     # "ЗАГРАН ПАСПОРТ ГРАЖДАНИНА РЕСПУБЛИКИ ТАДЖИКИСТАН"
        'СФ': 'SF',     # "УДОСТ ЧЛЕНА СОВЕТА ФЕДЕРАЦИИ ФЕДЕРАЛЬН СОБРАН РФ"
    }

    BP = "bp"
    PS = "ps"
    PSP = "psp"
    ZA = "za"
    NP = "np"
    VB = "vb"
    BG = 'bg'
    CVV = "cvv"
    VV = "vv"
    SPU = "spu"
    VUL = "vul"
    SR = "sr"
    DP = "dp"
    SP = "sp"
    UDL = "udl"
    PM = "pm"
    SPO = "spo"
    UD = "ud"
    SVV = "svv"
    VZH = "vzh"
    UP = "up"
    MS = "ms"
    PR = "ПР"
    ZC = "zc"
    ZB = "zb"
    SF = 'sf'


class DiscountCodeTypes(Enum):
    """
    Типы кода скидок
    """
    EGO_PROMO_CODE = 'ego_promocode'
    CODE = 'code'

    @classmethod
    def map_code(cls, code: Optional[str]) -> str:
        switch = {
            cls.EGO_PROMO_CODE.value: cls.CODE.value,
            cls.CODE.value: cls.CODE.value
        }
        code = switch.get('code') if switch.get('code') else code
        return code.upper() if isinstance(code, str) else code


class BookingCartDiscountTypes(Enum):
    """
    Типы скидок из корзины букинга
    """
    UserComarchMilesComponentItem = 'UserComarchMilesComponentItem'
    UserPromoCodeComponentItem = 'UserPromoCodeComponentItem'
    PersonalDiscountComponentItem = 'PersonalDiscountComponentItem'


class ChangePDRequestStatuses(Enum):
    """
    Статусы заявки на изменение перс данных пассажира
    """
    AUTHORIZED = 'authorized'
    PENDING = 'registered'
    PAID = 'not_acknowledged'
    DONE = 'acknowledged'
    UNPAID = 'not_authorized'
    CANCELED = 'canceled'
    FAILED = 'failed'


class UTairChangePDReqStatuses(Enum):
    """
    Наши статусы заявки на изменение перс данных пассажира
    """
    PENDING = 'pending'
    PAID = 'paid'
    DONE = 'done'
    UNPAID = 'unpaid'

    # Терминальные стадии / окончательные
    TERMINAL_LIST = ('paid', 'done', 'unpaid')


change_pd_req_statuses_mapping = {
    ChangePDRequestStatuses.PENDING.value: UTairChangePDReqStatuses.PENDING.value,
    ChangePDRequestStatuses.AUTHORIZED.value: UTairChangePDReqStatuses.PENDING.value,

    ChangePDRequestStatuses.PAID.value: UTairChangePDReqStatuses.PAID.value,
    ChangePDRequestStatuses.DONE.value: UTairChangePDReqStatuses.DONE.value,
    ChangePDRequestStatuses.UNPAID.value: UTairChangePDReqStatuses.UNPAID.value,

    ChangePDRequestStatuses.CANCELED.value: UTairChangePDReqStatuses.UNPAID.value,
    ChangePDRequestStatuses.FAILED.value: UTairChangePDReqStatuses.UNPAID.value
}


class StrEnum(Enum):
    def __str__(self) -> str:
        return self.value


class Agencies(Enum):
    UT_SITE = ('02TUM', '02ТЮМ')


class ServiceRFISCs(Enum):
    OBT = '0BT'
    OBS = '0BS'
    REFUND = 'VZR'


class SpecialServiceTypes(Enum):
    PETC = 'ЖВТК'
    AVIH = 'ЖВТБ'


class SpecServiceTypeDescr(Enum):
    PETC = 'КОШКА/СОБАКА 10КГ МЯГКАЯ ПЕРЕНОСКА 55Х40Х25'
    AVIH = 'КОШКА/СОБАКА/ПТИЦА ВЕС ДО 20 КГ КЛЕТКА ДО 203 СМ СУМ'


service_ssr_map = {
    ServiceRFISCs.OBT.value: SpecServiceTypeDescr.PETC.name,
    ServiceRFISCs.OBS.value: SpecServiceTypeDescr.AVIH.name
}


class SsrsSsr(Enum):
    """
    Варианты ssr
    """
    PDTS = 'PDTS'
    PETC = 'PETC'
    FQTV = 'FQTV'  # Frequent Traveller
    CKIN = 'CKIN'
    DEGR = 'DEGR'
    OTHS = 'OTHS'


class SsrsText(Enum):
    """
    Текст для ssr'ов
    """
    UPGRADE = 'ВЫНУЖД АПГРЕЙД'
    DOWNGRADE = 'ПАССАЖИР ЛО'


class ExchangeStatus(StrEnum):
    """Статусы обмена"""
    NEW = 'NEW'
    PENDING = 'PENDING'
    PROCESSING = 'PROCESSING'
    WAIT_RECEIPT = 'WAIT_RECEIPT'  # Ожидание квитанций, т.е. обмен произведен, но квитанции еще не готовы
    COMPLETE = 'COMPLETE'
    CANCELED = 'CANCELED'
    EXPIRED = 'EXPIRED'
    ERROR = 'ERROR'

    def is_new(self) -> bool:
        return self == self.NEW

    def is_pending(self) -> bool:
        return self == self.PENDING

    def is_error(self) -> bool:
        return self == self.ERROR

    def is_canceled(self) -> bool:
        return self in [
            self.CANCELED,
            self.EXPIRED,
            self.ERROR,
        ]

    def is_processing(self) -> bool:
        return self in [
            self.PROCESSING,
            self.WAIT_RECEIPT,
            self.COMPLETE,
        ]

    def with_exchangeable_services(self) -> bool:
        return self in [
            self.NEW,
            self.PENDING,
            self.PROCESSING,
        ]

    def is_complete(self):
        return self == self.COMPLETE

    def is_terminal(self) -> bool:
        return self == self.COMPLETE or self.is_canceled()

    def is_wait_receipt(self) -> bool:
        return self == self.WAIT_RECEIPT

    def allowed(self, new: 'ExchangeStatus') -> bool:
        if new.is_canceled():
            return True

        flow = {
            self.NEW: [self.PENDING],
            self.PENDING: [self.PROCESSING],
            self.PROCESSING: [self.COMPLETE, self.WAIT_RECEIPT],
            self.WAIT_RECEIPT: [self.COMPLETE],
        }

        return new in flow.get(self, [])


class ExchangeOrderState(StrEnum):
    STARTED = 'STARTED'
    CONFIRMED = 'CONFIRMED'
    CANCELED = 'CANCELED'


class ExchangeFlow(StrEnum):
    AUTO = 'AUTO'
    MANUAL = 'MANUAL'


class RefundServiceStatus(StrEnum):
    WAITING = 'WAITING'
    ERROR = 'ERROR'
    COMPLETE = 'COMPLETE'


class LoyaltyStatus(Enum):
    GOLD = 'GOLD'
    SILVER = 'SILVER'
    BRONZE = 'BRONZE'
    BASIC = 'BASIC'
    UNDEFINED = 'UNDEFINED'


class TypeCode(Enum):
    """
    Шаблон письма
    """
    SEATS_RELEASED = 'notify_seats_released'
    SPECIAL_SERVICE_SSR_NOT_CONFIRMED = 'not_confirmed_ssr'
    SPECIAL_SERVICE_SSR_CONFIRMED = 'confirm_ssr'


class JiraLabels(Enum):
    """
    Тема заявки
    """
    SPECIAL_SERVICE_DENIED = "отказ_спец_обслуживания"
    RELEASE_SEATS_FAILED = "необходимо_сдать_места"
