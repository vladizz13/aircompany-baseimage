from event_engine import PublishableEvent


class FlightsAircraftBortChangedEvent(PublishableEvent):
    topic = "utair.flights.aircraft-bort-changed.v1"
    is_internal = True

    def serialize(self):
        ev = {
            'type': str(self.__class__.__name__),
            'data': self.__dict__,
        }
        ev["data"]["event_key"] = None
        return ev
