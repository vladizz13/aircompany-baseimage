from event_engine import PublishableEvent


class OrderBookedEvent(PublishableEvent):
    topic = "utair.booking.new_order_notify.v1"
    is_internal = True

    def serialize(self):
        ev = {
            'type': str(self.__class__.__name__),
            'data': self.__dict__,
        }
        ev["data"]["event_key"] = None
        return ev
