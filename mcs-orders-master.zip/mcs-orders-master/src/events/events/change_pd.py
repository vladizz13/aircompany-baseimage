from event_engine import PublishableEvent


class PaymentNotifyEvent(PublishableEvent):
    """
    Событие обновления заказа
    """
    topic = "utair.payments.notify.v1"
