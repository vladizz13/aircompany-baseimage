from event_engine import PublishableEvent
from mcs_payments_client.event import BasePaymentEvent


class PaymentEvent(BasePaymentEvent, PublishableEvent):
    """
    Событие оплаты
    """
    is_internal = True
    topic = "utair.payments.orders.exchange.v1"

    def serialize(self) -> dict:
        data = super().serialize()
        data['data']['event_key'] = data['data']['event_key'].decode('utf-8')
        return data
