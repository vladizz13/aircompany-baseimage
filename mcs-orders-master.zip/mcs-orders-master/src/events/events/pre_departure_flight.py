from event_engine import PublishableEvent


class FlightsPreDepartureEvent(PublishableEvent):
    topic = "utair.flights.pre-departure.v1"

    def serialize(self) -> dict:
        # TODO: Костыль, в async event engine по дефолту ключ события байт. В синхронном мы ожидаем
        #       строку либо None
        ev = {
            'type': str(self.__class__.__name__),
            'data': self.__dict__,
        }
        ev["data"]["event_key"] = None
        return ev
