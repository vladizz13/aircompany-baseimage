from typing import Optional, Any
from event_engine import PublishableEvent


class RefundOrderEvent(PublishableEvent):
    """
    Отправка заказа для отмены билета в кафку
    """
    topic = 'utair.orders.refunds.v1'
    is_internal = False

    def __init__(self, data, *args, **kwargs):
        super(RefundOrderEvent, self).__init__(data, *args, **kwargs)

    def __get_event_key__(self, data: Any) -> Optional[str]:
        return data.get('data', {}).get('order_uuid', None)
