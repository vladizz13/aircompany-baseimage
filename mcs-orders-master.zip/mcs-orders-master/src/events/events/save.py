"""
Внутренние события приложения
"""
from typing import Union, Any
from event_engine import PublishableEvent


class CreateOrderEvent(PublishableEvent):
    """
    Событие сохранения заказа
    """
    topic = 'utair.orders.create.v1'

    def __init__(self, data, *args, **kwargs):
        super(CreateOrderEvent, self).__init__(data, *args, **kwargs)

    def __get_event_key__(self, data: Any) -> Union[str, None]:
        return data.get('data', {}).get('order_uuid', None)


class UpdateOrderEvent(PublishableEvent):
    """
    Событие обновления заказа
    """
    topic = 'utair.orders.update.v1'

    def __init__(self, data, *args, **kwargs):
        super(UpdateOrderEvent, self).__init__(data, *args, **kwargs)

    def __get_event_key__(self, data: Any) -> Union[str, None]:
        return data.get('data', {}).get('order_uuid', None)


class SendOrderToMonoAppEvent(PublishableEvent):
    """
    Послать заказ в моноапп через кафку
    """
    topic = 'utair.orders.mono_app_retranslation.v1'
    is_internal = False

    def __init__(self, data, *args, **kwargs):
        super(SendOrderToMonoAppEvent, self).__init__(data, *args, **kwargs)

    def __get_event_key__(self, data: Any) -> Union[str, None]:
        return data.get('data', {}).get('order_uuid', None)
