from domain.types import GDS
from event_engine import Event


class SplitOrderEvent(Event):
    """
    Событие зафиксированного сплита
    """

    @property
    def rloc(self) -> str:
        return self.data.get('rloc')    # noqa

    @property
    def last_name(self) -> str:
        return self.data.get('last_name')   # noqa

    @property
    def rloc_with_host(self) -> str:
        return f"{self.rloc}/{GDS.SIRENA.value}"
