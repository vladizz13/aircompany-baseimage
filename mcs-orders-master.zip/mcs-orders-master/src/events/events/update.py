from typing import List
from event_engine import Event


class DeferredUpdateOrderEvent(Event):
    """
    Событие обновления заказа в фоне, после поиска пользователем

    data: {
        'orders_to_update': [str[order_uuid]],
    }
    """

    def get_orders(self) -> List[str]:
        return self.data.get('orders_to_update', [])
