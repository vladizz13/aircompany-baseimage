from event_engine import Observer
from datetime import datetime
from use_cases.orders.events.aircraft_bort_changed.aircraft_bort_changed_request import AircraftBortChangedRequest
from use_cases.orders.events.aircraft_bort_changed.aircraft_bort_changed_use_case import AircraftBortChangedUseCase
from adapter.astra_adapter import AstraInternalAdapter
from events.events.aircraft_bort_changed import FlightsAircraftBortChangedEvent
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from libs.db_gateway import get_db_gateway
from domain import DomainOrder
from adapter.monoapp.monoapp_adapter import MonoAppAdapter


class FlightsAircraftBortChangedHandler(Observer):
    observer_id = "__FlightsAircraftBortChangedHandler__"

    def handle_event(self, event: FlightsAircraftBortChangedEvent) -> None:
        event_data = event.data # noqa

        departure_time = event_data["departure_time_local_plan"]
        event_data["departure_time_local_plan"] = datetime.fromisoformat(departure_time)

        request: AircraftBortChangedRequest = AircraftBortChangedRequest(**event_data)
        use_case: AircraftBortChangedUseCase = AircraftBortChangedUseCase(
            order_repo=GenericMongoRepository(
                instance=DomainOrder,
                gateway=get_db_gateway()
            ),
            astra_adapter=AstraInternalAdapter(),
            monoapp_adapter=MonoAppAdapter()
        )

        res = use_case.execute(request=request)
        return res.value
