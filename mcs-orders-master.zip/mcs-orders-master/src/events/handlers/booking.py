import logging
from time import time
from uuid import uuid4
from event_engine import Observer

from domain import DomainOrder
from events.events.booking import OrderBookedEvent
from adapter.sirena_adapter import SirenaInternalAdapter
from libs.db_gateway import get_db_gateway
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.events.special_services.base_special_services_use_case import RedisSpecialServicesUseCase
from use_cases.orders.exceptions.user import OrderNotFoundError
from domain.types import TransactionSource, SsrPassengerType

logger = logging.getLogger('OrderBookedHandler')


class OrderBookedHandler(Observer):
    observer_id = "__OrderBookedHandler__"

    def handle_event(self, event: OrderBookedEvent) -> None:
        event_data = event.data # noqa

        rloc: str = event_data["rloc"] # noqa
        last_name: str = event_data["last_name"] # noqa

        logger.info(f"New order from booking event has been received {rloc=} {last_name=}")
        if not all((
            rloc,
            last_name
        )):
            return None

        saved_order: DomainOrder = self.save_from_sirena(rloc=rloc, last_name=last_name)
        self.disabled_passengers(order=saved_order)

    @staticmethod
    def save_from_sirena(rloc: str, last_name: str) -> DomainOrder:
        sirena_adapter: SirenaInternalAdapter = SirenaInternalAdapter()
        sirena_raw_order = sirena_adapter.search_order(rloc=rloc, last_name=last_name)
        if not sirena_raw_order:
            raise OrderNotFoundError()

        internal_order_adapter: InternalOrderAdapter = InternalOrderAdapter()
        response = internal_order_adapter.save(
            raw_order=sirena_raw_order,
            provider=TransactionSource.SIRENA_GRS.value,
            received=time(),
            message_id=str(uuid4()),
            deferred_save=False,
            return_full_response=True
        )
        if not response:
            raise response.errors[0]
        return response.saved_order

    @staticmethod
    def disabled_passengers(order: DomainOrder):
        for ssr in order.data.ssrs:
            if ssr.ssr not in SsrPassengerType.SPECIAL_SERVICE_PASSENGERS.value:
                continue

            redis_adapter = RedisSpecialServicesUseCase(redis=get_db_gateway("redis"))
            _key = redis_adapter.get_key()
            _value = redis_adapter.create_set_value(order_uuid=order.data.order_uuid)
            redis_adapter.redis_set_value(_key, _value)
