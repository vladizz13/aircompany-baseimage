import logging

from event_engine import Observer
from mcs_payments_client.event import PaymentEventData

from libs.db_gateway import get_db_gateway

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

from domain import DomainOrder
from domain.exchange import DomainExchange

from events.events.payments import PaymentEvent
from libs.messages.telegram import TelegramMessenger

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_exchange_order_adapter import InternalExchangeOrderAdapter

from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.settings.settings import TELEGRAM_JETTY_CONFIG

logger = logging.getLogger('subscribers::payment')


class ExchangePaymentSubscriber(Observer):
    observer_id = "__ExchangePaymentSubscriber__"

    def handle_event(self, event: PaymentEvent) -> None:
        data: PaymentEventData = event.data

        if 'exchange_uuid' not in data.free_data:
            logger.info('Not an exchange payment')
            return

        logger.info(f'Starting payment event processing for {data.free_data["exchange_uuid"]} exchange')

        order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)
        exchange_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainExchange)

        internal_order_adapter = InternalOrderAdapter()
        internal_exchange_order_adapter = InternalExchangeOrderAdapter()
        internal_sirena_adapter = SirenaInternalAdapter()
        internal_payments_adapter = PaymentsInternalAdapter()

        from use_cases.orders.exchange.payment.payment_request import ExchangePaymentRequest
        from use_cases.orders.exchange.payment.payment_use_case import ExchangePaymentUseCase

        request = ExchangePaymentRequest(
            exchange_uuid=data.free_data['exchange_uuid'],
            transaction_uuid=data.transaction_uuid,
            state=data.state,
            meta=data.payment_meta,
        )

        use_case = ExchangePaymentUseCase(
            order_repo=order_repo,
            exchange_repo=exchange_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
            internal_payments_adapter=internal_payments_adapter,
            internal_exchange_order_adapter=internal_exchange_order_adapter,
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        )

        result = use_case.execute(request)

        if not result:
            logger.exception(result.errors[0])
            return

        logger.info(f'Done payment event processing for {data.free_data["exchange_uuid"]} exchange')
