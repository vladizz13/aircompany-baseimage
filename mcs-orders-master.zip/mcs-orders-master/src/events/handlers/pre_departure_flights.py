import logging

from event_engine import Observer
from datetime import datetime
from domain import DomainOrder
from base.exception import ApplicationError
from events.events.pre_departure_flight import FlightsPreDepartureEvent
from libs.db_gateway import get_db_gateway
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

logger = logging.getLogger('PreDepartureFlightsHandlers')


class PreDepartureFlightsHandlers(Observer):
    observer_id = "__FlightsPreDepartureEvent__"

    def handle_event(self, event: FlightsPreDepartureEvent) -> None:
        event_data = event.data # noqa
        """
        {
            'airline': 'UT',
            'flight_number': 138,
            'departure_time': '2022-10-22T13:00:00Z', # NB! дата в UTC
            'offset': 7200
        }
        """
        if event_data["offset"] == 7200:
            self.get_orders_to_pdts_ssr(event_data=event_data)
        if event_data["offset"] == 21600:
            self.degr_ssrs(event_data=event_data)

    @staticmethod
    def get_orders_to_pdts_ssr(event_data):
        from use_cases.orders.events.ssrs.pdts.request import PdtsSsrRequest
        from use_cases.orders.events.ssrs.pdts.usecase import PdtsSsrUseCase
        from adapter.sirena_adapter import SirenaInternalAdapter
        from rest.interfaces.internal_order_adapter import InternalOrderAdapter
        from repositories.mongo.mongo_generic_repository import GenericMongoRepository
        from libs.db_gateway import get_db_gateway
        from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter

        departure_time = event_data["departure_time"]
        # NB! дата в UTC
        date_obj = datetime.fromisoformat(departure_time)
        flight_number = str(event_data["flight_number"])

        request: PdtsSsrRequest = PdtsSsrRequest(flight_number=flight_number, departure_time=date_obj)
        use_case: PdtsSsrUseCase = PdtsSsrUseCase(
            sirena_adapter=SirenaInternalAdapter(),
            order_repo=GenericMongoRepository(
                instance=DomainOrder,
                gateway=get_db_gateway()
            ),
            internal_order_adapter=InternalOrderAdapter,
            redis_adapter=RedisSsrsAdapter(
                gateway=get_db_gateway('redis')
            ),
        )

        try:
            use_case.execute(request=request)
        except (ApplicationError, IndexError) as e:
            logger.exception(f"Unable to get orders pdts ssr, reason: {str(e)}")
            raise

    @staticmethod
    def degr_ssrs(event_data):
        from use_cases.orders.events.ssrs.degr.usecase import DegrSsrUseCase
        from use_cases.orders.events.ssrs.degr.request import DegrSsrRequest
        from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter
        from adapter.sirena_adapter import SirenaInternalAdapter

        departure_time = event_data["departure_time"]
        date_obj = datetime.fromisoformat(departure_time)
        flight_number = str(event_data["flight_number"])

        request = DegrSsrRequest(flight_number=flight_number, departure_time=date_obj)

        res = DegrSsrUseCase(
            sirena_adapter=SirenaInternalAdapter(),
            order_repo=GenericMongoRepository(
                instance=DomainOrder,
                gateway=get_db_gateway()
            ),
            internal_order_adapter=InternalOrderAdapter,
            redis_adapter=RedisSsrsAdapter(
                gateway=get_db_gateway('redis')
            ),
        )
        res.execute(request)
