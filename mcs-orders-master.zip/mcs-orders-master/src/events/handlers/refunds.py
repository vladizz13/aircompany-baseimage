from event_engine import Observer
from events.events.refunds import RefundOrderEvent


class RefundHandler(Observer):
    observer_id = '__RefundOrderPublisher__'

    def handle_event(self, event: RefundOrderEvent):
        pass
