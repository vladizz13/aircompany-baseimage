from typing import Dict, List
from event_engine import Observer

from adapter.monoapp import MonoAppAdapter
from base.exception import ApplicationError
from domain import DomainOrder
from domain.types import TransactionSource
from rest.applications.celery_app.tasks.add_ssrs import dispatch_add_ssrs_events
from rest.applications.celery_app.bootstrap import get_celery_application
from events.events.save import CreateOrderEvent, UpdateOrderEvent, SendOrderToMonoAppEvent
from libs.db_gateway import get_db_gateway
from rest.settings import settings


class CreateOrderSubscriber(Observer):
    """
    Обработчик события сохранения заказа
    """
    observer_id = '__CreateOrderSubscriber__'

    def handle_event(self, event: CreateOrderEvent):
        from rest.applications.celery_app.tasks.update_from_sirena import update_from_sirena_grs
        order: Dict = getattr(event, 'data')
        order: DomainOrder = DomainOrder.deserialize(order)

        if order.meta.created.provider != TransactionSource.SIRENA_GRS.value:
            # Обовляем из сирены, если первая транзакция не из сирены
            update_from_sirena_grs.delay(str(order.data.order_uuid))


class UpdateOrderSubscriber(Observer):
    """
    Обработчик события обновления заказа
    """
    observer_id = '__UpdateOrderSubscriber__'
    SSR_DISPATCH_COUNTDOWN = 60 * 10

    def handle_event(self, event: UpdateOrderEvent):
        order: Dict = getattr(event, 'data')
        order: DomainOrder = DomainOrder.deserialize(order)

        self.add_ssrs_to_order(order)
        self.send_order_to_mono_app(order)

    @staticmethod
    def send_order_to_mono_app(order: DomainOrder):
        """
        Этот эвент сработает при сохранении нового заказа либо обновления существующего
        Юзкейс проверит нужно ли отсылать заказ в моноапп и если нужно, смапит его и пошлет через
        кафку
        """
        from use_cases.orders.events.retranslation.send_to_monoapp_request import SendOrderToMonoAppRequest
        from use_cases.orders.events.retranslation.send_to_monoapp_use_case import SendOrderToMonoAppUseCase
        from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue

        if not settings.STREAM_ORDERS_TO_MONO_APP:
            return

        request: SendOrderToMonoAppRequest = SendOrderToMonoAppRequest(
            order=order,
            send_to_mono_app=settings.STREAM_ORDERS_TO_MONO_APP
        )
        use_case = SendOrderToMonoAppUseCase(
            mono_app_adapter=MonoAppAdapter(),
            save_order_queue=SaveOrdersQueue(
                gateway=get_db_gateway(label='redis'),
            )
        )
        try:
            use_case.execute(request=request)
        except ApplicationError:
            # Всё логируется юзкейсе, здесь ничего не делаем
            pass

    @classmethod
    def add_ssrs_to_order(cls, order: DomainOrder):
        """
        Добавляем ssr заказу, если нужно
        """
        celery_app = get_celery_application()
        # Если таска находится в очереди и ожидает выполнения, то отменяем её по task_id
        # ставим в ожидание новую таску, которая будет выполнена по истечении 10 мин
        # после сохранения последней транзакции
        celery_app.control.revoke(cls.get_prev_task_id(order))
        dispatch_add_ssrs_events.apply_async(
            (str(order.data.order_uuid), ),
            countdown=cls.SSR_DISPATCH_COUNTDOWN,
            task_id=cls.get_current_task_id(order),
            # Даём на 2 минуты больше, чем countdown, мы отменим такие таски сами,
            # Однако celery у нас работает stateless и при перезапуске мы можем
            # запустить ранее отмененные таски, перестраховываемся и ставим ttl
            expires=(cls.SSR_DISPATCH_COUNTDOWN + (60 * 2))
        )

    @staticmethod
    def __was_updated_from_sirena__(order: DomainOrder) -> bool:
        providers: List[str] = [order.meta.created.provider]
        providers.extend([u.provider for u in order.meta.updated])
        return TransactionSource.SIRENA_GRS.value in providers

    @classmethod
    def get_base_dispatch_id(cls, order: DomainOrder) -> str:
        return f'dispatch-ssrs-{order.data.rloc}'

    @classmethod
    def get_current_task_id(cls, order: DomainOrder):
        """
        Получаем актуальный (следующий) task_id
        """
        updates = [order.meta.created]
        updates.extend(order.meta.updated)
        return f'{cls.get_base_dispatch_id(order)}-{len(updates)}'

    @classmethod
    def get_prev_task_id(cls, order: DomainOrder):
        """
        Получаем предыдущий task_id для отмены
        """
        updates = [order.meta.created]
        updates.extend(order.meta.updated)
        return f'{cls.get_base_dispatch_id(order)}-{len(updates) - 1}'


class MonoAppOrderRetranslationSubscriber(Observer):
    observer_id = '__MonoAppOrderRetranslationSubscriber__'

    def handle_event(self, event: SendOrderToMonoAppEvent):
        pass
