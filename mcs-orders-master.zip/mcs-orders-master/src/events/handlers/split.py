from time import time
from uuid import uuid4
from typing import Dict, List
from base.exception import ApplicationError
from domain.types import TransactionSource
from event_engine import Observer
from events.events import SplitOrderEvent
from libs.db_gateway import get_db_gateway
from rest.settings import settings


class SplitOrderSubscriber(Observer):
    """
    Обработчик зафиксированного сплита
    Обновит и синхронизирует требуемый заказ в сирене
    """
    observer_id = '__SplitOrderSubscriber__'

    def __init__(self):
        super().__init__()

    def handle_event(self, event: SplitOrderEvent):
        self.update_order(event)

    @staticmethod
    def update_order(event: SplitOrderEvent):
        from adapter.tais_adapter import TaisInternalAdapter
        from rest.interfaces.internal_order_adapter import InternalOrderAdapter
        from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue

        if not settings.HANDLE_SPLITS:
            return

        adapter = TaisInternalAdapter()
        orders: List[Dict] = adapter.search_orders(
            rloc=event.rloc,
            last_name=event.last_name,
            sirena_sync=True,
            check_booking=True
        )
        if not orders:
            return
        queue = SaveOrdersQueue(
            gateway=get_db_gateway(label='redis'),
        )
        # Если очередь активна - закинем в нее, если нет, сохраним сразу
        deferred = queue.queue_is_active(event.rloc_with_host) and settings.ENABLE_DEFERRED_SAVE

        for order in orders:
            try:
                InternalOrderAdapter.save(
                    raw_order=order,
                    provider=TransactionSource.TAIS.value,
                    received=time(),
                    message_id=str(uuid4()),
                    deferred_save=deferred,
                    return_full_response=True
                )
            except ApplicationError:
                pass
