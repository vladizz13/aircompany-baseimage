import time
from typing import List
from base.exception import ApplicationError
from event_engine import Observer
from events.events import DeferredUpdateOrderEvent
from domain import DomainOrder
from domain.order.meta.transaction_source import DomainTransactionSource
from domain.types import TransactionSource, OrderStatus
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from libs.db_gateway import get_db_gateway
from redis import Redis
from repositories.query_builders.order import OrdersQueryBuilder


class DeferredUpdateOrderSubscriber(Observer):
    """
    Обработчик события обновления заказа в фоне, после поиска пользователем

    data: {
        'orders_to_update': [str[order_uuid]],
    }

    """
    TIME_DELTA = 60 * 60  # 1 час
    CACHE_TTL = TIME_DELTA

    observer_id = '__DeferredUpdateOrderSubscriber__'

    def __init__(self):
        super().__init__()
        self.__cache: Redis = get_db_gateway('redis')

    def handle_event(self, event: DeferredUpdateOrderEvent):
        self.__update_orders__(event)

    def __update_orders__(self, event: DeferredUpdateOrderEvent):
        from rest.interfaces.internal_order_adapter import InternalOrderAdapter
        adapter = InternalOrderAdapter()

        order_repo: GenericMongoRepository = GenericMongoRepository(
            gateway=get_db_gateway(),
            instance=DomainOrder
        )

        orders: List[DomainOrder] = order_repo.list(
            spec=OrdersQueryBuilder.get_by_order_uuid_multiple(
                order_uuids=event.get_orders()
            )
        )
        for order in orders:
            if not self.__is_update_needed__(order):
                continue
            try:
                adapter.update_from_sirena_grs(order.data.order_uuid)
            except ApplicationError:
                # Логирование происходит в SirenaGRSForceUpdateUseCase, здесь просто не падаем
                pass

    def __is_update_needed__(self, order: DomainOrder) -> bool:
        """
        Заказ должен быть обновлен, только если он не был обновлен в течении self.TIME_DELTA от SirenaGRS
        Либо вообще не был обновлен от этого провайдера и рлок не находится в кэше
        """
        if order.data.status in [
            OrderStatus.X.value, OrderStatus.A.value
        ]:
            return False

        if self.__is_cached__(rloc=order.data.rloc):
            return False

        transactions: List[DomainTransactionSource] = list()
        transactions.append(order.meta.created)
        transactions.extend(order.meta.updated)

        sirena_grs_transaction: List[DomainTransactionSource] = [
            t for t in transactions if t.provider == TransactionSource.SIRENA_GRS.value
        ]
        if not sirena_grs_transaction:
            return True

        sirena_grs_transaction.sort(key=lambda x: x.date)
        last_transaction: DomainTransactionSource = sirena_grs_transaction[-1]

        if int(last_transaction.date) <= (int(time.time()) - self.TIME_DELTA):
            return True

        return False

    def __is_cached__(self, rloc: str) -> bool:
        """
        Кэшируем рлоки с TTL (self.CACHE_TTL)
        """
        cache_prefix: str = 'sirena-grs-update-{}'
        cache_key: str = cache_prefix.format(rloc)
        if self.__cache.get(cache_key):
            return True
        self.__cache.set(name=cache_key, value=1, ex=self.CACHE_TTL)
        return False
