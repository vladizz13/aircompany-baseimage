import logging

from event_engine import Observer
from pymongo.database import Database

from adapter.monoapp import MonoAppAdapter
from domain.pd_changes import DomainPDChanges
from events.events.change_pd import PaymentNotifyEvent
from libs.db_gateway import get_db_gateway
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

logger = logging.getLogger('http-requests')


class PaymentNotifyHandler(Observer):
    observer_id = "__PaymentNotifyHandler__"

    def handle_event(self, event: PaymentNotifyEvent) -> None:
        if event.data.get("type") != "change_pd":
            return

        from rest.interfaces.internal_order_adapter import InternalOrderAdapter
        from adapter.sirena_adapter import SirenaInternalAdapter
        from use_cases.orders.user.change_personal_data.submit_request.request import UpdateChangePDReqStatusObj
        from use_cases.orders.user.change_personal_data.submit_request.update_status_use_case import (
            UpdateChangePDReqStatusUseCase,
        )

        logger.debug(f'change_pd_event data is:\n{event.data}')
        notify = event.data['data']['notify'][-1]
        payment_id = notify['order']['number']
        payment_status = notify['status']

        mongodb: Database = get_db_gateway()

        req_obj: UpdateChangePDReqStatusObj = UpdateChangePDReqStatusObj(payment_id, payment_status)
        use_case: UpdateChangePDReqStatusUseCase = UpdateChangePDReqStatusUseCase(
            pd_changes_repo=GenericMongoRepository(gateway=mongodb, instance=DomainPDChanges),
            mono_app_adapter=MonoAppAdapter(),
            internal_order_adapter=InternalOrderAdapter,
            sirena_adapter=SirenaInternalAdapter()
        )

        use_case.execute(request=req_obj)
