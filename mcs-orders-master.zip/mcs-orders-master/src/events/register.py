from event_engine import get_event_manager
from event_engine.exceptions import BaseEventEngineError, ObserverAlreadyRegistered
from libs.db_gateway import get_db_gateway
from pymongo.database import Database
import logging

logger = logging.getLogger('observers_registration')


def register_order_saved_observer(gateway: Database):
    """
    Регистрация события успешного сохранения заказа
    """
    from .events import CreateOrderEvent
    from .handlers import CreateOrderSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__CreateOrderSubscriber__',
        [CreateOrderEvent],
        CreateOrderSubscriber(),
        is_type_check=True
    )


def register_order_updated_observer(gateway: Database):
    """
    Регистрация события успешного обновления заказа
    """
    from .events import UpdateOrderEvent
    from .handlers import UpdateOrderSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__UpdateOrderSubscriber__',
        [UpdateOrderEvent],
        UpdateOrderSubscriber(),
        is_type_check=True
    )


def register_deferred_update_order_observer(gateway: Database):
    """
    Регистрация события отложенного обновления заказа
    :return:
    """
    from .events import DeferredUpdateOrderEvent
    from .handlers import DeferredUpdateOrderSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__DeferredUpdateOrderSubscriber__',
        [DeferredUpdateOrderEvent],
        DeferredUpdateOrderSubscriber(),
        is_type_check=True
    )


def register_send_order_to_mono_app_observer(gateway: Database):
    """
    Регистрация события отложенного обновления заказа
    :return:
    """
    from .events import SendOrderToMonoAppEvent
    from .handlers import MonoAppOrderRetranslationSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__MonoAppOrderRetranslationSubscriber__',
        [SendOrderToMonoAppEvent],
        MonoAppOrderRetranslationSubscriber(),
        is_type_check=True
    )


def register_change_pd_payment_notify(gateway: Database):
    """
    Регистрация события оплаты услуги изменения данных
    :return:
    """
    from .events import PaymentNotifyEvent
    from .handlers import PaymentNotifyHandler

    manager = get_event_manager(gateway)
    manager.register(
        '__PaymentNotifyHandler__',
        [PaymentNotifyEvent],
        PaymentNotifyHandler(),
        is_type_check=True
    )


def get_pre_departure_flight_observer(gateway: Database):

    from .events import FlightsPreDepartureEvent
    from .handlers import PreDepartureFlightsHandlers

    manager = get_event_manager(gateway)
    manager.register(
        '__FlightsPreDepartureEvent__',
        [FlightsPreDepartureEvent],
        PreDepartureFlightsHandlers(),
        is_type_check=True
    )


def register_exchange_payment_observer(gateway: Database):

    from .events import PaymentEvent
    from .handlers import ExchangePaymentSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__ExchangePaymentSubscriber__',
        [PaymentEvent],
        ExchangePaymentSubscriber(),
        is_type_check=True
    )


def register_split_order_observer(gateway: Database):
    """
    Регистрация события зафиксированного сплита
    """
    from .events import SplitOrderEvent
    from .handlers import SplitOrderSubscriber

    manager = get_event_manager(gateway)
    manager.register(
        '__CreateOrderSubscriber__',
        [SplitOrderEvent],
        SplitOrderSubscriber(),
        is_type_check=True
    )


def register_refund_order_observer(gateway: Database):
    """
    Регистрация события отмены заказа.
    :return:
    """
    from .events import RefundOrderEvent
    from .handlers import RefundHandler

    manager = get_event_manager(gateway)
    manager.register(
        '__RefundOrderPublisher__',
        [RefundOrderEvent],
        RefundHandler(),
        is_type_check=True
    )


def register_aircraft_bort_changed_observer(gateway: Database):
    """
    Регистрация события изменения категории мест+
    :return:
    """
    from .events import FlightsAircraftBortChangedEvent
    from .handlers import FlightsAircraftBortChangedHandler

    manager = get_event_manager(gateway)
    manager.register(
        '__FlightsAircraftBortChangedHandler__',
        [FlightsAircraftBortChangedEvent],
        FlightsAircraftBortChangedHandler(),
        is_type_check=True
    )


def register_order_booked_observer(gateway: Database):
    """
    Регистрация события бронирования заказа
    :return:
    """
    from .events import OrderBookedEvent
    from .handlers import OrderBookedHandler

    manager = get_event_manager(gateway)
    manager.register(
        '__OrderBookedHandler__',
        [OrderBookedEvent],
        OrderBookedHandler(),
        is_type_check=True
    )


def register_all():
    """
    Единая точка для регистрации всех событий,
    как в приложении так и в celery

    Из-за того, что celery-app импортится прям из модуля переменной, обработчики могут быть зарегистрированны
    дважды. Чтобы этого не происходило, нужно добавить is_type_check=True и ловить ObserverAlreadyRegistered
    >>> manager = get_event_manager(get_db_gateway())
    >>> manager.register(is_type_check=True)
    """
    gateway: Database = get_db_gateway()

    register_func_list = [
        register_order_saved_observer,
        register_order_updated_observer,
        register_deferred_update_order_observer,
        register_send_order_to_mono_app_observer,
        register_change_pd_payment_notify,
        register_split_order_observer,
        get_pre_departure_flight_observer,
        register_exchange_payment_observer,
        register_refund_order_observer,
        register_aircraft_bort_changed_observer,
        register_order_booked_observer
    ]

    for f in register_func_list:
        try:
            f(gateway=gateway)
        except ObserverAlreadyRegistered:
            pass
        except BaseEventEngineError as e:
            logger.critical("Не удалось зарегистрировать обработчика: {} - {}".format(f.__name__, str(e)))
