import copy
import json
import logging
from functools import wraps, partial
from inspect import getfullargspec
from typing import Any

from base.exception import ApplicationError
from libs.db_gateway import get_db_gateway
from libs.utils.tools.misc import get_nested_last_values_from_dict
from rest.settings.settings import REQUEST_CACHING

logger = logging.getLogger("request_cache")


class RequestCache(object):
    """
    Кэширование запросов по сигнатуре и параметрам

    >>>import requests
    >>>
    >>>class ExampleClass:
    >>>    @RequestCache.class_method_wrapper(ttl=10)
    >>>    def function_to_cache(self, kwarg_param: str = 'value') -> dict:
    >>>        return requests.get('http://some-fancy-api.zone').json()

    """

    def __init__(self, function: callable, ttl: int = REQUEST_CACHING.get('ttl', 60 * 60)):
        self.cache_ttl = ttl
        self.function = function
        self.__cache__ = get_db_gateway('redis') if REQUEST_CACHING.get('enabled', False) else None

    @staticmethod
    def class_method_wrapper(method=None, ttl: int = REQUEST_CACHING.get('ttl', 60 * 60)):
        """
        Декоратор для классовых методов
        """
        if not method:
            return partial(RequestCache.class_method_wrapper, ttl=ttl)

        @wraps(method)
        def _impl(self, *args, **kwargs):
            cache = RequestCache(function=method, ttl=ttl)

            arg_spec = getfullargspec(method)
            arg_name_list = copy.copy(arg_spec[0])
            arg_name_list.remove('self')
            arg_value_list = list()

            for name in arg_name_list:
                try:
                    arg_value_list.append(args[arg_spec.args.index(name) - 1])
                except IndexError:
                    try:
                        arg_value_list.append(args[arg_spec.args.index(name)])
                    except IndexError:
                        pass

            if not arg_value_list and kwargs:
                arg_value_list = [v for v in kwargs.values()]

            if not REQUEST_CACHING.get('enabled', False):
                return cache.function(self, *args, **kwargs)

            cache_key = cache.__generate_cache_key__(arg_value_list)
            cached_data = cache.__get_cached_value__(cache_key)
            if cached_data:
                return cached_data
            try:
                result = cache.function(self, *args, **kwargs)
                cache.__set_cached_value__(cache_key, result)
            except Exception as e:
                raise ApplicationError(message=f"Unable to cache request: {e}", inner_exception=e)
            return result

        return _impl

    def __generate_cache_key__(self, arg_value_list: list):
        """
        Генерируем ключ кэша
        вида func_name + func_params
        E.g. external_api_call-first_param_val-second_param_val
        """

        args = '-'.join(map(self.__get_cache_key_value__, arg_value_list))
        if not args:
            args = 'empty_args'
        cache_key = f'{self.function.__name__}-{args}'
        return cache_key

    def __get_cached_value__(self, cache_key: str):
        cached_value = self.__cache__.get(cache_key)
        if cached_value:
            cached_value = json.loads(cached_value)
        return cached_value

    def __set_cached_value__(self, cache_key: str, data: dict):
        data = json.dumps(data)
        self.__cache__.set(cache_key, data, ex=self.cache_ttl)

    def __get_cache_key_value__(self, value: Any):
        """
        Генерирует ключ из вложенной структуры
        :param value: массив, словарь, число, строка
        """

        if isinstance(value, list):
            return '.'.join(sorted([self.__get_cache_key_value__(v) for v in value]))
        elif isinstance(value, dict):
            return '.'.join(list(get_nested_last_values_from_dict(value)))
        else:
            return str(value)
