"""
  Convert camel-case to snake-case.
  e.g.: CamelCase  -> snake_case
  e.g.: snake_case -> CamelCase
  e.g.: CamelCase  -> dash-case
  e.g.: dash-case  -> CamelCase
"""
import re


class CaseConverter:
    _first_cap_re = re.compile(r'(.)([A-Z][a-z]+)')
    _all_cap_re = re.compile('([a-z0-9])([A-Z])')

    def camel_to_snake(self, camel_cased_str):
        """
        This function converts to snake_case from camelCase
        """
        sub1 = self._first_cap_re.sub(r'\1_\2', camel_cased_str)
        snake_cased_str = self._all_cap_re.sub(r'\1_\2', sub1).lower()
        return snake_cased_str.replace('__', '_')

    def camel_to_dash(self, camel_cased_str):
        """
        This function converts to dashed_case from camelCase
        """
        sub2 = self._first_cap_re.sub(r'\1-\2', camel_cased_str)
        dashed_case_str = self._all_cap_re.sub(r'\1-\2', sub2).lower()
        return dashed_case_str.replace('--', '-')

    def snake_to_camel(self, snake_cased_str):
        return self._convert_to_camel(snake_cased_str, "_")

    def dash_to_camel(self, snake_cased_str):
        return self._convert_to_camel(snake_cased_str, "-")

    def _convert_to_camel(self, snake_cased_str, separator):
        components = snake_cased_str.split(separator)
        preffix = ""
        suffix = ""
        if components[0] == "":
            components = components[1:]
            preffix = separator
        if components[-1] == "":
            components = components[:-1]
            suffix = separator
        if len(components) > 1:
            camel_cased_str = components[0].lower()
            for x in components[1:]:
                if x.isupper() or x.istitle():
                    camel_cased_str += x
                else:
                    camel_cased_str += x.title()
        else:
            camel_cased_str = components[0]
        return preffix + camel_cased_str + suffix

    def convert_keys_to_underscore(self, source_dict: dict) -> dict:
        return self.change_keys(source_dict, self.camel_to_snake)

    def change_keys(self, obj: dict, _convert: callable) -> dict:
        """
        Рекурсивно проходит по объекту и применяет к ключу функцию
        _convert, при этом сохраняя изначальные типы
        """
        if isinstance(obj, (str, int, float)):
            return obj
        if isinstance(obj, dict):
            # Создаем такой же объект, на случай если это был OrderedDict
            new = obj.__class__()
            for k, v in obj.items():
                new[_convert(k)] = self.change_keys(v, _convert)
        elif isinstance(obj, (list, set, tuple)):
            new = obj.__class__(self.change_keys(v, _convert) for v in obj)
        else:
            return obj
        return new
