from abc import ABC, abstractmethod
from typing import Any


class ChainHandler(ABC):
    """
    Интерфейс Обработчика объявляет метод построения цепочки обработчиков. Он
    также объявляет метод для выполнения запроса.
    """

    @abstractmethod
    def set_next(self, handler: 'ChainHandler') -> 'ChainHandler':
        """
        Устанавливает следующий обработчик в цепь
        :param handler: обработчик
        :return: обработчик
        """
        pass

    @abstractmethod
    def handle(self, _object: object, request: Any = None) -> Any:
        pass


class AbstractChainHandler(ChainHandler):
    """
    Поведение цепочки по умолчанию может быть реализовано внутри базового класса
    обработчика.
    """

    _next_handler: ChainHandler = None
    _default_return_value: Any = None

    def set_next(self, handler: ChainHandler) -> ChainHandler:
        self._next_handler = handler
        # Возврат обработчика отсюда позволит связать обработчики простым
        # способом, вот так:
        # handler1.set_next(handler2).set_next(handler3)
        return handler

    @abstractmethod
    def handle(self, _object: object, request: Any = None) -> Any:
        if self._next_handler:
            return self._next_handler.handle(_object, request)
        return self._default_return_value


class InitChainUnit(AbstractChainHandler):
    """
    Нулевое звено цепочки
    Синтаксический сахар, для создания первого звена, от которого
    дальше можно строить цепочку методом .set_next()
    >>> chain = InitChainUnit()
    >>> second_step = AbstractChainHandler() # Имплементированный хэндлер
    >>> chain.set_next(second_step)
    >>> chain.handle(object(), 'request_type')
    """

    def handle(self, _object: object, request: Any = None):
        return super().handle(_object, request)
