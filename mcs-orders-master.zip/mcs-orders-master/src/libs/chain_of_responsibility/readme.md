# Пример использования

```python
from libs.chain_of_responsibility.chain import AbstractChainHandler
from typing import Any
```

## Создаем хэндлеры 

```python
class NormalizeHandler(AbstractChainHandler):
    def handle(self, _object: object, request: Any = None) -> str:
        if request == "common":
            """
            Здесь будут реализованы общие нормалайзеры для всех провайдеров
            """
            return f"Common Normalizer: I'll handle the {request} normalization"
        else:
            return super().handle(_object, request)


class SirenaNormalizeHandler(AbstractChainHandler):
    def handle(self, _object: object, request: Any = None) -> str:
        if request == "sirena":
            """
            Здесь будут реализованы нормалайзеры сирены
            """
            return f"Sirena Normalizer: I'll handle the {request} normalization"
        else:
            return super().handle(_object, request)


class TaisNormalizeHandler(AbstractChainHandler):
    def handle(self, _object: object, request: Any = None) -> str:
        if request == "tais":
            """
            Здесь будут реализованы нормалайзеры таиса
            """
            return f"Tais Normalizer: I'll handle the {request} normalization"
        else:
            return super().handle(_object, request)


class SkipperHandler(AbstractChainHandler):
    def handle(self, _object: object, request: Any = None) -> str:
        if request == 'skipper':
            """
            Здесь будут реализованы скиперы
            """
            return f"Skipper Handler: I'll skip for you {type(_object)} "
        else:
            return super().handle(_object, request)

```

## Выполняем

```python

if __name__ == "__main__":

    # Пришел заказ и он от сирены
    class Request:
        provider = None

    class Order:
        order_normalized_data = '1'

    request = Request()
    request.provider = 'sirena'
    order = Order()

    # Создаем цепочки
    normalizer = NormalizeHandler()
    sirena_normalizer = SirenaNormalizeHandler()
    tais_normalizer = TaisNormalizeHandler()
    skipper_handler = SkipperHandler()

    normalizer.set_next(tais_normalizer).set_next(sirena_normalizer).set_next(skipper_handler)

    # Клиент должен иметь возможность отправлять запрос любому обработчику, а не
    # только первому в цепочке.
    for provider in [request.provider, 'common', 'skipper']:
        result = normalizer.handle(provider, order)
        print(result)

    """
    Sirena Normalizer: I'll handle the sirena
    Common Normalizer: I'll handle the common
    Skipper Handler: I'll skip for you skipper
    """
```
