from typing import Union
from threading import get_ident
from multiprocessing import current_process

from pymongo.database import Database
from redis import Redis
from rest.settings import settings

from .base.base_gateway import GateWayOperationError
from .pool_manager import ConnectionPoolManager


def get_db_gateway(
        label: str = 'default'
) -> Union[Database, Redis]:
    """
    Получение соединения с базой
    :param label: Наименование соединения из настроек settings.DATABASE

    Пример настроек:

    DATABASE = {
        'default': {
            'dbms': 'mongodb',
            'host': '127.0.0.1',
            'port': 27020,
            'db': 'orders',
            'user': '',
            'password': '',
            'auth_source': 'orders',
        },
        'redis-deferred-orders-save': {
            'dbms': 'redis',
            'host': '127.0.0.1',
            'port': REDIS_LOCAL_PORT,
            'db': 2
        }
    }
    :return: Database
    :raises: GateWayOperationError
    """
    identifier: str = f"{current_process().name}-{get_ident()}"
    manager = ConnectionPoolManager(process_name=identifier)
    try:
        return manager.resolve_connection(
            conn_string=settings.DATABASE[label],
            label=label
        )
    except KeyError:
        raise GateWayOperationError(f"Unknown db label: {label}")
