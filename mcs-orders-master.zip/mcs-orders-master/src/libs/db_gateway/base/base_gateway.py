from abc import ABC, abstractmethod
from typing import Any, Dict
from .base_connection_string import BaseConnectionString


class GateWayOperationError(Exception):
    """
    Ошибка работы с Менеджером соединений, будет прокинута на самый верх
    """
    pass


class BaseGateWay(ABC):

    def __init__(self):
        self.__CONNECTION_POOL__: Dict[str, Any] = dict()

    @abstractmethod
    def get_gateway(self, connection_string: BaseConnectionString) -> Any:
        """
        Создания соединения клиента
        Должно быть реализовано в дочернем классе
        """
        raise NotImplementedError()

    @abstractmethod
    def health_check(self):
        raise NotImplementedError()

    def add_to_pool(self, label: str, connection: Any):
        """
        Добавление соединения (self.get_gateway) в пул (self.__CONNECTION__POOL__) по ключу (label)
        """
        if label not in self.__CONNECTION_POOL__:
            self.__CONNECTION_POOL__[label] = connection

    def get_from_pool(self, label: str):
        """
        Получение соединения из пула по ключу (label)
        """
        try:
            return self.__CONNECTION_POOL__[label]
        except KeyError:
            raise GateWayOperationError(f"Unable to get {label} from pool. Connection does not exist.")

    def remove_from_pool(self, label: str):
        """
        Удаление соединения из пула по ключу (label)
        """
        try:
            del self.__CONNECTION_POOL__[label]
        except KeyError:
            # При отсутсвии подходящего соединения ничего не делаем, считаем, что оно удалилось
            pass
