from typing import NamedTuple, Type
from .base_connection_string import BaseConnectionString
from .base_gateway import BaseGateWay


class ConnectionPair(NamedTuple):
    """
    Контейнер для настроек и гейтвея
    """
    settings: Type[BaseConnectionString]
    gateway: BaseGateWay
