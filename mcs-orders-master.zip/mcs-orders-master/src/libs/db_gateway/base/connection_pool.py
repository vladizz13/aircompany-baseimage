from typing import Dict, Tuple
import inspect


class ConnectionPoolMeta(type):

    """
    Метакласс, реализующий синглтон по параметрам, переданным в конструктор класса
    """

    _instances: Dict[Tuple, object] = dict()
    _init: Dict[object, callable] = dict()

    def __init__(cls, _name: str, _bases: Tuple, _dict: Dict):
        cls._init[cls] = _dict.get('__init__', None)
        super().__init__(cls)

    def __call__(cls, *args, **kwargs):
        init = cls._init[cls]
        if init is not None:
            key = (cls, frozenset(
                inspect.getcallargs(init, None, *args, **kwargs).items())
            )
        else:
            key = cls

        if key not in cls._instances:
            cls._instances[key] = super(ConnectionPoolMeta, cls).__call__(*args, **kwargs)
        return cls._instances[key]
