import os
from rest.settings.settings import PROJECT_ROOT
from ..base.base_connection_string import BaseConnectionString


class MongoConnectionString(BaseConnectionString):

    """
    'default': {
        'dbms': 'mongodb',
        'host': '127.0.0.1',
        'port': 27020,
        'db': 'orders',
        'user': '',
        'password': '',
        'auth_source': 'orders',
    }

    ReplicaSet:

    'default_prod': {
        'dbms': 'mongodb',
        'host': [
            'host1',
            'host2'
        ],
        'port': [
            27017,
            27017
        ],
        'db': 'orders',
        'user': '',
        'password': '',
        'authSource': 'orders',
        'replicaSet': 'orders',
        'readPreference': 'primary'
    }
    """

    def __init__(
            self,
            dbms: str,
            host: str,
            port: int,
            db: str,
            user: str = None,
            password: str = None,
            *args, **kwargs
    ):
        super().__init__(dbms, host, port, db, user, password)

        self.kwargs = kwargs

    def __to_string__(self) -> str:
        """
        Создаем строку подкючения к базе основываясь на ключе replicaSet
        """
        if self.user:
            user_password = '{}:{}@'.format(self.user, self.password)
        else:
            user_password = ''
        self.port = [self.port] if not isinstance(self.port, list) else self.port
        self.host = [self.host] if not isinstance(self.host, list) else self.host

        if len(self.port) != len(self.host):
            raise Exception("Unable to create mongo connection string, ports and host len must be exactly the same")

        hosts = []
        for idx, h in enumerate(self.host):
            template = '{}:{}'
            hosts.append(template.format(h, self.port[idx]))

        connection_string = '{}://{}{}'.format(
            self.dbms,
            user_password,
            ','.join(hosts)
        )

        if self.kwargs.get('tlsCAFile'):
            self.kwargs['tlsCAFile'] = os.path.abspath(os.path.join(PROJECT_ROOT, self.kwargs.get('tlsCAFile')))

        options = '&'.join(["{}={}".format(key, value) for key, value in self.kwargs.items()])
        result_string = '{}/?{}'.format(connection_string, options)

        return result_string

    __str__ = __to_string__
