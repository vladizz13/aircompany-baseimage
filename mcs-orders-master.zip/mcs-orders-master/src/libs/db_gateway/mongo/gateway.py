from enum import Enum
from pymongo import MongoClient
from typing import Optional
from pymongo.database import Database
from .connection_string import MongoConnectionString
from ..base.base_gateway import BaseGateWay


class MongoReadPreference(Enum):
    PRIMARY = 'primary'
    PRIMARY_PREFERRED = 'primaryPreferred'
    SECONDARY = 'secondary'
    SECONDARY_PREFERRED = 'secondaryPreferred'
    NEAREST = 'nearest'


class MongoGateWay(BaseGateWay):
    """
    Реализация GateWay для клиента Mongo
    """

    # Immediately begin connecting to MongoDB in the background.
    # Otherwise connect on the first operation.
    connect: bool = False

    # The maximum number of connections that
    # each pool can establish concurrently. Defaults to `2`.
    max_connecting: int = 4

    # Utilities for choosing which member of a replica set to read from.
    read_preference: str = MongoReadPreference.PRIMARY.value

    # The maximum allowable number of concurrent connections to each
    # connected server. Requests to a server will block if there are
    # `maxPoolSize` outstanding connections to the requested server.
    # Defaults to 100. Cannot be 0.
    max_pool_size: int = 1024

    # The minimum required number of concurrent
    # connections that the pool will maintain to each connected server.
    min_pool_size: int = 4

    # wait_queue_multiple is multiplied by max_pool_size
    # to give the number of threads allowed to wait for a socket at one
    # time. Defaults to ``None`` (no limit)
    wait_queue_multiple: int = 10

    # How long (in milliseconds)
    # a thread will wait for a socket from the pool if the pool has no
    # free sockets. Defaults to ``None`` (no timeout).
    wait_queue_timeout_ms: int = 1000

    # The number of milliseconds between periodic server checks,
    # or None to accept the default frequency of 10 seconds.
    heart_beat_frequency_ms: int = 10 * 1000

    # The name of the application that created this MongoClient instance
    app_name: Optional[str] = None

    # Whether supported write operations executed within this
    # MongoClient will be retried once after a network error
    retry_writes: bool = True

    # Whether supported read operations executed within this
    # MongoClient will be retried once after a network error
    retry_reads: bool = True

    # The maximum number of milliseconds that
    # a connection can remain idle in the pool before being removed and
    # replaced. Defaults to `None` (no limit).
    max_idle_time_ms: int = 60 * 1000

    # Controls how long (in milliseconds) the driver will wait for a response after sending an
    # ordinary (non-monitoring) database operation before concluding that
    # a network error has occurred. ``0`` or ``None`` means no timeout.
    # Defaults to ``None`` (no timeout).
    socket_timeout_ms: int = 5 * 1000

    # Controls how long (in
    # milliseconds) the driver will wait when executing an operation
    # (including retry attempts) before raising a timeout error.
    # ``0`` or ``None`` means no timeout.
    timeout_ms: int = 60 * 1000

    def __init__(self):
        super().__init__()

    def get_gateway(self, connection_string: MongoConnectionString) -> Database:
        connection: MongoClient = MongoClient(
            str(connection_string),
            connect=self.connect,
            maxPoolSize=self.max_pool_size,
            waitQueueMultiple=self.wait_queue_multiple,
            waitQueueTimeoutMS=self.wait_queue_timeout_ms,
            heartbeatFrequencyMS=self.heart_beat_frequency_ms,
            appname=self.app_name,
            retryWrites=self.retry_writes,
            retryReads=self.retry_reads,
            readPreference=self.read_preference,
            maxIdleTimeMS=self.max_idle_time_ms,
            socketTimeoutMS=self.socket_timeout_ms,
            timeoutMS=self.timeout_ms,
            minPoolSize=self.min_pool_size,
            maxConnecting=self.max_connecting,
        )
        db: Database = connection[connection_string.db]
        return db

    def health_check(self):
        raise NotImplementedError()
