from typing import Dict
from enum import Enum
from .base.base_gateway import GateWayOperationError
from .base.connection_pair import ConnectionPair

from .mongo.connection_string import MongoConnectionString
from .mongo.gateway import MongoGateWay

from .redis.connection_string import RedisConnectionString
from .redis.gateway import RedisGateWay


class ConnectionPool(object):

    """
    Для добавления новой базы:

    1. Добавить dbms в AvailableDBMS

    2. Реализовать GateWay и добавить в init этого класса

    3. Реализовать ConnectionString и добавить ConnectionPair в connection_map

    4. [Optional] Добавить тайп-хинтинг в ConnectionPoolManager
    """

    class AvailableDBMS(Enum):
        """
        Доступные базы данных
        """
        MONGODB = 'mongodb'
        REDIS = 'redis'

    def __init__(self):
        self.__mongo_gateway: MongoGateWay = MongoGateWay()
        self.__redis_gateway: RedisGateWay = RedisGateWay()

    def __connection_map(self) -> Dict[str, ConnectionPair]:
        resolve_map: Dict[str, ConnectionPair] = {
            self.AvailableDBMS.MONGODB.value: ConnectionPair(MongoConnectionString, self.__mongo_gateway),
            self.AvailableDBMS.REDIS.value: ConnectionPair(RedisConnectionString, self.__redis_gateway),
        }
        return resolve_map

    def resolve_gateway(self, dbm: str) -> ConnectionPair:
        """
        Получение нужного gateway, отвечающего за базу, соответсвующего dbm
        """
        if not dbm:
            raise GateWayOperationError('Unknown db gateway')
        if dbm.lower() not in self.AvailableDBMS._value2member_map_:
            raise GateWayOperationError('Unknown db gateway')
        return self.__connection_map()[dbm]
