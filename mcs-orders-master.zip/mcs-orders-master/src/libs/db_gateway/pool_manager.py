from typing import Dict

from pymongo.database import Database
from redis import Redis
from typing import Union

from .base.base_connection_string import BaseConnectionString
from .base.base_gateway import BaseGateWay, GateWayOperationError
from .base.connection_pair import ConnectionPair

from .pool import ConnectionPool
from .base.connection_pool import ConnectionPoolMeta


class ConnectionPoolManager(metaclass=ConnectionPoolMeta):
    """
    Мэнеджер соединений
    Отдает соединение к базе, основываясь на переданном label
    Пример настроек:
    В данном случае label это:
    default/redis-deferred-orders-save

    DATABASE = {
        'default': {
            'dbms': 'mongodb',
            'host': '127.0.0.1',
            'port': 27020,
            'db': 'orders',
            'user': '',
            'password': '',
            'auth_source': 'orders',
        },
        'redis-deferred-orders-save': {
            'dbms': 'redis',
            'host': '127.0.0.1',
            'port': REDIS_LOCAL_PORT,
            'db': 2
        }
    }
    """
    def __init__(self, process_name: str):
        """
        Наименование процесса нужно для получения нового инстанса класса для fork'ов/дочерних потоков
        """
        self.process_name: str = process_name
        self.__pool_handler: ConnectionPool = ConnectionPool()

    def resolve_connection(
            self,
            conn_string: Dict,
            label: str
    ) -> Union[Database, Redis]:
        """
        Главная точка входа
        Создает соединение и возвращает его, либо возвращает соединение из пула, если таковое уже имеется
        :conn_string: Словарь настроек
        {
            'dbms': 'mongodb',
            'host': '127.0.0.1',
            'port': 27020,
            'db': 'orders',
            'user': '',
            'password': '',
            'auth_source': 'orders',
        }
        :label: Наименования настроек, должен быть уникальным среди всех пулов
        'default'
        """
        connection: ConnectionPair = self.__pool_handler.resolve_gateway(
            dbm=conn_string.get('dbms')
        )
        gateway: BaseGateWay = connection.gateway
        try:
            return gateway.get_from_pool(label=label)
        except GateWayOperationError:
            # Создание нового соединения и добавление его в пулл
            connection_string: BaseConnectionString = connection.settings(**conn_string)
            gateway.add_to_pool(
                label=label,
                connection=gateway.get_gateway(
                    connection_string=connection_string
                )
            )
        return gateway.get_from_pool(label=label)
