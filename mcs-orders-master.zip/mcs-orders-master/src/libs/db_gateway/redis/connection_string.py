import os
from urllib.parse import urlencode
from typing import Optional
from rest.settings import settings
from ..base.base_connection_string import BaseConnectionString


class RedisConnectionString(BaseConnectionString):

    """
    'redis': {
        'dbms': 'redis',
        'host': '127.0.0.1',
        'port': 1111,
        'db': 2
    }
    """

    def __init__(
            self,
            dbms: str,
            host: str,
            port: int,
            db: str,
            user: str = None,
            password: str = None,
            *args, **kwargs
    ):
        super().__init__(dbms, host, port, db, user, password)
        self.kwargs = kwargs
        self.tlsCAFile = self.kwargs.get("tlsCAFile")
        self.is_tls = bool(self.tlsCAFile)

    def absolute_cert_path(self) -> Optional[str]:
        if not self.tlsCAFile:
            return None
        if os.path.isabs(self.tlsCAFile):
            return self.tlsCAFile
        path = os.path.abspath(os.path.join(
            settings.PROJECT_ROOT, self.tlsCAFile)
        )
        return str(path)

    @property
    def connection_url(self) -> str:
        url: str = "redis://"
        params = dict()
        if self.is_tls:
            url: str = "rediss://"
            params = {
                "ssl_cert_reqs": "none",
                "ssl_ca_certs": self.absolute_cert_path()
            }
        if self.password:
            url = f"{url}:{self.password}@"
        url = f"{url}{self.host}:{self.port}/{self.db}"
        if not self.is_tls:
            return url
        return f"{url}?{urlencode(params)}"
