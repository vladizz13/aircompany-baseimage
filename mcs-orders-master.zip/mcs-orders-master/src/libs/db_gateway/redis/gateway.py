from redis import Redis, ConnectionPool, SSLConnection
from .connection_string import RedisConnectionString
from ..base.base_gateway import BaseGateWay


class RedisGateWay(BaseGateWay):
    """
    Реализация GateWay для клиента redis
    """

    # Decodes byte sting by default
    decode_responses: bool = True

    # Ensure that a health check is run on any connection that has been idle
    # for N or more seconds just before a command is executed on that connection.
    health_check_interval: int = 15

    socket_timeout: int = 60
    socket_connect_timeout: int = 60
    retry_on_timeout: bool = True

    def __init__(self):
        super().__init__()

    def get_gateway(self, connection_string: RedisConnectionString) -> Redis:
        if connection_string.is_tls:
            pool: ConnectionPool = ConnectionPool(
                host=connection_string.host,
                port=connection_string.port,
                password=connection_string.password,
                connection_class=SSLConnection,
                ssl_cert_reqs="required",
                ssl_ca_certs=connection_string.absolute_cert_path(),
                decode_responses=self.decode_responses,
                health_check_interval=self.health_check_interval,
                # NB: Чтобы правильно использовать таймаут, нужно обрабатывать команды, которые блокируются вечно
                #   отдельным таймаутом, например
                #   Redis.brpop()
                # socket_timeout=self.socket_timeout,
                socket_connect_timeout=self.socket_connect_timeout,
                retry_on_timeout=self.retry_on_timeout
            )
        else:
            pool: ConnectionPool = ConnectionPool(
                host=connection_string.host,
                port=connection_string.port,
                password=connection_string.password,
                decode_responses=self.decode_responses,
                health_check_interval=self.health_check_interval,
                # socket_timeout=self.socket_timeout,
                socket_connect_timeout=self.socket_connect_timeout,
                retry_on_timeout=self.retry_on_timeout
            )
        r = Redis(connection_pool=pool)
        return r

    def health_check(self):
        raise NotImplementedError()
