
class BaseMapping:
    """
    Базовый класс маппинга. Все маппинги передаваеммые классу маппер должны быть унаследованы от этого класса
    """
    mapping = dict()

    nested_data_key = ""

    def __init__(self, mapping_dict=None):
        self.mapping = mapping_dict if mapping_dict and isinstance(mapping_dict, dict) else self.mapping

    def __getitem__(self, item):
        return self.mapping.get(item)

    def __setitem__(self, key, value):
        self.mapping[key] = value

    def get(self, key, default_value=None):
        return self.mapping.get(key, default_value)

    def items(self):
        return self.mapping.items()

    def get_nested_data_key(self):
        return self.nested_data_key
