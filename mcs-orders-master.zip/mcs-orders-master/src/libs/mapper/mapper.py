'''
======================== Описание работы Mapper =======================================================================
Класс Mapper служит для маппинга данных.
Основные понятия:
1. Целевая структура - структура данных словаря (dict) которую необходимо получить в результате
маппинга источника данных.
2. Источник данных (data source) - набор данных, в котором содержится информация
необходимая для создания целевой структуры. Так как источники данных могут иметь вложенные структуры они разделяются
  на (более) "Конкретные Источники Данных" - specific data sources,
  и (более) "Общие Источники Данных" - generic data sources.
  Конкретные источники данных находятся глубже в структуре (имеют большую вложенность), чем общие.
3. Маппинг (mapping) - класс унаследованный от BaseMapping. При наследовании от BaseMapping необходимо переопределить
поле mapping, которое описывает целевую структуру маппинга в виде словаря (dict). Ключи словаря mapping будут
спроэцированы как ключи целевой структуры, а значения ключей будут вычислены. Значением ключа маппинга могут являться:
 - Строка с именем ключа из источника данных. Маппер попытается получить значение из источника данных по этому ключу.
 В случае неудачи (отсутствия ключа в источнике, или любого другого исключения) маппер залоггирует ошибку и запишет
 в данное поле целевой структуры None.
 - Функция. Маппер попытается выполнить функцию и полученное в результате значение запишет в качестве значения ключа в
 целевую структуру.
 - Маппинг. Mapper имеет поддержку вложенных маппингов, что позволяет описывать сложные, вложенные структуры.
 В случае если значение ключа маппинга, является объектом наследующим BaseMapping,
 Mapper вызовет функцию map рекурсивно и передаст в нее значение вложенного маппинга и источник данных.
 !!! ВАЖНО !!!
 Класс BaseMapping так же имеет функцию get_nested_data_key. Эту функцию маппер вызывает ТОЛЬКО у вложенного маппинга.
 При наследовании BaseMapping можно переопределить эту функцию указав в качестве ее возвращаемого значания
 строку с ключом который должен присутствовать в Источнике данных. В случае если результат вызова функции
 get_nested_data_key корректный, и ключ с таким названием присутствует в источнике данных, то значение полученное
 по этому ключу квалифицируется как Конкретный источник данных и передается в рекурсивный вызов map первым параметром.
 Чтобы получить доступ к источникам данных более верхних уровней используются последующие параметры, которые содержатся
 в списке параметров *sources. Чем выше индекс параметра, тем он более общий (находится выше в структуре вложенностей)
 Для инициации процесса маппинга класс Mapper имеет статический метод:
    map(*sources, mapping)
    При вызове map из клиентского кода, в sources передается Источник данных (всегда первым параметром),
 а в параметр mapping - экземпляр класса унаследованного от BaseMapping и содержащего целевую структуру в поле mapping.
 Элементом sources может быть так же и список (list). В этом случае Mapper будет пытаться применить переданный маппинг
 к каждому элементу списка, а результатом его работы будет так же список целевых структур.

 Example:

 Data source:

 data_source = {
    'source_key1': 'value1',
    'source_key2': 'value2',
    'source_key3': 'value3',
    'nested_object': {
        'nested_key1': 'nested value 1',
        'nested_key2': 'nested value 2',
        'nested_key3': 'nested value 3',
        'double_nested_object': {
            'double_nested_key1': 'double nested value 1',
            'double_nested_key2': 'double nested value 2',
            'double_nested_key3': 'double nested value 3'
        }
    }
 }

 Mappings:

 class MappingExample(BaseMapping):
    mapping = {
        'dest_key1': 'source_key1',
        'dest_key2': 'nested_object.nested_key3',
        'dest_key3': lambda conc_source, *gen_sources: conc_source['source_key2'] + conc_source['source_key3'],
        'dest_key4': None,
        'dest_nested_object': NestedMappingExample()
    }

 class NestedMappingExample(BaseMapping):
    mapping = {
        'dest_key1': 'nested_key1',
        'dest_key2': lambda conc_source, *gen_sources: conc_source['nested_key1'] + conc_source['nested_key3'],
        'dest_key3': None,
        'dest_key4': lambda conc_source, *gen_sources: conc_source['nested_key1'] + gen_sources[0]['source_key1'],
        'dest_double_nested_object': DoubleNestedMappingExample()
    }

    # Используется для определения конкретного источника данных вложенного маппинга
    # Если метод не реализован, то будет использован тот же источник данных, что и в корневом маппинге
    def get_nested_data_key():
        return 'nested_object'

 class DoubleNestedMappingExample(BaseMapping):
    mapping = {
        'dest_key1': 'double_nested_key1',
        'dest_key2': lambda conc_source, *gen_sources: gen_sources[0]['nested_key1'] + gen_sources[1]['source_key1'],
    }

    # Используется для определения конкретного источника данных вложенного маппинга
    # Если метод не реализован, то будет использован тот же источник данных, что и в корневом маппинге
    def get_nested_data_key():
        return 'double_nested_object'

 Usage:

 result = Mapper.map(data_source, MappingExample())

 print(result)

 Result:

 {
    'dest_key1': 'value1',
    'dest_key2': 'nested value 3',
    'dest_key3': 'value2value3',
    'dest_key4': None,
    'dest_nested_object': {
        'dest_key1': 'nested value 1',
        'dest_key2': 'nested value 1nested value 3',
        'dest_key3': None,
        'dest_key4': 'nested value 1value1',
        'dest_double_nested_object': {
            'dest_key1': 'double nested value 1',
            'dest_key2': 'nested value 1value1'
        }
    }
 }
=======================================================================================================================
'''
import logging

from .base_mapping import BaseMapping


logger = logging.getLogger('mapper')


class MapperError(Exception):
    pass


class Mapper:

    @staticmethod
    def map(*sources, mapping: BaseMapping, log_level: str = 'warning'):
        '''
        Метод для инициации процесса маппинга.
        :param *sources: источники данных.
        :param mapping: экземпляр объекта BaseMapping.
        '''
        if not isinstance(mapping, BaseMapping):
            raise TypeError("Parameter mapping should be instance derived from BaseMapping")

        if not sources:
            raise ValueError('At least one source item should be passed')

        result = {}
        source_data = list(sources)
        specific_source = source_data.pop(0)  # Берем самый "конкретный" источник данных

        if isinstance(specific_source, list):
            result = []
            for data_item in specific_source:
                result.append(Mapper.map_item(
                    log_level, mapping, data_item, *source_data)
                )
        else:
            result = Mapper.map_item(
                log_level, mapping, specific_source, *source_data
            )

        return result

    @staticmethod
    def map_item(log_level, mapping, source_item, *generic_sources):
        '''
        Метод для маппинга одной целевой структуры.
        :param mapping: BaseMapping экземпляр класса BaseMapping
        :param source_item: dict конкретный источник данных
        :param generic_sources: list(dict) общие источники данных
        :return: Целевая структура
        '''
        data = source_item

        result = {}
        for key, val in mapping.items():
            try:
                if isinstance(val, BaseMapping):
                    nested_dict = data
                    data_key = val.get_nested_data_key()

                    # Сложные ключи
                    data_keys = data_key.split('.')
                    sub_dict = nested_dict.get(data_keys.pop(0))
                    for k in data_keys:
                        sub_dict = sub_dict.get(k, {})
                    if data_key and sub_dict:
                        nested_dict = sub_dict

                    result[key] = Mapper.map(
                        nested_dict, data, *generic_sources,
                        mapping=val,
                        log_level=log_level,
                    )
                elif callable(val):
                    result[key] = val(data, *generic_sources)
                elif isinstance(val, str):
                    keys = val.split('.')

                    res_val = data.get(keys.pop(0))
                    for k in keys:
                        res_val = res_val.get(k, {})

                    if res_val:
                        result[key] = res_val
                    elif res_val == {}:
                        logger.warning('Key {k} missing and can not be mapped.'.format(k=val))
                        result[key] = None
                    else:
                        result[key] = res_val
                else:
                    result[key] = val

            except Exception as err:
                result[key] = None

                log_message = 'Cant map key {key} because of exception: <{err}>'.format(
                    key=key, err=err,
                )
                if log_level == 'fall_on_exception':
                    # Упадем на эксепшене, если маппинг любого поля очень важен
                    raise MapperError(log_message)
                elif log_level == 'error':
                    logger.exception(err)
                elif log_level == 'warning':
                    logger.warning(log_message)
                elif log_level == 'info':
                    logger.info(log_message)
                elif log_level == 'debug':
                    logger.debug(log_message)

        return result
