from abc import abstractmethod
from abc import ABCMeta
import logging


class BaseMessenger(metaclass=ABCMeta):

    def __init__(
            self,
            api_key: str,
            api_url: str
    ):
        self.api_key = api_key
        self.api_url = api_url
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def send_message(self, message: str):
        raise NotImplementedError()

    @abstractmethod
    def __log_error__(self, query: dict, response=None, e: Exception = None):
        raise NotImplementedError()
