import requests
from .base import BaseMessenger
from typing import Optional, Dict
from rest.settings.settings import ENABLE_TELEGRAM_MESSAGES


class TelegramMessenger(BaseMessenger):

    TG_TIMEOUT: int = 10
    DEFAULT_CHAT_ID = None

    def __init__(
            self,
            api_key: str,
            api_url: str,
            chat_id: Optional[int] = None,
            **kwargs
    ):
        self.chat_id = chat_id if chat_id else kwargs.get('default_chat_id')
        super().__init__(api_key=api_key, api_url=api_url)
        if self.chat_id is None:
            self.logger.warning("Initiated without chat id, use implicit chat id in send_message method")

    def send_message(self, message: str, chat_id: Optional[int] = None, **kwargs):
        if not ENABLE_TELEGRAM_MESSAGES:
            return None
        result = None
        target_chat = chat_id or self.chat_id
        if not target_chat:
            raise ValueError(f"Incorrect chat_id {target_chat}")
        query: Dict = self.__create_query__(
            chat_id=chat_id or self.chat_id,
            message=message,
            additional_params=kwargs
        )
        try:
            result = requests.post(
                url=self.__prepare_url__(),
                **query
            )
            if result.status_code != 200:
                self.__log_error__(query, result, None)
                return None
            return result.json()
        except Exception as e:
            self.__log_error__(query, result, e)
            self.logger.exception(f"[{query}, {result}, {str(e)}]")

    def __prepare_url__(self) -> str:
        return f"{self.api_url}{self.api_key}/sendMessage"

    def __create_query__(self, chat_id: str, message: str, additional_params: Dict) -> Dict:
        params = additional_params or dict()
        params.update(dict(
            chat_id=chat_id,
            text=message
        ))
        query = dict(
            data=params,
            timeout=self.TG_TIMEOUT
        )
        return query

    def __log_error__(self, query: dict, response=None, e: Exception = None):
        error_info = {
            'error_type': str(type(e)),
            'error_text': str(e),
            'response': {
                'status_code': None if response is None else str(getattr(response, 'status_code', None)),
                'text': None if response is None else str(getattr(response, 'text', None))
            },
            'chat_id': str((query.get('data', {}) or {}).get('chat_id')),
            'message': str((query.get('data', {}) or {}).get('text')),
            'is_proxy_used': 'proxies' in query.keys(),
            'timeout': query.get('timeout')
        }
        self.logger.error(str(error_info))
