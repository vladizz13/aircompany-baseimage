"""
Профилировщик исполнения
"""
import time
import json
from collections import OrderedDict


class Profiler(object):
    """
    Профилировщик
    """
    timing = None
    info_data = None

    def __init__(self, name=None):
        self.name = name
        self.timing = OrderedDict()
        self.info_data = {}

        self.add('start')

    def add(self, event_name):
        """Добавить событие"""
        self.timing[event_name] = time.time()

    def add_info(self, **data):
        """Добавить информацию"""
        self.info_data.update(data)

    @property
    def duration(self):
        """Общая продолжительность"""
        timing_values = list(self.timing.values())
        return round(timing_values[-1] - timing_values[0], 3)

    def make_message(self):
        """Создать сообщение для вывода"""
        duration = []

        if len(self.timing) >= 2:
            prev = None
            for event, t in self.timing.items():
                if prev is None:
                    duration.append('{event} at {ts}'.format(
                        event=event, ts=t))
                else:
                    duration.append('{event} in {duration} s.'.format(
                        event=event, duration=round(t - prev, 3)))
                prev = t
            duration.append('All in {duration} s.'.format(duration=self.duration))

        info = (
            '\nAdditional info:\n{}'.format(
                json.dumps(self.info_data, indent=2)
            )
            if self.info_data else ''
        )

        return '{name}:{info}\nTiming:{timing}\n'.format(
            name=self.name or 'Info',
            timing=json.dumps(duration, indent=2, ensure_ascii=False),
            info=info,
        )
