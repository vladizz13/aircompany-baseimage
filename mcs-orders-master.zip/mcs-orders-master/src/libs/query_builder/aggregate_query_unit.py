from .query_unit import QueryUnit


class AggregateQueryUnit(QueryUnit):

    def build_query(self) -> list:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        aggregation_list: list = list()
        for unit in filter(lambda x: x and x.is_unit(), self.__units__):
            aggregation_list.append(unit.build_query())
        return aggregation_list
