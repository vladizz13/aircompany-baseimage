from .query_unit import QueryUnit


class AndQueryUnit(QueryUnit):

    def build_query(self) -> dict:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        and_list: list = list()
        for unit in filter(lambda x: x and x.is_unit(), self.__units__):
            and_list.append(unit.build_query())
        return {"$and": and_list}
