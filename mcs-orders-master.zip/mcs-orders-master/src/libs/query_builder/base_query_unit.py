from abc import ABCMeta
from abc import abstractmethod


class BaseQueryUnit(metaclass=ABCMeta):
    """
    Абстрактный класс запроса (или его части) к MongoDB.
    Паттерн: Composite
    """

    @abstractmethod
    def add(self, unit: 'BaseQueryUnit') -> 'BaseQueryUnit':
        """
        Добавить unit к запросу
        Возваращает сам себя, с добавленным unit-ом, для того чтобы составлять цепочки "добавлений".
        :param unit: - Часть запроса
        :return: BaseQueryUnit
        """
        raise NotImplementedError

    @abstractmethod
    def remove(self, unit: 'BaseQueryUnit') -> None:
        """
        Удалить unit из запроса
        :param unit: - Часть запроса
        :return: None
        """
        raise NotImplementedError

    @abstractmethod
    def get_child(self, index: int) -> 'BaseQueryUnit':
        """
        Получить unit дочерний unit из запроса, по его индексу
        :param index: - индекс unit-a
        :return: BaseQueryUnit
        """
        raise NotImplementedError

    @abstractmethod
    def build_query(self) -> dict:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        raise NotImplementedError

    @abstractmethod
    def is_unit(self) -> bool:
        """Проверка на наличие unit-ов у объекта"""
        raise NotImplementedError
