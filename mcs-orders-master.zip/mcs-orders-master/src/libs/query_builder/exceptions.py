from base.exception import ApplicationError


class UnitError(ApplicationError):
    """Базовое исключение модуля query_unit"""


class NotCallableNestedUnitCollection(UnitError):
    """
    Вызывается при невозможности оперировать вложенной коллекцией __units__
    у дочернего объекта
    """
