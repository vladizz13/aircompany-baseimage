from .query_unit import QueryUnit


class OrQueryUnit(QueryUnit):

    def build_query(self) -> dict:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        or_list: list = list()
        for unit in filter(lambda x: x and x.is_unit(), self.__units__):
            or_list.append(unit.build_query())
        return {"$or": or_list}
