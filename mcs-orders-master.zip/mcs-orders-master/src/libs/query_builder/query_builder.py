from .query_unit import QueryUnit
from .exceptions import NotCallableNestedUnitCollection


class QueryBuilder(QueryUnit):
    """
    Класс составления поискового запроса.
    Не может иметь дочерних unit-ов, т.к. является "самым дочерним" в иерархии QueryUnit
    """
    def __init__(self, expression: dict):
        super().__init__()
        self.__units__ = None
        self.expression = expression

    def build_query(self) -> dict:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        return self.expression

    def add(self, unit: 'QueryUnit') -> int:
        """
        Добавить unit к запросу
        :param unit: - Часть запроса
        :return: index
        """
        raise NotCallableNestedUnitCollection

    def remove(self, unit: 'QueryUnit') -> None:
        """
        Удалить unit из запроса
        :param unit: - Часть запроса
        :return: None
        """
        raise NotCallableNestedUnitCollection

    def get_child(self, index: int) -> 'QueryUnit':
        """
        Получить unit дочерний unit из запроса, по его индексу
        :param index: - индекс unit-a
        :return: BaseQueryUnit
        """
        raise NotCallableNestedUnitCollection

    def is_unit(self) -> bool:
        """Проверка на наличие unit-ов у объекта"""
        return bool(self.expression)
