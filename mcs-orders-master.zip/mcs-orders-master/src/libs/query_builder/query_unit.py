import typing
from .base_query_unit import BaseQueryUnit


class QueryUnit(BaseQueryUnit):

    def __init__(self):
        self.__units__: typing.List['QueryUnit'] = list()

    def add(self, unit: typing.Union[None, 'QueryUnit']) -> 'QueryUnit':
        """
        Добавить unit к запросу.
        Возваращает сам себя, с добавленным unit-ом, для того чтобы составлять цепочки "добавлений". Например:
        my_object = QueryUnit().add(...).add(...).add(...)
        :param unit: - Часть запроса
        :return: QueryUnit
        """
        if unit and unit.is_unit():
            self.__units__.append(unit)
        return self

    def remove(self, unit: 'QueryUnit') -> None:
        """
        Удалить unit из запроса
        :param unit: - Часть запроса
        :return: None
        """
        self.__units__.remove(unit)

    def get_child(self, index: int) -> 'QueryUnit':
        """
        Получить unit дочерний unit из запроса, по его индексу
        :param index: - индекс unit-a
        :return: BaseQueryUnit
        """
        return self.__units__[index]

    def build_query(self) -> dict:
        """
        Построить/склеить запрос из всех unit-ов
        :return: dict
        """
        query = {}
        for unit in filter(lambda x: x and x.is_unit(), self.__units__):
            query.update(unit.build_query())
        return query

    def is_unit(self) -> bool:
        """Проверка на наличие unit-ов у объекта"""
        return bool(self.__units__)
