from redis import Redis
from typing import Any, List


class BaseRedisQueue(object):

    __gateway__: Redis = None

    def __init__(self, gateway: Redis):
        self.__gateway__ = gateway

    def enqueue(self, key, value: Any):
        raise NotImplementedError()

    def dequeue(self, key, value: Any):
        raise NotImplementedError()

    def get_gateway(self) -> Redis:
        return self.__gateway__

    def __get_keys_by_pattern__(self, pattern: str, count=1000) -> List[str]:
        results = self.__gateway__.scan_iter(match=pattern, count=count)
        unique_results = list(set(results))
        return unique_results
