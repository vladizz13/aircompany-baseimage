from redis import Redis, ResponseError
import json
from .base import BaseRedisQueue
from typing import List, Any
from contextlib import contextmanager


class AlreadyLockedError(Exception):
    pass


class ListRedisQueue(BaseRedisQueue):
    """
    Очередь вида:
    'lock-key': 1,
    'queue-key': [ 'val', 'val' ....],
    'queue-key': [ 'val', 'val' ....],
    """

    queue_prefix = 'queue-'
    lock_prefix = 'lock-'
    lock_expiration = 5 * 60  # 5 минут

    def __init__(self, gateway: Redis):
        super(ListRedisQueue, self).__init__(gateway=gateway)

    def __get_lock_key__(self, key: str) -> str:
        """
        Ключ блокировки вида lock-key
        """
        return self.lock_prefix+key

    def __get_queue_key__(self, key: str) -> str:
        """
        Ключ очереди вида queue-key
        """
        return self.queue_prefix+key

    def queue_is_active(self, key: str, custom_key: bool = False) -> bool:
        """
        Проверяет имеется ли очередь
        """
        if self.get_queue_values_by_key(key, custom_key):
            return True
        return False

    def queue_is_locked(self, key: str) -> bool:
        """
        Проверяет имеется ли лок на очередь
        """
        if self.get_queue_values_by_key(
            key=self.__get_lock_key__(key)
        ):
            return True
        return False

    def unlock(self, key: str, custom_key: bool = False):
        """
        Разблокировать очередь
        """
        locked_key = self.__get_lock_key__(key) if not custom_key else key
        if self.__gateway__.get(locked_key):
            self.__gateway__.delete(locked_key)

    @contextmanager
    def lock(self, key: str, custom_key: bool = False):
        """
        Контекстный менеджер блокировки очереди
        """
        locked_key = self.__get_lock_key__(key) if not custom_key else key
        if self.__gateway__.get(locked_key):
            raise AlreadyLockedError('Order {} Already locked!'.format(key))

        self.__gateway__.set(locked_key, ex=self.lock_expiration, value=1)
        try:
            yield
        finally:
            self.__gateway__.delete(locked_key)

    def enqueue(self, key: str, value: Any):
        """
        value: Любая модель которая умееет сериализоваться/десериализоваться
        Создаем/берем очередь по ключу и добавляем в нее значение
        """
        queue_key = self.__get_queue_key__(key)
        self.__gateway__.lpush(queue_key, json.dumps(value.serialize()))

    def dequeue(self, key: str, value: Any):
        """
        value: Любая модель которая умееет сериализоваться/десериализоваться
        Находим по ключу очередь и удаляем элемент по значению
        """
        queue_key = self.__get_queue_key__(key)
        self.__gateway__.lrem(queue_key, count=0, value=json.dumps(value.serialize()))

    def get_queue_values_by_key(self, key: str, custom_key: bool = False) -> List[Any]:
        """
        Получить все элементы очереди по ключу
        """
        # Все элементы массива под ключем

        queue_key = self.__get_queue_key__(key) if not custom_key else key
        try:
            queued_items: List[Any] = self.__gateway__.lrange(queue_key, 0, -1)
        except ResponseError:
            queued_items: List[int] = self.__gateway__.get(queue_key)
        return queued_items

    def get_available_queue_keys(self, max_items: int = 250) -> List[str]:
        """
        Получаем все доступные ключи очередей
        """
        scan_pattern = self.queue_prefix+'*'
        return [i.replace(self.queue_prefix, '') for i in self.__get_keys_by_pattern__(scan_pattern, count=max_items)]

    def get_available_queue_locks(self) -> List[str]:
        """
        Получаем все доступные блокировки
        """
        scan_pattern = self.lock_prefix+'*'
        return [i.replace(self.lock_prefix, '') for i in self.__get_keys_by_pattern__(scan_pattern)]
