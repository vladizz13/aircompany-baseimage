"""
Клиент для подключения и прослушивания очереди раббита
"""
from abc import abstractmethod


class BaseRmqClient(object):

    connection_url: str = None

    @abstractmethod
    def start_listening(self, on_message: callable, queue):
        raise NotImplementedError()

    @staticmethod
    @abstractmethod
    def on_message_decorator(on_message: callable, decoder):
        raise NotImplementedError()
