import json
import xmltodict


class BaseResponseDecoder:
    """Парсер ответа"""

    @classmethod
    def decode(cls, data):
        raise NotImplementedError()


class JsonResponseDecoder(BaseResponseDecoder):
    """Парсер ответа в JSON"""

    @classmethod
    def decode(cls, data):
        return json.loads(data)


class XmlResponseDecoder(BaseResponseDecoder):
    """Парсер ответа в XML"""

    @classmethod
    def decode(cls, data):
        return dict(dict(xmltodict.parse(data)))
