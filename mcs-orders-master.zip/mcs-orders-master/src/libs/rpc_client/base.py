"""Базовый класс для работы с JSON-RPC сервисами"""
from base.adapter import BaseAdapter
from rest.settings.settings import SERVICE_NAME
from libs.utils.tools.logging import get_app_version
from typing import Optional

import typing
import logging

from requests import post
from requests.auth import HTTPBasicAuth
from requests import Timeout, ReadTimeout, ConnectionError

from .const import BatchRequestItem, BatchResponseItem

from .exceptions import (
    RPCServiceRequestError, RPCServiceConnectionError, RPCServiceTimeoutError, RPCServiceResponseError,
    RPCServiceParseError, RPCServiceInvalidRequest, RPCServiceMethodNotFound, RPCServiceMethodInvalidParams,
    RPCServiceInternalError, RPCServiceUnavailableError
)


logger = logging.getLogger('rpc-service')


class BaseRPCService(BaseAdapter):
    """Базовый класс для работы с JSON-RPC сервисами"""
    DEFAULT_TIMEOUT: int = 60

    # Базовые ошибки JSON-RPC сервиса
    __service_errors__: dict = {
        -32700: RPCServiceParseError,
        -32600: RPCServiceInvalidRequest,
        -32601: RPCServiceMethodNotFound,
        -32602: RPCServiceMethodInvalidParams,
        -32603: RPCServiceInternalError
    }

    # Ошибки JSON-RPC сервиса
    service_errors: dict = None
    # Ошибки JSON-RPC сервиса, которые будут скипнуты
    service_errors_to_skip: dict = dict()
    # Версия приложения, для идентификации запросов в кибане
    app_version = get_app_version()

    def __init__(self, url: str, username: str, password: str, verify: str = None, timeout: Optional[int] = None):
        """
        :param url: Адрес сервиса
        :param user: Пользователь
        :param password: Пароль
        :param certificate: Путь к файлу сертификата (если не передан то проверяться не будет)
        """
        self.__url__ = url
        self.__auth__ = HTTPBasicAuth(username, password)
        self.__verify__ = verify or False
        self.__timeout__ = timeout

        if self.service_errors:
            self.__service_errors__ = dict(self.__service_errors__)
            self.__service_errors__.update(self.service_errors)

    def __check_error__(self, response: dict):
        """
        Проверить ошибку в ответе
        :param response: Ответ JSON-RPC сервиса
        """
        error = response.get('error')

        if not error:
            return

        code = error.get('code')
        message = error.get('message')

        if code:
            if code in self.__service_errors__:
                err = self.__service_errors__[code]()
                if message:
                    err.message = message
                raise err
            if code in self.service_errors_to_skip:
                logger.warning(self.service_errors_to_skip[code].message)
                return

        raise RPCServiceResponseError(error.get('message'))

    def __get_error__(self, response: dict) -> typing.Optional[RPCServiceResponseError]:
        """
        Получить ошибку из ответа
        :param response: Ответ JSON-RPC сервиса
        """
        error = response.get('error')

        if not error:
            return None

        code = error.get('code')

        if code and code in self.__service_errors__:
            return self.__service_errors__[code]()

        return RPCServiceResponseError(error.get('message'))

    def __request__(self, body: typing.Union[dict, list]) -> typing.Any:

        headers = {
            "User-Agent": "{}/{}".format(SERVICE_NAME, self.app_version)
        }

        try:
            response = post(
                self.__url__,
                auth=self.__auth__,
                json=body,
                verify=self.__verify__,
                headers=headers,
                timeout=self.__timeout__ or self.DEFAULT_TIMEOUT
            )
        except ConnectionError:
            raise RPCServiceConnectionError()
        except (Timeout, ReadTimeout):
            raise RPCServiceTimeoutError()
        except Exception as ex:
            logger.exception(ex)
            raise RPCServiceRequestError()

        if response.status_code in [502, 503]:
            raise RPCServiceUnavailableError()

        if response.status_code != 200:
            raise RPCServiceResponseError(response.text)

        return response.json()

    def request(self, method: str, request_id: int = None, **kwargs) -> typing.Any:
        """
        Выполнить запрос к JSON-RPC сервису
        :param method: Метод
        :param request_id: Id
        :param kwargs: Параметры метода
        :return: Результат
        """
        headers = {
            "User-Agent": "{}/{}".format(SERVICE_NAME, self.app_version)
        }

        try:
            response = post(
                self.__url__,
                auth=self.__auth__,
                json={
                    'jsonrpc': '2.0',
                    'method': method,
                    'params': kwargs,
                    'id': request_id
                },
                verify=self.__verify__,
                headers=headers,
                timeout=self.__timeout__ or self.DEFAULT_TIMEOUT
            )
        except ConnectionError:
            raise RPCServiceConnectionError()
        except (Timeout, ReadTimeout):
            raise RPCServiceTimeoutError()
        except Exception as ex:
            logging.exception(ex)
            raise RPCServiceRequestError()

        if response.status_code in [502, 503]:
            raise RPCServiceUnavailableError()

        if response.status_code != 200:
            raise RPCServiceResponseError(response.text)

        response = response.json()

        self.__check_error__(response)

        return response.get('result')

    def batch_request(self, method: str, batch: typing.List[BatchRequestItem]) -> typing.List[BatchResponseItem]:
        """
        Выполнить пакетный запрос к JSON-RPC сервису
        :param method: Метод
        :param batch: Параметры
        :return: Результат
        """
        response = self.__request__(
            body=[{
                'jsonrpc': '2.0',
                'method': method,
                'id': batch_item.id,
                'params': batch_item.params,
            } for batch_item in batch]
        )

        if not isinstance(response, list):
            self.__check_error__(response)
            raise RPCServiceResponseError(response.text)

        result = []

        for batch_item in response:
            error = self.__get_error__(batch_item)

            if error:
                logger.error(error)
            else:
                result.append(BatchResponseItem(id=batch_item.get('id'), result=batch_item.get('result')))

        return result
