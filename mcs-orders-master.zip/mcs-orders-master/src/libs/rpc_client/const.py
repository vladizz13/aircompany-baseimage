from collections import namedtuple

BatchRequestItem = namedtuple('BatchRequestItem', 'id params')
BatchResponseItem = namedtuple('BatchResponseItem', 'id result')
