from base.exception import ApplicationError


class RPCServiceError(ApplicationError):
    """
    Сервисная ошибка работы с RPC
    """
    status = 500
    code = 50001
    message = 'RPC service error'


class RPCServiceRequestError(RPCServiceError):
    """
    Ошибка запроса к серверу
    """
    code = 50002
    message = 'RPC service request error'


class RPCServiceConnectionError(RPCServiceRequestError):
    """
    Ошибка соединения с сервисом
    """
    code = 50003
    message = 'RPC service connection error'


class RPCServiceTimeoutError(RPCServiceRequestError):
    """
    Сервис не отвечает
    """
    code = 50004
    message = 'RPC service timeout error'


class RPCServiceResponseError(RPCServiceError):
    """
    Некорректный ответ сервиса
    """
    code = 50005
    message = 'RPC service response error'


class RPCServiceParseError(RPCServiceResponseError):
    """
    Invalid JSON was received by the server
    """
    code = 50006
    message = 'RPC service parse error'


class RPCServiceInvalidRequest(RPCServiceResponseError):
    """
    The JSON sent is not a valid Request object
    """
    code = 50007
    message = 'RPC service invalid request error'


class RPCServiceMethodNotFound(RPCServiceResponseError):
    """
    The method does not exist / is not available
    """
    code = 50008
    message = 'RPC service method not found error'


class RPCServiceMethodInvalidParams(RPCServiceResponseError):
    """
    Invalid method parameter(s)
    """
    code = 50009
    message = 'RPC service invalid params error'


class RPCServiceInternalError(RPCServiceResponseError):
    """
    Internal JSON-RPC error
    """
    code = 50010
    message = 'RPC service internal error'


class RPCServiceUnavailableError(RPCServiceResponseError):
    """
    RPC Service unavailable HTTP 502, 503
    """
    code = 50011
    message = 'RPC service unavailable error'
