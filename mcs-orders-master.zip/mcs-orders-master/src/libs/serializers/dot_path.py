from typing import Union, List, Dict, Set
from base.domain import BaseDomain


class DotPathSerializerError(Exception):
    pass


class DotPathSerializer(object):
    """
    Example usage:
    >>>fields_to_return = [
    >>>    'rloc',
    >>>
    >>>    'tickets.ticket',
    >>>    'tickets.passenger_id',
    >>>    'tickets.monetary_info.taxes.amount',
    >>>    'tickets.monetary_info.taxes.amount_rub',
    >>>
    >>>    'segments.segment_id',
    >>>    'segments.ak',
    >>>    'segments.marketing_tags.times_of_day',
    >>>    'segments.marketing_tags.party',
    >>>
    >>>    'passengers.first_name',
    >>>    'passengers.last_name',
    >>>
    >>>    'coupons.passenger_id',
    >>>    'coupons.ticket',
    >>>    'coupons.coupon_money.discount'
    >>>]
    >>> from domain import DomainOrder
    >>> order = DomainOrder()
    >>> sweeped_order   = DotPathSerializer(order.data).serialize(fields_to_return)
    >>> sweeped_order_2 = DotPathSerializer(order.data.serialize()).serialize(fields_to_return)

    """

    def __init__(
            self,
            object_to_sweep: Union[Dict, BaseDomain]
    ):
        self.object_to_sweep = object_to_sweep

    def serialize(self, path_list: Union[List, Set], silent: bool = False) -> Dict:
        """
        :param path_list: Массив из путей к данным через точку
        :param silent: Нужно ли выкидывать ошибку при дубликации полей, по дефолту кидаем DotPathSerializerError
        :return:
        """
        try:
            if not silent:
                self.check_duplicate_paths(path_list)
            return self.__remove_unwanted_fields__(
                self.__map_fields__(path_list)
            )
        except (IndexError, AttributeError, DotPathSerializerError) as e:
            raise DotPathSerializerError(e)

    @staticmethod
    def check_duplicate_paths(path_list: List):
        """
        Проверка на дублирование путей, например передали segments и segments.segment_id
        так как такой запрос не имеет смысла, а результат зависит от последовательности переданных полей
        сообщаем об этом
        """
        if not path_list:
            return
        splitted_fields = [f.split('.') for f in path_list if '.' in f]
        duplicated_paths = [f[0] for f in splitted_fields if len(f) > 1 and f[0] in path_list]
        if duplicated_paths:
            raise DotPathSerializerError(
                f"Duplicated paths provided, check fields that starts with: {set(duplicated_paths)}"
            )

    @staticmethod
    def __map_fields__(fields: List) -> Dict:
        """
        Мапим поля в структуру, с которой далее будет удобно работать
        :param fields: Поля, которые нужно оставить, вида ['rloc', 'tickets.monetary_info.taxes.amount']
        :return: Ремапленные поля
        """
        """
        Ключ словаря - первый уровень пути, далее в массиве ключи, которые находятся в глубине
        Это сделано для того, чтобы избежать вырезание повторных путей, однако путь с повторным адресом,
        например, key.go_here.go_there.go_here - не сработает. Для того, чтоб можно было вырезать по таким путям
        требуется следить на каком мы уровне в функции удаления данных по ключам self._remove_keys_ и удалять из массива
        ключи по индексу (индекс==уровень, на котором мы были)
        {
            "rloc": null,
            "tickets": [
                "monetary_info",
                "taxes",
                "amount
            ]
        }
        """
        result = dict()
        for item in fields:
            path = item.split('.')
            # Рутовые поля
            if len(path) == 1:
                result[path[0]] = None
                continue
            # Вложенные поля
            path = item.split('.', 1)
            if not result.get(path[0]):
                result[path[0]] = []
            result[path[0]].append(path[1])
        return result

    @staticmethod
    def __unpack_deep_paths__(path_list: List):
        """
        Распаковываем вложенные пути
        :param path_list: ['coupon_money.discount.some.deep.pathes']
        :return: ['coupon_money', 'discount', 'some' .... ]
        """
        unpacked_path_list = []
        cleaned_path_list = [i.split('.') if '.' in i else i for i in path_list]
        for cp in cleaned_path_list:
            if isinstance(cp, list):
                [unpacked_path_list.append(_cp) for _cp in cp]
                continue
            unpacked_path_list.append(cp)
        return unpacked_path_list

    def __remove_nested_fields__(self, nested_field: Dict, path_list: List):
        unpacked_path_list = self.__unpack_deep_paths__(path_list)
        result = self.__remove_keys__(nested_field, unpacked_path_list)
        return result

    def __remove_keys__(self, obj: Union[Dict, List], path_list: List) -> Union[Dict, List]:
        """
        Рекурсивно удаляем поля из переданного объекта, которых нет в path_list
        :param obj: Объект из которого нужно вырезать поля, может быть любой вложенности
        :param path_list: Массив полей, которые нужно оставить
        :return:
        """
        if isinstance(obj, dict):
            if not any(path in path_list for path in obj.keys()):
                # Это последняя итерация, не можем найти ключи во вложенном словаре
                # значит это последний по глубине словарь и нам нужны все поля из него
                return obj

            obj: Dict = {
                key: self.__remove_keys__(value, path_list)
                for key, value in obj.items()
                if key in path_list
            }

        elif isinstance(obj, list):
            obj: List = [
                self.__remove_keys__(item, path_list) for item in obj if item not in path_list
            ]
        return obj

    def __remove_unwanted_fields__(self, mapped_fields: Dict):
        if isinstance(self.object_to_sweep, BaseDomain):
            self.object_to_sweep: Dict = self.object_to_sweep.serialize()
        remapped_data = dict()
        for key, value in self.object_to_sweep.items():
            if key not in mapped_fields.keys():
                continue
            if not mapped_fields.get(key):
                # Рутовые поля
                remapped_data.update({key: value})
                continue
            remapped_data.update({
                key: self.__remove_nested_fields__(value, mapped_fields.get(key))
            })
        return remapped_data
