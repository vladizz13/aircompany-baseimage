import collections


def get_dict_val(key_chain, data):
    """
    Return value of mappable by keys chain:
        exists, value
    """
    if not key_chain:
        return True, data

    k = key_chain[0]
    key_chain = key_chain[1:]

    if k not in data:
        return False, None
    else:
        return get_dict_val(key_chain, data.get(k))


def make_dict_flat(data, flat_key='', delim='__'):
    """
    Return list of flat values
    """
    if not data:
        return {}

    flat_values = {}
    for k, v in data.items():
        flat_k = '{}{}{}'.format(flat_key, delim, k) if flat_key else k
        if isinstance(v, dict):
            flat_values.update(make_dict_flat(v, flat_k, delim))
        else:
            flat_values[flat_k] = v
    return flat_values


def deep_convert_dict(layer):
    """
    Конвертация OrderedDict в обычный словарь
    Note: полезно для дебага
    """
    to_ret = layer
    if isinstance(layer, collections.OrderedDict):
        to_ret = dict(layer)
    try:
        for key, value in to_ret.items():
            if isinstance(value, list):
                to_ret[key] = [deep_convert_dict(v) for v in value]
            else:
                to_ret[key] = deep_convert_dict(value)
    except AttributeError:
        pass
    return to_ret
