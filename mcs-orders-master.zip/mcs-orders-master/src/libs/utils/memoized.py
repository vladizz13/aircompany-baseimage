'''
Утилита для мемоизации. Аналог утилиты из prompt_toolkit,
но с возвожностью мемоизации аргументов словарей, объектов и тп.
'''
import pickle


def memoized(func):
    '''
    Функция возвращает декорированную функцию func.
    При вызове декорированной версии этой функции в первый раз - результат ее выполнения сохраняется
    в переменную из замыкания memory. При вызове этой функции с теми же аргументами, функция не выполняется повторно,
    а выбирает результат предыдущего выполнения из memory.
    !!!ВАЖНО!!!
    Мемоизировать можно ТОЛЬКО ЧИСТЫЕ ФУНКЦИИ!
    https://ru.wikipedia.org/wiki/%D0%A7%D0%B8%D1%81%D1%82%D0%BE%D1%82%D0%B0_%D1%84%D1%83%D0%BD%D0%BA%D1%86%D0%B8%D0%B8
    '''
    memory = {}

    def memo(*args, **kwargs):
        dump = pickle.dumps((args, sorted(kwargs.items())))
        hash_sum = hash(dump)
        if hash_sum not in memory:
            memory[hash_sum] = func(*args, **kwargs)
        return memory[hash_sum]

    return memo
