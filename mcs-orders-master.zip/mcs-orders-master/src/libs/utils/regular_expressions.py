import re
from domain.types import LoyaltyStatus


def loyalty_status(ssr_text: str):
    _FQTV_RE = re.compile(r'^UT(\d+)(\.(\w+))?')  # UT{card_number}.{LEVEL}

    def _get_fqtv_level():
        match = _FQTV_RE.match(ssr_text or '')
        if match:
            return match.group(3)

    if _get_fqtv_level() == LoyaltyStatus.GOLD.value:
        return LoyaltyStatus.GOLD.value
    if _get_fqtv_level() == LoyaltyStatus.SILVER.value:
        return LoyaltyStatus.SILVER.value
    if _get_fqtv_level() == LoyaltyStatus.BRONZE.value:
        return LoyaltyStatus.BRONZE.value
    if _get_fqtv_level() == LoyaltyStatus.BASIC.value:
        return LoyaltyStatus.BASIC.value
    return LoyaltyStatus.UNDEFINED.value
