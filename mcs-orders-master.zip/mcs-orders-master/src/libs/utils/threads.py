from typing import Callable, List, Union


def bulk_requests(request_call: Callable, many_request_kwargs: List[dict]) -> List[Union[Exception, list, dict]]:
    # todo: Пришлось убрать потоки. В рамках другой задачи будем подключать новый клиент
    return [
        request_call(**request)
        for request in many_request_kwargs
    ]
