from threading import Thread


def timeout(func, args: tuple = (), kwargs: dict = {}, timeout: int = 3, default=None):

    class InterruptableThread(Thread):
        def __init__(self):
            Thread.__init__(self)
            self.result = None

        def run(self):
            try:
                self.result = func(*args, **kwargs)
            except Exception:
                self.result = default

    it = InterruptableThread()
    it.start()
    it.join(timeout)
    result = getattr(it, 'result', default)
    return result if result is not None else default
