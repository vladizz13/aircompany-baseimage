import requests


def rewrite_config_from_vault(api_url: str, namespace: str, secret_name: str, api_token: str, global_settings: dict):
    """
    Заменяет константы в настройках константами из vault
    :param api_url: url vault
    :param namespace: группа секретов
    :param secret_name: Имя секретов
    :param api_token: Токен для запросов в vault
    :param global_settings: globals() из файла в котором нужно заменить константы
    """
    url = f"{api_url}/v1/{namespace}/data/{secret_name}"
    response = requests.get(url, headers={"X-Vault-Token": api_token})
    if response.status_code != 200:
        raise Exception(response)
    response_data = response.json()
    for k, v in response_data.get("data", {}).get("data", {}).items():
        global_settings[k] = v
