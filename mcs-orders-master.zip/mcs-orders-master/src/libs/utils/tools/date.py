from datetime import datetime, date, timezone, timedelta
import pytz


def get_utc_date_fromtimestamp(ts: int) -> date:
    '''Получить UTC дату по timestamp'''
    return datetime.fromtimestamp(ts, timezone.utc).date()


def convert_datetime_string_to_datetime(dt_str: str, dt_format: str, timezone) -> datetime:
    '''Конвертировать дату-время в виде строки в объект datetime c зоной

    dt_str - дата-время в виде строки
    timezone - объект временной зоны, которой принадлежит dt_str
    dt_format - формат даты и времени для  dt_str
    '''
    assert dt_str
    assert dt_format
    assert timezone

    dt_obj = datetime.strptime(dt_str, dt_format)

    if isinstance(timezone, str):
        return pytz.timezone(timezone).localize(dt_obj).astimezone(pytz.utc)

    return datetime(
        dt_obj.year,
        dt_obj.month,
        dt_obj.day,
        dt_obj.hour,
        dt_obj.minute,
        dt_obj.second,
        tzinfo=timezone,
    )


def convert_datetime_string_to_timestamp(dt_str: str, dt_format: str, timezone) -> int:
    '''Конвертировать дату-время в виде строки в UNIX timestamp

    dt_str - дата-время в виде строки
    timezone - объект временной зоны, которой принадлежит dt_str
    dt_format - формат даты и времени для  dt_str
    '''
    assert dt_str
    assert dt_format
    assert timezone

    if isinstance(dt_str, datetime):
        dt_str = dt_str.strftime(dt_format)
    dt_obj = convert_datetime_string_to_datetime(dt_str, dt_format, timezone)

    return int(dt_obj.timestamp())


def get_age_from_date(birthday):
    """Получение возвраста
    :birthday: Дата рождения в datetime.date
    """
    today = date.today()
    age = today.year - birthday.year
    if today.month < birthday.month:
        age -= 1
    elif today.month == birthday.month and today.day < birthday.day:
        age -= 1
    return age


def time_to_seconds(value: str) -> int:
    if not value:
        return 0

    parts = value.split(':')

    if len(parts) != 2:
        return 0

    value_delta = timedelta(hours=int(parts[0]), minutes=int(parts[1]))
    return int(value_delta.total_seconds())


def parse_sirena_bad_datetime(date_value: str, time_value: str) -> datetime:
    date_ = parse_sirena_bad_date(date_value)
    return datetime.strptime(f'{date_} {time_value}', '%Y-%m-%d %H:%M')


def parse_sirena_bad_date(value: str):
    """
    01.03.23 -> 2023-03-01

    Интересный формат передачи даты от сирены
    Не знаю что будет в 2100 году...
    """
    day, month, short_year = value.split('.')
    return f'20{short_year}-{month}-{day}'
