import os

from raven import Client, fetch_git_sha


def get_app_version() -> str:
    '''
    Получить версию приложения
    '''
    version = os.getenv('APP_VERSION')
    if version is None:
        version = fetch_git_sha(
            os.path.abspath(os.path.join(
                os.path.dirname(__file__),
                '..', '..', '..', '..',
            ))
        )
    return version


def setup_sentry_client(dsn: str, env: str = None) -> Client:
    '''Получить Sentry клиент'''
    return Client(
        dsn=dsn,
        auto_log_stacks=True,
        release=get_app_version(),
        environment=env,
    )
