import os


def proj_path(project_root, *args):
    """
    Получить абсолютный путь к args в проекте
    """
    return os.path.realpath(os.path.join(project_root, *args))


def get_nested_last_values_from_dict(value: dict):
    """
    Возвращает все последние значения из вложенного словаря
    :param value: словарь со вложенными структурами
    """

    for v in value.values():
        if isinstance(v, dict):
            yield from get_nested_last_values_from_dict(v)
        else:
            yield v
