import fastjsonschema

from rest.settings.settings import PROJECT_ROOT

from importlib import import_module
import pkgutil


def make_strict_schema(schema: dict, level: int = 0) -> dict:
    """Сделать схему строгой"""
    new_schema = schema.copy()

    for k, v in new_schema.items():
        if isinstance(v, dict):
            new_schema[k] = make_strict_schema(v, level + 1)
            if 'properties' in v:
                new_schema[k]['additionalProperties'] = False

    if level == 0:
        new_schema['additionalProperties'] = False
    return new_schema


def jsonschema_validate_strict(params, schema):
    """
    Валидация json
    """
    strict_schema = make_strict_schema(schema)
    return fastjsonschema.validate(strict_schema, params)


def get_schema(name: str) -> [object]:
    """
    Возвращает json схему по названию. Ищет в заданном в настройках package
    модулях в атрибуте __all__

    :param name: Название схемы
    :return: schema object or raise NameError
    """
    if not name:
        raise NameError('Specify schema name!')
    schemas_path = __package__ + '.schemas'
    pkg_schemas = import_module(schemas_path)

    for loader, module_name, is_pkg in pkgutil.walk_packages(
            pkg_schemas.__path__, pkg_schemas.__name__ + '.'
    ):
        mod_name = import_module(module_name, pkg_schemas)
        if name in getattr(mod_name, '__all__', []):
            return getattr(mod_name, name)


class SchemaCompiler(object):
    schemas_path = '{}/src/libs/validators/compiled_schemas'.format(PROJECT_ROOT)

    schemas = [
        'order_schema',
        'airline_transaction_schema',
        'mono_app_schema'
    ]

    def compile(self):
        for schema in self.schemas:
            # При неудачной компиляции выкинет JsonSchemaDefinitionException
            schema_code = fastjsonschema.compile_to_code(
                make_strict_schema(
                    get_schema(schema)
                )
            )

            with open('{}/{}.py'.format(self.schemas_path, schema), 'w', encoding='utf-8') as file:
                file.write('# flake8: noqa\n')
                file.write(schema_code)
