"""Схема для заказов"""
from domain import types

__all__ = ('airline_transaction_schema',)

airline_transaction_schema = {
    'id': 'airline_transaction',
    'title': 'Транзакция',
    'description': 'Авиационная транзакция',
    'type': 'object',
    '$schema': 'http://json-schema.org/draft-07/schema#',
    'definitions': {
        'remark': {
            'type': 'object',
            'description': 'Ремарки',
            'properties': {
                'remark_id': {
                    'type': ['string', 'null'],
                    'description': 'Порядковый номер ремарки'
                },
                'carrier': {
                    'type': ['string', 'null'],
                    'description': 'Система, которая добавила ремарку'
                },
                'text': {
                    'type': ['string', 'null'],
                    'description': 'Текст ремарки'
                }
            }
        },
        'passenger': {
            'type': 'object',
            'description': 'Информация о пасажире',
            'properties': {
                'passenger_id': {
                    'type': 'string',
                    'description': 'ID пассажира внутри заказа'
                },
                'parent_id': {
                    'type': ['string', 'null'],
                    'description': 'ID Родителя пасажира'
                },
                'tais_passenger_id': {
                    'type': ['string', 'integer', 'null'],
                    'description': 'ID пассажира внутри заказа'
                },
                'first_name': {
                    'type': 'string',
                    'description': 'Имя пользователя'
                },
                'last_name': {
                    'type': 'string',
                    'description': 'Фамилия пользователя'
                },
                'second_name': {
                    'type': ['string', 'null'],
                    'description': 'Отчество пассажира'
                },
                'loyalty_cardnumber': {
                    'type': ['string', 'null'],
                    'description': 'Номер карты бонусной программы'
                },
                'type': {
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(types.PassengerCategory._value2member_map_)},
                        {'type': 'null'}
                    ],
                },
                'gender': {
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(types.Gender._value2member_map_)},
                        {'type': 'null'}
                    ],
                    'description': 'Пол'
                },
                'category': {
                    'type': ['string', 'null'],
                    'description': 'Дополнительная (маркетинговая) категоризация пассажира'
                },
                'title': {
                    'type': ['string', 'null'],
                    'description': 'Обращение к пассажиру (Mr/Mrs)'
                },
            }
        },
        'document': {
            'type': 'object',
            'description': 'Информация о документах пассажира',
            'properties': {
                'passenger_id': {
                    'type': 'string',
                    'description': 'ID пассажира внутри заказа'
                },
                'birthday': {
                    'type': ['string', 'null'],
                    'description': 'Дата рождения пассажира'
                },
                'doccountry': {
                    'type': ['string', 'null'],
                    'description': 'Страна выдачи документа'
                },
                'docexpiration': {
                    'type': ['string', 'null'],
                    'description': 'Дата истечения документа'
                },
                'docnumber': {
                    'type': ['string', 'null'],
                    'description': 'Номер документа'
                },
                'doctype': {
                    'type': ['string', 'null'],
                    'description': 'Тип документа'
                },
            }
        },
        'segment': {
            'type': 'object',
            'description': 'Информация о сегменте',
            'properties': {
                'segment_id': {
                    'type': 'string',
                    'description': 'Идентификатор сегмента внутри pnr'
                },
                'tais_segment_id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента в ТАИС'
                },
                'ak': {
                    'type': ['string', 'null'],
                    'description': 'Название авиакомпании'
                },
                'ak_full_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название авиакомпании,'
                                   ' создавшей рейс'
                },
                'oak': {
                    'type': ['string', 'null'],
                    'description': 'Название авиакомпании, выполняющей рейс'
                },
                'oak_full_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название авиакомпании,'
                                   ' выполняющей рейс'
                },
                'arrival_airport_code': {
                    'type': 'string',
                    'description': 'Код аэропорта прибытия'
                },
                'arrival_city_code': {
                    'type': 'string',
                    'description': 'Код города прибытия'
                },
                'departure_airport_code': {
                    'type': 'string',
                    'description': 'Код аэропорта вылета'
                },
                'departure_city_code': {
                    'type': 'string',
                    'description': 'Код города вылета'
                },
                'class': {
                    'type': ['string', 'null'],
                    'description': 'Класс полета'
                },
                'rbd': {
                    'type': ['string', 'null'],
                    'description': 'Класс бронирования'
                },
                'standby': {
                    'type': ['boolean', 'null'],
                    'description': 'Признак билета на подсадку'
                },
                'direction': {
                    'type': 'string',
                    'description': 'Направление сегмента'
                },
                'duration': {
                    'type': ['integer', 'null'],
                    'description': 'Длительность полета в секундах'
                },
                'flight_number': {
                    'type': ['string', 'null'],
                    'description': 'Номер рейса'
                },
                'layover_time': {
                    'type': ['integer', 'null'],
                    'description': 'Время ожидания между рейсами. Вычисляемое нами'
                },
                'plane_type': {
                    'type': ['string', 'null'],
                    'description': 'Тип самолета кратко'
                },
                'plane_type_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название типа самолета'
                },
                'status': {
                    'type': ['string', 'null'],
                    'description': 'Статус сегмента'
                },
                'status_visual': {
                    'type': ['string', 'null'],
                    'description': 'Статус сегмента'
                },
                'seg_type': {
                    'type': ['string', 'null'],
                    'description': 'Тип сегмента'
                },
                'ns': {
                    'type': ['number', 'null'],
                    'description': 'Количество мест забронированных на борту'
                },
                'arrival_local_iso': {
                    'type': ['number', 'string', 'null'],
                    'description': 'Дата и время прибытия в локальном времени'
                },
                'arrival_timestamp': {
                    'type': ['number', 'null'],
                    'description': 'Дата и время прибытия по utc в unixtime'
                },
                'departure_local_iso': {
                    'type': ['number', 'string', 'null'],
                    'description': 'Дата и время прибытия в локальном времени'
                },
                'departure_timestamp': {
                    'type': ['number', 'null'],
                    'description': 'Дата и время вылета по utc в unixtime'
                },
                'booking_timestamp': {
                    'type': ['integer', 'null'],
                    'description': 'Время создания брони'
                },
                'marketing_tags': {
                    'type': 'object',
                    'description': 'Маркетинговые характеристики',
                    'properties': {
                        'times_of_day': {
                            'type': ['string', 'null'],
                            'oneOf': [
                                {'enum': list(types.TimesOfDay.__members__)},
                                {'type': 'null'}
                            ],
                            'description': 'Время суток',
                        },
                        'baby': {
                            'type': ['boolean', 'null'],
                            'description': 'В броне есть хотя бы один РМ'
                        },
                        'party': {
                            'type': ['boolean', 'null'],
                            'description': 'От 3х взрослых в броне'
                        },
                        'pair': {
                            'type': ['boolean', 'null'],
                            'description': 'Два человека в броне, оба взрослые, разных полов'
                        },
                    },
                },
                'gds_active': {
                    'type': ['boolean', 'null'],
                    'description': 'Чек актуальности'
                },
            },
        },
        'ticket': {
            'type': 'object',
            'description': 'Данные о каждом билете',
            'properties': {
                'ticket': {
                    'type': 'string',
                    'description': 'Номер билета'
                },
                'passenger_id': {
                    'type': 'string',
                    'description': 'ID пассажира внутри заказа'
                },
                'fare_calc': {
                    'type': ['string', 'null'],
                    'description': 'Строка расчета(построения) тарифа'
                },
                'issue_datetime': {
                    'type': ['integer', 'null'],
                    'description': 'Время выпуска билетов'
                },
                'taxes': {
                    'description': 'Список всех сборов по типам',
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/tax'
                    }
                },
                'monetary_info': {
                    'description': 'Список базовых тарифов',
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/monetary_info'
                    }
                }
            }
        },
        'tax': {
            'type': 'object',
            'description': 'Сборы',
            'properties': {
                'coupon_id': {
                    'type': ['string', 'null'],
                    'description': 'ID купона, которому принадлежит тариф'
                },
                'code': {
                    'type': ['string', 'null'],
                    'description': 'Код сбора'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость сбора'
                },
                'amount_rub': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость сбора в рублях'
                },
                'category': {
                    'type': ['string', 'null'],
                    'description': 'Категория сбора'
                },
                'owner': {
                    'type': ['string', 'null'],
                    'description': 'Агент'
                },
            },
        },
        'monetary_info': {
            'type': 'object',
            'description': 'Список базовых тарифов',
            'properties': {
                'coupon_id': {
                    'type': ['string', 'null'],
                    'description': 'ID купона, которому принадлежит тариф'
                },
                'code': {
                    'type': ['string', 'null'],
                    'description': 'Код тарифа'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Размер тарифа'
                },
                'currency': {
                    'type': ['string', 'null'],
                    'description': 'Валюта тарифа'
                },
                'amount_rub': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость сбора в рублях'
                }
            },
        },
        'coupon': {
            'type': 'object',
            'description': 'Информация о купонах',
            'properties': {
                'number': {
                    'type': ['number', 'null'],
                    'description': 'Номер купона'
                },
                'ticket': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета, к которому относится купон'
                },
                'passenger_id': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира, на которого выписан купон'
                },
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента, на который выписан купон'
                },
                'status': {
                    'type': 'string',
                    'description': 'Cтатус купона'
                },
                'sac': {
                    'type': ['string', 'null'],
                    'description': 'Код авторизации в СЭБ при переходе купона в конечное состояние'
                },
                'fare_code': {
                    'type': ['string', 'null'],
                    'description': 'Код тарифа'
                },
                'op_comment': {
                    'type': ['string', 'null'],
                    'description': 'Комментарий'
                },
                'marketing': {
                    'type': ['string', 'null'],
                    'description': 'Рейс, как его продала компания'
                },
                'operating': {
                    'type': ['string', 'null'],
                    'description': 'Рейс, как он числится '
                                   'в компании-перевозчике'
                },
                'updated': {
                    'type': ['array', 'null'],
                    'description': "История обновления статуса купона",
                    'items': {
                        '$ref': '#/definitions/coupon_status_update'
                    }
                },
                'flights': {
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/flight'
                    }
                },
                'coupon_money': {
                    'type': 'object',
                    'description': 'Стоимость купона',
                    'properties': {
                        'fare': {
                            'type': ['integer', 'null'],
                            'description': 'сумма тарифа купона'
                        },
                        'tax': {
                            'type': ['integer', 'null'],
                            'description': 'сумма сборов купона'
                        },
                        'discount': {
                            'type': ['integer', 'null'],
                            'description': 'сумма сборов купона'
                        },
                    }
                },
            },
        },
        'order_status_updated': {
            'type': 'object',
            'description': 'Информация о предыдущих статусах заказа',
            'properties': {
                'status': {
                    'type': ['string', 'null'],
                    'description': 'Статус заказа'
                },
                'date': {
                    'type': ['number', 'null'],
                    'description': 'Время создание записи'
                },
            }
        },
        'coupon_status_update': {
            'type': 'object',
            'description': 'Информация о предыдущих статусах купона',
            'properties': {
                'status': {
                    'type': ['string', 'null'],
                    'description': 'Статус купона'
                },
                'date': {
                    'type': ['number', 'null'],
                    'description': 'Время создание записи'
                },
            }
        },
        'flight': {
            'type': 'object',
            'description': 'Информация о полетах',
            'properties': {
                'marketing': {
                    'type': ['string', 'null'],
                    'description': 'Рейс, как его продала компания'
                },
                'operating': {
                    'type': ['string', 'null'],
                    'description': 'Рейс, как он числится '
                                   'в компании-перевозчике'
                },
                'departure_airport_code': {
                    'type': ['string', 'null'],
                    'description': 'Код аэропорта вылета'
                },
                'arrival_airport_code': {
                    'type': ['string', 'null'],
                    'description': 'Код аэропорта прибытия'
                },
                'rbd': {
                    'type': ['string', 'null'],
                    'description': 'Класс бронирования'
                },
                'departure_local_iso': {
                    'type': ['string', 'null'],
                    'description': 'Дата и время вылета по utc в unixtime'
                },
                'booking_timestamp': {
                    'type': ['number', 'null'],
                    'description': 'Время бронирования сегмента'
                },
                'created': {
                    'type': ['number', 'null'],
                    'description': 'Время добавления полета в купон'
                },
            },
        },
        'offer': {
            'type': 'object',
            'description': 'информация о тарифе',
            'properties': {
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'Идентификатор сегмента'
                },
                'brand_code': {
                    'type': ['string', 'null'],
                    'description': 'Наименование тарифа'
                },
                'brand_name': {
                    'description': 'Код тарифа согласно правилам сайта',
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(types.BrandName._value2member_map_)},
                        {'type': 'null'}
                    ],
                },
                'fare_code': {
                    'type': ['string', 'null'],
                    'description': 'Код тарифа'
                }
            }
        },
        'service': {
            'type': 'object',
            'description': 'список дополнительных услуг',
            'properties': {
                'guid': {
                    'type': ['string', 'null'],
                    'description': 'уникальный guid услуги из service_agent"а'
                },
                'emd': {
                    'type': ['string', 'null'],
                    'description': 'Номер Emd'
                },
                'emd_type': {
                    'type': ['string', 'null'],
                    'description': 'Тип Emd'
                },
                'count': {
                    'type': ['integer', 'null'],
                    'description': 'Количество купленной услуги'
                },
                'description': {
                    'type': ['string', 'null'],
                    'description': 'Описание услуги. Приходит пустым'
                },
                'tais_id': {
                    'type': ['string', 'null'],
                    'description': 'ID услуги в ТАИС'
                },
                'link': {
                    'type': ['string', 'null'],
                    'description': 'Ссылка на договор по услуге'
                },
                'pdf_link': {
                    'type': ['string', 'null'],
                    'description': 'Ссылка на pdf с описанием услуги'
                },
                'ins_num': {
                    'type': ['null', 'string'],
                    'description': 'Номер страховки'
                },
                'ins_id': {
                    'type': ['null', 'string'],
                    'description': 'Идентификатор страховки'
                },
                'exchangeable': {
                    'type': ['null', 'boolean'],
                    'description': 'Возможность обмена'
                },
                'passenger_id': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира, для которого куплена данная '
                                   'услуга'
                },
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента, для которого куплена данная '
                                   'услуга'
                },
                'status': {
                    'type': ['string', 'null'],
                    'description': 'Статус услуги'
                },
                'type': {
                    'type': ['string', 'null'],
                    'description': 'Тип услуги'
                },
                'add_method': {
                    'type': ['string', 'null'],
                    'description': 'Способ добавления услуги'
                },
                'rfisc': {
                    'type': ['string', 'null'],
                    'description': 'rfisc-код услуги'
                },
                'provider': {
                    'type': ['string', 'null'],
                    'description': 'Код компании, предоставляющей услугу'
                },
                'price': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость услуги'
                }
            }
        },
        'service_money': {
            'type': 'object',
            'description': 'Даннаые о базовой стоимости услуги',
            'properties': {
                'emd': {
                    'type': ['string', 'null'],
                    'description': 'Номер Emd'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость'
                },
                'amount_rub': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость в рублях'
                },
                'currency': {
                    'type': ['string', 'null'],
                    'description': 'Валюта'
                }
            }
        },
        'fop': {
            'type': 'object',
            'description': 'типы оплаты заказа',
            'properties': {
                'fops_id': {
                    'type': ['integer', 'null'],
                    'description': 'Порядковый номер'
                },
                'ticket': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета'
                },
                'coupon_id': {
                    'type': ['string', 'null'],
                    'description': 'Номер купона'
                },
                'emd': {
                    'type': ['string', 'null'],
                    'description': 'Номер Emd'
                },
                'indicator': {
                    'type': ['string', 'integer', 'null'],
                    'description': 'Индикатор'
                },
                'code': {
                    'type': ['string', 'null'],
                    'description': 'Код формы оплаты'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость'
                },
                'vendor': {
                    'type': ['string', 'null'],
                    'description': 'Код вендора'
                },
                'account_num': {
                    'type': ['string', 'null'],
                    'description': 'Карта, с которой списаны средства'
                },
                'app_code': {
                    'type': ['string', 'null'],
                    'description': 'Код приложения оплаты'
                },
                'auth_center': {
                    'type': ['string', 'null'],
                    'description': 'Платежный шлюз/Payment Gateaway'
                },
                'exp_date': {
                    'type': ['string', 'null'],
                    'description': 'Если оплата картой, то здесь дата '
                                   'истечения карты'
                },
                'free_text': {
                    'type': ['string', 'null'],
                    'description': 'Доп информация об оплате'
                }
            }
        },
        'ssr': {
            'type': 'object',
            'description': 'Список специальных услуг',
            'properties': {
                'airline': {
                    'type': 'string',
                    'description': 'Авиакомпания'
                },
                'passenger_id': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира, которому заказана спецуслуга'
                },
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента, к которому'
                },
                'count': {
                    'type': 'integer',
                    'description': 'Количество услуг'
                },
                'ssr': {
                    'type': 'string',
                    'description': 'Код услуги'
                },
                'status': {
                    'type': 'string',
                    'description': 'Статус'
                },
                'text': {
                    'type': 'string',
                    'description': 'инфо по заказанной услуге'
                }
            }
        },
        'contacts': {
            'type': 'object',
            'description': 'Контакты',
            'properties': {
                'contact': {
                    'type': ['string', 'null'],
                    'description': 'Контакты, указанные при оформлении pnr.'
                },
                'sirena_type': {
                    'type': ['string', 'null'],
                    'description': 'Тип контакта от сирены'
                },
                'type': {
                    'oneOf': [
                        {'enum': list(types.ContactType._value2member_map_)},
                        {'type': ['null']}
                    ],
                    'description': 'Общий тип контакта (почта/телефон/other)'
                },
                'match_type': {
                    'oneOf': [
                        {'enum': list(types.MatchTypes._value2member_map_)},
                        {'type': ['null']}
                    ],
                    'description': 'Метод добавления контакта'
                },
                'confirmed': {
                    'type': ['boolean', 'null'],
                    'description': 'Контакт подтвержен'
                },
                'hide': {
                    'type': 'boolean',
                    'description': 'Контакт скрыт'
                },
                'created': {
                    'type': ['number', 'null'],
                    'description': 'Время добавления контакта'
                },
            }
        },
        'pos_data': {
            'type': 'object',
            'description': 'pos data',
            'properties': {
                'pos_id': {
                    'type': ['string', 'null'],
                    'description': 'ID пункта продажи'
                },
                'agency': {
                    'type': ['string', 'null'],
                    'description': 'Код агентства, через которое создан  pnr'
                },
                'term_id': {
                    'type': ['string', 'null'],
                    'description': 'Номер пульта продаж'
                },
                'gds': {
                    'type': 'object',
                    'description': 'Список GDS',
                    'properties': {
                        'value': {
                            'type': 'string',
                            'description': 'Наименование GDS'
                        },
                        'created': {
                            'type': 'integer',
                            'description': 'Время добавления в Mongo'
                        },
                    }
                },
            },
        },
        'price': {
            'type': 'object',
            'description': 'Цена',
            'properties': {
                'full_price': {
                    'type': 'number',
                    'description': 'Стоимость PNR'
                },
                'tickets_price': {
                    'type': ['number', 'null'],
                    'description': 'Итоговая цена всех билетов в заказе'
                },
                'currency': {
                    'type': ['string', 'null'],
                    'description': 'Валюта'
                },
                'discount': {
                    'type': 'array',
                    'items': {
                        '$ref': '#/definitions/discount'
                    }
                }
            }
        },
        'discount': {
            'type': 'object',
            'description': 'Скидка',
            'properties': {
                'amount': {
                    'type': 'number',
                    'description': 'Скидка'
                },
                'type': {
                    'type': ['string', 'null'],
                    'description': 'Тип скидки, тип объекта из корзины букинга'
                },
                'code': {
                    'type': ['string', 'null'],
                    'description': 'Промокод'
                },
                'card_number': {
                    'type': ['string', 'null'],
                    'description': 'Номер карты'
                },
            }
        },
        'analytics_data': {
            'type': 'object',
            'description': 'Данные аналитики',
            'properties': {
                'payment_id': {
                    'type': ['string', 'null'],
                    'description': 'От ТАИС ID платежа'
                },
                'partner_id': {
                    'type': ['string', 'null'],
                    'description': 'Логин агента'
                },
                'partner_data': {
                    'type': ['string', 'null']
                },
                'partner_data_ex': {
                    'type': ['string', 'null'],
                    'description': 'От ТАИС описания нет'
                },
                'pay_method_id': {
                    'type': ['string', 'null'],
                    'description': 'От ТАИС это ID платежного метода'
                },
                'pay_method_code': {
                    'type': ['string', 'null'],
                    'description': 'От ТАИС это код платежного метода для этого '
                                   'заказа'
                },
                'first_segment_booking_time': {
                    'type': ['number', 'string', 'null'],
                    'description': 'Время бронирования первого сегмента'
                },
                'device_token': {
                    'type': ['string', 'null'],
                    'description': 'Идентификатор устроства/приложения пользователя для пуш уведомлений'
                },
                'platform': {
                    'type': ['string', 'null'],
                    'description': 'Платформа, на которой была совершена покупка, приходит из корзины моноаппа'
                },
                'utm': {
                    'type': ['object', 'null'],
                    'description': 'Данные об источнике заказа',
                    'properties': {
                        'source': {
                            'type': ['string', 'null'],
                            'description': 'Источник трафика'
                        },
                        'campaign': {
                            'type': ['string', 'null', 'array'],
                            'description': 'Компании, по которым пришел пассажир купивший билеты'
                        },
                        'medium': {
                            'type': ['string', 'null'],
                            'description': 'Тип трафика рекламной компании'
                        },
                        'term': {
                            'type': ['string', 'null', 'array'],
                            'description': 'Ключевое слово при поиске билета'
                        },
                        'content': {
                            'type': ['string', 'null', 'array'],
                            'description': 'Различия контента рекламы, привлекшей пассажира'
                        },
                    },
                }
            },
        },
        'available_actions': {
            'type': 'object',
            'description': 'Флаги возможных действий с боронью',
            'properties': {
                'can_change': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность обмена'
                },
                'can_purchase_services': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность покупки доп услуг'
                },
                'can_return_deposit': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность возврата ваучера'
                },
                'can_print_mk': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность получения маршрутной квитанции'
                },
                'can_pay_order': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность оплаты заказа'
                },
                'can_check_in': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность регистрации на рейс'
                },
                'can_release': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность сдачи мест'
                },
                'can_change_personal_data': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность смены персональных данных'
                },
                'can_return': {
                    'type': ['boolean', 'null'],
                    'description': 'Возможность денежного возврата'
                },
            },
        },
    },

    # Ключи в заказе
    'properties': {
        'rloc': {
            'type': 'string',
            'description': 'PNR locator. Уникальный идентификатор PNR'
        },
        'order_id': {
            'type': ['string', 'null'],
            'description': 'ID заказа'
        },
        'order_key': {
            'type': ['string', 'null'],
            'description': 'order_key присылает только Tais'
        },
        'order_uuid': {
            'type': 'string',
            'description': 'UUID-идентификатор заказа, для получения данных заказа по ссылке в email без авторизации'
        },
        'sirena_id': {
            'type': ['string', 'null'],
            'description': 'ID заказа Сирены'
        },
        'rloc_host': {
            'type': ['array', 'null'],
            'description': 'HOST номер брони'
        },
        'rloc_parent_gds': {
            'type': ['string', 'null'],
            'description': 'GDS номер брони родительский, заполняется если происходила операция Claim'
        },
        'status': {
            'enum': list(types.OrderStatus._value2member_map_),
            'description': 'Статус заказа.'
        },
        'waiting_for_refund': {
            'oneOf': [
                {'enum': list(types.StringBoolRepresentation._value2member_map_)},
                {'type': ['boolean', 'null']}
            ],
            'description': 'Флаг стоит, если билет в очереди на обработку '
                           'возврата'
        },
        'owrt': {
            'enum': list(types.OWRT._value2member_map_),
            'description': 'Направление'
        },
        'departure_point': {
            'type': 'string',
            'description': 'Пункт вылета (город)'
        },
        'arrival_point': {
            'type': 'string',
            'description': 'Пункт прибытия'
        },
        'segment_count': {
            'type': 'integer',
            'description': 'Общее количество летных сегментов в pnr'
        },
        'passenger_count': {
            'type': 'integer',
            'description': 'Общее количество пассажиров в pnr'
        },
        'group': {
            'type': ['boolean', 'null'],
            'description': "Группа пассажиров"
        },
        'departure_start_timestamp': {
            'type': 'integer',
            'description': 'Дата время вылета первого сегмента'
        },
        'departure_end_timestamp': {
            'type': 'integer',
            'description': 'Дата время прилета последнего сегмента'
        },
        # Вложенные данные
        'status_updated': {
            'type': ['array', 'null'],
            'description': "История обновления статусов",
            'items': {
                '$ref': '#/definitions/order_status_updated'
            }
        },
        'remarks': {
            'description': 'Список ремарок к заказу',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/remark'
            }
        },
        'passengers': {
            'description': 'список пассажиров с подробной информацией',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/passenger'
            }
        },
        'segments': {
            'description': 'Сегменты',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/segment'
            }
        },
        'tickets': {
            'description': 'Билеты',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ticket'
            }
        },
        'coupons': {
            'description': '',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/coupon'
            }
        },
        'offers': {
            'description': 'информацией о тарифе каждого сегмента',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/offer'
            }
        },
        'services': {
            'description': 'услуги',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/service'
            }
        },
        'service_money': {
            'description': 'Данные о базовой стоимости каждой услуги',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/service_money'
            }
        },
        'fops': {
            'description': 'Список типов оплаты за транзакцию',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/fop'
            }
        },
        'ssrs': {
            'description': 'Список специальных услуг',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ssr'
            }
        },
        'documents': {
            'description': 'Список документов пассажиров',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/document'
            }
        },
        'contacts': {
            'description': 'Контакты',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/contacts'
            }
        },
        'pos_data': {
            'description': '',
            'type': 'object',
            'items': {
                '$ref': '#/definitions/pos_data'
            }
        },
        'price': {
            'description': 'Цена',
            'type': 'object',
            'items': {
                '$ref': '#/definitions/price'
            }
        },
        'analytics_data': {
            'description': 'Данные аналитики',
            'type': 'object',
            'items': {
                '$ref': '#/definitions/analytics_data'
            }
        },
        'available_actions': {
            'description': 'Флаги возможных действий с бронью',
            'type': 'object',
            'items': {
                '$ref': '#/definitions/available_actions'
            }
        }
    }
}
