"""Схема для авиационных транзакций"""
from enum import Enum

service_class = Enum('service_class', 'E B F')
type_bool = Enum('type_bool', 'Y N')
passcat = Enum('passcat', 'ADT CHD INF')
gender = Enum('gender', 'M F')
doctype = Enum('doctype', 'PS PSP NP VUL SR')
order_status = Enum('order_status', 'S B X T')
owrt = Enum('owrt', 'RT OW TR')
status = Enum('status', 'S X B T')
marketing_fare = Enum('marketing_fare', 'BUSINESS FLEX STANDARD STANDART LIGHT LIGHT_SA COMFORT PREFERENTIAL MINIMUM_NEW MINIMUM_CORP OPTIMUM_NEW OPTIMUM_CORP PREMIUM_NEW PREMIUM_CORP BUSINESS_NEW BUSINESS_CORP STANDBY UTAIR UNKNOWN MINIMUM_PLUS OPTIMUM_PLUS')  # noqa
# Чтобы отдавать корректно старые заказы
archive_marketing_fare = Enum('archive_marketing_fare', 'CFLEX SUB')
business_class = Enum('business_class', 'A D C J')
econom_class = Enum('econom_class', 'P K L H V O U X R B N G W E S T Y Z Q F')

__all__ = ('mono_app_schema',)
base_transaction_schema = {
    '$schema': 'http://json-schema.org/draft-04/schema#',
    'definitions': {
        'passenger': {
            'type': 'object',
            'description': 'Информация о пасажире',
            'properties': {
                'birthday': {
                    'type': ['string', 'null'],
                    'description': 'Дата рождения пассажира'
                },
                'age': {
                    'type': ['integer', 'null'],
                    'description': 'Возраст пассажира в годах'
                },
                'doccountry': {
                    'type': ['string', 'null'],
                    'description': 'Страна выдачи документа'
                },
                'docexpiration': {
                    'type': ['string', 'null'],
                    'description': 'Дата истечения документа'
                },
                'docnumber': {
                    'type': ['string', 'null'],
                    'description': 'Номер документа'
                },
                'doctype': {
                    'type': ['string', 'null'],
                    'description': 'Тип документа'
                },
                'ff_cardnumber': {
                    'type': ['string', 'null'],
                    'description': 'Номер карты бонусной программы'
                },
                'first_name': {
                    'type': 'string',
                    'description': 'Имя пользователя'
                },
                'last_name': {
                    'type': 'string',
                    'description': 'Фамилия пользователя'
                },
                'second_name': {
                    'type': ['string', 'null'],
                    'description': 'Отчество пассажира'
                },
                'id': {
                    'type': ['string', 'null'],
                    'description': 'id пассажира'
                },
                'passenger_id': {
                    'type': 'string',
                    'description': 'ID пассажира внутри заказа'
                },
                'passenger_parent_id': {
                    'type': ['string', 'integer', 'null'],
                    'description': 'ID пассажира внутри заказа'
                },
                'docs_first_name': {
                    'type': ['string', 'null'],
                    'description': 'Имя по документу'
                },
                'docs_surname': {
                    'type': ['string', 'null'],
                    'description': 'Фамилия по документу'
                },
                'pass_type': {
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(passcat.__members__)},
                        {'type': 'null'}
                    ],
                },
                'gender': {
                    'type': ['string', 'null'],
                    'enum': ['M', 'F', None],
                    'description': 'Пол'
                }
            }
        },
        'segment': {
            'type': 'object',
            'description': 'Информация о сегменте',
            'properties': {
                'ak': {
                    'type': ['string', 'null'],
                    'description': 'Название авиакомпании'
                },
                'ak_full_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название авиакомпании,'
                                   ' создавшей рейс'
                },
                'oak': {
                    'type': ['string', 'null'],
                    'description': 'Название авиакомпании, выполняющей рейс'
                },
                'oak_full_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название авиакомпании,'
                                   ' выполняющей рейс'
                },
                'arrival_airport_code': {
                    'type': 'string',
                    'description': 'Код аэропорта прибытия'
                },
                'arrival_airport_full_name': {
                    'type': 'string',
                    'description': 'Полное название аэропорта прибытия'
                },
                'arrival_city_code': {
                    'type': 'string',
                    'description': 'Код города прибытия'
                },
                'arrival_city_full_name': {
                    'type': 'string',
                    'description': 'Полное название города прибытия'
                },
                'arrival_date': {
                    'type': ['string', 'null'],
                    'description': 'Дата прибытия по местному времени'
                },
                'arrival_time': {
                    'type': ['string', 'null'],
                    'description': 'Время прибытия по местному времени'
                },
                'arrival_utc': {
                    'type': ['string', 'null'],
                    'description': 'Дата и время прибытия по utc'
                },
                'arrival_unixtime': {
                    'type': ['number', 'null'],
                    'description': 'Дата и время прибытия по utc в unixtime'
                },
                'class': {
                    'type': ['string', 'null'],
                    'description': 'Класс полета'
                },
                'rbd': {
                    'type': ['string', 'null'],
                    'description': 'Класс бронирования'
                },
                'price': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость сегмента по fare_calc полю'
                },
                'standby': {
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(type_bool.__members__)},
                        {'type': 'null'}
                    ],
                    'description': 'Признак билета на подсадку'
                },
                'departure_airport_code': {
                    'type': 'string',
                    'description': 'Код аэропорта вылета'
                },
                'departure_airport_full_name': {
                    'type': 'string',
                    'description': 'Полное название аэропорта вылета'
                },
                'departure_city_code': {
                    'type': 'string',
                    'description': 'Код города вылета'
                },
                'departure_city_full_name': {
                    'type': 'string',
                    'description': 'Полное название города вылета'
                },
                'departure_date': {
                    'type': ['string', 'null'],
                    'description': 'Дата вылета по местному времени'
                },
                'departure_time': {
                    'type': ['string', 'null'],
                    'description': 'Время вылета по местному времени'
                },
                'departure_utc': {
                    'type': ['string', 'null'],
                    'description': 'Дата и время вылета по utc'
                },
                'departure_unixtime': {
                    'type': ['number', 'null'],
                    'description': 'Дата и время вылета по utc в unixtime'
                },
                'direction': {
                    'type': 'string',
                    'description': 'Направление сегмента'
                },
                'duration': {
                    'type': ['integer', 'null'],
                    'description': 'Длительность полета в секундах'
                },
                'flight_number': {
                    'type': ['string', 'null'],
                    'description': 'Номер рейса'
                },
                'id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента в ТАИС'
                },
                'segment_id': {
                    'type': 'string',
                    'description': 'Идентификатор сегмента внутри pnr'
                },
                'layover_time': {
                    'type': ['integer', 'null'],
                    'description': 'Время ожидания между рейсами. Вычисляемое нами'
                },
                'plane_type': {
                    'type': ['string', 'null'],
                    'description': 'Тип самолета кратко'
                },
                'plane_type_name': {
                    'type': ['string', 'null'],
                    'description': 'Полное название типа самолета'
                },
                'status': {
                    'type': 'string',
                    'description': 'Статус сегмента'
                },
                'seg_type': {
                    'type': 'string',
                    'description': 'Тип сегмента'
                },
                'ns': {
                    'type': 'number',
                    'description': 'Количество мест забронированных на борту'
                },
                'marketing_tags': {
                    'description': 'Маркетинговые характеристики (старые)',
                    'type': ['null', 'object'],
                },
                'departure_hour': {
                    'type': ['integer', 'null'],
                    'description': 'Час вылета сегмента (локальное время)'
                },
                'departure_weekday': {
                    'type': ['string', 'null'],
                    'description': 'День недели вылета MO, TU, WE, TH, FR, SA, SU'
                },
            }
        },
        'fare_service': {
            'type': 'object',
            'description': 'Список услуг',
            'properties': {
                'code': {
                    'type': 'string',
                    'description': 'Код услуги тарифа'
                },
                'name': {
                    'type': 'string',
                    'description': 'Имя услуги'
                },
                'status': {
                    'type': 'string',
                    'description': 'Статус услуги'
                },
                'value': {
                    'type': 'string',
                    'description': 'Значение услуги'
                },
                'included': {
                    'enum': list(type_bool.__members__),
                }
            }
        },
        'gds': {
            'type': 'object',
            'description': 'Список GDS',
            'properties': {
                'value': {
                    'type': 'string',
                    'description': 'Наименование GDS'
                },
                'created': {
                    'type': 'integer',
                    'description': 'Время добавления в Mongo'
                },
            }
        },
        'contact_info': {
            'type': 'object',
            'description': 'Информация о добавлении контактов',
            'properties': {
                'contact': {
                    'type': 'string',
                    'description': 'Контакт'
                },
                'hide': {
                    'type': 'boolean',
                    'description': 'Контакт скрыт'
                },
                'confirmed': {
                    'type': 'boolean',
                    'description': 'Подтвердженный контакт'
                },
            }
        },
        'fare_calc': {
            'type': 'object',
            'description': 'Список строк расчета стоимости бронирования',
            'properties': {
                'value': {
                    'type': 'string',
                    'description': 'Строка расчета стоимости бронирования'
                },
                'created': {
                    'type': 'integer',
                    'description': 'Время создания'
                },
            }
        },
        'offer': {
            'type': 'object',
            'description': 'информация о тарифе',
            'properties': {
                'marketing_fare_code': {
                    'type': ['string', 'null'],
                    'description': 'Наименование тарифа'
                },
                'marketing_fare_code2': {
                    'description': 'Код тарифа согласно правилам сайта',
                    'type': ['string', 'null'],
                    'oneOf': [
                        {'enum': list(marketing_fare.__members__)},
                        {'type': 'null'}
                    ],
                },
                'fare_code': {
                    'type': ['string', 'null'],
                    'description': 'Код тарифа'
                },
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'Идентификатор сегмента'
                },
                'sa': {
                    'type': ['boolean', 'null'],
                    'description': 'Тариф без времени'
                },
                'fare_services':
                    {
                        'description': 'Список услуг сегмента',
                        'type': ['array', 'null'],
                        'items': {
                            '$ref': '#/definitions/fare_service'
                        }
                    }
            }
        },
        'ticket_active': {
            'type': 'object',
            'description': 'оплаченные билеты',
            'properties': {
                'docno': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета'
                },
                'fare': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость билета'
                },
                'passcat': {
                    'type': ['string', 'null'],
                    'description': 'Признак билета - взрослый/детский',
                    'oneOf': [
                        {'enum': list(passcat.__members__)},
                        {'type': 'null'}
                    ],
                },
                'price_active': {
                    'type': ['number', 'null'],
                    'description': 'Цена билета'
                },
                'psgid': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира'
                },
                'refundable': {
                    'type': ['string', 'null'],
                    'description': 'Согласно текущему БП компании,'
                                   ' это решение принимается вручную.'
                },
                'taxes': {
                    'type': ['number', 'null'],
                    'description': 'Сборы по билету'
                }
            }
        },
        'ticket_returned': {
            'type': 'object',
            'description': 'возвращенные билеты',
            'properties': {
                'docno': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета'
                },
                'fare': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость билета'
                },
                'passcat': {
                    'type': ['string', 'null'],
                    'description': 'Признак билета - взрослый/детский',
                    'oneOf': [
                        {'enum': list(passcat.__members__)},
                        {'type': 'null'}
                    ],
                },
                'price_active': {
                    'type': ['number', 'null'],
                    'description': 'Цена билета'
                },
                'psgid': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира.'
                },
                'refundable': {
                    'type': ['string', 'null'],
                    'description': 'Согласно текущему БП компании,'
                                   ' это решение принимается вручную'
                },
                'taxes': {
                    'type': ['number', 'null'],
                    'description': 'Сборы по билету'
                }
            }
        },
        'coupon': {
            'type': 'object',
            'description': 'Информация о купонах',
            'properties': {
                'n': {
                    'type': ['number', 'null'],
                    'description': 'Номер купона'
                },
                'num': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета, к которому относится купон'
                },
                'status': {
                    'type': 'string',
                    'description': 'Cтатус купона'
                },
                'sac': {
                    'type': ['string', 'null'],
                    'description': 'Код авторизации в СЭБ при переходе купона в конечное состояние'
                },
                'op_comment': {
                    'type': ['string', 'null'],
                    'description': 'Комментарий'
                },
                'pass_num': {
                    'type': ['integer', 'null'],
                    'description': 'ID пассажира, на которого выписан купон'
                },
                'seg_num': {
                    'type': ['integer', 'null'],
                    'description': 'ID сегмента, на который выписан купон'
                },
                'coupon_money': {
                    'fare': {
                        'type': 'integer',
                        'description': 'сумма тарифа купона'
                    },
                    'tax': {
                        'type': 'integer',
                        'description': 'сумма сборов купона'
                    },
                    'discount': {
                        'type': 'integer',
                        'description': 'сумма сборов купона'
                    },
                    'created': {
                        'type': 'integer',
                        'description': 'дата добавления информации о стоимости сегмента'
                    }
                },
                'fare_code': {
                    'type': 'string',
                    'description': 'Код тарифа'
                },
                'itinerary': {
                    # Данные маршрута
                    'marketing': {
                        'type': ['string', 'null'],
                        'description': 'Рейс, как его продала компания'
                    },
                    'operating': {
                        'type': ['string', 'null'],
                        'description': 'Рейс, как он числится '
                                       'в компании-перевозчике'
                    },
                    'rpi_status': {
                        'type': ['string', 'null'],
                        'description': 'Статус маршрута в билете. Менее актуальный аналог Segments.Status'
                    }
                }
            }
        },
        'ssr': {
            'type': 'object',
            'description': 'Список специальных услуг',
            'properties': {
                'airline': {
                    'type': 'string',
                    'description': 'Авиакомпания'
                },
                'pass_num': {
                    'type': ['integer', 'null'],
                    'description': 'ID пассажира, которому заказана спецуслуга'
                },
                'qtty': {
                    'type': 'integer',
                    'description': 'Количество услуг'
                },
                'seg_num': {
                    'type': ['integer', 'null'],
                    'description': 'ID сегмента, к которому'
                },
                'ssr': {
                    'type': 'string',
                    'description': 'Код услуги'
                },
                'status': {
                    'type': 'string',
                    'description': 'Статус'
                },
                'text': {
                    'type': 'string',
                    'description': 'инфо по заказанной услуге'
                }
            }
        },
        'service': {
            'type': 'object',
            'description': 'список дополнительных услуг',
            'properties': {
                'applicability': {
                    'type': ['string', 'null'],
                    'description': 'Применимость услуги. Приходит пустой'
                },
                'count': {
                    'type': ['integer', 'null'],
                    'description': 'Количество купленной услуги'
                },
                'description': {
                    'type': ['string', 'null'],
                    'description': 'Описание услуги. Приходит пустым'
                },
                'ext_id': {
                    'type': ['string', 'null'],
                    'description': 'Внешний ID'
                },
                'freetext': {
                    'type': ['string', 'null'],
                    'description': 'Дополнительная служебная информация'
                },
                'id': {
                    'type': ['string', 'null'],
                    'description': 'ID услуги в ТАИС'
                },
                'link': {
                    'type': ['string', 'null'],
                    'description': 'Ссылка на договор по услуге'
                },
                'max_count': {
                    'type': ['string', 'null'],
                    'description': 'Максимально допустимое количество услуги'
                },
                'passenger_id': {
                    'type': ['string', 'null'],
                    'description': 'ID пассажира, для которого куплена данная '
                                   'услуга'
                },
                'pdf_link': {
                    'type': ['string', 'null'],
                    'description': 'Ссылка на pdf с описанием услуги'
                },
                'price': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость услуги'
                },
                'provider': {
                    'type': ['string', 'null'],
                    'description': 'Код компании, предоставляющей услугу'
                },
                'rfisc': {
                    'type': ['string', 'null'],
                    'description': 'rfisc-код услуги'
                },
                'segment_id': {
                    'type': ['string', 'null'],
                    'description': 'ID сегмента, для которого куплена данная '
                                   'услуга'
                },
                'type': {
                    'type': ['string', 'null'],
                    'description': 'Тип услуги'
                },
                'type2': {
                    'type': ['string', 'null'],
                    'description': 'Тип услуги'
                },
                'status': {
                    'type': ['string', 'null'],
                    'description': 'Статус услуги'
                }
            }
        },
        'fop': {
            'type': 'object',
            'description': 'типы оплаты заказа',
            'properties': {
                'number': {
                    'type': ['integer', 'null'],
                    'description': 'Порядковый номер'
                },
                'ticket': {
                    'type': ['string', 'null'],
                    'description': 'Номер билета'
                },
                'emd': {
                    'type': ['string', 'null'],
                    'description': 'Номер Emd'
                },
                'indicator': {
                    'type': ['string', 'integer', 'null'],
                    'description': 'Индикатор'
                },
                'code': {
                    'type': ['string', 'null'],
                    'description': 'Код формы оплаты'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Стоимость'
                },
                'vendor': {
                    'type': ['string', 'null'],
                    'description': 'Код вендора'
                },
                'account_num': {
                    'type': ['string', 'null'],
                    'description': 'Карта, с которой списаны средства'
                },
                'app_code': {
                    'type': ['string', 'null'],
                    'description': 'Код приложения оплаты'
                },
                'exp_date': {
                    'type': ['string', 'null'],
                    'description': 'Если оплата картой, то здесь дата '
                                   'истечения карты'
                },
                'free_text': {
                    'type': ['string', 'null'],
                    'description': 'Доп информация об оплате'
                }
            }
        },
        'tax': {
            'type': 'object',
            'description': 'Сборы',
            'properties': {
                'code': {
                    'type': 'string',
                    'description': 'Код сбора'
                },
                'amount': {
                    'type': 'number',
                    'description': 'Стоимость сбора'
                },
                'category': {
                    'type': 'string',
                    'description': 'Категория сбора'
                },
                'owner': {
                    'type': ['string', 'null'],
                    'description': 'Агент'
                }
            }
        },
        'monetary_info': {
            'type': 'object',
            'description': 'Список базовых тарифов',
            'properties': {
                'code': {
                    'type': 'string',
                    'description': 'Код тарифа'
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Размер тарифа'
                },
                'currency': {
                    'type': ['string', 'null'],
                    'description': 'Валюта тарифа'
                }
            }
        },
        'ticket_money': {
            'type': 'object',
            'description': 'Данные о базовой стоимости и сборах в разрезе '
                           'каждого билета',
            'properties': {
                'number': {
                    'type': 'string',
                    'description': 'Номер билета'
                },
                'fare_calc': {
                    'type': ['string', 'null'],
                    'description': 'Строка расчета(построения) тарифа'
                },
                'taxes':
                    {
                        'description': 'Список всех сборов по типам',
                        'type': ['array', 'null'],
                        'items': {
                            '$ref': '#/definitions/tax'
                        }
                    },
                'monetary_info':
                    {
                        'description': 'Список базовых тарифов',
                        'type': ['array', 'null'],
                        'items': {
                            '$ref': '#/definitions/monetary_info'
                        }
                    }
            }
        },
        'service_money': {
            'type': 'object',
            'description': 'Данные о базовой стоимости каждой услуги',
            'properties': {
                'number': {
                    'type': 'string',
                    'description': 'Номер билета'
                },

                'taxes':
                    {
                        'description': 'Список всех сборов по типам',
                        'type': ['array', 'null'],
                        'items': {
                            '$ref': '#/definitions/tax'
                        }
                    },
                'monetary_info':
                    {
                        'description': 'Список базовых тарифов',
                        'type': ['array', 'null'],
                        'items': {
                            '$ref': '#/definitions/monetary_info'
                        }
                    }
            }
        },
        'additional_data': {
            'type': 'object',
            'description': 'Дополнительные данные о заказе',
            'properties': {
                'discounts': {
                    'type': 'array',
                    'description': 'Данные о смешанной оплате',
                    'items': {
                        '$ref': '#/definitions/discount'
                    }
                },
                'profile_card_number': {
                    'type': 'string'
                },
                'business_card_number': {
                    'type': ['string', 'null'],
                },
                'pay_token': {
                    'type': ['string', 'null']
                },
                'voucher': {
                    'description': 'Информация о ваучере (от ТАИС)',
                    'type': 'object',
                    'items': {
                        '$ref': '#/definitions/voucher'
                    }
                },
                'utm': {
                    'description': 'Информация об источнике заказа',
                    'type': 'object',
                    'items': {
                        '$ref': '#/definitions/utm'
                    }
                }
            }
        },
        'voucher': {
            'type': 'object',
            'description': 'Информация о ваучере (от ТАИС)',
            'properties': {
                'id': {
                    'type': ['string', 'null'],
                    'description': 'Уникальный идентификатор',
                },
                'amount': {
                    'type': ['number', 'null'],
                    'description': 'Количество',
                }
            }
        },
        'utm': {
            'type': 'object',
            'description': 'Информация об источнике заказа',
            'properties': {
                'source': {
                    'type': ['string', 'null'],
                    'description': 'Источник трафика'
                },
                'campaign': {
                    'type': ['string', 'null', 'array'],
                    'description': 'Компании, по которым пришел пассажир купивший билеты'
                },
                'medium': {
                    'type': ['string', 'null'],
                    'description': 'Тип трафика рекламной компании'
                },
                'term': {
                    'type': ['string', 'null', 'array'],
                    'description': 'Ключевое слово при поиске билета'
                },
                'content': {
                    'type': ['string', 'null', 'array'],
                    'description': 'Различия контента рекламы, привлекшей пассажира'
                },
            },
        },
        'discount': {
            'type': 'object',
            'description': 'Данные о смешанной оплате',
            'properties': {
                'type': {
                    'type': 'string'
                },
                'amount': {
                    'type': 'number'
                },
                'promo_code': {
                    'type': 'string'
                },
                'card_number': {
                    'type': 'string'
                }
            }
        },
        'available_action': {
            'type': 'object',
            'description': 'Доступные действия с броней',
            'properties': {
                'can_change': {
                    'type': ['boolean', 'null']
                },
                'can_return': {
                    'type': ['boolean', 'null']
                },
                'can_purchase_services_': {
                    'type': ['boolean', 'null']
                },
            }
        },
        'marketing_tags': {
            'type': 'object',
            'description': 'Маркетинговые характеристики',
            'properties': {
                'adults_quantity': {
                    'type': ['integer', 'null'],
                    'description': 'Количество взрослых пассажиров в броне'
                },
                'adult_women_quantity': {
                    'type': ['integer', 'null'],
                    'description': 'Количество взрослых женщин в броне'
                },
                'adult_men_quantity': {
                    'type': ['integer', 'null'],
                    'description': 'Количество взрослых мужчин в броне'
                },
                'children_quantity': {
                    'type': ['integer', 'null'],
                    'description': 'Количество детей от 2 до 18 лет в броне'
                },
                'babies_quantity': {
                    'type': ['integer', 'null'],
                    'description': 'Количество младенцев в броне'
                },
                'booking_depth': {
                    'type': ['integer', 'null'],
                    'description': 'Глубина бронирования в часах (от выписки билета до вылета первого сегмента)'
                },
                'booking_owner': {
                    'type': ['string', 'null'],
                    'description': 'Компания-владелец брони'
                },
            },
        }
    }
}

mono_app_schema = base_transaction_schema.copy()
mono_app_schema.update({
    'title': 'Транзакция',
    'description': 'Авиационная транзакция',
    'type': 'object',
    '$schema': 'http://json-schema.org/draft-04/schema#',
    'properties': {
        'order_id': {
            'type': ['string', 'null'],
            'description': 'ID заказа'
        },
        'order_uuid': {
            'type': 'string',
            'description': 'UUID-идентификатор заказа, для получения данных заказа по ссылке в email без авторизации'
        },
        'order_key': {
            'type': ['string', 'null'],
            'description': 'order_key присылает только Tais'
        },
        'term_id': {
            'type': ['string', 'null'],
            'description': 'Номер пульта продаж'
        },
        'owrt': {
            'enum': list(owrt.__members__),
            'description': 'Направление'
        },
        'full_price': {
            'type': 'number',
            'description': 'Стоимость PNR'
        },
        'full_price_active': {
            'type': ['number', 'null'],
            'description': 'Фактически выплаченная пользователем сумма за '
                           'заказ'
        },
        'rloc': {
            'type': 'string',
            'description': 'PNR locator. Уникальный идентификатор PNR'
        },
        'rloc_host': {
            'type': 'string',
            'description': 'HOST номер брони'
        },
        'rloc_parent_gds': {
            'type': ['string', 'null'],
            'description': 'GDS номер брони родительский, заполняется если происходила операция Claim'
        },
        'status': {
            'enum': list(status.__members__),
            'description': 'Статус заказа.'
        },
        'arrival_point': {
            'type': 'string',
            'description': 'Пункт прибытия'
        },
        'departure_point': {
            'type': 'string',
            'description': 'Пункт вылета (город)'
        },
        'booking_timestamp': {
            'type': ['integer', 'null'],
            'description': 'Время создания брони'
        },
        'canceled': {
            'type': ['boolean', 'null'],
            'description': 'Флаг отмены pnr'
        },
        'ctc_phone2': {
            'type': ['array', 'null'],
            'description': 'Всегда пустое от Сирены и ТАИС'
        },
        'ctc_phone': {
            'type': ['array', 'null'],
            'description': 'Контакты, указанные при оформлении pnr.'
        },
        'ctc_mail': {
            'type': ['array', 'null'],
            'description': 'Контакты, указанные при оформлении pnr.'
        },
        'finalized': {
            'type': ['boolean', 'null'],
            'description': '# True если билет был финализирован '
                           '(оплачен онлайн или готов к оплате оффлайн)'
        },
        'timelimit': {
            'type': ['number', 'null'],
            'description': 'Дата и время истечения'
        },
        'transfer_start_time': {
            'type': 'integer',
            'description': 'Дата время вылета первого сегмента'
        },
        'transfer_end_time': {
            'type': 'integer',
            'description': 'Дата время прилета последнего сегмента'
        },
        'waiting_for_refund': {
            'oneOf': [
                {'enum': ['Y', 'N']},
                {'type': ['boolean', 'null']}
            ],
            'description': 'Флаг стоит, если билет в очереди на обработку '
                           'возврата'
        },
        'pay_method_code': {
            'type': ['string', 'null'],
            'description': 'От ТАИС это код платежного метода для этого '
                           'заказа'
        },
        'pay_method_id': {
            'type': ['string', 'null'],
            'description': 'От ТАИС это ID платежного метода'
        },
        'payment_id': {
            'type': ['string', 'null'],
            'description': 'От ТАИС ID платежа'
        },
        'partner_data': {
            'type': ['string', 'null']
        },
        'device_token': {
            'type': ['string', 'null']
        },
        'partner_data_ex': {
            'type': ['string', 'null'],
            'description': 'От ТАИС описания нет'
        },
        'partner_fee': {
            'type': ['string', 'null'],
            'description': 'Сбор партнера'
        },
        'partner_id': {
            'type': ['string', 'null'],
            'description': 'Логин агента'
        },
        'tickets_price': {
            'type': ['number', 'null'],
            'description': 'Итоговая цена всех билетов в заказе'
        },
        'passenger_count': {
            'type': 'integer',
            'description': 'Общее количество пассажиров в pnr'
        },
        'segment_count': {
            'type': 'integer',
            'description': 'Общее количество летных сегментов в pnr'
        },
        'pos_id': {
            'type': ['string', 'null'],
            'description': 'ID пункта продажи'
        },
        'location': {
            'type': ['string', 'null'],
            'description': 'Город создания pnr'
        },
        'country': {
            'type': ['string', 'null'],
            'description': 'Страна создания pnr'
        },
        'agency': {
            'type': ['string', 'null'],
            'description': 'Код агентства, через которое создан  pnr'
        },
        'sirena_id': {
            'type': ['string', 'null'],
            'description': 'ID заказа Сирены'
        },
        'partner_discount': {
            'type': ['integer', 'null'],
            'description': 'Скидка партнера по билету'
        },
        'partner_discount_active': {
            'type': ['integer', 'null'],
            'description': 'Скидка партнера по билету'
        },
        'contact_info': {
            'description': 'Информация о добавлении контактов',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/contact_info'
            }
        },
        'gds': {
            'description': 'Примечания по расчету стоимости заказа',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/gds'
            }
        },
        'fare_calc': {
            'description': 'Примечания по расчету стоимости заказа',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/fare_calc'
            }
        },
        'passengers': {
            'description': 'список пассажиров с подробной информацией',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/passenger'
            }
        },
        'segments': {
            'description': 'Сегменты',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/segment'
            }
        },
        'offers': {
            'description': 'информацией о тарифе каждого сегмента',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/offer'
            }
        },
        'tickets_active': {
            'description': 'Оплаченные билеты',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ticket_active'
            }
        },
        'tickets_returned': {
            'description': 'возвращенные билеты',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ticket_returned'
            }
        },
        'coupons': {
            'description': '',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/coupon'
            }
        },
        'ssrs': {
            'description': 'Список специальных услуг',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ssr'
            }
        },
        'services': {
            'description': 'услуги',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/service'
            }
        },
        'fops': {
            'description': 'Список типов оплаты за транзакцию',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/fop'
            }
        },
        'ticket_money': {
            'description': 'Данные о базовой стоимости и сборах в разрезе каждого билета',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/ticket_money'
            }
        },
        'ticket_money_rub': {
            'description': 'Данные о базовой стоимости и сборах в разрезе каждого билета (в рублях) ',
            'type': ['array', 'null'],
            'items': {
                '$ref': '#/definitions/ticket_money'
            }
        },
        'service_money': {
            'description': 'Данные о базовой стоимости каждой услуги',
            'type': 'array',
            'items': {
                '$ref': '#/definitions/service_money'
            }
        },
        'marketing_tags': {
            'description': 'Маркетинговые характеристики',
            'type': ['null', 'object'],
            'items': {
                '$ref': '#/definitions/marketing_tags'
            }
        },
        'available_actions': {
            'description': 'Доступные действия с броней',
            'type': ['object'],
            'items': {
                '$ref': '#/definitions/available_action'
            }
        },
        'additional_data': {
            'description': 'Информация о смешанной оплате от ТАИС',
            'type': 'object',
            'items': {
                '$ref': '#/definitions/additional_data'
            }
        },
    }
})
