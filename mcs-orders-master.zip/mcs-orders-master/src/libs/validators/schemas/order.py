"""Схема для заказов"""
from libs.validators.schemas.airline_transaction import airline_transaction_schema
import copy
__all__ = ('order_schema',)

airline_transaction_schema_copy = copy.copy(airline_transaction_schema)

nested_definitions = {
    'transaction_source': {
        'type': 'object',
        'description': 'Информация о создании/обновлении заказа',
        'properties': {
            'date': {
                'type': ['number', 'null'],
                'description': 'Фамилия пользователя'
            },
            'provider': {
                'type': ['string', 'null'],
                'description': 'Провайдер'
            },
            'message_id': {
                'type': ['string', 'null'],
                'description': 'ID сообщения от провайдера'
            }
        }
    },
    'sub_owners': {
        'type': 'object',
        'description': 'Информация о владельцах заказа',
        'properties': {
            'match_type': {
                'type': ['string', 'null'],
            },
            'userId': {
                'type': ['string', 'null'],
            },
            'timestamp': {
                'type': ['number', 'null'],
            },
            'contact_email': {
                'type': ['string', 'null'],
            },
            'contact_phone': {
                'type': ['string', 'null'],
            },
        }
    },
    'additional_data': {
        'type': 'object',
        'description': 'Дополнительная информация',
        'properties': {
            'data': {
                'type': ['string', 'number', 'null'],
            },
            'loader': {
                'type': ['string', 'null'],
            },
        }
    },
    'is_hidden_for': {
        'type': 'object',
        'description': 'Юзеры, для которых заказ спрятан',
        'properties': {
            'userId': {
                'type': ['string', 'null'],
            },
            'timestamp': {
                'type': ['number', 'null'],
            },
            'is_admin_panel': {
                'type': ['boolean', 'null'],
            },
        }
    },
    'actions': {
        'type': 'object',
        'description': 'Действия с заказом',
        'properties': {
            'accrual_on_buy': {
                'type': ['string', 'boolean', 'null'],
            },
            'send_feed_back_survey': {
                'type': ['string', 'null'],
            },
        }
    }
}

order_schema = {
    'id': 'order',
    'title': 'Заказ',
    'description': 'Заказ',
    'type': 'object',
    '$schema': 'http://json-schema.org/draft-07/schema#',
    'definitions': dict(nested_definitions, **airline_transaction_schema_copy['definitions']),
    'properties': {
        'data': {
            'type': airline_transaction_schema_copy['type'],
            'description': airline_transaction_schema_copy['description'],
            'properties': airline_transaction_schema_copy['properties']
        },
        'actions': {
            'type': ['object', 'null'],
            'description': 'Действия с заказом',
            'properties': {
                'accrual_on_buy': {
                    'type': ['string', 'boolean', 'null'],
                },
                'send_feedback_survey': {
                    'type': ['string', 'boolean', 'null'],
                }
            }
        },
        'meta': {
            'type': ['object', 'null'],
            'description': 'Мета информация',
            'properties': {
                'additional_data': {
                    'type': ['object', 'null'],
                    '$ref': '#/definitions/additional_data'
                },
                'updated': {
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/transaction_source'
                    }
                },
                'created': {
                    'type': ['object', 'null'],
                    'items': {
                        '$ref': '#/definitions/transaction_source'
                    }
                },
                'sub_owners': {
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/sub_owners'
                    }
                },
                'is_hidden_for': {
                    'type': ['array', 'null'],
                    'items': {
                        '$ref': '#/definitions/is_hidden_for'
                    }
                },
            }
        }
    }
}
