from typing import List
from repositories.index_updater.updater.mongo import MongoIndexUpdater
from repositories.index_updater.updater.index import Index
from domain.order.order import DomainOrder
from pymongo import ASCENDING
from pymongo.database import Database


class OrdersMongoIndexUpdater(MongoIndexUpdater):

    domain_instance = DomainOrder
    background_mode: bool = True

    indexes_to_roll: List[Index] = [
        # Unique
        Index(index={"data.order_uuid": ASCENDING}, unique=True),
        # Plain
        Index(index={'data.status': ASCENDING}),
        Index(index={"data.rloc": ASCENDING}),
        Index(index={"data.departure_end_timestamp": ASCENDING}),
        Index(index={"data.departure_start_timestamp": ASCENDING}),
        Index(index={"data.rloc_host.value": ASCENDING}),

        Index(index={"meta.sub_owners.userId": ASCENDING}),
        Index(index={"meta.is_hidden_for.userId": ASCENDING}),

        Index(index={'data.passengers.last_name': ASCENDING}),
        Index(index={'data.documents.docnumber': ASCENDING}),
        Index(index={'data.segments.flight_number': ASCENDING}),
        Index(index={'data.tickets.ticket': ASCENDING}),

        Index(index={'data.segments.arrival_local_iso': ASCENDING}),
        Index(index={'data.segments.departure_local_iso': ASCENDING}),

        Index(index={'data.contacts.contact': ASCENDING}),

        Index(index={'data.pos_data.additional_data.profile_card_number': ASCENDING}),

        # Compound
        Index(index={"data.departure_end_timestamp": ASCENDING, "data.tickets.ticket": ASCENDING}),
        Index(index={"data.rloc": ASCENDING, "data.departure_end_timestamp": ASCENDING}),
        Index(index={'data.contacts.contact': ASCENDING, 'data.contacts.type': ASCENDING}),
        Index(index={'data.status': ASCENDING, 'data.pos_data.timelimit': ASCENDING}),
        Index(index={'data.fops.code': ASCENDING, 'data.fops.account_num': ASCENDING})
    ]

    def __init__(self, gateway: Database = None):
        super().__init__(gateway=gateway)
