from typing import List
from repositories.index_updater.updater.mongo import MongoIndexUpdater
from repositories.index_updater.updater.index import Index
from domain.origin_transaction import DomainOriginTransaction
from pymongo import ASCENDING
from pymongo.database import Database


class OriginTransactionsMongoIndexUpdater(MongoIndexUpdater):

    domain_instance = DomainOriginTransaction
    background_mode: bool = True

    indexes_to_roll: List[Index] = [
        Index(index={"message_uuid": ASCENDING}, unique=True),
        Index(index={"provider": ASCENDING}),
        Index(index={"created": ASCENDING}),

        # Sirena rloc и rloc_host
        Index(index={"raw.Reclocs.Gds": ASCENDING}),
        Index(index={"raw.Reclocs.Host": ASCENDING})

    ]

    def __init__(self, gateway: Database = None):
        super().__init__(gateway=gateway)
