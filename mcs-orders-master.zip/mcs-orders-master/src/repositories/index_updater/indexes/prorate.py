from typing import List
from repositories.index_updater.updater.mongo import MongoIndexUpdater
from repositories.index_updater.updater.index import Index
from domain.prorate import DomainProrate
from pymongo import ASCENDING
from pymongo.database import Database


class ProrateMongoIndexUpdater(MongoIndexUpdater):

    domain_instance = DomainProrate
    background_mode: bool = True

    indexes_to_roll: List[Index] = [
        Index(index={"departure": ASCENDING}),
        Index(index={"arrival": ASCENDING}),
        Index(index={"arrival": ASCENDING, "departure": ASCENDING}),
        Index(index={"date_from": ASCENDING}),
        Index(index={"date_to": ASCENDING}),
        Index(index={"date_to": ASCENDING, "date_from": ASCENDING}),

    ]

    def __init__(self, gateway: Database = None):
        super().__init__(gateway=gateway)
