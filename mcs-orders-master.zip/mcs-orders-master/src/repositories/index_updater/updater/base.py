from typing import List, Type, Any
from base.domain import BaseDomain
from .index import Index
from abc import abstractmethod


class BaseIndexUpdater(object):
    """
    Базовый класс для накатки индексов
    Для реализации накатки для определенной базы
    унаследоваться отсюда
    """
    indexes_to_roll: List[Index] = []
    domain_instance: Type[BaseDomain] = None
    db_connection = None

    def __init__(self, gateway=None):
        if self.domain_instance is None:
            raise Exception("Incorrect domain instance")
        self.db_connection = gateway

    @abstractmethod
    def prepare_indexes(self):
        """
        Подготавливаем индексы
        """
        raise NotImplementedError()

    @abstractmethod
    def roll_indexes(self):
        """
        Накатывает индексы
        Это идемпотентная операция, проверка на существующие индексы не нужна
        """
        raise NotImplementedError()

    @abstractmethod
    def convert_index(self, index: Index) -> Any:
        """
        Конвертируем индекс
        """
        raise NotImplementedError()

    @abstractmethod
    def ensure_indexes(self):
        """
        Проверяем, что все индексы накатились
        """
        raise NotImplementedError()

    @abstractmethod
    def represent_indexes_as_native_command(self):
        """
        Представляем индексы как нативную команду для
        запроса к базе данных
        :return:
        """
        raise NotImplementedError()
