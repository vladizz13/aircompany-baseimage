class Index(object):
    """
    Контейнер для индексов
    """
    def __init__(
            self,
            index: dict = None,
            unique: bool = None,
            background: bool = None,
            name: str = None
    ):
        self.index = index
        self.unique = unique
        self.background = background
        self.name = name
