from pymongo.database import Database
from typing import List, Tuple, Type
from base.domain import BaseDomain
from repositories.mongo.mongo_domain_identity import DomainMongoIdentity
from libs.db_gateway import get_db_gateway
from .index import Index
from .base import BaseIndexUpdater


class MongoIndexUpdater(BaseIndexUpdater):
    indexes_to_roll: List[Index] = []
    domain_instance: Type[BaseDomain] = None

    # Дефолтное значение, можно перегрузить в init
    # По дефолту все индексы будут накатыватся в бэкграунде
    # Либо добавить background: True/False в options контейнера
    background_mode: bool = True

    def __init__(
            self,
            gateway: Database = None,
    ):
        self.identity = DomainMongoIdentity.map_identity(self.domain_instance)
        super().__init__(gateway=gateway if gateway else get_db_gateway())

    def prepare_indexes(self):
        """
        Подготавливаем индексы
        """
        if not self.indexes_to_roll:
            raise Exception("Unable to roll index, IndexList is empty")
        for index in self.indexes_to_roll:
            if index.background is None:
                index.background = self.background_mode

    def roll_indexes(self):
        """
        Накатывает индексы
        Это идемпотентная операция, проверка на существующие индексы не нужна
        """
        self.prepare_indexes()

        for index in self.indexes_to_roll:
            index_list, unique, background = self.convert_index(index)
            self.db_connection[self.identity.collection].create_index(
                index_list, unique=unique, background=background
            )

    def convert_index(self, index: Index) -> (list, bool, bool):
        """
        Конвертируем индекс в формат pymongo
        """
        unique_option = index.unique if index.unique else False
        background_option = index.background if index.background is not None else self.background_mode
        converted_index_list: List[Tuple] = []
        for k, v in index.index.items():
            converted_index_list.append((k, v))
        return converted_index_list, unique_option, background_option

    def ensure_indexes(self):
        """
        Проверяем, что все индексы накатились
        """
        index_info = self.db_connection[self.identity.collection].index_information()
        for list_index, mongo_index in enumerate(self.indexes_to_roll):
            index_list, unique, background = self.convert_index(mongo_index)
            found = False
            for k, v in index_info.items():
                index = v.get('key', [])
                if index == index_list:
                    found = True
            try:
                assert found is True
            except AssertionError:
                raise Exception("Unable to ensure index {} is rolled".format(index_list))

    def represent_indexes_as_native_command(self):
        """
        Представляем индексы как нативную команду для
        запроса к базе данных
        :return:
        """
        print('# {}\n'.format(self.identity.collection))
        for index in self.indexes_to_roll:
            options = {
                "background": int(index.background if index.background is not None else self.background_mode),
                "unique": int(index.unique if index.unique is not None else False)
            }
            template = "{0},{1}".format(index.index, options)
            mongo_index_template = 'db.{}.createIndex({})'.format(self.identity.collection, template)
            print(mongo_index_template)

        print('\n')
