from typing import Type

from base.domain import BaseDomain
from domain import DomainOrder
from domain.currency_rates import DomainCurrencyRates
from domain.exchange import DomainExchange
from domain.origin_transaction import DomainOriginTransaction
from domain.pd_changes import DomainPDChanges
from domain.prorate import DomainProrate
from domain.refunds import DomainRefund
from domain.release_seats import DomainReleaseSeats


class DomainMongoIdentity(object):
    """
    Маппинг доменной модели к коллекции, которой она принадлежит
    """

    def __init__(self, collection: str):
        self.collection = collection

    @classmethod
    def map_identity(cls, item: Type[BaseDomain]) -> 'DomainMongoIdentity':
        map = {
            DomainOrder: DomainMongoIdentity(collection='orders'),
            DomainProrate: DomainMongoIdentity(collection='prorates'),
            DomainCurrencyRates: DomainMongoIdentity(collection='currency_rates'),
            DomainOriginTransaction: DomainMongoIdentity(collection='origin_transactions'),
            DomainRefund: DomainMongoIdentity(collection='refunds'),
            DomainPDChanges: DomainMongoIdentity(collection='pd_changes'),
            DomainReleaseSeats: DomainMongoIdentity(collection='release_seats'),
            DomainExchange: DomainMongoIdentity(collection='exchanges'),
        }
        return map[item]
