from base.repository import BaseRepository
from base.domain import BaseDomain
from base.exception import ApplicationError
from pymongo.database import Database
from .mongo_domain_identity import DomainMongoIdentity
from libs.query_builder.query_unit import QueryUnit
from libs.query_builder.aggregate_query_unit import AggregateQueryUnit
from typing import List, Type, Generic


class GenericMongoRepository(BaseRepository):
    """
    Паттерн репозиторий
    Пример использования:
    >>> from repositories.query_builders import OrdersQueryBuilder
    >>> repo = GenericMongoRepository(
    >>>            gateway=Database,   # Соединение с базой (в данном случае монга)
    >>>            instance=BaseDomain # Инстанс модели, который будем смаплен в соотв. коллекцию
    >>>      )
    >>> order_uuid = '123'
    >>> query = OrdersQueryBuilder().get_by_order_uuid(order_uuid)
    >>> repo.get_single(query)
    """

    def __init__(
            self,
            gateway: Database = None,
            instance: Type[BaseDomain] = None,
    ):
        self.gateway = gateway
        self.instance: Type[BaseDomain] = instance
        self.domain_identity = DomainMongoIdentity.map_identity(instance)
        super().__init__(gateway=gateway)

    def create(self, item: BaseDomain):
        self.gateway[self.domain_identity.collection].insert_one(item.serialize())

    def delete(self, spec: QueryUnit):
        # Не даем удалять с пустой спецификацией
        query = self.__build_query__(spec)
        if query == {}:
            raise ApplicationError(message="Specification is too broad to delete")
        self.gateway[self.domain_identity.collection].delete_many(query)

    def update(self, item: BaseDomain, spec: QueryUnit, upsert: bool = True):
        self.gateway[self.domain_identity.collection].replace_one(
            self.__build_query__(spec),
            item.serialize(),
            upsert=upsert
        )

    def list(
            self,
            spec: QueryUnit = None,
            sort: List[tuple] = None,
            limit: int = 0,
            skip: int = 0
    ) -> 'List[Generic[BaseDomain]]':
        query = self.__build_query__(spec) if spec else {}
        result = self.gateway[self.domain_identity.collection].find(query, sort=sort).limit(limit).skip(skip)
        return [self.instance.deserialize(i) for i in result]

    def get_single(self, spec: QueryUnit = None, sort: List[tuple] = None) -> 'Generic[BaseDomain]':
        query = self.__build_query__(spec) if spec else {}
        result = self.gateway[self.domain_identity.collection].find_one(query, sort=sort)
        return self.instance.deserialize(result) if result else result

    def aggregate(self, spec: AggregateQueryUnit) -> 'List[Generic[BaseDomain]]':
        result = list(self.gateway[self.domain_identity.collection].aggregate(
            self.__build_aggregation_query__(spec)
        ))
        return [self.instance.deserialize(i) for i in result]

    def count(self, spec: QueryUnit) -> int:
        query = self.__build_query__(spec)
        result = int(self.gateway[self.domain_identity.collection].count_documents(query))
        return result

    @staticmethod
    def __build_query__(spec: QueryUnit) -> dict:
        if not isinstance(spec, QueryUnit):
            raise ApplicationError(message='Incorrect specification instance')
        return spec.build_query()

    @staticmethod
    def __build_aggregation_query__(spec: AggregateQueryUnit) -> list:
        if not isinstance(spec, AggregateQueryUnit):
            raise ApplicationError(message='Incorrect specification instance for aggregation')
        return spec.build_query()
