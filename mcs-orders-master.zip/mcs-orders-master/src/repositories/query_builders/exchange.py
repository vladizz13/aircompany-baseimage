import logging
import typing

from libs.query_builder import (
    AndQueryUnit, OrQueryUnit, QueryBuilder
)

logger = logging.getLogger('exchange_query_builder')


class ExchangeQueryBuilder(QueryBuilder):
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __uuid_selector__: QuerySelectorType = (lambda _uuid: {'exchange_uuid': _uuid})
    __order_uuid_selector__: QuerySelectorType = (lambda _order_uuid: {'order_uuid': _order_uuid})
    __divided_order_uuid_selector__: QuerySelectorType = (
        lambda _order_uuid: {'divided_order_uuid': _order_uuid}
    )

    @classmethod
    def get_exchange_by_uuid(cls, exchange_uuid: str) -> AndQueryUnit:
        """Поиск по uuid"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__uuid_selector__(exchange_uuid)))
        return misc_criterion

    @classmethod
    def get_exchange_by_order_uuid(cls, order_uuid: str) -> AndQueryUnit:
        """Поиск по order_uuid"""
        misc_criterion = OrQueryUnit()
        misc_criterion.add(cls(cls.__order_uuid_selector__(str(order_uuid))))
        misc_criterion.add(cls(cls.__divided_order_uuid_selector__(str(order_uuid))))
        return misc_criterion
