from datetime import datetime
import logging
import typing
from typing import Union, List, Optional, Dict
import re

from libs.query_builder import AndQueryUnit
from libs.query_builder import QueryBuilder
from libs.query_builder import OrQueryUnit
from libs.query_builder import QueryUnit
from libs.query_builder.exceptions import UnitError

from use_cases.orders.save.normalize_order.normalizers.contacts import ContactsCommonNormalizer

from domain.types import ContactType, PassengerCategory, UtairCabinClass
from domain.order.data.contacts import DomainContact

logger = logging.getLogger('orders_query_bulder')


class OrdersQueryBuilder(QueryBuilder):
    """
    Класс составления поискового запроса по заказам/транзакциям.
    Не может иметь дочерних unit-ов, т.к. является "самым дочерним" в иерархии QueryUnit
    """
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __default_skip__: int = 0
    __default_limit__: int = 10

    __max_limit__: int = 100
    __phone_blacklist__: list = ['777', '+777']

    __add_field_criterion__: QuerySelectorType = (
        lambda field_name, field_data: {
            '$addFields': {
                'matched_{}'.format(field_name): {
                    '$eq': [
                        '$data.{}'.format(field_name), field_data
                    ]
                }
            }
        }
    )

    __add_field__: QuerySelectorType = (
        lambda field_name, field_data: {
            '$addFields': {
                'matched_{}'.format(field_name): field_data
            }
        }
    )

    __branch_eq__: QuerySelectorType = (
        lambda data: {
            'case': {'$eq': ['$data.{}'.format(data["key"]), data["value"]]}, 'then': data["default"]
        }
    )

    __switch_case__: QuerySelectorType = (
        lambda branches, default_value: {
            '$switch': {
                'branches': branches,
                'default': default_value,
            }
        }
    )

    __sort__: QuerySelectorType = (
        lambda key, value: {
            '$sort': {
                key: value
            }
        }
    )

    __multiple_sort__: QuerySelectorType = (
        lambda sort: {
            '$sort': sort
        }
    )

    __limit__: QuerySelectorType = (
        lambda value: {
            '$limit': value
        }
    )

    __skip__: QuerySelectorType = (
        lambda value: {
            '$skip': value
        }
    )

    __match_selector__: QuerySelectorType = (
        lambda selector: {'$match': selector}
    )

    __status_selector__: QuerySelectorType = (
        lambda status: {'data.status': status}
    )

    __multiple_status_selector__: QuerySelectorType = (
        lambda status: {'data.status': {'$in': status}}
    )

    __status_ne_selector__: QuerySelectorType = (
        lambda status: {'data.status': {'$ne': status}}
    )

    __order_uuid_selector__: QuerySelectorType = (
        lambda order_uuid: {'data.order_uuid': order_uuid}
    )

    __multiple_uuid_selector__: QuerySelectorType = (
        lambda order_uuids: {'data.order_uuid': {'$in': order_uuids}}
    )

    __tickets_elem_match_single_selector__: QuerySelectorType = (
        lambda ticket: {'data.tickets.ticket': ticket}
    )

    __ticket_elem_match_selector__: QuerySelectorType = (
        lambda tickets: {'data.tickets.ticket': {'$in': tickets}}
    )

    __rloc_selector__: QuerySelectorType = (
        lambda rloc: {'data.rloc': rloc}
    )

    __rloc_regex_selector__: QuerySelectorType = (
        lambda rloc: {'data.rloc': {'$regex': f'^{rloc}'}}
    )

    __rloc_and_departure_end_timestamp_selector__: QuerySelectorType = (
        lambda rloc, departure_end_timestamp: {
            'data.rloc': rloc, 'data.departure_end_timestamp': int(departure_end_timestamp)
        }
    )

    __arrival_city_selector__: QuerySelectorType = (
        lambda code: {'data.segments.arrival_city_code': code}
    )

    __departure_city_selector__: QuerySelectorType = (
        lambda code: {'data.segments.departure_city_code': code}
    )

    __arrival_city_simple_selector__: QuerySelectorType = (
        lambda code: {'arrival_city_code': code}
    )

    __departure_city_simple_selector__: QuerySelectorType = (
        lambda code: {'departure_city_code': code}
    )

    __host_rloc_elem_match_selector__: QuerySelectorType = (
        lambda host_rloc: {'data.rloc_host.value': {'$in': host_rloc}}
    )

    __host_rloc_elem_match_single_selector__: QuerySelectorType = (
        lambda host_rloc: {'data.rloc_host.value': host_rloc}
    )

    __departure_start_timestamp_gte_selector__: QuerySelectorType = (
        lambda departure_start_timestamp: {'data.departure_start_timestamp': {'$gte': int(departure_start_timestamp)}}
    )

    __departure_start_timestamp_lte_selector__: QuerySelectorType = (
        lambda departure_start_timestamp: {'data.departure_start_timestamp': {'$lte': int(departure_start_timestamp)}}
    )

    __departure_end_timestamp_lte_selector__: QuerySelectorType = (
        lambda departure_end_timestamp: {'data.departure_end_timestamp': {'$lte': int(departure_end_timestamp)}}
    )

    __departure_end_timestamp_gte_selector__: QuerySelectorType = (
        lambda departure_end_timestamp: {'data.departure_end_timestamp': {'$gte': int(departure_end_timestamp)}}
    )

    __departure_end_timestamp_eq_selector__: QuerySelectorType = (
        lambda departure_end_timestamp: {'data.departure_end_timestamp': int(departure_end_timestamp)}
    )

    __passenger_last_name_selector__: QuerySelectorType = (
        lambda passenger_last_name: {'data.passengers.last_name': passenger_last_name}
    )

    __passenger_types_selector__: QuerySelectorType = (
        lambda passenger_types: {'data.passengers.type': {"$nin": passenger_types}}
    )

    __passenger_first_name_selector__: QuerySelectorType = (
        lambda passenger_first_name: {'data.passengers.first_name': passenger_first_name}
    )

    __passenger_first_and_last_name_selector__: QuerySelectorType = (
        lambda pass_first_name, pass_last_name: {
            'data.passengers': {
                '$elemMatch': {'first_name': pass_first_name, 'last_name': pass_last_name}}
        }
    )

    __passenger_doc_number_selector__: QuerySelectorType = (
        lambda passenger_doc_number: {'data.documents.docnumber': passenger_doc_number}
    )

    __flight_number_selector__: QuerySelectorType = (
        lambda flight_number: {'data.segments.flight_number': flight_number}
    )

    __flight_number_regex_selector__: QuerySelectorType = (
        lambda flight_number: {'data.segments.flight_number': {'$regex': flight_number}}
    )

    __segment_departure_local_date_selector__: QuerySelectorType = (
        lambda local_date: {'data.segments.departure_local_iso': {'$regex': f'^{local_date}'}}
    )

    __flight_number_selector_simple__: QuerySelectorType = (
        lambda flight_number: {'flight_number': flight_number}
    )

    __flight_number_regex_simple_selector__: QuerySelectorType = (
        lambda flight_number: {'flight_number': {'$regex': flight_number}}
    )

    __segment_departure_local_date_simple_selector__: QuerySelectorType = (
        lambda local_date: {'departure_local_iso': {'$regex': f'^{local_date}'}}
    )

    __segment_departure_timestamp_simple_selector__: QuerySelectorType = (
        lambda timestamp: {'departure_timestamp': {"$lt": timestamp + 2, "$gt": timestamp - 2}}
    )

    __segment_class_selector__: QuerySelectorType = (
        lambda segment_class: {"class": segment_class}
    )

    __loyalty_card_number_selector__: QuerySelectorType = (
        lambda card_number: {'data.pos_data.additional_data.profile_card_number': card_number}
    )

    __fops_account_num_regexp_selector__: QuerySelectorType = (
        lambda prefix, code: {'data.fops': {'$elemMatch': {
            'account_num': {'$regex': f'^{prefix}.*'}, "code": code
        }}}
    )

    __oak_selector__: QuerySelectorType = (
        lambda oak: {'data.segments.oak': oak}
    )

    __oak_simple_selector__: QuerySelectorType = (
        lambda oak: {'oak': oak}
    )

    __get_by_user_email__: QuerySelectorType = (
        lambda user_email_list: {
            'data.contacts': {
                '$elemMatch': {
                    'contact': {'$in': user_email_list}, 'type': ContactType.MAIL.value
                },
            }
        }
    )

    __get_by_segment_query__: QuerySelectorType = (
        lambda query: {
            'data.segments': {
                '$elemMatch': query,
            }
        }
    )

    __get_by_user_phone__: QuerySelectorType = (
        lambda user_phone_list: {
            'data.contacts': {
                '$elemMatch': {
                    'contact': {'$in': user_phone_list}, 'type': ContactType.PHONE.value
                },
            }
        }
    )

    __exclude_user_order_is_hidden__: QuerySelectorType = (
        lambda user_id: {'meta.is_hidden_for': {'$not': {'$elemMatch': {'userId': user_id}}}}
    )

    __exclude_order_is_hidden_by_any_user__: QuerySelectorType = (
        lambda: {'meta.is_hidden_for': {'$not': {'$exists': True, '$type': 'array', '$ne': []}}}
    )

    __include_user_order_sub_owners__: QuerySelectorType = (
        lambda user_id: {'meta.sub_owners.userId': user_id}
    )

    __timelimit_lt_timestamp: QuerySelectorType = (
        lambda timelimit: {'data.pos_data.timelimit': {'$lte': int(timelimit)}}
    )

    __timelimit_is_none__: QuerySelectorType = (
        lambda timelimit: {'data.pos_data.timelimit': {'$eq': None}}
    )

    __order_status_nin__: QuerySelectorType = (
        lambda status: {'data.status': {'$nin': status}}
    )

    @classmethod
    def get_limit(cls, limit: int):
        """
        Пагинация, лимит
        """
        if limit and int(limit) <= cls.__max_limit__:
            return int(limit)
        return cls.__default_limit__

    @classmethod
    def get_skip(cls, skip: int = None):
        if skip:
            return int(skip)
        return cls.__default_skip__

    @classmethod
    def get_sort(cls, key, value):
        criterion = QueryUnit()
        criterion.add(cls(cls.__sort__(key, value)))
        return criterion

    @classmethod
    def get_multiple_sort(cls, sort: Dict):
        criterion = QueryUnit()
        criterion.add(cls(cls.__multiple_sort__(sort)))
        return criterion

    @classmethod
    def limit_aggregation(cls, value: int):
        criterion = QueryUnit()
        criterion.add(cls(cls.__limit__(value)))
        return criterion

    @classmethod
    def skip_aggregation(cls, value: int):
        criterion = QueryUnit()
        criterion.add(cls(cls.__skip__(value)))
        return criterion

    @classmethod
    def get_by_status_and_timelimit(cls, status: str, time_limit: int) -> AndQueryUnit:
        """
        Нахождение заказа по status и истекшему таймлимиту
        timelimit <= timelimit
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.get_by_status(status).build_query()))
        or_critertion = OrQueryUnit()
        or_critertion.add(cls(cls.__timelimit_lt_timestamp(time_limit)))
        or_critertion.add(cls(cls.__timelimit_is_none__(None)))
        misc_criterion.add(or_critertion)
        return misc_criterion

    @classmethod
    def get_by_user_data(cls, user_data: dict) -> OrQueryUnit:
        """
        Поиск заказа по почте или телефону в контактах
        :param user_data:
        >>>{
        >>> "email": "user@provider.zone",
        >>> "phone": "88005553535",
        >>> "user_id": "user id"
        >>>}
        """
        misc_criterion = OrQueryUnit()
        if user_data.get('email', None):
            misc_criterion.add(cls.get_by_user_mail(user_data.get('email')))
        if user_data.get('phone', None):
            misc_criterion.add(cls.get_by_user_phone(user_data.get('phone')))
        if user_data.get('user_id', None):
            misc_criterion.add(cls(cls.__include_user_order_sub_owners__(user_data.get('user_id'))))
        return misc_criterion

    @classmethod
    def get_by_user_mail(cls, user_email: Union[str, list]) -> QueryUnit:
        """
        Поиск заказа по почте в контактах
        """
        normalizer = ContactsCommonNormalizer()
        if isinstance(user_email, str):
            user_email = [user_email]
        contacts: typing.List[DomainContact] = [DomainContact(contact=e) for e in user_email]
        normalized_contacts: typing.List[DomainContact] = [normalizer.normalize_email(c) for c in contacts]
        emails: typing.List[str] = [e.contact for e in normalized_contacts]
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__get_by_user_email__(emails)))
        return misc_criterion

    @classmethod
    def get_by_user_phone(cls, user_phone: Union[str, list]) -> QueryUnit:
        """
        Поиск заказа по номеру телефона в контактах
        """
        normalizer = ContactsCommonNormalizer()
        if isinstance(user_phone, str):
            user_phone = [user_phone]
        contacts: typing.List[DomainContact] = [DomainContact(contact=p) for p in user_phone]
        normalized_contacts: typing.List[DomainContact] = [normalizer.normalize_phone(c) for c in contacts]
        phones: typing.List[str] = [p.contact for p in normalized_contacts]
        misc_criterion = QueryUnit()
        user_phone[:] = [up for up in phones if up not in cls.__phone_blacklist__]
        misc_criterion.add(cls(cls.__get_by_user_phone__(phones)))
        return misc_criterion

    @classmethod
    def get_by_status(cls, status: Union[str, List[str]]) -> AndQueryUnit:
        """
        Поиск заказа по статусу заказа
        """
        misc_criterion = AndQueryUnit()
        if isinstance(status, List):
            misc_criterion.add(cls(cls.__multiple_status_selector__(status)))
        else:
            misc_criterion.add(cls(cls.__status_selector__(status)))
        return misc_criterion

    @classmethod
    def get_by_segment(
            cls,
            arrival_city_code: Optional[str] = None,
            departure_city_code: Optional[str] = None,
            flight_number: Optional[str] = None,
            departure_local_date: Optional[datetime] = None,
            departure_utc_date: Optional[datetime] = None,
            segment_class: Optional[UtairCabinClass] = None
    ) -> AndQueryUnit:
        """
        Поиск заказа по информации из сегмента
        """
        if not any((
            arrival_city_code, departure_city_code, flight_number, departure_local_date
        )):
            raise UnitError(message="Unable to build search segment query, empty args")
        misc_criterion = AndQueryUnit()

        if arrival_city_code:
            misc_criterion.add(cls.get_segment_by_arrival_city(arrival_city_code))
        if departure_city_code:
            misc_criterion.add(cls.get_segment_by_departure_city(departure_city_code))
        if flight_number:
            misc_criterion.add(cls.get_segment_by_flight_number(flight_number))
        if departure_local_date:
            misc_criterion.add(cls.get_segment_by_departure_date_local(departure_local_date))
        if departure_utc_date:
            misc_criterion.add(cls.get_segment_by_departure_date_utc(departure_utc_date))
        if segment_class:
            misc_criterion.add(cls.get_segment_by_class(segment_class))
        seg_criterion = AndQueryUnit()
        seg_criterion.add(cls(cls.__get_by_segment_query__(misc_criterion.build_query())))
        return seg_criterion

    @classmethod
    def get_by_status_ne(cls, status: str) -> AndQueryUnit:
        """
        Поиск заказа по статусу заказа
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__status_ne_selector__(status)))
        return misc_criterion

    @classmethod
    def get_by_departure_city(cls, code: str) -> AndQueryUnit:
        """
        Поиск заказа по городу вылета
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_city_selector__(code)))
        return misc_criterion

    @classmethod
    def get_segment_by_departure_city(cls, code: str) -> AndQueryUnit:
        """
        Поиск сегмента по городу вылета
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_city_simple_selector__(code)))
        return misc_criterion

    @classmethod
    def get_by_arrival_city(cls, code: str) -> AndQueryUnit:
        """
        Поиск заказа по городу прилета
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__arrival_city_selector__(code)))
        return misc_criterion

    @classmethod
    def get_segment_by_arrival_city(cls, code: str) -> AndQueryUnit:
        """
        Поиск сегмента по городу прилета
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__arrival_city_simple_selector__(code)))
        return misc_criterion

    @classmethod
    def get_by_order_uuid(cls, order_uuid: str) -> AndQueryUnit:
        """Поиск заказа по order_uuid"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__order_uuid_selector__(order_uuid)))
        return misc_criterion

    @classmethod
    def get_by_order_uuid_multiple(cls, order_uuids: List[str]) -> AndQueryUnit:
        """Поиск заказа по order_uuid"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__multiple_uuid_selector__(order_uuids)))
        return misc_criterion

    @classmethod
    def get_by_order_rloc(cls, order_rloc: str) -> AndQueryUnit:
        """Поиск заказа по rloc"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__rloc_selector__(order_rloc)))
        return misc_criterion

    @classmethod
    def get_by_order_rloc_regexp(cls, order_rloc: str) -> AndQueryUnit:
        """Поиск заказа по rloc используя regexp"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__rloc_regex_selector__(order_rloc.upper())))
        return misc_criterion

    @classmethod
    def get_by_order_rloc_extended(cls, order_rloc: str, regexp: bool = True) -> AndQueryUnit:
        """
        Получение заказа по рлоку в зависимости от его формата
        """
        misc_criterion = AndQueryUnit()
        post_fix_search: bool = False

        if order_rloc and '/' in order_rloc:
            post_fix_search: bool = True

        if regexp and not post_fix_search:
            misc_criterion.add(cls(cls.__rloc_regex_selector__(order_rloc)))
        else:
            misc_criterion.add(cls(cls.__rloc_selector__(order_rloc)))
        return misc_criterion

    @classmethod
    def get_by_order_rloc_or_rloc_host(cls, rloc: str, regexp: bool = True) -> OrQueryUnit:
        """
        Поиск заказа по rloc или rloc_host
        """
        post_fix_search: bool = False

        misc_criterion = OrQueryUnit()
        misc_criterion.add(cls(cls.__host_rloc_elem_match_single_selector__(rloc)))

        if rloc and '/' in rloc:
            post_fix_search: bool = True

        if regexp and not post_fix_search:
            misc_criterion.add(cls(cls.__rloc_regex_selector__(rloc)))
        else:
            misc_criterion.add(cls(cls.__rloc_selector__(rloc)))
        return misc_criterion

    @classmethod
    def get_by_rloc_host(cls, rloc_host: str) -> AndQueryUnit:
        """
        Поисск заказа по rloc_host
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__host_rloc_elem_match_single_selector__(rloc_host)))
        return misc_criterion

    @classmethod
    def get_by_multiple_rloc_host(cls, rloc_host: List[str]) -> AndQueryUnit:
        """
        Поисск заказа по всем rloc_host
        """
        rloc_host = [i for i in rloc_host if i is not None]
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__host_rloc_elem_match_selector__(rloc_host)))
        return misc_criterion

    @classmethod
    def get_by_passenger_last_name(cls, passenger_last_name: str) -> AndQueryUnit:
        """Поиск заказа по фамилии пассажира"""
        misc_criterion = AndQueryUnit()
        if passenger_last_name:
            passenger_last_name = str(passenger_last_name).strip().capitalize()
        misc_criterion.add(cls(cls.__passenger_last_name_selector__(passenger_last_name)))
        return misc_criterion

    @classmethod
    def get_by_passenger_first_name(cls, passenger_first_name: str) -> AndQueryUnit:
        """Поиск заказа по имени пассажира"""
        misc_criterion = AndQueryUnit()
        if passenger_first_name:
            passenger_first_name = str(passenger_first_name).strip().capitalize()
        misc_criterion.add(cls(cls.__passenger_first_name_selector__(passenger_first_name)))
        return misc_criterion

    @classmethod
    def get_by_passenger_first_and_last_name(cls, first_name: str, last_name: str) -> AndQueryUnit:
        """Поиск заказа по имени и фамилии"""
        misc_criterion = AndQueryUnit()
        if first_name:
            first_name = str(first_name).strip().capitalize()
        if last_name:
            last_name = str(last_name).strip().capitalize()
        misc_criterion.add(cls(cls.__passenger_first_and_last_name_selector__(first_name, last_name)))
        return misc_criterion

    @classmethod
    def get_by_passenger_type(cls, types: List[PassengerCategory]) -> AndQueryUnit:
        """
        Поиск по типу пассажира
        """
        _types = [e.value for e in PassengerCategory if e not in types]
        if not _types:
            raise RuntimeError(f"Search by passenger type is ambiguous, all categories are provided: {types}")
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__passenger_types_selector__(list(_types))))
        return misc_criterion

    @classmethod
    def get_by_ticket_number(cls, ticket_number: str) -> AndQueryUnit:
        """Поиск заказа по номеру билета"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__tickets_elem_match_single_selector__(ticket_number)))
        return misc_criterion

    @classmethod
    def get_by_ticket_numbers(cls, ticket_numbers: typing.List[str]) -> AndQueryUnit:
        """
        Поиск заказа по нескольким билетам
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__ticket_elem_match_selector__(ticket_numbers)))
        return misc_criterion

    @classmethod
    def get_by_passenger_doc_number(cls, passenger_doc_number: str) -> AndQueryUnit:
        """Поиск заказа по документу пассажира"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__passenger_doc_number_selector__(passenger_doc_number)))
        return misc_criterion

    @classmethod
    def get_by_departure_start_timestamp_gte(cls, departure_start_timestamp: int) -> AndQueryUnit:
        """Поиск заказа по дате вылета"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_start_timestamp_gte_selector__(departure_start_timestamp)))
        return misc_criterion

    @classmethod
    def get_by_departure_start_timestamp_lte(cls, departure_start_timestamp: int) -> AndQueryUnit:
        """Поиск заказа по дате вылета"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_start_timestamp_lte_selector__(departure_start_timestamp)))
        return misc_criterion

    @classmethod
    def get_by_departure_end_timestamp_lte(cls, departure_end_timestamp: int) -> AndQueryUnit:
        """Поиск заказа по дате прилета"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_end_timestamp_lte_selector__(departure_end_timestamp)))
        return misc_criterion

    @classmethod
    def get_by_departure_end_timestamp_gte(cls, departure_end_timestamp: int) -> AndQueryUnit:
        """Поиск заказа по дате прилета"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure_end_timestamp_gte_selector__(departure_end_timestamp)))
        return misc_criterion

    @classmethod
    def get_by_flight_number(cls, flight_number: str) -> Union[QueryUnit, None]:
        """Поиск заказа по номеру рейса"""
        return cls._get_by_flight_number(flight_number)

    @classmethod
    def get_segment_by_flight_number(cls, flight_number: str) -> Union[QueryUnit, None]:
        """Поиск сегмента по номеру рейса"""
        return cls(cls._get_by_flight_number(flight_number, True).build_query())

    @classmethod
    def _get_by_flight_number(cls, flight_number: str, skip_segments: bool = False) -> Union[QueryUnit, None]:
        """Поиск заказа по номеру рейса"""
        flight_number = str(flight_number).upper()
        # Регулярка для номера рейса вида "UT277"
        flight_regex = re.compile('^[a-z]{2}[1-9]{3,4}[a-z]{0,1}$', re.IGNORECASE)
        if flight_number.isdigit() and len(flight_number) <= 4:  # поиск рейса вида "2777"
            misc_criterion = AndQueryUnit()
            if skip_segments:
                misc_criterion.add(cls(cls.__flight_number_selector_simple__(flight_number)))
            else:
                misc_criterion.add(cls(cls.__flight_number_selector__(flight_number)))
            return misc_criterion
        elif re.search(flight_regex, flight_number):  # поиск рейса вида "UT 277"
            flight_number = re.sub(r'[^\w\s\d-]', r'', flight_number).strip()
            regex_pattern = re.compile('^{}'.format(flight_number), re.IGNORECASE)
            flight_number_criterion = OrQueryUnit()
            if skip_segments:
                flight_number_criterion.add(cls(cls.__flight_number_regex_simple_selector__(regex_pattern)))
            else:
                flight_number_criterion.add(cls(cls.__flight_number_regex_selector__(regex_pattern)))
            segment_flight_number_criterion = AndQueryUnit()
            if skip_segments:
                segment_flight_number_criterion.add(
                    cls(cls.__flight_number_selector_simple__(flight_number[2:])))
                segment_flight_number_criterion.add(
                    cls(cls.__oak_simple_selector__(flight_number[0:2])))
            else:
                segment_flight_number_criterion.add(
                    cls(cls.__flight_number_selector__(flight_number[2:])))
                segment_flight_number_criterion.add(
                    cls(cls.__oak_selector__(flight_number[0:2])))
            flight_number_criterion.add(segment_flight_number_criterion)
            return flight_number_criterion
        else:
            misc_criterion = AndQueryUnit()
            if skip_segments:
                misc_criterion.add(cls(cls.__flight_number_selector_simple__(flight_number)))
            else:
                misc_criterion.add(cls(cls.__flight_number_selector__(flight_number)))
            return misc_criterion

    @classmethod
    def exclude_order_is_hidden_by_anyone(cls) -> AndQueryUnit:
        """Исключаем из поиска спрятанные любым юзером заказы"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__exclude_order_is_hidden_by_any_user__()))
        return misc_criterion

    @classmethod
    def exclude_all_segments_flown(cls, before_date: datetime) -> AndQueryUnit:
        """
        Поиск заказа, где есть хотя бы один сегмент не пролетанный
        """
        criterion = AndQueryUnit()
        query = {
            'data.segments.departure_timestamp': {
                "$gt": int(before_date.timestamp())
            }
        }
        criterion.add(cls(query))
        return criterion

    @classmethod
    def exclude_order_is_hidden_by_user(cls, user_id: str) -> AndQueryUnit:
        """Исключаем из поиска спрятанные указанным пользователем заказы"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__exclude_user_order_is_hidden__(user_id)))
        return misc_criterion

    @classmethod
    def get_by_locator(cls, locator: str) -> OrQueryUnit:
        """
        Локатор ищет по:
        РЛОК ИЛИ Хост РЛОК
        ИЛИ номер документа пассажира
        ИЛИ номер билета пассажира
        """
        misc_criterion = OrQueryUnit()
        if locator and 6 <= len(locator) <= 9:
            # Добавляем рлок только если он подходит под правила, чтобы не гонять regexp запросы просто так
            misc_criterion.add(cls(cls.get_by_order_rloc_or_rloc_host(locator, regexp=True).build_query()))
        misc_criterion.add(cls(cls.get_by_passenger_doc_number(locator).build_query()))
        misc_criterion.add(cls(cls.get_by_ticket_number(locator).build_query()))
        return misc_criterion

    @classmethod
    def get_by_loyalty_card_number(cls, card_number: str) -> QueryUnit:
        """
        Поиск заказа по номеру карты лояльности
        """
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__loyalty_card_number_selector__(card_number)))
        return criterion

    @classmethod
    def get_by_fops_account_num_prefix(cls, account_prefix: str) -> QueryUnit:
        """
        Поиск по префиксу data.fops.account_num
        """
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__fops_account_num_regexp_selector__(account_prefix, "VZ")))
        return criterion

    @classmethod
    def get_by_departure_date_local(cls, date: datetime) -> AndQueryUnit:
        """
        Поиск по дате вылета в местном времени
        """
        date_format = "%Y-%m-%d"
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__segment_departure_local_date_selector__(
            date.strftime(date_format)
        )))
        return criterion

    @classmethod
    def get_segment_by_departure_date_local(cls, date: datetime) -> AndQueryUnit:
        """
        Поиск сегмента по дате вылета в местном времени
        """
        date_format = "%Y-%m-%d"
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__segment_departure_local_date_simple_selector__(
            date.strftime(date_format)
        )))
        return criterion

    @classmethod
    def get_segment_by_departure_date_utc(cls, date: datetime) -> AndQueryUnit:
        """
        Поиск сегмента по дате вылета по UTC
        """
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__segment_departure_timestamp_simple_selector__(
            int(date.timestamp())
        )))
        return criterion

    @classmethod
    def get_segment_by_class(cls, class_: UtairCabinClass) -> AndQueryUnit:
        """
        Поиск сегмента по классу
        """
        criterion = AndQueryUnit()
        criterion.add(cls(cls.__segment_class_selector__(class_.value)))
        return criterion

    @classmethod
    def get_order_status_nin(cls, status: List[str]) -> QueryUnit:
        """
        Поиск по отрицательным статусам заказа
        """
        criterion = QueryUnit()
        criterion.add(cls(cls.__order_status_nin__(status)))
        return criterion

    @classmethod
    def all_segments_flown(cls, departure_timestamp: int) -> QueryUnit:
        """
        Поиск заказа, где все сегменты пролетаны
        """
        criterion = QueryUnit()
        query = {
          "data.segments": {
            "$all": [
                {'$elemMatch': {'departure_timestamp': {'$ne': {'$lte': departure_timestamp}}}}
            ]
          }
        }
        criterion.add(cls(query))
        return criterion

    @classmethod
    def branch_eq(cls, key, value, default_value) -> QueryUnit:
        """
        Создание ветки для switch'а. Находим значения равные переданным условиям.
        :param key: ключ поля в БД по которому происходит поиск
        :param value: значение, по которому осуществляем поиск
        :param default_value: значение которое будет равно, если условие совпадает
        """
        criterion = QueryUnit()
        criterion.add(cls(cls.__branch_eq__(
            {
                'key': key,
                'value': value,
                'default': default_value
            }
        )))
        return criterion

    @classmethod
    def switch_case(cls, branches: List[Dict], default_value) -> QueryUnit:
        """
        Базовый метод для создания условий. Принимает массив веток условий.
        При необходимости можно создать новые ветки.
        :param branches: массив веток условий
        :param default_value: значение которое будет равно, если ни одно из условий не совпадает
        """
        criterion = QueryUnit()
        criterion.add(cls(cls.__switch_case__(branches, default_value)))
        return criterion

    @classmethod
    def add_field(cls, field_name, field_data) -> QueryUnit:
        """
        Метод добавления нового поля в модель данных при выборке.
        :param field_name: название нового поля
        :param field_data: основной query для выборки данных
        """
        criterion = QueryUnit()
        criterion.add(cls(cls.__add_field__(field_name, field_data)))
        return criterion

    @classmethod
    def match_query(cls, query) -> QueryUnit:
        """
        Фильтрует документы, которые соответствуют указанным условиям.
        """
        criterion = QueryUnit()
        criterion.add(cls(cls.__match_selector__(query)))
        return criterion
