import logging
import typing

from libs.query_builder import AndQueryUnit
from libs.query_builder import QueryBuilder

logger = logging.getLogger('orders_query_bulder')


class OriginTransactionsQueryBuilder(QueryBuilder):
    """
    Класс составления поискового запроса по оригинальным транзакциям/транзакциям.
    Не может иметь дочерних unit-ов, т.к. является "самым дочерним" в иерархии QueryUnit
    """
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __transaction_uuid_selector__: QuerySelectorType = (
        lambda transaction_uuid: {'message_uuid': {'$in': transaction_uuid}}
    )

    @classmethod
    def get_by_transaction_uuid(cls, message_uuid: typing.Union[str, list]) -> AndQueryUnit:
        """Поиск заказа по message_uuid"""
        misc_criterion = AndQueryUnit()
        if isinstance(message_uuid, str):
            message_uuid = [message_uuid]
        misc_criterion.add(cls(cls.__transaction_uuid_selector__(message_uuid)))
        return misc_criterion
