import logging
import typing

from libs.query_builder import QueryBuilder
from libs.query_builder import QueryUnit

logger = logging.getLogger('pd_changes_query_builder')


class PDChangesQueryBuilder(QueryBuilder):
    """
    Класс составления поискового запроса по коллекции заявок на изменение персональных данных.
    Не может иметь дочерних unit-ов, т.к. является "самым дочерним" в иерархии QueryUnit
    """
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __order_uuid_selector__: QuerySelectorType = (lambda order_uuid: {'order_uuid': order_uuid})
    __passenger_id_selector__: QuerySelectorType = (lambda passenger_id: {'passenger_id': passenger_id})
    __payment_id_selector__: QuerySelectorType = (lambda payment_id: {'payment_id': payment_id})
    __status_selector__: QuerySelectorType = (lambda status: {'status': status})

    @classmethod
    def get_by_order_uuid(cls, order_uuid: str) -> QueryUnit:
        """ Поиск заявки, по order_uuid """
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__order_uuid_selector__(order_uuid)))
        return misc_criterion

    @classmethod
    def get_by_passenger_id(cls, passenger_id: str) -> QueryUnit:
        """ Поиск заявки, по passenger_id """
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__passenger_id_selector__(passenger_id)))
        return misc_criterion

    @classmethod
    def get_by_payment_id(cls, payment_id: str) -> QueryUnit:
        """ Поиск заявки, по payment_id """
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__payment_id_selector__(payment_id)))
        return misc_criterion

    @classmethod
    def get_by_status(cls, status: str) -> QueryUnit:
        """ Поиск заявки, по payment_id """
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__status_selector__(status)))
        return misc_criterion
