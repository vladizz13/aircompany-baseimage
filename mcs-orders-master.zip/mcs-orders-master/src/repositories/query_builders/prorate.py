import logging
import typing

from libs.query_builder import AndQueryUnit
from libs.query_builder import QueryBuilder

logger = logging.getLogger('prorate_query_builder')


class ProrateQueryBuilder(QueryBuilder):
    """
    Класс составления поискового запроса по прорейтам.
    """
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __default_skip__: int = 0
    __default_limit__: int = 20

    __departure__: QuerySelectorType = (
        lambda departure: {'departure': departure}
    )
    __arrival__: QuerySelectorType = (
        lambda arrival: {'arrival': arrival}
    )

    @classmethod
    def get_by_deaprture_and_arrival(cls, departure: str, arrival: str) -> AndQueryUnit:
        """
        Поиск прорейта по точке отправления и прибытия
        """
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__departure__(departure)))
        misc_criterion.add(cls(cls.__arrival__(arrival)))

        return misc_criterion
