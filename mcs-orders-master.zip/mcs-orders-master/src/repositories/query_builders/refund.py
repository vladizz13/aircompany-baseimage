import logging
import typing

from libs.query_builder import AndQueryUnit
from libs.query_builder import QueryBuilder
from libs.query_builder import QueryUnit

logger = logging.getLogger('refunds_query_builder')


class RefundsQueryBuilder(QueryBuilder):
    """
    Класс составления поискового запроса по коллекции заявок на возврат заказа.
    Не может иметь дочерних unit-ов, т.к. является "самым дочерним" в иерархии QueryUnit
    """
    QuerySelectorType = typing.Callable[[typing.Any], dict]

    __order_uuid_selector__: QuerySelectorType = (lambda order_uuid: {'order_uuid': order_uuid})
    __first_name_selector__: QuerySelectorType = (
        lambda first_name: {'passengers': {'$elemMatch': {'first_name': first_name}}}
    )
    __passenger_first_and_last_name_selector__: QuerySelectorType = (
        lambda pass_first_name, pass_last_name: {
            'passengers': {'$elemMatch': {'first_name': pass_first_name, 'last_name': pass_last_name}}
        }
    )

    @classmethod
    def find_refund_request(cls, order_uuid: str, first_name: str, last_name: str) -> QueryUnit:
        """ Поиск успешно оформленной заявки на возврат заказа, по order_uuid, first_name, last_name """
        misc_criterion = QueryUnit()
        misc_criterion.add(cls(cls.__order_uuid_selector__(order_uuid)))
        misc_criterion.add(cls(cls.__passenger_first_and_last_name_selector__(first_name, last_name)))
        return misc_criterion

    @classmethod
    def get_by_order_uuid(cls, order_uuid: str) -> AndQueryUnit:
        """Поиск по order_uuid"""
        misc_criterion = AndQueryUnit()
        misc_criterion.add(cls(cls.__order_uuid_selector__(order_uuid)))
        return misc_criterion
