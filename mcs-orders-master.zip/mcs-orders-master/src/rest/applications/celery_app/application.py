from rest.applications.celery_app.bootstrap import Celery
from rest.applications.celery_app.bootstrap import get_celery_application

celery_app: Celery = get_celery_application()
