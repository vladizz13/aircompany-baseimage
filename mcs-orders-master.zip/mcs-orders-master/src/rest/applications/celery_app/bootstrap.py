import os
import sys
import logging
import logging.config
from pathlib import Path
from typing import List

import raven
from raven.contrib.celery import register_signal, register_logger_signal
from celery import Celery as BaseCelery

from libs.utils.tools.logging import get_app_version
from libs.db_gateway.redis.connection_string import RedisConnectionString
from rest.settings.logging import get_logging_settings
from rest.settings import settings
from events.register import register_all
from kombu import Exchange, Queue


__CELERY__APPLICATION__ = None
__IS_CELERY_OBSERVERS_REGISTERED__: bool = False


# Очереди
QUEUES = (
    # Event engine
    Queue('event_engine', Exchange('event_engine'), routing_key='event_engine'),
    # Отложенное сохранение
    Queue('deferred_save', Exchange('deferred_save'), routing_key='deferred_save'),
    # SSR Events Dispatch
    Queue('dispatch_ssr_events', Exchange('dispatch_ssr_events'), routing_key='dispatch_ssr_events')
)
# Маршрутизация задач
TASK_ROUTES = {
    # Event engine
    'rest.applications.celery_app.tasks.celery_tasks.async_event.*': {'queue': 'event_engine'},
    # Отложенное сохранение
    'rest.applications.celery_app.tasks.celery_tasks.deferred_save.*': {'queue': 'deferred_save'},
    # SSR Events
    'rest.applications.celery_app.tasks.celery_tasks.add_ssrs.*': {'queue': 'dispatch_ssr_events'},
}


def register_all_observers():
    global __IS_CELERY_OBSERVERS_REGISTERED__

    if __IS_CELERY_OBSERVERS_REGISTERED__:
        return

    register_all()

    __IS_CELERY_OBSERVERS_REGISTERED__ = True


class Celery(BaseCelery):

    def on_configure(self):

        env = getattr(settings, 'SENTRY_ENVIRONMENT', None) or settings.FLASK_ENV

        logging.config.dictConfig(get_logging_settings(
            settings.SERVICE_NAME,
            settings.DEBUG,
            settings.SENTRY_DSN,
            settings.LOGSTASH_SETTINGS,
            environment=env,
        ))

        if settings.SENTRY_DSN:
            client = raven.Client(
                dsn=settings.SENTRY_DSN,
                environment=env,
                release=get_app_version(),
                site='celery',

                include_paths=[
                    'raven',
                ],
                list_max_length=100,
                string_max_length=4096,
                auto_log_stacks=True,

                processors=(
                    'raven.processors.SanitizePasswordsProcessor',
                ),
            )

            # register a custom filter to filter out duplicate logs
            register_logger_signal(client, loglevel=logging.ERROR)
            # hook into the Celery error handler
            register_signal(client)

        if settings.ELASTIC_APM:
            import elasticapm
            from elasticapm.contrib.celery import register_instrumentation, register_exception_tracking
            elasticapm.instrument()
            apm_client = elasticapm.get_client() or elasticapm.Client(
                service_name=settings.ELASTIC_APM["SERVICE_NAME"],
                server_url=settings.ELASTIC_APM.get("SERVER_URL"),
                environment=settings.ELASTIC_APM.get("ENVIRONMENT") or env,
                secret_token=settings.ELASTIC_APM.get("SECRET_TOKEN"),
            )
            register_instrumentation(apm_client)
            register_exception_tracking(apm_client)


def get_celery_task_paths() -> List[str]:
    result = []
    root_directory = Path(__file__).parent.parent.parent.parent
    tasks_directory = Path(os.path.join(root_directory, 'rest', 'applications', 'celery_app', 'tasks'))
    for item in tasks_directory.rglob('[!_]*.py'):
        relative_path = '.'.join(item.parts[len(root_directory.parts):-1] + (item.stem, ))
        if settings.IS_DEV and relative_path in settings.CELERY_EXCLUDE:
            continue  # Для стейджа возможность отключить задачи
        result.append(relative_path)
    return result


def get_celery_application() -> Celery:
    global __CELERY__APPLICATION__

    if __CELERY__APPLICATION__:
        return __CELERY__APPLICATION__

    cs = RedisConnectionString(**settings.DATABASE["redis"])
    __CELERY__APPLICATION__ = Celery(
        'celery',
        broker=cs.connection_url,
        include=get_celery_task_paths(),
        # Очереди
        task_default_queue='default',
        task_default_exchange_type='direct',
        task_default_routing_key='default',
        task_queues=QUEUES,
        task_routes=TASK_ROUTES,
        task_time_limit=600,
    )

    __CELERY__APPLICATION__.conf.beat_schedule = settings.CELERY_BEAT_SCHEDULE
    __CELERY__APPLICATION__.conf.timezone = 'UTC'
    __CELERY__APPLICATION__.conf.ONCE = {
          'backend': 'celery_once.backends.Redis',
          'settings': {
            'url': cs.connection_url,
            'default_timeout': 60 * 60,
          }
        }
    __CELERY__APPLICATION__.conf.task_always_eager = settings.CELERY_TASK_ALWAYS_EAGER
    # Не регистрируем обработчиков, если запуск из произошел из тестов
    # TODO Грязное решение, исправить если найдется другой способ
    if len(sys.argv) >= 1 and 'nose' in sys.argv[0]:
        __CELERY__APPLICATION__.conf.task_always_eager = True
        return get_celery_application()

    register_all_observers()

    return get_celery_application()
