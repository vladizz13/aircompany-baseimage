from typing import Optional, List, Dict
from domain import DomainOrder
from domain.origin_transaction import DomainOriginTransaction
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from base.exception import ApplicationError
from libs.db_gateway import get_db_gateway
from adapter.sirena_adapter import SirenaInternalAdapter
from celery_once import QueueOnce
from sirena_xml_client.exceptions import (
    SirenaPnrBusyError,
    SirenaPnrAndSurnameDontMatch,
    SirenaMessageTimedOutError,
    SirenaPassengersTitleNotFoundError, BaseSirenaError
)

from rest.applications.celery_app.bootstrap import get_celery_application
from use_cases.orders.exceptions.save import OrderSavingBlockedByAnother
from use_cases.orders.exceptions.update import OrderQueueIsNotEmptyError

celery_app = get_celery_application()


@celery_app.task
def dispatch_add_ssrs_events(order_uuid: str):
    add_service_baggage_task.apply_async((order_uuid, ), countdown=5)
    add_ssr_with_brand_task.apply_async((order_uuid, ), countdown=10)
    add_ssr_when_transporting_animals_task.apply_async((order_uuid, ), countdown=15)
    add_ssr_ckin_status.apply_async((order_uuid,), countdown=20)


def _get_order_by_uuid_helper(order_uuid: str) -> Optional[DomainOrder]:
    order_repo = GenericMongoRepository(
        instance=DomainOrder,
        gateway=get_db_gateway()
    )
    order: Optional[DomainOrder] = order_repo.get_single(
        spec=OrdersQueryBuilder.get_by_order_uuid(order_uuid)
    )
    return order


@celery_app.task(bind=True, max_retries=2, base=QueueOnce, once={'keys': ['order_uuid'], 'graceful': True})
def add_service_baggage_task(self, order_uuid: str):
    """
    Добавление заказу услуги O6O, если требуется
    """
    from repositories.mongo.mongo_generic_repository import GenericMongoRepository
    from use_cases.orders.events.add_service_baggage.add_service_baggage_use_case import AddServiceBaggageUseCase
    from use_cases.orders.events.add_service_baggage.add_service_baggage_request import AddServiceBaggageRequest
    from adapter.sirena_adapter import SirenaInternalAdapter
    from rest.interfaces.internal_order_adapter import InternalOrderAdapter
    from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue
    from rest.applications.celery_app.tasks.send_message import send_telegram_message

    order = _get_order_by_uuid_helper(order_uuid)
    if not order:
        return

    request: AddServiceBaggageRequest = AddServiceBaggageRequest(
        order=order
    )
    use_case = AddServiceBaggageUseCase(
        transaction_repo=GenericMongoRepository(
            gateway=get_db_gateway(),
            instance=DomainOriginTransaction
        ),
        save_queue=SaveOrdersQueue(
            gateway=get_db_gateway(label='redis'),
        ),
        internal_order_adapter=InternalOrderAdapter,
        sirena_adapter=SirenaInternalAdapter(),
        send_message_func=send_telegram_message
    )
    try:
        res = use_case.execute(request=request)
        if not bool(res) and all([
            res.errors[0].inner_exception,
            isinstance(res.errors[0].inner_exception, SirenaPnrBusyError)
        ]):
            raise self.retry(exc=res.errors[0].inner_exception, countdown=60 * 4)
    except (ApplicationError, IndexError):
        # Всё логируется в юзкейсе, здесь ничего не делаем
        pass


@celery_app.task(bind=True, base=QueueOnce, once={'keys': ['order_uuid'], 'graceful': True})
def add_ssr_with_brand_task(self, order_uuid: str):
    """
    Во все заказы, вылетающие из городов, где нет Астры (сейчас это Стамбул и Занзибар)
    добавляет SSR с указанием бренда
    """
    from use_cases.orders.events.ssrs.brand.brand_request import BrandSsrRequest
    from use_cases.orders.events.ssrs.brand.brand_usecase import BrandSsrUseCase

    order = _get_order_by_uuid_helper(order_uuid)
    if not order:
        return

    request: BrandSsrRequest = BrandSsrRequest(order=order)
    use_case: BrandSsrUseCase = BrandSsrUseCase()
    try:
        res = use_case.execute(request=request)
        if res.value and not res.has_errors():
            add_ssr.apply_async(
                (res.value["order_uuid"], res.value["rloc"], res.value["last_name"], res.value["ssrs"]),
            )
    except (ApplicationError, IndexError):
        # Всё логируется в юзкейсе, здесь ничего не делаем
        pass


@celery_app.task(bind=True, base=QueueOnce, once={'keys': ['order_uuid'], 'graceful': True})
def add_ssr_when_transporting_animals_task(self, order_uuid: str):
    """
    Добавляет SSR "ЖВТК"/"ЖВТБ" при продаже услуг перевозки животных
    """

    from use_cases.orders.events.ssrs.petc_avih.request import AddAnimalsSSRRequest
    from use_cases.orders.events.ssrs.petc_avih.usecase import AddAnimalsSSRUseCase

    order = _get_order_by_uuid_helper(order_uuid)
    if not order:
        return

    request: AddAnimalsSSRRequest = AddAnimalsSSRRequest(order=order)
    use_case: AddAnimalsSSRUseCase = AddAnimalsSSRUseCase()
    try:
        res = use_case.execute(request=request)
        if res.value and not res.has_errors():
            add_ssr.apply_async(
                (res.value["order_uuid"], res.value["rloc"], res.value["last_name"], res.value["ssrs"]),
            )
    except (ApplicationError, IndexError):
        # Всё логируется в юзкейсе, здесь ничего не делаем
        pass


@celery_app.task(bind=True, base=QueueOnce, once={'keys': ['order_uuid'], 'graceful': True})
def add_ssr_ckin_status(self, order_uuid: str):
    """
    SSR "CKIN" коммерчески важный пассажир
    """

    from use_cases.orders.events.ssrs.ckin.request import CkinSsrRequest
    from use_cases.orders.events.ssrs.ckin.usecase import CkinSsrUseCase
    from adapter.sirena_adapter import SirenaInternalAdapter

    order = _get_order_by_uuid_helper(order_uuid)

    if not order:
        return

    request: CkinSsrRequest = CkinSsrRequest(order=order)
    use_case: CkinSsrUseCase = CkinSsrUseCase(
        sirena_adapter=SirenaInternalAdapter()
    )
    try:
        res = use_case.execute(request=request)
        if res.value and not res.has_errors():
            add_ssr.apply_async(
                (res.value["order_uuid"], res.value["rloc"], res.value["last_name"], res.value["ssrs"]),
            )
    except (ApplicationError, IndexError):
        # Всё логируется в юзкейсе, здесь ничего не делаем
        pass


@celery_app.task(bind=True, base=QueueOnce, once={'keys': ['order_uuid'], 'graceful': True})
def add_ssr_vzr(self, order_uuid: str, passengers: List[Dict]):

    from use_cases.orders.events.ssrs.vzr.vzr_request import VzrSsrRequest
    from use_cases.orders.events.ssrs.vzr.vzr_usecase import VzrSsrUseCase

    order = _get_order_by_uuid_helper(order_uuid)

    if not order:
        return

    request: VzrSsrRequest = VzrSsrRequest(order=order, passengers=passengers)
    use_case: VzrSsrUseCase = VzrSsrUseCase()
    try:
        res = use_case.execute(request=request)
        if res.value and not res.has_errors():
            add_ssr.apply_async(
                (res.value["order_uuid"], res.value["rloc"], res.value["last_name"], res.value["ssrs"]),
            )
    except (ApplicationError, IndexError):
        pass


@celery_app.task(
    bind=True,
    max_retries=2,
    base=QueueOnce,
    once={'keys': ['flight_number', 'departure_time'], 'graceful': True}
)
def degr_ssrs_get_price(self, flight_number: str, departure_time: int):
    """
    Получить стоимость заказа
    """
    from use_cases.orders.events.ssrs.degr.usecase import DegrSsrGetTotalPriceUseCase
    from use_cases.orders.events.ssrs.degr.request import DegrGetPriceRequest
    from rest.interfaces.internal_order_adapter import InternalOrderAdapter
    from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter

    request: DegrGetPriceRequest = DegrGetPriceRequest(flight_number=flight_number, departure_time=departure_time)
    use_case: DegrSsrGetTotalPriceUseCase = DegrSsrGetTotalPriceUseCase(
        redis_adapter=RedisSsrsAdapter(
            gateway=get_db_gateway('redis')
        ),
        internal_order_adapter=InternalOrderAdapter,
    )
    try:
        res = use_case.execute(request=request)
        if res.has_errors() and self.request.retries < self.max_retries:
            raise self.retry(exc=res.errors[0].inner_exception, countdown=60 * 4)

        degr_ssrs_send.apply_async(
            (request.flight_number, departure_time)
        )

    except (ApplicationError, IndexError):
        pass


@celery_app.task(bind=True)
def degr_ssrs_send(self, flight_number: str, departure_time: int):
    """
    Отправить сср с типом DEGR.
    """
    from use_cases.orders.events.ssrs.degr.usecase import DegrSendSsrsUseCase
    from use_cases.orders.events.ssrs.degr.request import DegrSendSsrsUseCaseRequest
    from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter

    request: DegrSendSsrsUseCaseRequest = DegrSendSsrsUseCaseRequest(
        flight_number=flight_number, departure_time=departure_time
    )
    try:
        send_ssrs_use_case: DegrSendSsrsUseCase = DegrSendSsrsUseCase(
            redis_adapter=RedisSsrsAdapter(
                gateway=get_db_gateway('redis')
            ),
            sirena_adapter=SirenaInternalAdapter(),
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            )
        )
        res = send_ssrs_use_case.execute(request=request)
        if not bool(res) and all([
            res.errors[0].inner_exception,
            isinstance(res.errors[0].inner_exception, (SirenaPnrBusyError, SirenaMessageTimedOutError))
        ]):
            raise self.retry(exc=res.errors[0].inner_exception, countdown=30)
    except (ApplicationError, IndexError):
        pass


@celery_app.task(
    bind=True,
    max_retries=2,
    base=QueueOnce,
    once={'keys': ['flight_number', 'departure_time'], 'graceful': True}
)
def pdts_ssrs_get_price(self, flight_number: str, departure_time: int):
    """
    Получить стоимость заказа
    """
    from use_cases.orders.events.ssrs.pdts.usecase import PdtsSsrGetTotalPriceUseCase
    from use_cases.orders.events.ssrs.pdts.request import PdtsGetPriceRequest
    from rest.interfaces.internal_order_adapter import InternalOrderAdapter
    from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter

    request: PdtsGetPriceRequest = PdtsGetPriceRequest(flight_number=flight_number, departure_time=departure_time)
    use_case: PdtsSsrGetTotalPriceUseCase = PdtsSsrGetTotalPriceUseCase(
        redis_adapter=RedisSsrsAdapter(
            gateway=get_db_gateway('redis')
        ),
        internal_order_adapter=InternalOrderAdapter,
    )
    try:
        res = use_case.execute(request=request)
        if res.has_errors() and self.request.retries < self.max_retries:
            raise self.retry(exc=res.errors[0].inner_exception, countdown=60 * 4)

        pdts_ssrs_send.apply_async(
            (request.flight_number, departure_time)
        )

    except (ApplicationError, IndexError):
        pass


@celery_app.task(bind=True)
def pdts_ssrs_send(self, flight_number: str, departure_time: int):
    """
    Отправить сср с типом PDTS.
    """
    from use_cases.orders.events.ssrs.pdts.usecase import PdtsSendSsrsUseCase
    from use_cases.orders.events.ssrs.pdts.request import PdtsSendSsrsUseCaseRequest
    from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter

    request: PdtsSendSsrsUseCaseRequest = PdtsSendSsrsUseCaseRequest(
        flight_number=flight_number, departure_time=departure_time
    )
    try:
        send_ssrs_use_case: PdtsSendSsrsUseCase = PdtsSendSsrsUseCase(
            redis_adapter=RedisSsrsAdapter(
                gateway=get_db_gateway('redis')
            ),
            sirena_adapter=SirenaInternalAdapter(),
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            )
        )
        res = send_ssrs_use_case.execute(request=request)
        if not bool(res) and all([
            res.errors[0].inner_exception,
            isinstance(res.errors[0].inner_exception, BaseSirenaError)
        ]):
            raise self.retry(exc=res.errors[0].inner_exception, countdown=60)
    except (ApplicationError, IndexError):
        pass


@celery_app.task(
    bind=True,
    autoretry_for=(SirenaPnrBusyError, SirenaMessageTimedOutError, ),
    max_retries=2,
    retry_backoff=5,
    retry_backoff_max=60 * 4,
    retry_jitter=True,
)
def add_ssr(self, order_uuid: str, rloc: str, last_name: str, ssrs: List[Dict]):
    """
    Отправка ssr в сирену
    """
    from rest.interfaces.internal_order_adapter import InternalOrderAdapter
    from use_cases.orders.events.ssrs.exception_handler.add_ssr_exception_handler_request import (
        ExceptionHandlerRequest
    )
    from use_cases.orders.events.ssrs.exception_handler.add_ssr_exception_handlers import (
        OrderQueueIsNotEmptyErrorHandler,
        SirenaPassengersTitleNotFoundErrorHandler
    )

    exception_handler_request = ExceptionHandlerRequest(
        order_uuid=order_uuid,
        rloc=rloc,
        last_name=last_name,
        ssrs=ssrs,
    )

    try:
        sirena = SirenaInternalAdapter()
        sirena.add_ssr_to_order(
            rloc=rloc,
            last_name=last_name,
            ssrs=ssrs
        )
        # принудительное обновление заказа
        adapter = InternalOrderAdapter()
        adapter.update_from_sirena_grs(order_uuid)
    except (OrderQueueIsNotEmptyError, OrderSavingBlockedByAnother):
        use_case = OrderQueueIsNotEmptyErrorHandler()
        use_case.execute(request=exception_handler_request)
    except (SirenaPnrAndSurnameDontMatch, SirenaPassengersTitleNotFoundError) as e:
        use_case = SirenaPassengersTitleNotFoundErrorHandler()
        res = use_case.execute(request=exception_handler_request)
        if res.value:
            raise self.retry(
                (res.value.order_uuid, res.value.rloc, res.value.last_name, res.value.ssrs),
                max_retries=1,
                countdown=60 * 4,
                exc=e
            )
    except ApplicationError:
        pass
