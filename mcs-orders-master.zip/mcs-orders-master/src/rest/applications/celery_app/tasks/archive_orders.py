import time
from rest.applications.celery_app.bootstrap import get_celery_application
import logging
from rest.interfaces.internal_order_adapter import InternalOrderAdapter

logger = logging.getLogger('archive_orders')

celery_app = get_celery_application()


@celery_app.task
def archive_orders_job():
    """
    Архивируем заказы (переводим в статус X)
    Если нет билетов и оплаты и купонов
    """
    adapter = InternalOrderAdapter()
    adapter.archive_orders(int(time.time()))
