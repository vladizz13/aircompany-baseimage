import json
from event_engine import get_event_manager
from rest.applications.celery_app.bootstrap import get_celery_application
from libs.db_gateway import get_db_gateway

celery_app = get_celery_application()


@celery_app.task
def event_manager_handle(event_json):
    event_manager = get_event_manager(get_db_gateway())
    event = event_manager.deserialize_event(json.loads(event_json))
    event_manager.raise_event(event)
