'''Аудит API'''
import logging

from rest.applications.celery_app.bootstrap import get_celery_application

requests_logger = logging.getLogger('http-requests')
celery_app = get_celery_application()


@celery_app.task
def save_audit_info(message: str, extra: dict):
    """
    Сохранить данные аудита в Logstash
    """
    requests_logger.info(message, extra=extra)
