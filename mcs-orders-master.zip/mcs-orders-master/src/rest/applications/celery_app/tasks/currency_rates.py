import logging
from datetime import datetime

import requests

from adapter.sirena_adapter import SirenaInternalAdapter
from domain.currency_rates import DomainCurrencyRates
from libs.db_gateway import get_db_gateway
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.applications.celery_app.bootstrap import get_celery_application
from rest.settings import settings

logger = logging.getLogger('celery_currency_rates_update')


celery_app = get_celery_application()


@celery_app.task(bind=True, max_retries=5)
def download_actual_currency_rates(self):
    """
    Периодическая задача, которая загружает файл с данными по курсам валют.
    Должна запускаться один раз в день в 00:00 utc.
    """
    try:
        response = requests.get('{host}/api/latest.json?app_id={app_id}'.format(
            host=settings.CURRENCY_RATES_SETTINGS.get('HOST'),
            app_id=settings.CURRENCY_RATES_SETTINGS.get('APP_ID')
        ))
        data = response.json()

        timestamp = data.get('timestamp')
        data.update({'timestamp': datetime.fromtimestamp(timestamp)})

        # TODO: Запрашивать адекватный курс NUC к USD (из Сирены приходят странные данные)
        sirena_adapter = SirenaInternalAdapter()
        nuc_dollar = sirena_adapter.get_currency_rates("NUC", "USD")
        data['rates'].update({'NUC': int(nuc_dollar[0]['text']) / int(nuc_dollar[1]['text'])})

        currency_rate = DomainCurrencyRates.deserialize(data)

        currency_repo = GenericMongoRepository(
            instance=DomainCurrencyRates,
            gateway=get_db_gateway()
        )

        currency_repo.create(currency_rate)

    except (requests.ConnectTimeout, requests.ConnectionError) as exc:
        logger.warning(str(exc))
        raise self.retry(exc=exc, countdown=60)
