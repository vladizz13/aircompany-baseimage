from typing import List
from libs.redis_queues.list_queue import AlreadyLockedError
from rest.applications.celery_app.bootstrap import get_celery_application
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue
from use_cases.orders.save.deferred_save.deferred_save_order_use_case import DeferredSaveOrderUseCase
from use_cases.orders.search.libs.rloc_transliteration import RlocTransliteration
from domain.pd_changes import DomainPDChanges
from libs.db_gateway import get_db_gateway
from rest.settings import settings
import logging
from domain import DomainOrder
from domain.prorate import DomainProrate
from domain.currency_rates import DomainCurrencyRates
from domain.origin_transaction import DomainOriginTransaction
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.save.utils.currency_rates import CurrencyRates
from use_cases.orders.save.deferred_save.deferred_save_order_request import DeferredSaveOrderRequest
from use_cases.orders.events.retranslation.send_to_monoapp_use_case import SendOrderToMonoAppUseCase
from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

logger = logging.getLogger('deferred_order_save')

celery_app = get_celery_application()


@celery_app.task
def deferred_save_job():
    """
    Собираем стоящие в очереди заказы и отправляем каждый из них на сохранение
    """
    if not settings.ENABLE_DEFERRED_SAVE:
        return
    save_queue = SaveOrdersQueue(
        gateway=get_db_gateway(label='redis')
    )
    for queue_key in save_queue.get_active_orders(max_queues_to_return=250):
        deferred_save_task.delay(queue_key)


@celery_app.task
def deferred_save_task(queue_key: str):
    """
    Таска отложенного сохранения заказа
    Берем заказ из очереди по его ключу сохраняем заказы по порядку

    пример очередей в редисе:

    56) "queue-7BMV3X/1H"                   # Очередь ждет своего часа [внутри смапленные заказы, готовые к десериализ]
    57) "lock-6XZ41S/1H"                    # Очередь разбирается, заблокирована [внутри пусто, это просто плейсхолдер]
    ...
    63) "mono_app_retranslation-6XZ41S/1H"  # Заказ заблокирован для ретрансляции [внутри пусто, .. ]


    """

    if not settings.ENABLE_DEFERRED_SAVE:
        return

    save_queue = SaveOrdersQueue(
        gateway=get_db_gateway(label='redis')
    )

    mongo_gateway = get_db_gateway()

    use_case = DeferredSaveOrderUseCase(
        order_repo=GenericMongoRepository(
            gateway=mongo_gateway,
            instance=DomainOrder
        ),
        prorate_repo=GenericMongoRepository(
            gateway=mongo_gateway,
            instance=DomainProrate
        ),
        origin_transactions_repo=GenericMongoRepository(
            gateway=mongo_gateway,
            instance=DomainOriginTransaction
        ),
        currency_adapter=CurrencyRates(
            currency_repo=GenericMongoRepository(
                gateway=mongo_gateway,
                instance=DomainCurrencyRates
            )
        ),
        mono_app_adapter=MonoAppAdapter(),
        sirena_adapter=SirenaInternalAdapter(),
        rloc_transliteration=RlocTransliteration(),
        change_pd_repo=GenericMongoRepository(
            gateway=mongo_gateway,
            instance=DomainPDChanges
        ),
        redis=save_queue.get_gateway()
    )

    try:
        # Ставим лок на очередь, чтоб разбор не запустился еще раз из deferred_save_job()
        with save_queue.lock(queue_key):
            mono_app_retranslation_lock_key: str = SendOrderToMonoAppUseCase.get_retranslation_lock_key(queue_key)
            orders_to_save: List[DeferredSaveOrderRequest] = save_queue.get_save_queue(queue_key)
            total_orders: int = len(orders_to_save)
            # Ставим лок на ретрансляцию в моноапп, во время лока заказ не будет отправлен в моноапп
            with save_queue.lock(mono_app_retranslation_lock_key, custom_key=True):
                for idx, request in enumerate(orders_to_save, start=1):

                    if total_orders - idx <= 0:
                        # Снимаем лок на отправку в моноапп если сохраняем последний заказ из очереди
                        save_queue.unlock(mono_app_retranslation_lock_key, custom_key=True)

                    try:
                        use_case.execute(request=request)
                    except Exception as e:
                        logger.warning("Не удалось сохранить заказ, пропускаем: {}".format(e))

    except AlreadyLockedError as e:
        logger.warning(str(e))
