import logging

from celery.exceptions import MaxRetriesExceededError

from rest.applications.celery_app.bootstrap import get_celery_application
from rest.interfaces.internal_exchange_order_adapter import InternalExchangeOrderAdapter

celery_app = get_celery_application()
logstash_logger = logging.getLogger('exchange_logger')

WAIT_EMD_COUNTDOWN = 60 * 8
EXPIRES_7_MIN = 60 * 7
EXPIRES_3_DAYS = 60 * 60 * 24 * 3
DELAY_30_SEC = 30
DELAY_10_MIN = 60 * 10


@celery_app.task(bind=True, default_retry_delay=DELAY_30_SEC, max_retries=14)
def wait_emd_fast_task(self, exchange_uuid: str, exchange_pricing_response: dict):
    """
    Ждем билеты примерно 7 минут. Если не дождались, запускаем wait_emd_long_task
    """
    logstash_logger.info(f'Run {self.name}: {exchange_uuid}')
    try:
        return InternalExchangeOrderAdapter.wait_emd(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
    except Exception as ex:
        logstash_logger.warning(f'Retry {self.name} {exchange_uuid} ({type(ex)})')

    try:
        self.retry()
    except MaxRetriesExceededError:
        wait_emd_long_task.delay(exchange_uuid, exchange_pricing_response)
        InternalExchangeOrderAdapter.send_error_wait_emd(exchange_uuid=exchange_uuid)


@celery_app.task(bind=True, default_retry_delay=DELAY_10_MIN, expires=EXPIRES_3_DAYS, max_retries=450)
def wait_emd_long_task(self, exchange_uuid: str, exchange_pricing_response: dict):
    """
    Раз в 10 минут проверяем наличие emd
    """
    logstash_logger.info(f'Run {self.name}: {exchange_uuid}')
    try:
        return InternalExchangeOrderAdapter.wait_emd(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
    except Exception as ex:
        logstash_logger.warning(f'Retry {self.name} {exchange_uuid} ({type(ex)})')
        self.retry()


@celery_app.task(bind=True, default_retry_delay=DELAY_30_SEC, max_retries=3)
def payments_confirm_fast_task(self, exchange_uuid: str, exchange_pricing_response: dict):
    """
    Подтверждаем платеж до 3-х раз. Если не удалось, запускаем payments_confirm_long_task
    """
    logstash_logger.info(f'Run {self.name}: {exchange_uuid}')
    try:
        return InternalExchangeOrderAdapter.payments_confirm(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
    except Exception as ex:
        logstash_logger.warning(f'Retry {self.name} {exchange_uuid} ({type(ex)})')

    try:
        self.retry()
    except MaxRetriesExceededError:
        InternalExchangeOrderAdapter.send_error_payment_confirm(exchange_uuid=exchange_uuid)
        payments_confirm_long_task.delay(exchange_uuid, exchange_pricing_response)


@celery_app.task(bind=True, default_retry_delay=DELAY_10_MIN, expires=EXPIRES_3_DAYS, max_retries=450)
def payments_confirm_long_task(self, exchange_uuid: str, exchange_pricing_response: dict):
    """
    Ждем до 3-х дней когда подтвердится платеж
    """
    logstash_logger.info(f'Run {self.name}: {exchange_uuid}')
    try:
        return InternalExchangeOrderAdapter.payments_confirm(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
    except Exception as ex:
        logstash_logger.warning(f'Retry {self.name} {exchange_uuid} ({type(ex)})')
    self.retry()
