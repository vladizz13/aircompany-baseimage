from rest.applications.celery_app.bootstrap import get_celery_application
import logging
from rest.interfaces.internal_order_adapter import InternalOrderAdapter

logger = logging.getLogger('load_modified_orders')

celery_app = get_celery_application()


@celery_app.task
def load_modified_orders_task():
    """
    Загрузка измененных заказов из сирены
    """
    adapter = InternalOrderAdapter()
    adapter.load_modified_orders(hours_offset=2)
