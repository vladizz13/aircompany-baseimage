import logging
from uuid import uuid4
from time import time
from typing import Dict

from base.exception import ApplicationError
from domain.types import TransactionSource
from rest.interfaces.external_order_adapter import InternalOrderAdapter
from adapter.tais_adapter import TaisInternalAdapter
from rest.applications.celery_app.bootstrap import get_celery_application

celery_app = get_celery_application()
logger = logging.getLogger("taisCeleryDeferredTasks")


@celery_app.task
def save_from_tais(order_id: str):
    """
    Сохранение транзакции от таиса в /api/v2/system/transaction/
    """
    interface: InternalOrderAdapter = InternalOrderAdapter()
    tais_adapter: TaisInternalAdapter = TaisInternalAdapter()
    order_body: Dict = tais_adapter.search_order(order_id=order_id)

    if not order_body:
        return

    interface.save(
        raw_order=order_body,
        message_id=str(uuid4()),
        received=time(),
        provider=TransactionSource.TAIS.value,
        deferred_save=True
    )


@celery_app.task
def update_order_from_booking_cart(cart_data: dict):
    """
    Обновление / синк заказа с корзиной из букинга
    Если заказ имеется в базе: Обогащение заказа данными корзины букинга
    Если заказ не найден: Сохранение заказа по order_id из корзины и обогащение данными корзины
    :param cart_data: Данные корзины
    :return:
    """
    interface: InternalOrderAdapter = InternalOrderAdapter()
    try:
        interface.update_from_booking_cart(cart_data=cart_data)
    except ApplicationError as e:
        logging.info(f"Failed to sync booking cart, reason: {e.message}")
