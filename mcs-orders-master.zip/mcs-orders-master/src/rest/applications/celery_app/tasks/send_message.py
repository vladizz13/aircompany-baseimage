"""Отправка сообщения в мессенджеры"""
from rest.applications.celery_app.bootstrap import get_celery_application
from rest.settings.settings import TELEGRAM_CONFIG
from libs.messages.telegram import TelegramMessenger

celery_app = get_celery_application()


@celery_app.task
def send_telegram_message(message: str, chat_id: int = None):
    """
    Отправить сообщение в телеграмм
    :param message:
    :param chat_id:
    :return:
    """
    messenger = TelegramMessenger(**TELEGRAM_CONFIG)
    messenger.send_message(message=message, chat_id=chat_id)
