from rest.applications.celery_app.bootstrap import get_celery_application
from rest.interfaces.internal_ssr_adapter import InternalSsrAdapter


celery_app = get_celery_application()


@celery_app.task(bind=True)
def disabled_passengers(self):
    """
    Задача, которая запускается в celery beat раз в 30 минут
    """
    interface = InternalSsrAdapter()
    interface.process_passengers_with_special_service()


@celery_app.task(bind=True)
def confirmed_service(self, order_uuid: str):
    """
    Флоу работы с ссрами в статусе HK (подтвержденная услуга)
    """
    interface = InternalSsrAdapter()
    interface.process_confirmed_special_services(order_uuid=order_uuid)


@celery_app.task(bind=True)
def canceled_service(self, order_uuid: str):
    """
    Флоу работы с ссрами в статусе UN (отмененная услуга)
    """
    interface = InternalSsrAdapter()
    interface.process_canceled_special_services(order_uuid=order_uuid)


@celery_app.task(bind=True)
def requested_service(self, order_uuid: str):
    """
    Флоу работы с ссрами в статусе HN (услуга находится в обработке)
    """
    interface = InternalSsrAdapter()
    interface.process_requested_special_services(order_uuid=order_uuid)
