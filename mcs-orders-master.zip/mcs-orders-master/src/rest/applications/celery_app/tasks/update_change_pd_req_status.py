"""Проверка статуса платежа"""
import logging

from pymongo.database import Database

from adapter.monoapp import MonoAppAdapter
from domain.pd_changes import DomainPDChanges
from libs.db_gateway import get_db_gateway
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.applications.celery_app.bootstrap import get_celery_application

logger = logging.getLogger("CeleryChangePDSentinel")

celery_app = get_celery_application()


@celery_app.task(bind=True, max_retries=5)
def update_payment_status(self, payment_id):
    """
    Проверяет и, при необходимости, обновляет статус заявки на изменение п.д.
    :param self:
    :param payment_id:
    :return:
    """
    mongodb: Database = get_db_gateway()

    from use_cases.orders.user.change_personal_data.submit_request.request import UpdateChangePDReqStatusObj
    from use_cases.orders.user.change_personal_data.submit_request.update_status_use_case import (
        UpdateChangePDReqStatusUseCase,
    )
    from rest.interfaces.internal_order_adapter import InternalOrderAdapter
    from adapter.sirena_adapter import SirenaInternalAdapter

    req_obj: UpdateChangePDReqStatusObj = UpdateChangePDReqStatusObj(payment_id)
    use_case: UpdateChangePDReqStatusUseCase = UpdateChangePDReqStatusUseCase(
        pd_changes_repo=GenericMongoRepository(gateway=mongodb, instance=DomainPDChanges),
        mono_app_adapter=MonoAppAdapter(),
        sirena_adapter=SirenaInternalAdapter(),
        internal_order_adapter=InternalOrderAdapter
    )

    try:
        res = use_case.execute(request=req_obj)
        if not bool(res):
            raise res.errors[0]
    except Exception as err:
        logger.exception(
            f'{payment_id} - Не удалось проверить статус операции по услуге изменения перс. данных: {err}'
        )
        raise self.retry(exc=err, countdown=60)
