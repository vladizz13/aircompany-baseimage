from base.exception import ApplicationError
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.applications.celery_app.bootstrap import get_celery_application

from use_cases.orders.exceptions.update import (
    SirenaGRSOrderNotFoundError,
    UnableToUpdateUnpayedOrder,
    OrderNotFoundError
)
from use_cases.orders.exceptions.save import (
    UnableToMapOrderError,
    UnableToMergeOrderError,
    UnableToExpandOrderError,
    UnableToNormalizeOrderError,
    UnableToValidateOrderError,
    UnableToDeserializeOrderModelError,
    UnableToProcessSirenaGRSEdgeCase
)

celery_app = get_celery_application()


@celery_app.task(bind=True, max_retries=2)
def update_from_sirena_grs(self, order_uuid: str, deferred: bool = True):
    """
    Обновление заказа из сирены
    """
    errors_to_skip = (
        SirenaGRSOrderNotFoundError,
        UnableToUpdateUnpayedOrder,
        OrderNotFoundError,

        UnableToMapOrderError,
        UnableToMergeOrderError,
        UnableToExpandOrderError,
        UnableToNormalizeOrderError,
        UnableToValidateOrderError,
        UnableToDeserializeOrderModelError,
        UnableToProcessSirenaGRSEdgeCase
    )

    try:
        res = InternalOrderAdapter().update_from_sirena_grs(order_uuid, deferred=deferred, skip_alien_gds=True)
        if bool(res):
            return

        error: ApplicationError = res.errors[0]
        if isinstance(error, errors_to_skip):
            return

        raise self.retry(exc=error, countdown=60 * 30)

    except ApplicationError as e:
        if isinstance(e, errors_to_skip):
            return
        raise self.retry(exc=e, countdown=60 * 30)
