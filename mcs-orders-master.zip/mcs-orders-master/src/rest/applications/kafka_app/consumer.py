from rest.settings import settings # noqa
from logging import getLogger
from event_engine import get_event_manager
from rest.applications.celery_app.tasks.async_event import event_manager_handle
from events.register import register_all
from event_engine import run_kafka_broadcast_consumer
from libs.db_gateway import get_db_gateway
from rest.settings.settings import KAFKA_CONFIG
from event_engine import KafkaConfig


if __name__ == '__main__':
    kafka_config = KafkaConfig(**KAFKA_CONFIG)
    kafka_config.set_project_root(settings.PROJECT_ROOT)
    run_kafka_broadcast_consumer(
        config=kafka_config,
        event_manager=get_event_manager(
            db_gateway=get_db_gateway(),
            redis_gateway=get_db_gateway('redis')
        ),
        register_observer_func=register_all,
        async_raise=True,
        manager_async_task=event_manager_handle,
        logger=getLogger('kafka::consumer')
    )
