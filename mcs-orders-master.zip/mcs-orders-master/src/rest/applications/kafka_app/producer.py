"""
Event publication
"""
from rest.settings import settings # noqa
from logging import getLogger
from libs.db_gateway import get_db_gateway
from event_engine import run_kafka_broadcast
from rest.settings.settings import KAFKA_CONFIG
from event_engine import KafkaConfig


if __name__ == '__main__':
    kafka_config = KafkaConfig(**KAFKA_CONFIG)
    kafka_config.set_project_root(settings.PROJECT_ROOT)
    run_kafka_broadcast(
        config=kafka_config,
        logger=getLogger('kafka::producer'),
        redis_gateway=get_db_gateway('redis')
    )
