"""
Джоб для прослушивания очереди транзакций сирены
"""
from rest.settings import settings # noqa SetupLogging
import argparse
import logging
from rest.applications.rmq_listener.sirena.sirena_listener import SirenaRmqListener, AvailableQueues


if __name__ == '__main__':
    """
    v2:
        vhost=CRM
        queue=crm.ut.pnr.v2
    v5:
        vhost=LEONARDO
        queue=leout_airline_ut_pnr
    """

    parser = argparse.ArgumentParser(description=(
        'Слушает RMQ очередь заказов Сирены'
    ))

    parser.add_argument(
        '--logging',
        help='Logging level (info, error or debug)',
        default='info',
    )
    parser.add_argument(
        '--queue',
        help='RabbitMQ queue to connect',
        default="V1"
    )

    parsed_args = parser.parse_args()
    listener = SirenaRmqListener(
        queue=AvailableQueues[parsed_args.queue]
    )

    # Log lever settings
    if parsed_args.logging == 'error':
        listener.logger.setLevel(logging.ERROR)
    elif parsed_args.logging == 'info':
        listener.logger.setLevel(logging.INFO)
    elif parsed_args.logging == 'debug':
        listener.logger.setLevel(logging.DEBUG)

    listener.connect_to_queue()
