import pika
import logging
import json
import uuid
import time
import ssl

from base.exception import ApplicationError

from typing import Type, Dict
from enum import Enum

from libs.rmq_listener import BaseResponseDecoder, BaseRmqClient, JsonResponseDecoder
from libs.profiler import Profiler

from domain.types import TransactionSource
from domain.origin_transaction import DomainOriginTransaction
from libs.db_gateway import get_db_gateway
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.settings import settings

from rest.interfaces.internal_order_adapter import InternalOrderAdapter


class AvailableQueues(str, Enum):
    V1 = "crm.ut.pnr.v2"
    V2 = "leout_airline_ut_pnr"


class AvailableVhosts(str, Enum):
    V1 = "CRM"
    V2 = "LEONARDO"


class SirenaRmqClient(BaseRmqClient):

    connection_url: str = None
    logger = logging.getLogger('sirena.rmq.client')

    def __init__(
        self,
        host: str,
        port: int,
        login: str,
        password: str,
        vhost: str,
        decoder: Type[BaseResponseDecoder],
    ):
        self.connection_params = pika.ConnectionParameters(
            host=host,
            port=port,
            virtual_host=vhost,
            credentials=pika.PlainCredentials(
                username=login,
                password=password
            ),
            heartbeat=30,
            ssl_options=pika.SSLOptions(context=ssl.SSLContext())
        )

        self.decoder = decoder

        self.logger.info(f'Connection params initialized: {str(self.connection_params)}')

    def start_listening(self, on_message, queue):
        """Инициализирует подключение к очереди и декорирует on_message callback"""
        self.logger.info('Preparing connection')

        connection = pika.BlockingConnection(self.connection_params)
        channel = connection.channel()
        decorated_on_message = SirenaRmqClient.on_message_decorator(
            on_message=on_message, decoder=self.decoder,
        )
        channel.basic_consume(
            on_message_callback=decorated_on_message,
            queue=queue
        )

        try:
            self.logger.info('Start consuming queue')
            channel.start_consuming()
        except Exception as ex:
            channel.stop_consuming()
            raise ex
        finally:
            connection.close()
            self.logger.info("Connection closed")

    @staticmethod
    def on_message_decorator(on_message, decoder):
        """Декоратор callback on_message. Добавляет профайлинг и отправку ack"""
        def decorated_on_message(channel, method_frame, header_frame, body):
            timing = Profiler('rmq.package.process')
            timing.add('start')
            SirenaRmqClient.logger.debug('Raw message: {}'.format(body))
            data = decoder.decode(body)
            timing.add('parse_body')
            channel.basic_ack(delivery_tag=method_frame.delivery_tag)
            timing.add('send_ack')
            on_message(data)
            timing.add('package_processing')
            profiling_message = timing.make_message()
            SirenaRmqClient.logger.debug(profiling_message)

        return decorated_on_message


class SirenaRmqListener(object):
    RETRIES_LIMIT = 10
    logger = logging.getLogger('sirena.rmq.transactions.listener')

    def __init__(self, queue: AvailableQueues):
        self.queue = queue
        self.vhost = self.get_vhost_by_queue(self.queue)
        self.client = SirenaRmqClient(
            vhost=self.vhost.value,
            decoder=JsonResponseDecoder,
            **settings.SIRENA_RMQ
        )
        self.transaction_repo = GenericMongoRepository(
            gateway=get_db_gateway(),
            instance=DomainOriginTransaction
        )

    @staticmethod
    def get_vhost_by_queue(queue: AvailableQueues) -> AvailableVhosts:
        _map = {
            AvailableQueues.V1: AvailableVhosts.V1,
            AvailableQueues.V2: AvailableVhosts.V2
        }
        return _map[queue]

    def process_message(self, transaction: Dict):
        """
        Callback который вызывается при получении очередного сообщения из очереди Сирены
        """
        queue_switch = {
            AvailableQueues.V1: self.process_v1_queue,
            AvailableQueues.V2: self.process_v2_queue,
        }
        queue_switch[self.queue](transaction=transaction)

    def connect_to_queue(self):
        """
        Инициализирует подключение к очереди Сирены
        """
        retries_count = 0
        while retries_count < self.RETRIES_LIMIT:
            retries_count += 1
            try:
                self.logger.info("===== Rmq Sirena listener started ======")
                self.logger.info(f"===== Rmq Sirena listener: queue {self.queue.value} ======")
                self.client.start_listening(
                    self.process_message,
                    queue=str(self.queue.value)
                )
            except KeyboardInterrupt:
                self.logger.info("Manually disconnected from sirena RMQ - {}".format(self.queue.value))
                break
            except Exception as ex:
                self.logger.exception("Rmq - {} listener stopped with exception {}".format(self.queue.value, ex))

    def process_v2_queue(self, transaction: Dict):
        transaction_body = transaction.get("v5", None)
        if not transaction_body:
            return
        origin_transaction = DomainOriginTransaction(
            message_uuid=str(uuid.uuid4()),
            provider=TransactionSource.SIRENA_V2.value,     # noqa
            created=time.time(),                            # noqa
            raw=transaction
        )
        self.transaction_repo.create(origin_transaction)

    def process_v1_queue(self, transaction: Dict):
        received_at = time.time()
        message_uid = str(uuid.uuid4())

        rloc = transaction.get('Reclocs', {}).get('Gds', 'not defined')
        version = transaction.get('Version', None)
        SirenaRmqListener.logger.info(
            (
                'Transaction with rloc: {rloc}, version: {version}, '
                'processing from {queue}. '
                'Internal message_uid: {message_uid}'
            ).format(
                rloc=rloc, version=version,
                queue=self.queue.value, message_uid=message_uid,
            ),
            extra=dict(
                sirena_rloc=rloc, sirena_version=version,
                sirena_transaction_uid=message_uid,
            )
        )
        SirenaRmqListener.logger.debug(json.dumps(transaction, indent=2))
        try:
            InternalOrderAdapter.save(
                raw_order=transaction,
                message_id=message_uid,
                received=received_at,
                provider=TransactionSource.SIRENA.value,
                deferred_save=True,
                save_origin_transaction=True
            )
        except ApplicationError:
            # Все будет залогировано в юзкейсе сохранения
            pass
