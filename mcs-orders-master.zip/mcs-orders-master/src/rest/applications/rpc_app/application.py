# if __name__ == '__main__':
#     # local development gevent friendly built-ins
#     from gevent import monkey
#     monkey.patch_all()

from rest.settings import settings
from rest.applications.rpc_app import bootstrap


bootstrap.bootstrap()
application = bootstrap.get_application()


if __name__ == '__main__':
    application.run(
        host=settings.HOST,
        port=settings.PORT,
        ssl_context=settings.SSL_CONTEXT,
        debug=settings.DEBUG
    )
