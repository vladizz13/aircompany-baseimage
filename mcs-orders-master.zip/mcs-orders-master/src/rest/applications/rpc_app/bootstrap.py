import logging.config
import time

from flask import Flask, request, g
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_jsonrpc import JSONRPC
from raven.contrib.flask import Sentry

from libs.utils.tools.logging import get_app_version
from libs.db_gateway.mongo.monitor import (
    MongoConnectionPoolLogger,
    MongoHeartbeatLogger,
    MongoTopologyLogger,
    MongoServerLogger,
    MongoCommandLogger
)

from rest.applications.rpc_app.utils.apm_enricher import CustomizedElasticAPM
from rest.settings import settings
from rest.applications.rpc_app.utils.audit.request_audit import audit
from events.register import register_all
from pymongo import monitoring


__APPLICATION__ = None
__JSONRPC_APPLICATION__ = None
__IS_APP_OBSERVERS_REGISTERED__: bool = False


def register_all_observers():
    global __IS_APP_OBSERVERS_REGISTERED__

    if __IS_APP_OBSERVERS_REGISTERED__:
        return

    register_all()

    __IS_APP_OBSERVERS_REGISTERED__ = True


def get_application() -> Flask:
    global __APPLICATION__
    if __APPLICATION__:
        return __APPLICATION__

    __APPLICATION__ = Flask(__name__)
    __APPLICATION__.env = settings.FLASK_ENV
    __APPLICATION__.secret_key = settings.SECRET_KEY
    __APPLICATION__.url_map.strict_slashes = False
    __APPLICATION__.wsgi_app = ProxyFix(__APPLICATION__.wsgi_app)

    # Init Elastic APM
    if settings.ELASTIC_APM:
        CustomizedElasticAPM(
            __APPLICATION__,
            service_name=settings.SERVICE_NAME,
            server_url=settings.ELASTIC_APM.get("SERVER_URL"),
            debug=True,
            environment=settings.ELASTIC_APM.get("ENVIRONMENT") or settings.FLASK_ENV,
            secret_token=settings.ELASTIC_APM.get("SECRET_TOKEN")
        )

    if settings.MONGO_MONITOR_ENABLED:
        monitoring.register(MongoTopologyLogger())
        monitoring.register(MongoServerLogger())
        monitoring.register(MongoConnectionPoolLogger())
        monitoring.register(MongoHeartbeatLogger())
        monitoring.register(MongoCommandLogger())

    return get_application()


def get_jsonrpc_application() -> JSONRPC:
    global __JSONRPC_APPLICATION__
    if __JSONRPC_APPLICATION__:
        return __JSONRPC_APPLICATION__
    __JSONRPC_APPLICATION__ = JSONRPC(
        get_application(),
        '/{}'.format(settings.JSON_RPC_API_PREFIX),
        enable_web_browsable_api=True
    )
    return get_jsonrpc_application()


def __register_blueprint__():
    """
    Регистрируем HTTP API/роуты
    :return:
    """
    from . import endpoints     # noqa


def __register_rpc__():
    """
    Регистрируем RPC методы
    :return:
    """
    # from .methods import sys      # noqa
    from . import methods           # noqa


def __setup_logging__():
    # Setup Sentry
    app = get_application()
    if settings.SENTRY_DSN:
        sentry = Sentry()

        app.config['SENTRY_CONFIG'] = {
            'release': get_app_version(),
            'auto_log_stacks': True,
        }
        sentry.init_app(
            app,
            dsn=settings.SENTRY_DSN,
            logging=True,
            level=logging.ERROR,
        )


def __setup_audit__():
    '''Setup audit'''
    app = get_application()

    @app.before_request
    def set_request_start_start():
        g.request_start_start = time.time()

    @app.after_request
    def audit_request(response):
        """
        Аудит запроса
        """
        if not settings.REQUEST_AUDIT_ENABLED:
            return response
        audit(request, response, duration=time.time() - g.request_start_start)
        return response


def bootstrap() -> None:
    get_application()
    __setup_logging__()
    get_jsonrpc_application()
    __register_blueprint__()
    __register_rpc__()
    register_all_observers()
    __setup_audit__()
