from ..bootstrap import get_application
from flask import redirect
from rest.settings.settings import JSON_RPC_API_PREFIX
import pkgutil
from flask import jsonify
from use_cases.sys.health import HealthUseCase, HealthUseCaseRequest

# динамический импорт всех модулей в пакете "endpoints"
__path__ = pkgutil.extend_path(__path__, __name__)
for importer, modname, ispkg in pkgutil.walk_packages(path=__path__, prefix=__name__ + '.'):
    __import__(modname)


app = get_application()
methods = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'CONNECT', 'OPTIONS', 'TRACE']


@app.route('/{}'.format(JSON_RPC_API_PREFIX), methods=['GET'])
def index():
    return jsonify({'response': True})


@app.route('/health', methods=['GET'])
def health():
    health_result = HealthUseCase().execute(HealthUseCaseRequest())
    return jsonify(health_result.value), 200 if bool(health_result.value.get('is_up', False)) else 500


@app.route('/', defaults={'path': ''}, methods=methods)
@app.route('/<path:path>', methods=methods)
def catch_all(path):
    # редиректим евсь трафик на rpc
    return redirect('/{}'.format(JSON_RPC_API_PREFIX), code=307)
