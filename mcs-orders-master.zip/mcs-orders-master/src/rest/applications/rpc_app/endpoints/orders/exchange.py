from uuid import UUID

from flask import Response, request
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth

from rest.interfaces.external_exchange_order_adapter import ExternalExchangeOrderAdapter
from rest.settings.settings import MONO_APP_JSONRPC
from ...bootstrap import get_application

app = get_application()


@app.route('/api/v2/orders/<uuid:order_uuid>/exchange', methods=['GET'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def exchange_order(order_uuid: UUID) -> Response:
    """
    Прокси метод для подготовки заказа к возврату в таисе
    """
    interface: ExternalExchangeOrderAdapter = ExternalExchangeOrderAdapter()

    result: Response = interface.exchange_order_v1(order_uuid=order_uuid)
    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/exchange_v2', methods=['GET'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def get_order_exchange_data(order_uuid: UUID) -> Response:
    """
    Получение данных заказа для обмена
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.get_order_exchange_data(order_uuid=order_uuid)
    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/exchange/options', methods=['POST'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def get_order_exchange_options(order_uuid: UUID) -> Response:
    """
    Получение вариантов для обмена заказа
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.get_order_exchange_options(
        order_uuid=order_uuid,
        passenger_ids=request.json.get('passenger_ids', []),
        flights=request.json.get('flights', []),
    )

    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/exchange', methods=['POST'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def confirm_order_exchange(order_uuid: UUID) -> Response:
    """
    Подтверждение обмена заказа
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.confirm_order_exchange(
        order_uuid=order_uuid,
        passenger_ids=request.json.get('passenger_ids', []),
        flights=request.json.get('flights', []),
    )

    return result


@app.route('/api/v2/orders/exchanges/<uuid:exchange_uuid>/start', methods=['POST'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def start_order_exchange(exchange_uuid: UUID) -> Response:
    """
    Начало флоу оплаты обмена
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.start_order_exchange(
        exchange_uuid=exchange_uuid,
        success_url=request.json.get('success_url'),
        fail_url=request.json.get('fail_url'),
    )

    return result


@app.route('/api/v2/orders/exchanges/<uuid:exchange_uuid>', methods=['DELETE'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def cancel_order_exchange(exchange_uuid: UUID) -> Response:
    """
    Отмена обмена заказа
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.cancel_order_exchange(exchange_uuid=exchange_uuid)

    return result


@app.route('/api/v2/orders/exchanges/<uuid:exchange_uuid>', methods=['GET'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def get_order_exchange_status(exchange_uuid: UUID) -> Response:
    """
    Получение статуса обмена заказа
    """
    interface = ExternalExchangeOrderAdapter()

    result = interface.get_order_exchange_status(exchange_uuid=exchange_uuid)

    return result
