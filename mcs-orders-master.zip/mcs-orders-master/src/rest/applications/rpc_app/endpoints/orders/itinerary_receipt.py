from flask import request, Response
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth

from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from rest.settings.settings import MONO_APP_JSONRPC
from ...bootstrap import get_application

app = get_application()


@app.route('/api/v2/orders/<uuid:order_uuid>/itinerary_receipt', methods=['GET'])
@cross_origin()
@require_oauth('app.booking', connection_settings=MONO_APP_JSONRPC)
def get_itinerary_receipt(order_uuid: str) -> Response:
    """
    Получение ссылки на скачивание маршрута-квитанции
    order_uuid - уникальный идентификатор заказа. Обязательный. Нельзя применять без фамилии пассажира.
    last_name - фамилия пассажира.
    """
    passenger_last_name: str = request.args.get('last_name')

    interface = ExternalOrderAdapter()

    result = interface.get_itinerary_receipt_download_link(
        order_uuid=order_uuid, passenger_last_name=passenger_last_name
    )

    return result
