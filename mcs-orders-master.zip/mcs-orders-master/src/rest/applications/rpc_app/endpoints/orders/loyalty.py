from ...bootstrap import get_application
from flask_cors import cross_origin
from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from flask import request
from typing import Dict, List
from mcs_oauth_client import require_oauth
from rest.settings.settings import MONO_APP_JSONRPC


app = get_application()
methods = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'CONNECT', 'OPTIONS', 'TRACE']


@app.route('/api/v2/orders/loyalty', methods=['POST'])
@cross_origin()
@require_oauth("app.booking", connection_settings=MONO_APP_JSONRPC)
def add_loyalty_cart():
    """
    Добавление карты в заказ
    Доступные фильтры:
    >>> from use_cases.orders.loyalty.add_card.input_types import AddLoyaltyCardFilters
    filter[rloc] - Рлок. Обязательный. Нельзя применять один.

    """
    filters: Dict = request.json.get('filters', None)
    passengers: List[Dict] = request.json.get('passengers', None)

    interface = ExternalOrderAdapter()
    result = interface.add_loyalty_card(
        passengers=passengers,
        filters=filters,
    )
    return result
