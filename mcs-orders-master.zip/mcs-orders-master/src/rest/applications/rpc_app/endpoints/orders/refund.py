from uuid import UUID

from flask import Response, request
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth

from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from rest.settings.settings import MONO_APP_JSONRPC
from ...bootstrap import get_application
from ...utils.recaptcha import valid_recaptcha, InvalidRecaptchaError

app = get_application()


@app.route('/api/v2/orders/<uuid:order_uuid>/refund', methods=['GET'])
@cross_origin()
@require_oauth('app.orders.refund', connection_settings=MONO_APP_JSONRPC)
def refund_order_customers(order_uuid: UUID) -> Response:
    """
    Предоставляет начальные данные, необходимые для старта процесса возврата заказа.
    """

    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface = ExternalOrderAdapter()

    result = interface.get_initial_data_for_start_refund(order_uuid=order_uuid)

    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/refund', methods=['POST'])
@cross_origin()
@require_oauth('app.orders.refund', connection_settings=MONO_APP_JSONRPC)
def initiate_order_refund(order_uuid: UUID) -> Response:
    """
    Запуск процесса возврата заказа.
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()
    result: Response = interface.initiate_order_refund(order_uuid=order_uuid, data=request.json)
    return result


@app.route('/api/v2/orders/refunds', methods=['POST'])
@cross_origin()
@require_oauth('app.orders.refund', connection_settings=MONO_APP_JSONRPC)
def submit_order_refund_request() -> Response:
    """
    Оформление заявки на возврат
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()
    result: Response = interface.submit_order_refund_request(request.json)
    return result
