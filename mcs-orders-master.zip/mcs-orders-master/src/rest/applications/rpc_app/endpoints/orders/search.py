from typing import Dict, List

from flask import request
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth, DomainOauth

from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from rest.settings.settings import MONO_APP_JSONRPC
from use_cases.orders.search.input_types.app import AppScopeFilters
from use_cases.orders.search.input_types.common import AvailableLanguages, Page
from use_cases.orders.search.input_types.user import UserScopeFilters
from ...bootstrap import get_application
from ...utils.recaptcha import valid_recaptcha, InvalidRecaptchaError
from ...utils.request_parser import parse_key_values

app = get_application()
methods = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'CONNECT', 'OPTIONS', 'TRACE']


@app.route('/api/v2/users/orders/', methods=['GET'])
@cross_origin()
@require_oauth('user.profile', connection_settings=MONO_APP_JSONRPC)
def search_order_user_context():
    """
    Поиск заказа по контексту пользователя
    Доступные фильтры:
    >>> from use_cases.orders.search.input_types.user import UserScopeFilters
    filter[datetime_from]- Если в броне есть хоть один сегмент, датавремя вылета которого больше или равна datetime_from
    filter[datetime_to] - Если в броне есть хоть один сегмент, датавремя вылета которого меньше или равна datetime_to
    filter[flight_number] - номер рейса, строка, необязательный
    filter[date] - дата, ограничивающая поиск

    Доступная пагинация:
    >>> from use_cases.orders.search.input_types.common import Page
    page[skip] - смещение, по умолчанию 0
    page[limit] - количество записей, по умолчанию 10, макс. 100

    """
    # Фильтры, для генерации запроса
    filters: Dict = parse_key_values(request, UserScopeFilters)
    # Параметры пагинации
    page: Dict = parse_key_values(request, Page)
    # Пользователь, инициировавший запрос на поиск
    user: DomainOauth = request.oauth
    # Язык
    lang: str = request.accept_languages.best_match(
        AvailableLanguages._value2member_map_, default=AvailableLanguages.RU.value
    )

    interface = ExternalOrderAdapter()
    result = interface.find_orders_user_context(
        user=user, filters=filters, page=page, lang=lang
    )
    return result


@app.route('/api/v2/users/orders/checkin/', methods=['GET'])
@cross_origin()
@require_oauth('user.profile', connection_settings=MONO_APP_JSONRPC)
def search_open_order_user_context():
    """
    Поиск заказа с сегментами, на которые открыта регистрация по контексту пользователя
    """
    # Пользователь, инициировавший запрос на поиск
    user: DomainOauth = request.oauth
    # Язык
    lang: str = request.accept_languages.best_match(
        AvailableLanguages._value2member_map_, default=AvailableLanguages.RU.value
    )

    interface = ExternalOrderAdapter()
    result = interface.find_open_orders_user_context(
        user=user, lang=lang
    )

    return result


@app.route('/api/v2/orders/', methods=['GET'])
@cross_origin()
@require_oauth('app.booking', connection_settings=MONO_APP_JSONRPC)
def search_order_app_context():
    """
    Поиск заказа по контексту приложения

    Доступные фильтры:
    >>> from use_cases.orders.search.input_types.app import AppScopeFilters
    filter[uuid] - Идентификатор заказа. Необязательный
    filter[rloc] - Рлок. Необязательный. Нельзя применять один.
    filter[passenger_lastname] - фамилия пассажира. Необязательный. Нельзя применять один.
    filter[flight_number] - Номер рейса. Необязательный. Нельзя применять один.
    filter[passenger_doc_number] - номер документа пассажира. Необязательный. Нельзя применять один.
    filter[passenger_ticket_number] - номер билета пассажира. Необязательный. Нельзя применять один.
    filter[departure_date] - дата вылета. В формате ISO (timestamp ?). Необязательный. Нельзя применять один.

    Доступная пагинация:
    >>> from use_cases.orders.search.input_types.common import Page
    page[skip] - смещение, по умолчанию 0
    page[limit] - количество записей, по умолчанию 10, макс. 100

    Доступные поля для серализации:
    >>> from use_cases.orders.search.input_types.app import AppScopeFields
    """

    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    # Поля для сериализации
    fields: str = request.args.get('fields', [])
    if fields:
        fields: List = [i.strip() for i in fields.split(',')]
    # Сортировка
    sort: str = request.args.get('sort', None)
    if sort:
        sort: List = sort.split(',')
    # Фильтры для построения запроса
    filters: Dict = parse_key_values(request, AppScopeFilters)
    # Пагинация
    page: Dict = parse_key_values(request, Page)
    # Язык
    lang: str = request.accept_languages.best_match(
        AvailableLanguages._value2member_map_, default=AvailableLanguages.RU.value
    )

    interface = ExternalOrderAdapter()
    result = interface.find_orders_app_context(
        fields=fields, filters=filters, page=page, sort=sort, lang=lang
    )
    return result


@app.route('/api/v2/orders/checkin/', methods=['GET'])
@cross_origin()
@require_oauth('app.booking', connection_settings=MONO_APP_JSONRPC)
def search_open_order_app_context():
    """
    Поиск заказа с сегментами, на которые открыта регистрация по контексту приложения
    """

    # if not valid_recaptcha(request):
    #     return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    lang: str = request.accept_languages.best_match(
        AvailableLanguages._value2member_map_, default=AvailableLanguages.RU.value
    )

    locator: str = request.args.get(AppScopeFilters.LOCATOR.value)
    last_name: str = request.args.get(AppScopeFilters.PASSENGER_LASTNAME.value)

    interface = ExternalOrderAdapter()
    result = interface.find_open_orders_app_context(
        locator=locator, last_name=last_name, lang=lang
    )

    return result
