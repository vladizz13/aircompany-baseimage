from uuid import UUID

from ...bootstrap import get_application
from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from flask import request, Response
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth, DomainOauth
from rest.settings.settings import MONO_APP_JSONRPC
from ...utils.recaptcha import valid_recaptcha, InvalidRecaptchaError

app = get_application()
methods = ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'CONNECT', 'OPTIONS', 'TRACE']


@app.route('/api/v2/users/orders/', methods=['POST'])
@cross_origin()
@require_oauth("user.profile", connection_settings=MONO_APP_JSONRPC)
def add_order():
    """
    Добавление заказа пользователю
    """
    user: DomainOauth = request.oauth
    rloc = request.json.get('rloc', None)
    last_name = request.json.get('last_name', None)

    interface = ExternalOrderAdapter()
    result = interface.add_order(
        user=user,
        rloc=rloc,
        last_name=last_name
    )
    return result


@app.route('/api/v2/users/orders/<order_uuid>', methods=['DELETE'])
@cross_origin()
@require_oauth("user.profile", connection_settings=MONO_APP_JSONRPC)
def hide_order(order_uuid: str):
    """
    Удаление (сокрытие) заказа пользователя
    """
    user: DomainOauth = request.oauth
    interface = ExternalOrderAdapter()
    result = interface.hide_order(
        user=user,
        order_uuid=order_uuid
    )
    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/passengers/<int:passenger_id>/personal_data', methods=['GET'])
@cross_origin()
@require_oauth("app.user.change_personal_data", connection_settings=MONO_APP_JSONRPC)
def check_possibility_change_personal_data(order_uuid: UUID, passenger_id: int) -> Response:
    """
    Проверка, возможно ли для пассажира изменить перс данные в заказе
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()
    result: Response = interface.check_possibility_change_personal_data(
        {'order_uuid': order_uuid, 'passenger_id': passenger_id}
    )
    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/passengers/<int:passenger_id>/personal_data', methods=['POST'])
@cross_origin()
@require_oauth("app.user.change_personal_data", connection_settings=MONO_APP_JSONRPC)
def shape_change_personal_data_request(order_uuid: UUID, passenger_id: int):
    """
    Сформировывает заявку на изменение персональных данных юзера
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()

    input_data = request.json or {}
    input_data['order_uuid'] = order_uuid
    input_data['passenger_id'] = passenger_id

    result: Response = interface.shape_change_personal_data_request(input_data)
    return result


@app.route('/api/v2/orders/passengers/personal_data', methods=['POST'])
@cross_origin()
@require_oauth("app.user.change_personal_data", connection_settings=MONO_APP_JSONRPC)
def submit_change_personal_data_request():
    """
    Оформить заявку на изменение персональных данных пассажира
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()
    result: Response = interface.submit_change_personal_data_request(request.json)
    return result
