from uuid import UUID

from flask import Response, request
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth

from rest.interfaces.external_order_adapter import ExternalOrderAdapter
from rest.settings.settings import MONO_APP_JSONRPC
from ...bootstrap import get_application
from ...utils.recaptcha import valid_recaptcha, InvalidRecaptchaError

app = get_application()


@app.route('/api/v2/orders/<uuid:order_uuid>/withdraw', methods=['GET'])
@cross_origin()
@require_oauth("app.orders.withdraw", connection_settings=MONO_APP_JSONRPC)
def release_seats_customers(order_uuid: UUID) -> Response:
    """
    Предоставляет сегменты из брони, доступные к снятию мест.
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()

    result: Response = interface.get_segments_available_for_withdraw(order_uuid=order_uuid)
    return result


@app.route('/api/v2/orders/<uuid:order_uuid>/withdraw', methods=['POST'])
@cross_origin()
@require_oauth("app.orders.withdraw", connection_settings=MONO_APP_JSONRPC)
def initiate_order_release_seats(order_uuid: UUID) -> Response:
    """
    Предоставляет сегменты из брони, доступные к снятию мест.
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()

    result: Response = interface.initiate_order_release_seats(order_uuid=order_uuid, data=request.json)
    return result


@app.route('/api/v2/orders/withdraw/submit', methods=['POST'])
@cross_origin()
@require_oauth("app.orders.withdraw", connection_settings=MONO_APP_JSONRPC)
def submit_order_release_seats() -> Response:
    """
    Предоставляет сегменты из брони, доступные к снятию мест.
    """
    if not valid_recaptcha(request):
        return ExternalOrderAdapter.build_from_application_error(InvalidRecaptchaError())

    interface: ExternalOrderAdapter = ExternalOrderAdapter()

    result: Response = interface.submit_order_release_seats(data=request.json)
    return result
