from flask import Response, request
from flask_cors import cross_origin
from mcs_oauth_client import require_oauth
from rest.settings.settings import MONO_APP_JSONRPC, ENABLE_TAIS_STREAM
from ...bootstrap import get_application
from rest.applications.celery_app.tasks.save_tais import save_from_tais

app = get_application()


@app.route('/api/v2/orders/system/transaction/', methods=['POST'])
@cross_origin()
@require_oauth("app.system.transactions", connection_settings=MONO_APP_JSONRPC)
def save_tais_transaction() -> Response:
    """
    Сохранение транзакции от таиса
    """
    # Эксперимент https://team.utair.io/dit/pl/are6amujd3ns3dueyj74uf5pih
    if not ENABLE_TAIS_STREAM:
        return Response(status=200)
    transaction_body = request.json or dict()
    order_id = transaction_body.get('order_id')
    if not order_id:
        return Response(status=400)
    save_from_tais.delay(order_id=order_id)
    return Response(status=200)
