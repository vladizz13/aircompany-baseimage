from typing import List, Dict, Optional
from rest.applications.rpc_app.bootstrap import get_jsonrpc_application
from rest.applications.rpc_app.utils.auth import auth
from rest.interfaces.internal_order_adapter import InternalOrderAdapter


rpc = get_jsonrpc_application()


@rpc.method('order.save')
@auth.login_required
def save(order_raw_data: dict, provider: str, received: float, message_id: str):
    """
    Метод сохранения заказа
    :param order_raw_data: Сырой, необработанный словарь заказа
    :param provider: Провайдер, от которого поступил заказ
    :param received: Время получения заказа
    :param message_id: Идентификатор транзакции от провайдера
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.save(
        raw_order=order_raw_data,
        provider=provider,
        received=received,
        message_id=message_id
    )
    return response


@rpc.method('order.update.fromBookingCart.v1')
@auth.login_required
def update_from_booking_cart(cart_data: dict):
    """
    Метод обновления / сохранения заказа из данных корзины букинга
    :param cart_data: Данные корзины
    :return:
    """
    from rest.applications.celery_app.tasks.save_tais import update_order_from_booking_cart
    update_order_from_booking_cart.delay(cart_data=cart_data)
    return dict(
        deferred=True
    )


@rpc.method('order.internal.find.v1')
@auth.login_required
def search(filters: dict, fields: list, sort: list, page: dict, lang: str = 'ru'):
    """
    Метод поиска брони для внутреннего использования среди микросервисов

    :param filters: Доступные фильтры:
    >>> from use_cases.orders.search.input_types.internal import InternalScopeFilters
    :param fields: Доступные поля для сериализации
    >>> from use_cases.orders.search.input_types.internal import InternalScopeFields
    :param sort: Поля для сортировки
    :param page: Пагинация, скип и лимит
    :param lang: Язык перевода сервисов, сегментов итд

    >>>{
    >>>    "filters": {
    >>>        "uuid": "orderuuid",
    >>>    }
    >>>    "fields": ['data', 'meta'],
    >>>    "sort": ["-meta.created"],
    >>>    "page": {
    >>>        "skip": 10,
    >>>        "limit": 10,
    >>>    },
    >>>    "lang": "ru" # "en
    >>>}
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.search(
        filters=filters,
        fields=fields,
        sort=sort,
        page=page,
        lang=lang
    )
    return response


@rpc.method('order.internal.admin.hide.v1')
@auth.login_required
def hide(order_uuid: str, user_id: str):
    """
    Скрытие заказа
    """
    return InternalOrderAdapter.hide_order(order_uuid, user_id)


@rpc.method('order.internal.admin.add.v1')
@auth.login_required
def add(order_uuid: str, user_id: str):
    """
    Добавление заказа
    """
    return InternalOrderAdapter.add_order(order_uuid, user_id)


@rpc.method('order.internal.update.v1')
@auth.login_required
def update(order_uuid: str, deferred: bool = False):
    """
    Метод принудительного обновления брони данными SirenaGRS
    :param order_uuid: uuid заказа из базы
    :param deferred: Отложенное сохранение
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.update_from_sirena_grs(
        order_uuid=order_uuid,
        deferred=deferred
    )
    return response


@rpc.method('order.internal.loyalty.addCard.v1')
@auth.login_required
def add_loyalty_card(filters: dict, passengers: List[dict]):
    """
    Метод добавления карты лояльности пользователю
    :param filters: Фильтры для поиска заказа
    {
        "rloc": "much_wow"
    }
    :param passengers: Данные пассажиров:
    [
        {
            "last_name": "Половникова",
            "loyalty_card": "123321",
            "phone_number": "79068243200",
            "email": "LESYA2049@YANDEX.RU",
            "doc_number": "3708320226"
        }
    ]
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.add_loyalty_card(
        filters=filters,
        passengers=passengers
    )
    return response


@rpc.method('order.internal.loyalty.getOrderDetailPrice.v1')
@auth.login_required
def get_order_detail_price(ticket_number: str, last_name: str, rloc: Optional[str] = None):
    """
    Получение детализированной цены по заказу
    Мили/EMD/Рубли
    :param rloc: Рлок заказа (необязательный)
    :param ticket_number: Номер билета (обязательный)
    :param last_name: Фамилия пассажира (обязательный)
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.get_order_detail_price(
        rloc=rloc,
        ticket_number=ticket_number,
        last_name=last_name
    )
    return response


@rpc.method('order.internal.user.admin.addContacts.v1')
@auth.login_required
def admin_add_contacts(rloc: str, last_name: str, contacts: List[Dict]):
    """
    Метод добавления контактов в бронь.
    :param rloc: Rloc заказа
    :param last_name: Фамилия одно из пассажиров
    :param contacts: Контакты для добавления
    [
        {
            "contact": "jony.ive@apple.com,
            "confirmed": true
        },
        {
            "contact": "88005553535"
        }
    ]
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.admin_add_contacts(
        rloc=rloc,
        last_name=last_name,
        contacts=contacts
    )
    return response


@rpc.method('order.internal.user.admin.manageContacts.v1')
@auth.login_required
def admin_manage_contacts(rloc: str, last_name: str, contacts: List[Dict]):
    """
    Метод управления контактами в броне.
    :param rloc: Rloc заказа
    :param last_name: Фамилия одно из пассажиров
    :param contacts: Контакты для добавления
    [
        {
            "contact": "jony.ive@apple.com,
            "confirmed": true,
            "hide": true,
        }
    ]
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.admin_manage_contacts(
        rloc=rloc,
        last_name=last_name,
        contacts=contacts
    )
    return response


@rpc.method('order.internal.reSave.v1')
@auth.login_required
def re_save_order(order_uuid: str, force: bool = False, providers: list = None):
    """
    Метод пересохранения заказа с нуля по всем имеющимся транзакциям
    :param order_uuid: uuid заказа из базы
    :param force: Пересохранит заказ, даже если не будет хватать каких-то транзакций
    :param providers: Транзакции каких провайдеров сохранить, если значение пустое - сохранит все транзакции
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.re_save_order(
        order_uuid=order_uuid,
        force=force,
        providers=providers
    )
    return response


@rpc.method('order.internal.getOrderMonoAppStructure.v1')
@auth.login_required
def get_mono_app_order(order_uuid: str, send_to_mono_app: bool = False, discard_order_data: bool = False):
    """
    Метод получения заказа в структуре моноапп
    :param order_uuid: айдишник заказа из базы
    :param send_to_mono_app: послать полученный заказ на сохранение в моноапп через кафку
    :param discard_order_data: не возвращать данные заказа (для экономии трафика, если нужно просто переслать заказ)
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.get_mono_app_order(
        order_uuid=order_uuid,
        send_to_mono_app=send_to_mono_app,
        discard_order_data=discard_order_data
    )
    return response


@rpc.method('order.getItineraryReceipt.v1')
@auth.login_required
def get_itinerary_receipt(order_uuid: str, last_name: str):
    """
    Метод получения ссылки на скачивание маршрутной квитанции

    :param order_uuid: уникальный идентификатор заказа. Обязательный. Нельзя применять без фамилии пассажира.
    :param last_name: фамилия пассажира.

    :return:
    """
    interface = InternalOrderAdapter()

    response = interface.get_itinerary_receipt_download_link(
        order_uuid=order_uuid,
        passenger_last_name=last_name,
    )

    return response


@rpc.method('order.getRefunds.v1')
@auth.login_required
def get_order_refunds(order_uuid: str):
    """
    Метод получения заявок на возврат
    :param order_uuid: айдишник заказа из базы
    :return:
    """
    interface = InternalOrderAdapter()
    response = interface.get_order_refunds(
        order_uuid=order_uuid
    )
    return response


@rpc.method('order.internal.exchange.v1')
@auth.login_required
def exchange_v1(order_uuid: str):
    """
    Прокси метод получения инфо по обмену брони в таисе
    """
    return InternalOrderAdapter.exchange_order_v1(order_uuid)
