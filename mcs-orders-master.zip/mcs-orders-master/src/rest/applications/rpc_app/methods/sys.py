from ..bootstrap import get_jsonrpc_application


rpc = get_jsonrpc_application()


@rpc.method('sys.ping')
def ping():
    return u'pong'
