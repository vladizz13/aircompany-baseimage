import logging

import elasticapm
from elasticapm.contrib.flask import ElasticAPM
from flask import request

err_logger = logging.getLogger("audit")


class CustomizedElasticAPM(ElasticAPM):
    """ Flask application for Elastic APM,
    with JSONRPC support to distinguish between methods
    """

    def request_started(self, app):
        super().request_started(app)

        # (повторяет условие в родительском методе)
        if (not self.app.debug or self.client.config.debug) and not self.client.should_ignore_url(request.path):

            # Добавим JSONRPC-специфичную инфу, если надо и получится.
            try:
                self.__add_jsonrpc_info()
            except Exception as e:
                err_logger.exception(f"Failed to add JSONRPC info to ElasticAPM transaction: {e}")

    def __add_jsonrpc_info(self):
        if f"{request.method} {request.path}" != "POST /jsonrpcapi":  # fixme
            return

        try:
            jsondata = request.json
            if isinstance(jsondata, list):
                # В батче могут вызываться разные методы, да и с т.з. "профилирования"
                # хз как это удобно/красиво оформить, будем пока просто их все в одну кучу валить.
                jsonrpc_method_name = "batch"
            else:
                jsonrpc_method_name = str(jsondata["method"])
        except (ValueError, TypeError, LookupError):
            jsonrpc_method_name = "unknown"

        # todo: доп. инфу в labels и/или custom context?
        # elasticapm.label(jsonrpc_method=jsonrpc_method_name)

        elasticapm.set_transaction_name(f"JSONRPC {jsonrpc_method_name}", override=True)
