import binascii
import json
import logging
from base64 import b64decode
from datetime import datetime
from ipaddress import ip_network
from json import JSONDecodeError

import flask
from werkzeug.exceptions import BadRequest

from .utils import extract_response_data, convert_bytes_to_str


logger = logging.getLogger('audit')
requests_logger = logging.getLogger('http-requests')


def detect_ip(request):
    '''Prevent using of werkzeug.contrib.fixers.ProxyFix'''
    real_ip = request.headers.get('X-Real-Ip', None)

    # HTTP_X_FORWARDED_FOR can be a comma-separated list of IPs. The
    # client's IP will be the first one.
    try:
        forwarded_ips = request.headers.getlist("X-Forwarded-For")[0]
        forwarded_ips = [x.strip() for x in forwarded_ips.split(',')]
        # фильтруем локальные сети
        for forwarded_ip in forwarded_ips:
            try:
                if ip_network(forwarded_ip).is_global:
                    return forwarded_ip
            except ValueError:
                continue
        try:
            if real_ip and ip_network(real_ip).is_global:
                return real_ip
        except ValueError:
            pass
    except IndexError:
        pass

    # Default IP
    return request.remote_addr


def _logstash_json(data):
    try:
        return json.dumps(
            data,
            ensure_ascii=False, sort_keys=True
        )
    except KeyError:
        return ''


def prepare_logstash(log: dict):
    '''Подготовить в формат logstash'''

    # response exists
    if 'response' not in log:
        log['response'] = {}

    # fix logstash ERROR: Can’t get text on a START_OBJECT
    log['response']['body'] = _logstash_json(log['response']['body'])

    # fix logstash request parsing body
    log['request']['body'] = _logstash_json(log['request']['body'])

    # fix typing of 'data.headers.Authorization'
    # db.audit.find({}, {'data.headers.Authorization': 1}).sort({date: -1})
    # {"data":{"headers":{"Authorization":{"login":"website_client","password":"nA2REtuw$a-uZ?R3sw&s5A!UW2veDU3U"}}}}
    # "data": { "headers" : { "Authorization" : "Bearer JarsNC9Sx8LUJK6obQSOkveJesKebb" } } }
    log['request']['headers'] = _logstash_json(log['request']['headers'])

    # Fix "reason"=>"Limit of total fields [1000] in index [flask-02.2019] has been exceeded"
    log['request']['form'] = _logstash_json(log['request']['form'])

    # Convert query
    log['request']['query'] = _logstash_json(log['request']['query'])

    # Trash remover
    if log['request']['body'] == '"b\'\'"':
        log['request']['body'] = ''

    return log


def get_request_info(request) -> dict:
    """
    Возвращает информацию о запросе
    :param request:
    :return:
    """
    if hasattr(request, 'url_rule') and request.url_rule is not None:
        endpoint = f'{request.method} {request.url_rule.rule}'
    else:
        endpoint = f'{request.method} {request.path}'
    record = {
        'endpoint': endpoint,
        'ip': detect_ip(request),
        'method': request.method,
        'pathname': request.path,
        'headers': dict(request.headers),
        'query': request.args,
        'form': request.form,
    }
    return record


def update_auth_client_info(request, record) -> dict:
    """
    Возвращает данные о client
    :param request:
    :return:
    """

    prefix = 'Basic '
    authorization = (
        record
        .get('request', {}) or {}
        .get('headers', {}) or {}
        .get('Authorization')
    )
    if isinstance(authorization, str) and authorization.startswith(prefix):
        b64str = authorization.split(prefix)[1]
        try:
            base = b64decode(b64str).decode('utf-8').split(':')
            if len(base) == 2:
                login, passwd = base
                record.update(dict(
                    client_id=login,
                    client_token=passwd,
                ))
        except binascii.Error:
            pass


def store_audit_data(
    request: flask.Request,
    response: flask.Response,
    duration: float
):
    '''Сохранить данные аудита
    request - данные запроса flask
    response - данные ответа flask, в случае исключения будет None
               тогда ответ не запишется
    duration - время генерации отввета
    '''
    record = dict(
        date=datetime.utcnow(),
        duration=duration,
    )

    # Данные запроса
    record['request'] = get_request_info(request)

    jsonrpc_method = None
    if request.is_json:
        try:
            jsonrpc_method = request.json.get('method')
            if jsonrpc_method:
                record['jsonrpc_method'] = jsonrpc_method
        except (AttributeError, JSONDecodeError, BadRequest):
            pass

    try:
        body_data = json.loads(request.data.decode('utf-8'))
    except ValueError:
        body_data = str(request.data)
    if body_data:
        record['request']['body'] = body_data

    # Данные авторизации
    update_auth_client_info(request, record)

    # Данные ответа
    record_response = {}
    http_code, response_body = extract_response_data(response)
    if http_code:
        record_response['http_code'] = http_code
        try:
            response_body_str = (
                response_body if isinstance(response_body, str)
                else response_body.decode('utf-8')
            )
            resp_body_data = json.loads(response_body_str)

            if 'error_code' in resp_body_data.get('meta', {}):
                record['error_code'] = resp_body_data['meta']['error_code']

            if all((
                jsonrpc_method,
                'error' in resp_body_data,
            )):
                record_response['error_code'] = resp_body_data['error']['code']
        except ValueError:
            resp_body_data = str(response_body)
        record_response['body'] = resp_body_data

    if record_response:
        record['response'] = record_response

    # Отправка данных
    prepared_record = prepare_logstash(convert_bytes_to_str(record))
    message = record.get('request').get('endpoint')

    requests_logger.info(message, extra=prepared_record)


def audit(request: flask.Request, response: flask.Response, duration: float):
    '''Аудит вызовов'''
    try:
        store_audit_data(request, response, duration)
    except Exception as e:
        logger.exception(e)
