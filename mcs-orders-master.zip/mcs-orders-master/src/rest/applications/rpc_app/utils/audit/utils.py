import logging

from flask import Response as FlaskResponse
from werkzeug import Response as WerkzeugResponse


logger = logging.getLogger('audit')


def convert_bytes_to_str(obj: dict) -> dict:
    '''Конввертировать bytes строки словаря в обычные'''
    for key, value in obj.items():
        if isinstance(value, dict):
            obj[key] = convert_bytes_to_str(value)
        elif isinstance(value, bytes):
            try:
                obj[key] = value.decode('utf-8')
            except UnicodeDecodeError:
                obj[key] = str(value)
    return obj


def __get_flask_response_data(flask_response):
    '''Получить данные flask ответа'''
    try:
        return flask_response.data
    except RuntimeError as ex:
        logger.warning(ex)
        return ''


def extract_response_data(flask_response):
    '''Извлечь данные Flask ответа

    Возвращает:
    http_code, response_body
    '''
    if flask_response is None:
        return None, None

    http_code = None
    response_body = None
    if isinstance(flask_response, FlaskResponse):
        http_code = flask_response.status_code
        response_body = __get_flask_response_data(flask_response)
    elif isinstance(flask_response, tuple) and len(flask_response) == 2:
        resp, http_code = flask_response
        if isinstance(resp, FlaskResponse):
            response_body = __get_flask_response_data(resp)
        else:
            logger.error('Unexpected resp')
    elif isinstance(flask_response, WerkzeugResponse):
        http_code = flask_response.status_code
        response_body = __get_flask_response_data(flask_response)
    elif isinstance(flask_response, str):
        http_code = 200
        response_body = flask_response
    else:
        logger.error('Unexpected Flask response: {}'.format(
            type(flask_response)
        ))

    return http_code, response_body
