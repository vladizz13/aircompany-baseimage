from flask_httpauth import HTTPBasicAuth
from rest.settings.settings import ACCESS_LIST

auth = HTTPBasicAuth()


@auth.get_password
def get_pw(username):
    if username in ACCESS_LIST:
        return ACCESS_LIST.get(username)
    return None
