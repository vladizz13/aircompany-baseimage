from base.exception import ApplicationError


class UnauthorizedError(ApplicationError):
    code = 40101
    message = "The server could not verify that you are authorized to access"
    status = 401
