from ipaddress import ip_network


def detect_ip(request):
    """
    Prevent using of werkzeug.contrib.fixers.ProxyFix
    """
    real_ip = request.headers.get('X-Real-Ip', None)

    # HTTP_X_FORWARDED_FOR can be a comma-separated list of IPs. The
    # client's IP will be the first one.
    try:
        forwarded_ips = request.headers.getlist("X-Forwarded-For")[0]
        forwarded_ips = [x.strip() for x in forwarded_ips.split(',')]
        # фильтруем локальные сети
        for forwarded_ip in forwarded_ips:
            try:
                if ip_network(forwarded_ip).is_global:
                    return forwarded_ip
            except ValueError:
                continue
        try:
            if real_ip and ip_network(real_ip).is_global:
                return real_ip
        except ValueError:
            pass
    except IndexError:
        pass

    # Default IP
    return request.remote_addr
