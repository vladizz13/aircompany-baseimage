import logging
import ipaddress
from requests import post
from .ip import detect_ip
from base.exception import ApplicationError
from rest.settings import settings


class InvalidRecaptchaError(ApplicationError):
    """
    Некорректная рекаптча
    """
    message = "Invalid recaptcha in request"
    code = 40020
    status = 400


def is_ip_in_whitelist(ip_address: str) -> bool:
    """
    Проверяет находиться ли ip в белом списке
    :param ip_address: ip адрес для проверки
    :type ip_address: str
    :return:
    :rtype: bool
    """
    ip_address_obj = ipaddress.ip_address(ip_address)
    for item in settings.IP_WHITELIST:
        if isinstance(item, ipaddress.IPv4Network):
            if ip_address_obj in item:
                return True
        elif isinstance(item, ipaddress.IPv4Address):
            if ip_address_obj == item:
                return True
        elif isinstance(item, str):
            if ip_address == item:
                return True
    return False


def valid_recaptcha(_request) -> bool:
    """
    Проверка recaptcha
    :param _request: объект текущего запроса flask.Request
    :param module_name: функция для которой выполняется проверка
    :return:
    """
    logger = logging.getLogger('recaptcha')
    logger_recaptcha_failure = logging.getLogger('recaptcha_failure')

    if not settings.RECAPTCHA_CONFIG.get('is_enabled', False):
        return True

    if (
        hasattr(_request, 'oauth') and
        _request.oauth.oauth_client.client_id != 'website_client'
    ):
        return True

    # Если ip в белом списке не используем recaptcha
    ip_address = detect_ip(_request)
    if is_ip_in_whitelist(ip_address):
        return True

    extra = {
        "endpoint": f"{_request.method} {_request.url_rule.rule}",
        "url": _request.path,
        "remote_addr": ip_address,
        "status": "missed g-recaptcha-response header"
    }

    recaptcha_response = _request.headers.get('g-recaptcha-response')
    if not recaptcha_response:
        extra.update({"status": "missed g-recaptcha-response header"})
        logger_recaptcha_failure.info("Missed g-recaptcha-response header for checking recaptcha", extra=extra)
        return False

    try:
        response = post(
            settings.RECAPTCHA_CONFIG.get('g_recaptcha_url'),
            data={
                'secret': settings.RECAPTCHA_CONFIG.get('g_recaptcha_secret'),
                'response': recaptcha_response,
            },
            timeout=5,
        )
        if response.status_code != 200:
            logger.error('Response HTTP code: {}; body: {}'.format(
                response.status_code, response.content,
            ))
            return True

        google_resp = response.json()
        if google_resp.get('score', 0) < settings.RECAPTCHA_CONFIG.get('recaptcha_min_score'):
            extra.update({
                "g-recaptcha-response": recaptcha_response,
                "google_response": google_resp,
                "status": "checked"
            })
            logger_recaptcha_failure.info("Information about not passing recaptcha", extra=extra)

            return False
    except Exception as e:
        logger.info(e)

    return True
