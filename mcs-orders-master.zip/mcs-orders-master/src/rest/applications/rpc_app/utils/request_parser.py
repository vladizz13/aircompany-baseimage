from enum import Enum
from typing import Type


def parse_key_values(request, enum: Type[Enum]) -> dict:
    """
    Достает словарь из параметров flask request'a вида value[key], value[key2]
    """
    _result = dict()
    for key, value in request.args.items():
        for member in enum._value2member_map_:
            if member in key:
                _result.update({member: value})
    return _result
