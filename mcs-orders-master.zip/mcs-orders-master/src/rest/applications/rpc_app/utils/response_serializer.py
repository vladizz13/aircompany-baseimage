from base.use_case import BaseUseCaseResponse
from base.exception import ApplicationError
from typing import Callable


def serialize(
        response: BaseUseCaseResponse,
        value_serialize_function: Callable = None,
        rpc_response: bool = False
) -> dict:
    if bool(response):
        return dict(response.value) if not value_serialize_function else value_serialize_function(response.value)
    else:
        occured_errors = []
        first_error = None
        for row in response.errors:
            if rpc_response:
                setattr(row, 'status', 200)
            if not first_error:
                first_error = row
            occured_errors.append({
                'code': getattr(row, 'code', None),
                'message': getattr(row, 'message', str(row)),
                'data': getattr(row, 'data', None),
                'status': getattr(row, 'status', None),
                'type': str(type(row))
            })
        if isinstance(first_error, ApplicationError):
            raise first_error
        error = ApplicationError(
            status=getattr(first_error, 'status', ApplicationError.status),
            code=getattr(first_error, 'code', ApplicationError.code),
            message=getattr(first_error, 'message', ApplicationError.message),
            data={
                'errors': occured_errors
            }
        )
        raise error
