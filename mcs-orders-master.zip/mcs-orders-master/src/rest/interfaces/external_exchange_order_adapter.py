from typing import List
from uuid import UUID

from flask import Response

from adapter.monoapp import MonoAppAdapter
from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.sirena_bulk_adapter import SirenaAdapter
from adapter.tais_adapter import TaisInternalAdapter
from base.adapter import BaseAdapter
from domain import DomainOrder
from domain.currency_rates import DomainCurrencyRates
from domain.exchange import DomainExchange
from libs.db_gateway import get_db_gateway
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.save.utils.currency_rates import CurrencyRates
from rest.settings.settings import TELEGRAM_JETTY_CONFIG


class ExternalExchangeOrderAdapter(BaseAdapter):
    """
    Интерфейс для обмена заказов
    """

    def __init__(self):
        self.order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)
        self.exchange_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainExchange)

    def cancel_order_exchange(self, exchange_uuid: UUID) -> Response:
        """Отмена обмена заказа"""
        from use_cases.orders.exchange.cancel.cancel_use_case import ExchangeCancelUseCase
        from use_cases.orders.exchange.cancel.cancel_request import ExchangeCancelRequest

        request = ExchangeCancelRequest(exchange_uuid=exchange_uuid)

        use_case = ExchangeCancelUseCase(
            exchange_repo=self.exchange_repo,
            internal_payments_adapter=PaymentsInternalAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)

    def start_order_exchange(self, exchange_uuid: UUID, success_url: str, fail_url: str) -> Response:
        """Начало флоу оплаты обмена"""
        from use_cases.orders.exchange.start.start_use_case import ExchangeStartUseCase
        from use_cases.orders.exchange.start.start_request import ExchangeStartRequest

        request = ExchangeStartRequest(exchange_uuid=exchange_uuid, success_url=success_url, fail_url=fail_url)

        use_case = ExchangeStartUseCase(
            order_repo=self.order_repo,
            exchange_repo=self.exchange_repo,
            internal_order_adapter=InternalOrderAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)

    def exchange_order_v1(self, order_uuid: UUID) -> Response:
        """
        Прокси метод для обмена брони в таисе
        """
        from use_cases.orders.exchange.v1.exchange_v1_request import ExchangeOrderV1Request
        from use_cases.orders.exchange.v1.exchange_v1_use_case import ExchangeOrderV1UseCase
        from use_cases.orders.exchange.v1.exchange_v1_response import ExchangeOrderV1Response
        from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue

        request: ExchangeOrderV1Request = ExchangeOrderV1Request(
            order_uuid=order_uuid
        )

        use_case: ExchangeOrderV1UseCase = ExchangeOrderV1UseCase(
            order_repo=self.order_repo,
            internal_order_adapter=InternalOrderAdapter,
            orders_queue=SaveOrdersQueue(
                gateway=get_db_gateway(label='redis')
            ),
            tais_adapter=TaisInternalAdapter()
        )
        response: ExchangeOrderV1Response = use_case.execute(request)
        return self._create_flask_response(response)

    def get_order_exchange_data(self, order_uuid: UUID) -> Response:
        """
        Получение данных заказа для обмена
        """
        from use_cases.orders.exchange.v2.exchange_v2_request import ExchangeOrderV2Request
        from use_cases.orders.exchange.v2.exchange_v2_use_case import ExchangeOrderV2UseCase

        request = ExchangeOrderV2Request(order_uuid=order_uuid)

        use_case = ExchangeOrderV2UseCase(
            order_repo=self.order_repo,
            exchange_repo=self.exchange_repo,
            internal_order_adapter=InternalOrderAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)

    def get_order_exchange_options(
            self, order_uuid: UUID, passenger_ids: List[str], flights: List[dict]
    ) -> Response:
        """
        Получение вариантов для обмена заказа
        """
        from use_cases.orders.exchange.options.options_request import ExchangeOptionsRequest, FlightExchangeData
        from use_cases.orders.exchange.options.options_use_case import ExchangeOptionsUseCase
        currency_adapter = CurrencyRates(
            currency_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainCurrencyRates)
        )
        request = ExchangeOptionsRequest(
            order_uuid=order_uuid,
            passenger_ids=passenger_ids,
            flights=[FlightExchangeData.parse_obj(f) for f in flights]
        )

        use_case = ExchangeOptionsUseCase(
            order_repo=self.order_repo,
            exchange_repo=self.exchange_repo,
            internal_order_adapter=InternalOrderAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            sirena_adapter=SirenaAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            currency_adapter=currency_adapter,
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)

    def confirm_order_exchange(
            self,
            order_uuid: UUID,
            passenger_ids: List[str],
            flights: List[dict],
    ) -> Response:
        """
        Подтверждение обмена заказа
        """
        from use_cases.orders.exchange.confirm.confirm_request import ExchangeConfirmRequest
        from use_cases.orders.exchange.confirm.confirm_use_case import ExchangeConfirmUseCase
        currency_adapter = CurrencyRates(
            currency_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainCurrencyRates)
        )
        request = ExchangeConfirmRequest(
            order_uuid=order_uuid,
            passenger_ids=passenger_ids,
            flights=flights,
        )

        use_case = ExchangeConfirmUseCase(
            order_repo=self.order_repo,
            exchange_repo=self.exchange_repo,
            internal_order_adapter=InternalOrderAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            currency_adapter=currency_adapter,
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)

    def get_order_exchange_status(self, exchange_uuid: UUID) -> Response:
        """Получение статуса обмена заказа"""
        from use_cases.orders.exchange.status.status_use_case import ExchangeStatusUseCase
        from use_cases.orders.exchange.status.status_request import ExchangeStatusRequest

        request = ExchangeStatusRequest(exchange_uuid=exchange_uuid)

        use_case = ExchangeStatusUseCase(
            order_repo=self.order_repo,
            exchange_repo=self.exchange_repo,
            internal_order_adapter=InternalOrderAdapter(),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        )

        response = use_case.execute(request)
        return self._create_flask_response(response)
