from typing import List, Dict, AnyStr, Optional
from uuid import UUID

from flask import Response
from mcs_oauth_client import DomainOauth

from adapter.astra_adapter import AstraInternalAdapter
from adapter.file_storage_adapter import FileStorageAdapter
from adapter.service_desk import JiraServiceDeskAdapter
from adapter.monoapp import MonoAppAdapter
from adapter.service_agent import ServiceAgentAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.tais_adapter import TaisInternalAdapter
from base.adapter import BaseAdapter
from domain import DomainOrder
from domain.exchange import DomainExchange
from domain.origin_transaction import DomainOriginTransaction
from domain.refunds import DomainRefund
from domain.pd_changes import DomainPDChanges
from domain.release_seats import DomainReleaseSeats
from libs.db_gateway import get_db_gateway
from libs.serializers.dot_path import DotPathSerializer
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.settings.settings import STORAGE_CONFIG
from rest.settings.settings import JIRA_SERVICE_DESK
from use_cases.orders.refund.initiate_order_refund.initiate_order_refund_response import InitiateOrderRefundResponse
from use_cases.orders.refund.submit_order_refund_request.resp_obj import SubmitOrderRefundRequestRespObj
from use_cases.orders.user.change_personal_data.submit_request.response import SubmitChangePDResponse
from use_cases.orders.withdraw.initiate_order_release_seats.initiate_order_release_seats_response import (
    InitiateOrderReleaseSeatsResponse
)
from use_cases.orders.withdraw.submit_order_release_seats_request.resp_obj import (
    SubmitOrderReleaseSeatsRespObj
)
from use_cases.orders.withdraw.get_available_segments.response_obj import (
    WithdrawGetAvailableSegmentsResponse,
)
from use_cases.orders.user.change_personal_data.check_possibility.response import CheckPossibilityChangePDResponse
from use_cases.orders.user.change_personal_data.shape_request.response import ShapeChangePDReqResponse


class ExternalOrderAdapter(BaseAdapter):
    """
    Интерфейс для поиска заказов
    """

    def __init__(self):
        self.order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)
        self.exchange_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainExchange)

    def find_orders_app_context(
        self, fields: List, filters: Dict, page: Dict, sort: List, lang: AnyStr = 'ru'
    ) -> Response:
        """
        Поиск заказа в скоупе приложения
        :param fields: Поля для выдачи при сериализации
        :param filters: Фильтры поиска заказа
        :param sort: Сортировка выдачи
        :param page: Пагинация
        :param lang: Язык городов сегментов

        :return response: Response объект flask
        """
        from use_cases.orders.search.external.app_context.search_order_app_context_request import (
            SearchOrderAppContextRequest,
        )
        from use_cases.orders.search.external.app_context.search_order_app_context_use_case import (
            SearchOrderAppContextUseCase,
        )

        request = SearchOrderAppContextRequest(
            fields=fields, filters=filters, page=page, sort=sort, lang=lang
        )

        use_case = SearchOrderAppContextUseCase(
            order_repo=self.order_repo,
            mono_app_adapter=MonoAppAdapter(),
            astra_adapter=AstraInternalAdapter(),
            sirena_adapter=SirenaInternalAdapter(),
            serializer=DotPathSerializer,
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
            service_agent_adapter=ServiceAgentAdapter(),
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def find_open_orders_app_context(
        self, locator: Optional[str] = None, last_name: Optional[str] = None, lang: AnyStr = 'ru'
    ) -> Response:
        """
        Поиск заказа с сегментами, на которые открыта регистрация в скоупе приложения
        :param locator: Номер документа/билета/брони
        :param last_name: Фамилия пассажира
        :param lang: Язык городов сегментов
        :return response: Response объект flask
        """
        from use_cases.orders.search.checkin_open.app_context.search_open_order_app_context_request import (
            SearchOpenOrderAppContextRequest,
        )
        from use_cases.orders.search.checkin_open.app_context.search_open_order_app_context_use_case import (
            SearchOpenOrderAppContextUseCase,
        )

        request = SearchOpenOrderAppContextRequest(
            locator=locator, last_name=last_name, lang=lang
        )

        use_case = SearchOpenOrderAppContextUseCase(
            order_repo=self.order_repo,
            astra_adapter=AstraInternalAdapter(),
            sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            internal_order_adapter=InternalOrderAdapter
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def find_orders_user_context(
        self, user: DomainOauth, filters: Dict, page: Dict, lang: AnyStr = 'ru'
    ) -> Response:
        """
        Поиск заказа в скоупе пользователя
        :param user: Oauth пользователь
        :param filters: Фильтры поиска заказа
        :param page: Пагинация
        :param lang: Язык городов сегментов
        :return response: Response объект flask
        """
        from use_cases.orders.search.external.user_context.search_order_user_context_request import (
            SearchOrderUserContextRequest,
        )
        from use_cases.orders.search.external.user_context.search_order_user_context_use_case import (
            SearchOrderUserContextUseCase,
        )

        request = SearchOrderUserContextRequest(
            user=user, filters=filters, page=page, lang=lang
        )

        use_case = SearchOrderUserContextUseCase(
            order_repo=self.order_repo,
            mono_app_adapter=MonoAppAdapter(),
            serializer=DotPathSerializer,
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def find_open_orders_user_context(
        self, user: DomainOauth, lang: AnyStr = 'ru'
    ) -> Response:
        """
        Поиск заказа с сегментами, на которые открыта регистрация в скоупе пользователя
        :param user: Oauth пользователь
        :param lang: Язык городов сегментов
        :return response: Response объект flask
        """
        from use_cases.orders.search.checkin_open.user_context.search_open_order_user_context_request import (
            SearchOpenOrderUserContextRequest,
        )
        from use_cases.orders.search.checkin_open.user_context.search_open_order_user_context_use_case import (
            SearchOpenOrderUserContextUseCase,
        )

        request = SearchOpenOrderUserContextRequest(
            user=user, lang=lang
        )

        use_case = SearchOpenOrderUserContextUseCase(
            order_repo=self.order_repo,
            mono_app_adapter=MonoAppAdapter(),
            astra_adapter=AstraInternalAdapter(),
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def add_order(
        self,
        user: DomainOauth,
        rloc: str,
        last_name: str,
    ) -> Response:
        """
        Добавление заказа пользователю
        :param user: Oauth пользователь
        :param rloc: rloc заказа
        :param last_name: Фамилия одного из пассажиров
        :return:
        """
        from use_cases.orders.user.add_order.add_order_request import AddOrderRequest
        from use_cases.orders.user.add_order.add_order_use_case import AddOrderUseCase

        request = AddOrderRequest(rloc=rloc, last_name=last_name, oauth=user)

        use_case = AddOrderUseCase(
            order_repo=self.order_repo,
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def hide_order(
        self,
        user: DomainOauth,
        order_uuid: str,
    ) -> Response:
        """
        Удаление (скрытие) заказа пользователя
        :param user: Oauth пользователь
        :param order_uuid: order_uuid заказа
        :return:
        """
        from use_cases.orders.user.hide_order.hide_order_request import HideOrderRequest
        from use_cases.orders.user.hide_order.hide_order_use_case import HideOrderUseCase

        request = HideOrderRequest(order_uuid=order_uuid, oauth=user)

        use_case = HideOrderUseCase(order_repo=self.order_repo)

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def add_loyalty_card(self, filters: Dict, passengers: List[Dict]):
        """
        Добавление карты лояльности пользователю
        :param filters: Фильтры для поиска заказа
        {
            'rloc': 'much_wow'
        }
        :param passengers:
        [
            {
                "last_name": "Половникова",
                "loyalty_card": "123321",
                "phone_number": "79068243200",
                "email": "LESYA2049@YANDEX.RU",
                "doc_number": "3708320226"
            }
        ]
        :return:
        """
        from use_cases.orders.loyalty.add_card.add_card_request import (
            AddLoyaltyCardRequest,
        )
        from use_cases.orders.loyalty.add_card.add_card_use_case import (
            AddLoyaltyCardUseCase,
        )

        request = AddLoyaltyCardRequest(filters=filters, passengers_data=passengers)

        use_case = AddLoyaltyCardUseCase(
            order_repo=self.order_repo,
            sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def get_itinerary_receipt_download_link(
        self, order_uuid: str, passenger_last_name: str,
    ) -> Response:
        """
        :param order_uuid: уникальный идентификатор заказа
        :param passenger_last_name: фамилия пассажира
        :return: Response-объект flask-а
        """
        from use_cases.orders.itinerary_receip.get_itinerary_receipt_request import (
            GetItineraryReceiptRequest,
        )
        from use_cases.orders.itinerary_receip.get_itinerary_receipt_use_case import (
            GetItineraryReceiptUseCase,
        )

        request = GetItineraryReceiptRequest(
            order_uuid=order_uuid, last_name=passenger_last_name, tais_look_up=True
        )

        use_case = GetItineraryReceiptUseCase(
            order_repo=self.order_repo,
            sirena_adapter=SirenaInternalAdapter(),
            tais_adapter=TaisInternalAdapter(),
            filestorage_adapter=FileStorageAdapter(**STORAGE_CONFIG),
            save_order_func=InternalOrderAdapter.save,
            change_pd_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainPDChanges),
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def get_initial_data_for_start_refund(self, order_uuid: UUID) -> Response:
        """
        :param order_uuid: уникальный идентификатор заказа
        :return: Response-объект flask-а
        """
        from use_cases.orders.refund.get_initial_data.get_initial_data_request import (
            RefundGetInitialDataRequest,
        )
        from use_cases.orders.refund.get_initial_data.get_initial_data_use_case import (
            RefundGetInitialDataUseCase,
        )

        request = RefundGetInitialDataRequest(order_uuid=order_uuid)

        use_case = RefundGetInitialDataUseCase(
            order_repo=self.order_repo,
            internal_order_adapter=InternalOrderAdapter,
        )

        response = use_case.execute(request)

        return self._create_flask_response(response)

    def initiate_order_refund(self, order_uuid: UUID, data: Dict[str, str]) -> Response:
        """
        Прослойка (для соблюдения DIP) для вызова бизнес логики формирования заявки на возврат
        :param order_uuid: уникальный идентификатор заказа
        :param data: набор данных для формирования заявки на возврат заказа
        :return: Response-объект flask-а
        """
        from use_cases.orders.refund.initiate_order_refund.initiate_order_refund_request import (
            InitiateOrderRefundRequest,
        )
        from use_cases.orders.refund.initiate_order_refund.initiate_order_refund_use_case import (
            InitiateOrderRefundUseCase,
        )

        request: InitiateOrderRefundRequest = InitiateOrderRefundRequest(order_uuid, **data)

        use_case: InitiateOrderRefundUseCase = InitiateOrderRefundUseCase(
            order_repo=self.order_repo,
            mono_app_adapter=MonoAppAdapter(),
            redis_adapter=get_db_gateway('redis'),
            refunds_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainRefund),
            service_desk=JiraServiceDeskAdapter(**JIRA_SERVICE_DESK),
        )

        response: InitiateOrderRefundResponse = use_case.execute(request)

        return self._create_flask_response(response)

    def submit_order_refund_request(self, input_data) -> Response:
        """
        Прослойка (для соблюдения DIP) для вызова бизнес логики оформления заявки на возврат
        :param input_data: набор данных для оформления заявки на возврат
        :return: Response-объект flask-а
        """
        from use_cases.orders.refund.submit_order_refund_request.req_obj import (
            SubmitOrderRefundRequestReqObj,
        )
        from use_cases.orders.refund.submit_order_refund_request.submit_order_refund_request_use_case import (
            SubmitOrderRefundRequestUseCase,
        )

        request_obj: SubmitOrderRefundRequestReqObj = SubmitOrderRefundRequestReqObj(**input_data)

        use_case: SubmitOrderRefundRequestUseCase = SubmitOrderRefundRequestUseCase(
            order_repo=self.order_repo,
            internal_order_adapter=InternalOrderAdapter,
            refunds_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainRefund),
            redis_adapter=get_db_gateway('redis'),
            service_desk=JiraServiceDeskAdapter(**JIRA_SERVICE_DESK),
            sirena_adapter=SirenaInternalAdapter()
        )

        response: SubmitOrderRefundRequestRespObj = use_case.execute(request_obj)

        return self._create_flask_response(response)

    def get_segments_available_for_withdraw(self, order_uuid: UUID) -> Response:
        """
        Прокси, для соблюдения 'DIP'
        :param order_uuid: уникальный идентификатор заказа
        :return: Response-объект flask-а
        """
        from use_cases.orders.withdraw.get_available_segments.request_obj import (
            WithdrawGetAvailableSegmentsRequest,
        )
        from use_cases.orders.withdraw.get_available_segments.use_case import (
            WithdrawGetAvailableSegmentsUseCase,
        )

        request: WithdrawGetAvailableSegmentsRequest = WithdrawGetAvailableSegmentsRequest(order_uuid=order_uuid)

        use_case: WithdrawGetAvailableSegmentsUseCase = WithdrawGetAvailableSegmentsUseCase(
            order_repo=self.order_repo,
            sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter()
        )

        response: WithdrawGetAvailableSegmentsResponse = use_case.execute(request)
        return self._create_flask_response(response)

    def check_possibility_change_personal_data(self, input_data: Dict) -> Response:
        """
        Проверка, возможно ли для пассажира изменить перс данные в заказе
        :param input_data: входные данные. пример:
        {'order_uuid': '286355b6-33ee-46b8-b0af-02836339d10a', 'passenger_id': '1'}
        :return:
        """
        from use_cases.orders.user.change_personal_data.check_possibility.request import (
            CheckPossibilityChangePDRequest
        )
        from use_cases.orders.user.change_personal_data.check_possibility.use_case import (
            CheckPossibilityChangePDUseCase,
        )

        request: CheckPossibilityChangePDRequest = CheckPossibilityChangePDRequest(**input_data)

        use_case: CheckPossibilityChangePDUseCase = CheckPossibilityChangePDUseCase(
            order_repo=self.order_repo,
            pd_changes_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainPDChanges),
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,
        )

        response: CheckPossibilityChangePDResponse = use_case.execute(request)
        return self._create_flask_response(response)

    def shape_change_personal_data_request(self, input_data: Dict) -> Response:
        """
        Прокси-интерфейс, для соблюдения 'DIP'.
        :param input_data: входные данные
        :return:
        """
        from use_cases.orders.user.change_personal_data.shape_request.request import (
            ShapeChangePDRequest
        )
        from use_cases.orders.user.change_personal_data.shape_request.use_case import (
            ShapeChangePDRequestUseCase,
        )

        request: ShapeChangePDRequest = ShapeChangePDRequest(**input_data)

        use_case: ShapeChangePDRequestUseCase = ShapeChangePDRequestUseCase(
            order_repo=self.order_repo,
            pd_changes_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainPDChanges),
            mono_app_adapter=MonoAppAdapter(),
            redis_adapter=get_db_gateway('redis'),
        )

        response: ShapeChangePDReqResponse = use_case.execute(request)
        return self._create_flask_response(response)

    def submit_change_personal_data_request(self, input_data: Dict) -> Response:
        """
        Прокси-интерфейс, для соблюдения 'DIP'
        :param input_data: входные данные
        :return:
        """
        from use_cases.orders.user.change_personal_data.submit_request.request import (
            SubmitChangePDRequest
        )
        from use_cases.orders.user.change_personal_data.submit_request.main_use_case import (
            SubmitChangePDRequestUseCase,
        )

        request: SubmitChangePDRequest = SubmitChangePDRequest(**input_data)

        use_case: SubmitChangePDRequestUseCase = SubmitChangePDRequestUseCase(
            order_repo=self.order_repo,
            transaction_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOriginTransaction),
            pd_changes_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainPDChanges),
            mono_app_adapter=MonoAppAdapter(),
            sirena_adapter=SirenaInternalAdapter(),
            redis_adapter=get_db_gateway('redis'),
        )

        response: SubmitChangePDResponse = use_case.execute(request)
        return self._create_flask_response(response)

    def initiate_order_release_seats(self, order_uuid: UUID, data: Dict[str, str]) -> Response:
        """
        Прослойка (для соблюдения DIP) для вызова бизнес логики формирования заявки на аннулирования мест.
        :param order_uuid: уникальный идентификатор заказа
        :param data: набор данных для формирования заявки на возврат заказа
        :return: Response-объект flask-а
        """
        from use_cases.orders.withdraw.initiate_order_release_seats.initiate_order_release_seats_request import (
            InitiateOrderReleaseSeatsRequest,
        )
        from use_cases.orders.withdraw.initiate_order_release_seats.initiate_order_release_seats_use_case import (
            InitiateOrderReleaseSeatsUseCase,
        )

        request: InitiateOrderReleaseSeatsRequest = InitiateOrderReleaseSeatsRequest(order_uuid, **data)

        use_case: InitiateOrderReleaseSeatsUseCase = InitiateOrderReleaseSeatsUseCase(
            order_repo=self.order_repo,
            mono_app_adapter=MonoAppAdapter(),
            redis_adapter=get_db_gateway('redis'),
            release_seats_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainReleaseSeats),
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter
        )

        response: InitiateOrderReleaseSeatsResponse = use_case.execute(request)
        return self._create_flask_response(response)

    def submit_order_release_seats(self, data: Dict[str, str]) -> Response:
        """
        Прослойка (для соблюдения DIP) для вызова бизнес логики формирования заявки на аннулирования мест.
        :param data: набор данных для формирования заявки на возврат заказа
        :return: Response-объект flask-а
        """
        from use_cases.orders.withdraw.submit_order_release_seats_request.req_obj import (
            SubmitOrderReleaseSeatsRequestObj,
        )
        from use_cases.orders.withdraw.submit_order_release_seats_request.submit_order_refund_request_use_case import (
            SubmitOrderReleaseSeatsUseCase,
        )

        request: SubmitOrderReleaseSeatsRequestObj = SubmitOrderReleaseSeatsRequestObj(**data)

        use_case: SubmitOrderReleaseSeatsUseCase = SubmitOrderReleaseSeatsUseCase(
            order_repo=self.order_repo,
            internal_order_adapter=InternalOrderAdapter,
            release_seats_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainReleaseSeats),
            redis_adapter=get_db_gateway('redis'),
            sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter()
        )

        response: SubmitOrderReleaseSeatsRespObj = use_case.execute(request)
        return self._create_flask_response(response)
