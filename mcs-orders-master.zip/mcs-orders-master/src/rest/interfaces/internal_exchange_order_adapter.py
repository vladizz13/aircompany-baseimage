from typing import Union
from uuid import UUID

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.service_agent import ServiceAgentAdapter
from base.adapter import BaseAdapter
from domain import DomainOrder
from domain.exchange import DomainExchange
from libs.db_gateway import get_db_gateway
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.applications.rpc_app.utils.response_serializer import serialize
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.settings.settings import TELEGRAM_JETTY_CONFIG
from use_cases.orders.exchange.send_telegram.message_generators import (
    SendErrorPaymentExpiredMessageGenerator,
    SendErrorWaitEMDMessageGenerator,
    SendErrorPaymentConfirmMessageGenerator,
)
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue


class InternalExchangeOrderAdapter(BaseAdapter):

    @staticmethod
    def exchange_clear_segments(exchange_uuid: Union[str, UUID]):
        from use_cases.orders.exchange.clear_segments.use_case import (
            ExchangeClearSegmentsRequest,
            ExchangeClearSegmentsUseCase,
        )
        gateway = get_db_gateway()
        request = ExchangeClearSegmentsRequest(exchange_uuid=exchange_uuid)
        response = ExchangeClearSegmentsUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            internal_order_adapter=InternalOrderAdapter(),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            service_agent_adapter=ServiceAgentAdapter(),
            save_order_queue=SaveOrdersQueue(gateway=get_db_gateway(label='redis')),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG)
        ).execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def payments_confirm(
        exchange_uuid: Union[str, UUID],
        exchange_pricing_response: dict,
    ):
        from use_cases.orders.exchange.payment_confirm.use_case import (
            ExchangePaymentConfirmRequest,
            ExchangePaymentConfirmUseCase,
        )
        gateway = get_db_gateway()
        request = ExchangePaymentConfirmRequest(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
        response = ExchangePaymentConfirmUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            internal_order_adapter=InternalOrderAdapter(),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        ).execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def wait_emd(
        exchange_uuid: Union[str, UUID],
        exchange_pricing_response: dict,
    ):
        from use_cases.orders.exchange.wait_emd.use_case import WaitEMDUseCase
        from use_cases.orders.exchange.wait_emd.request import WaitEMDRequest
        gateway = get_db_gateway()
        request = WaitEMDRequest(
            exchange_uuid=exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )
        response = WaitEMDUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            internal_order_adapter=InternalOrderAdapter(),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            internal_sirena_adapter=SirenaInternalAdapter(),
            internal_payments_adapter=PaymentsInternalAdapter(),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
        ).execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def send_error_wait_emd(exchange_uuid: Union[str, UUID]):
        from use_cases.orders.exchange.send_telegram.request import ExchangeSendErrorRequest
        from use_cases.orders.exchange.send_telegram.use_case import ExchangeSendErrorUseCase

        gateway = get_db_gateway()
        request = ExchangeSendErrorRequest(exchange_uuid=exchange_uuid, data={})
        response = ExchangeSendErrorUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
            message_generator=SendErrorWaitEMDMessageGenerator,
        ).execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def send_error_payment_confirm(exchange_uuid: Union[str, UUID]):
        from use_cases.orders.exchange.send_telegram.request import ExchangeSendErrorRequest
        from use_cases.orders.exchange.send_telegram.use_case import ExchangeSendErrorUseCase

        gateway = get_db_gateway()
        request = ExchangeSendErrorRequest(exchange_uuid=exchange_uuid, data={})
        response = ExchangeSendErrorUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
            message_generator=SendErrorPaymentConfirmMessageGenerator,
        ).execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def send_error_payment_expired(exchange_uuid: Union[str, UUID], data: dict = None):
        from use_cases.orders.exchange.send_telegram.request import ExchangeSendErrorRequest
        from use_cases.orders.exchange.send_telegram.use_case import ExchangeSendErrorUseCase

        gateway = get_db_gateway()
        request = ExchangeSendErrorRequest(exchange_uuid=exchange_uuid, data=data or {})
        response = ExchangeSendErrorUseCase(
            order_repo=GenericMongoRepository(gateway=gateway, instance=DomainOrder),
            exchange_repo=GenericMongoRepository(gateway=gateway, instance=DomainExchange),
            messenger=TelegramMessenger(**TELEGRAM_JETTY_CONFIG),
            message_generator=SendErrorPaymentExpiredMessageGenerator,
        ).execute(request)
        return serialize(response, rpc_response=True)
