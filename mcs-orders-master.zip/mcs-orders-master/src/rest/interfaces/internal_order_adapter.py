import datetime
from typing import Union, List, Dict, Optional

from base.adapter import BaseAdapter
from base.use_case import BaseUseCaseResponse
from adapter.file_storage_adapter import FileStorageAdapter
from adapter.monoapp import MonoAppAdapter
from adapter.service_agent import ServiceAgentAdapter
from domain import DomainOrder
from domain.refunds import DomainRefund
from domain.prorate import DomainProrate
from domain.origin_transaction import DomainOriginTransaction
from domain.currency_rates import DomainCurrencyRates
from domain.pd_changes import DomainPDChanges
from adapter.tais_adapter import TaisInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from libs.serializers.dot_path import DotPathSerializer
from adapter.astra_adapter import AstraInternalAdapter
from use_cases.orders.save.utils.currency_rates import CurrencyRates
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue
from libs.db_gateway import get_db_gateway
from use_cases.orders.search.libs.rloc_transliteration import RlocTransliteration
from rest.applications.rpc_app.utils.response_serializer import serialize
from rest.settings import settings


class InternalOrderAdapter(BaseAdapter):
    """
    Интерфейс для работы с заказами
    """
    @staticmethod
    def save(
            raw_order: dict,
            provider: str,
            received: float,
            message_id: str,
            deferred_save: bool = True,
            return_full_response: bool = False,
            save_origin_transaction: bool = True,
    ):
        """
        Сохранение заказа
        :param raw_order: Сырая транзакция
        :param provider: Источник транзакции
        :param received: Время поступления транзакции
        :param message_id: Идентификатор транзакции от провайдера
        :param deferred_save: Отложенное сохранение заказа
        :param return_full_response: Вернет полный SaveOrderResponse объект
        :param save_origin_transaction: Сохранять оригинальную транзакцию в базу
        """
        from use_cases.orders.save.save_order.save_order_use_case import SaveOrderUseCase
        from use_cases.orders.save.save_order.save_order_use_case import SaveOrderRequest

        request = SaveOrderRequest(
            order=raw_order,
            provider=provider,
            received=received,
            message_id=message_id,
        )

        gateway = get_db_gateway()

        save_order_queue: Union[SaveOrdersQueue, None] = None
        if deferred_save and settings.ENABLE_DEFERRED_SAVE:
            save_order_queue = SaveOrdersQueue(
                gateway=get_db_gateway(label='redis')
            )

        use_case = SaveOrderUseCase(
            order_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainOrder
            ),
            prorate_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainProrate
            ),
            origin_transactions_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainOriginTransaction
            ),
            change_pd_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainPDChanges
            ),
            currency_adapter=CurrencyRates(
                currency_repo=GenericMongoRepository(
                    gateway=gateway,
                    instance=DomainCurrencyRates
                )
            ),
            mono_app_adapter=MonoAppAdapter(),
            save_orders_queue=save_order_queue,
            sirena_adapter=SirenaInternalAdapter(),
            service_agent_adapter=ServiceAgentAdapter(),
            save_origin_transaction=save_origin_transaction,
            rloc_transliteration=RlocTransliteration(),
            redis=get_db_gateway("redis")
        )

        response = use_case.execute(request)
        if return_full_response:
            return response

        return serialize(response, rpc_response=True)

    @staticmethod
    def archive_orders(timestamp: int):
        """
        Архивирование заказов
        Проставляет статусы заказам в Х (архивирует их)
        :param timestamp: Дата, с которой нужно высчитать дельту в прошлое и архивировать заказы
        :return:
        """
        from use_cases.orders.save.archive_order.archive_order_request import ArchiveOrdersRequest
        from use_cases.orders.save.archive_order.archive_order_usecase import ArchiveOrderUseCase

        request = ArchiveOrdersRequest(
            timestamp=timestamp
        )

        use_case = ArchiveOrderUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            )
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def load_modified_orders(hours_offset: int = 2):
        """
        Загрузка измененных заказов за последние hours_offset часов
        """
        from use_cases.orders.save.additional_loader.use_case import LoadModifiedOrdersUseCase
        from use_cases.orders.save.additional_loader.use_case import LoadModifiedOrdersRequest

        offset = datetime.datetime.now()
        offset = offset - datetime.timedelta(hours=hours_offset)

        r = LoadModifiedOrdersRequest(offset=offset)
        uc = LoadModifiedOrdersUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder,
            ),
            sirena_adapter=SirenaInternalAdapter(),
            save_order_func=InternalOrderAdapter().save,
            redis=get_db_gateway("redis")
        )
        response = uc.execute(r)
        return serialize(response, rpc_response=True)

    @staticmethod
    def search(filters: dict, fields: list, sort: list, page: dict, lang: str):
        """
        Поиск заказа
        :param filters: Фильтры поиска
        :param fields: Поля для сериализации
        :param sort: Сортировка
        :param page: Пагинация
        :param lang: Язык перевода
        """
        from use_cases.orders.search.internal.search_order_internal_request import SearchOrderInternalRequest
        from use_cases.orders.search.internal.search_order_internal_use_case import SearchOrderInternalUseCase

        request = SearchOrderInternalRequest(
            filters=filters,
            fields=fields,
            sort=sort,
            page=page,
            lang=lang
        )

        use_case = SearchOrderInternalUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            astra_adapter=AstraInternalAdapter(),
            serializer=DotPathSerializer,
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
            service_agent_adapter=ServiceAgentAdapter(),
            mono_app_adapter=MonoAppAdapter()
        )
        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    def update_from_booking_cart(self, cart_data: dict):
        """
        Если заказ имеется в базе: Обогащение заказа данными корзины букинга
        Если заказ не найден: Сохранение заказа по order_id из корзины и обогащение данными корзины
        :param cart_data: Данные корзины
        :return:
        """
        from use_cases.orders.booking.update_from_cart.update_from_cart_use_case import UpdateFromCartUseCase
        from use_cases.orders.booking.update_from_cart.update_from_cart_request import UpdateFromCartRequest

        request = UpdateFromCartRequest(
            cart_data=cart_data
        )

        use_case = UpdateFromCartUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            tais_adapter=TaisInternalAdapter(),
            order_save_func=self.save,
        )

        response = use_case.execute(request)
        return serialize(response)

    def update_from_sirena_grs(
            self,
            order_uuid: str,
            deferred: bool = False,
            skip_alien_gds: bool = False
    ) -> Union[Dict, BaseUseCaseResponse]:
        """
        Принудительное обновления заказа данными из SirenaGRS
        :param order_uuid: data.order_uuid заказа из базы
        :param deferred: Отложеное сохранение, положим заказ в очередь
        :param skip_alien_gds: Пропускать чужие GDS
        :return:
        """
        from use_cases.orders.update.sirenagrs_force_update_request import SirenaGRSForceUpdateRequest
        from use_cases.orders.update.sirenagrs_force_update_use_case import SirenaGRSForceUpdateUseCase

        request = SirenaGRSForceUpdateRequest(
            order_uuid=order_uuid,
            deferred=deferred,
            skip_alien_gds=skip_alien_gds
        )

        use_case = SirenaGRSForceUpdateUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            sirena_adapter=SirenaInternalAdapter(),
            order_save_func=self.save,
            save_order_queue=SaveOrdersQueue(
                gateway=get_db_gateway(label='redis')
            )
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def add_loyalty_card(filters: Dict, passengers: List[Dict]):
        """
        Добавление карты лояльности пользователю
        :param filters: Фильтры для поиска заказа
        {
            "rloc": "much_wow"
        }
        :param passengers:
        [
            {
                "last_name": "Половникова",
                "loyalty_card": "123321",
                "phone_number": "79068243200",
                "email": "LESYA2049@YANDEX.RU",
                "doc_number": "3708320226"
            }
        ]
        :return:
        """
        from use_cases.orders.loyalty.add_card.add_card_request import AddLoyaltyCardRequest
        from use_cases.orders.loyalty.add_card.add_card_use_case import AddLoyaltyCardUseCase

        request = AddLoyaltyCardRequest(
            filters=filters,
            passengers_data=passengers
        )

        use_case = AddLoyaltyCardUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            sirena_adapter=SirenaInternalAdapter(),
            mono_app_adapter=MonoAppAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def get_order_detail_price(ticket_number: str, last_name: str, rloc: Optional[str] = None):
        """
        Получение детализированной цены по заказу
        Мили/EMD/Рубли
        """
        from use_cases.orders.loyalty.get_order_detail_price.get_order_detail_price_request import (
            GetOrderDetailPriceRequest
        )
        from use_cases.orders.loyalty.get_order_detail_price.get_order_detail_price_use_case import (
            GetOrderDetailPriceUseCase
        )

        request = GetOrderDetailPriceRequest(rloc=rloc, lastname=last_name, ticket_number=ticket_number)

        use_case = GetOrderDetailPriceUseCase(
            order_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder),
            transaction_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOriginTransaction),
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def admin_add_contacts(rloc: str, last_name: str, contacts: List[dict]):
        """
        Добавляет контакты в заказ.
        :param rloc: Rloc заказа
        :param last_name: Фамилия одно из пассажиров
        :param contacts: Контакты для добавления
        [
            {
                "contact": "jony.ive@apple.com,
                "confirmed": true
            },
            {
                "contact": "88005553535"
            }
        ]
        :return:
        """
        from use_cases.orders.admin.add_contacts.add_contacts_request import AdminAddContactsRequest
        from use_cases.orders.admin.add_contacts.add_contatcs_use_case import AdminAddContactsUseCase

        request = AdminAddContactsRequest(
            rloc=rloc,
            last_name=last_name,
            contacts=contacts
        )

        use_case = AdminAddContactsUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def admin_manage_contacts(rloc: str, last_name: str, contacts: List[dict]):
        """
        Управление контактом в броне.
        :param rloc: Rloc заказа
        :param last_name: Фамилия одно из пассажиров
        :param contacts: Словарь контактов
        [
            {
                "contact": "jony.ive@apple.com,
                "confirmed": true,
                "hide": true,
            }
        ]

        """
        from use_cases.orders.admin.manage_contacts.manage_contatcs_use_case import AdminManageContactsUseCase
        from use_cases.orders.admin.manage_contacts.manage_contacts_request import AdminManageContactsRequest

        request = AdminManageContactsRequest(
            rloc=rloc,
            last_name=last_name,
            contacts=contacts
        )

        use_case = AdminManageContactsUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            )
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    def re_save_order(self, order_uuid: str, force: bool, providers: List[str], return_full_response: bool = False):
        """
        Пересохранения заказа с нуля по всем имеющимся транзакциям
        :param order_uuid: uuid заказа из базы
        :param force: Пересохранит заказ, даже если не будет хватать каких-то транзакций
        :param providers: Транзакции каких провайдеров сохранить, если значение пустое - сохранит все транзакции
        :param return_full_response: Вернет полный объект ReSaveOrderResponse
        :return:
        """
        from use_cases.orders.save.resave_order.resave_order_request import ReSaveOrderRequest
        from use_cases.orders.save.resave_order.resave_order_use_case import ReSaveOrderUseCase

        request = ReSaveOrderRequest(
            order_uuid=order_uuid,
            force=force,
            providers=providers
        )

        save_order_queue = SaveOrdersQueue(
            gateway=get_db_gateway(label='redis')
        )

        gateway = get_db_gateway()

        use_case = ReSaveOrderUseCase(
            order_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainOrder
            ),
            origin_transaction_repo=GenericMongoRepository(
                gateway=gateway,
                instance=DomainOriginTransaction
            ),
            save_method=self.save,
            save_order_queue=save_order_queue
        )

        response = use_case.execute(request)
        if return_full_response:
            return response

        return serialize(response, rpc_response=True)

    @staticmethod
    def get_mono_app_order(order_uuid: str, send_to_mono_app: bool = False, discard_order_data: bool = False):
        """
        Получение заказа в структуре моноапп
        :param order_uuid: uuid заказа из базы
        :param send_to_mono_app: послать полученный заказ на сохранение в моноапп через кафку
        :param discard_order_data: не возвращать данные заказа (для экономии трафика, если нужно просто переслать заказ)
        """
        from use_cases.orders.events.retranslation.send_to_monoapp_use_case import SendOrderToMonoAppUseCase
        from use_cases.orders.events.retranslation.send_to_monoapp_use_case import SendOrderToMonoAppRequest

        if send_to_mono_app and not settings.SEND_ORDER_TO_MONO_APP:
            send_to_mono_app: bool = False

        request = SendOrderToMonoAppRequest(
            order=order_uuid,
            send_to_mono_app=send_to_mono_app,
            discard_order_data=discard_order_data
        )

        use_case = SendOrderToMonoAppUseCase(
            mono_app_adapter=MonoAppAdapter(),
            save_order_queue=SaveOrdersQueue(
                gateway=get_db_gateway(label='redis')
            ),
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            )
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def get_itinerary_receipt_download_link(
        order_uuid: str,
        passenger_last_name: str,
    ):
        """
        :param order_uuid: уникальный идентификатор заказа
        :param passenger_last_name: фамилия пассажира
        """
        from use_cases.orders.itinerary_receip.get_itinerary_receipt_request import (
            GetItineraryReceiptRequest,
        )
        from use_cases.orders.itinerary_receip.get_itinerary_receipt_use_case import (
            GetItineraryReceiptUseCase,
        )

        request = GetItineraryReceiptRequest(
            order_uuid=order_uuid, last_name=passenger_last_name, tais_look_up=False
        )

        use_case = GetItineraryReceiptUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder,
            ),
            sirena_adapter=SirenaInternalAdapter(),
            tais_adapter=TaisInternalAdapter(),
            filestorage_adapter=FileStorageAdapter(**settings.STORAGE_CONFIG),
            save_order_func=InternalOrderAdapter.save,
            change_pd_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainPDChanges,
            )
        )

        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def get_order_refunds(order_uuid: str):
        """
        Получение заявок на возврат для заказа
        :param order_uuid: uuid заказа из базы
        """
        from use_cases.orders.refund.search.order_refunds_search_use_case import OrderRefundsSearchRequest
        from use_cases.orders.refund.search.order_refunds_search_use_case import OrderRefundsSearchUseCase

        request = OrderRefundsSearchRequest(
            order_uuid=order_uuid
        )

        use_case = OrderRefundsSearchUseCase(
            order_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOrder
            ),
            refund_repo=GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainRefund
            )
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def add_order(order_uuid: str, user_id: str):
        """
        Добавление заказа пользователю
        * используется для Админки
        """
        from use_cases.orders.user.add_order.add_order_use_case import AddOrderUseCase
        from use_cases.orders.admin.add_order.add_order_request import AdminAddOrderRequest
        from use_cases.orders.admin.add_order.add_order_use_case import AdminAddOrderUseCase

        order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)

        proxy_request = AdminAddOrderRequest(order_uuid=order_uuid, user_id=user_id)
        proxy_use_case = AdminAddOrderUseCase(
            order_repo=order_repo,
            mono_app_adapter=MonoAppAdapter()
        )
        proxy_response = proxy_use_case.execute(proxy_request)

        request = proxy_response.value
        use_case = AddOrderUseCase(
            order_repo=order_repo,
            sirena_adapter=SirenaInternalAdapter(),
            internal_order_adapter=InternalOrderAdapter,  # Для сохранения заказа, найденного в ГДС
        )
        response = use_case.execute(request)

        return serialize(response, rpc_response=True)

    @staticmethod
    def hide_order(order_uuid: str, user_id: str):
        """
        Удаление (скрытие) заказа пользователя
        * используется для Админки
        """
        from use_cases.orders.admin.hide_order.hide_order_request import AdminHideOrderRequest
        from use_cases.orders.admin.hide_order.hide_order_use_case import AdminHideOrderUseCase
        from use_cases.orders.user.hide_order.hide_order_use_case import HideOrderUseCase

        order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)

        proxy_request = AdminHideOrderRequest(order_uuid=order_uuid, user_id=user_id)
        proxy_use_case = AdminHideOrderUseCase(mono_app_adapter=MonoAppAdapter())
        proxy_response = proxy_use_case.execute(proxy_request)

        request = proxy_response.value
        if not request or proxy_response.errors:
            return serialize(proxy_response, rpc_response=True)
        use_case = HideOrderUseCase(order_repo=order_repo)
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def exchange_order_v1(order_uuid: str):
        """
        Прокси метод для обмена брони в таисе
        """
        from use_cases.orders.exchange.v1.exchange_v1_request import ExchangeOrderV1Request
        from use_cases.orders.exchange.v1.exchange_v1_use_case import ExchangeOrderV1UseCase
        from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue

        order_repo = GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder)

        request: ExchangeOrderV1Request = ExchangeOrderV1Request(
            order_uuid=order_uuid
        )

        use_case: ExchangeOrderV1UseCase = ExchangeOrderV1UseCase(
            order_repo=order_repo,
            internal_order_adapter=InternalOrderAdapter,
            orders_queue=SaveOrdersQueue(
                gateway=get_db_gateway(label='redis')
            ),
            tais_adapter=TaisInternalAdapter()
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)
