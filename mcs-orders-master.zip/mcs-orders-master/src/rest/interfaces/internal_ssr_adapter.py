from adapter.service_desk import JiraServiceDeskAdapter
from base.adapter import BaseAdapter
from adapter.monoapp import MonoAppAdapter
from domain import DomainOrder
from domain.refunds import DomainRefund
from adapter.sirena_adapter import SirenaInternalAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from libs.db_gateway import get_db_gateway
from rest.applications.rpc_app.utils.response_serializer import serialize
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.settings import settings


class InternalSsrAdapter(BaseAdapter):
    """
    Интерфейс для работы с ssr'ми заказа
    """

    @staticmethod
    def process_passengers_with_special_service():
        """
        Обработка пассажиров со специальным обслуживанием.
        """
        from use_cases.orders.events.special_services.special_services_request import ProcessSpecialServicesRequest
        from use_cases.orders.events.special_services.special_services_use_case import ProcessSpecialServicesUseCase
        from use_cases.orders.events.special_services.base_special_services_use_case import RedisSpecialServicesUseCase

        special_services_key: str = RedisSpecialServicesUseCase.get_key()

        request = ProcessSpecialServicesRequest(special_services_key=special_services_key)
        use_case = ProcessSpecialServicesUseCase(
            order_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder),
            redis=get_db_gateway("redis"),
            mono_app_adapter=MonoAppAdapter(),
            internal_order_adapter=InternalOrderAdapter,
            sirena_adapter=SirenaInternalAdapter(),
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def process_confirmed_special_services(order_uuid: str):
        """
        Обработка пассажиров с подтвержденной услугой специального обслуживания.
        """
        from use_cases.orders.events.special_services.special_services_request import HkSpecialServicesRequest
        from use_cases.orders.events.special_services.special_services_use_case import HkSpecialServicesUseCase

        request = HkSpecialServicesRequest(order_uuid=order_uuid)
        use_case = HkSpecialServicesUseCase(
            order_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder),
            redis=get_db_gateway("redis"),
            mono_app_adapter=MonoAppAdapter()
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def process_canceled_special_services(order_uuid: str):
        """
        Обработка пассажиров с отмененной услугой специального обслуживания.
        """
        from use_cases.orders.events.special_services.special_services_request import UnSpecialServicesRequest
        from use_cases.orders.events.special_services.special_services_use_case import UnSpecialServicesUseCase

        request = UnSpecialServicesRequest(order_uuid=order_uuid)
        use_case = UnSpecialServicesUseCase(
            order_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder),
            redis=get_db_gateway("redis"),
            mono_app_adapter=MonoAppAdapter(),
            sirena_adapter=SirenaInternalAdapter(),
            jira_adapted=JiraServiceDeskAdapter(**settings.JIRA_SERVICE_DESK),
            refunds_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainRefund)
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)

    @staticmethod
    def process_requested_special_services(order_uuid: str):
        """
        Обработка пассажиров у которых услуга специального обслуживания не подтвердилась спустя 30 минут.
        """
        from use_cases.orders.events.special_services.special_services_request import HnSpecialServicesRequest
        from use_cases.orders.events.special_services.special_services_use_case import HnSpecialServicesUseCase

        request = HnSpecialServicesRequest(order_uuid=order_uuid)
        use_case = HnSpecialServicesUseCase(
            order_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainOrder),
            redis=get_db_gateway("redis"),
            mono_app_adapter=MonoAppAdapter(),
            sirena_adapter=SirenaInternalAdapter(),
            jira_adapted=JiraServiceDeskAdapter(**settings.JIRA_SERVICE_DESK),
            refunds_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainRefund)
        )
        response = use_case.execute(request)
        return serialize(response, rpc_response=True)
