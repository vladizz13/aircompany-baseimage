"""Конфигурирование логирования"""

from libs.utils.tools.logging import setup_sentry_client, get_app_version


def clear_handlers(
        logging_dict: dict,
        sentry_dsn: str,
        logstash_settings: dict
) -> dict:
    """
    Убрать handlers, если не подключен Sentry или ELK
    :param logging_dict:
    :param sentry_dsn:
    :param logstash_settings:
    :return:
    """
    logstash_ok = all([
        logstash_settings.get("HOST"),
        logstash_settings.get("PORT"),
    ])
    availability = {
        'sentry': bool(sentry_dsn),
        'logstash': logstash_ok,
        'recaptcha': logstash_ok,
        'logstash-http': logstash_ok,
    }

    handlers = logging_dict.get('handlers', {})

    # handlers clear
    for key in availability:
        if key in handlers and not availability[key]:
            del logging_dict['handlers'][key]

    # root clear
    root_handlers = logging_dict['root'].get('handlers', [])
    for key in availability:
        if key in root_handlers and not availability[key]:
            logging_dict['root']['handlers'].remove(key)

    # loggers clear
    loggers = logging_dict.get('loggers', {})
    for name, sets in loggers.items():
        handlers = sets.get('handlers', [])
        for key in availability:
            if key in handlers and not availability[key]:
                logging_dict['loggers'][name]['handlers'].remove(key)

    return logging_dict


def get_logging_settings(
        service_name: str,
        debug: bool,
        sentry_dsn: str,
        logstash_settings: dict,
        environment: str,
) -> dict:
    """
    Настройки логирования в формате dict
    :param service_name:
    :param debug:
    :param sentry_dsn:
    :param logstash_settings:
    :param environment:
    :return:
    """

    tags = [service_name, environment]

    settings = {
        'version': 1,
        'disable_existing_loggers': True,

        'root': {
            'level': 'DEBUG' if debug else 'ERROR',
            'handlers': ['console', 'sentry'],
        },

        'filters': {},
        'formatters': {
            'console': {
                'format': (
                    '[%(levelname)s][%(asctime)s] %(name)s %(filename)s:'
                    '%(funcName)s:%(lineno)d | %(message)s'
                ),
            },
            'average': {
                'format': (
                    '%(levelname)-8s %(name)-1s [%(asctime)s] %(message)s'
                ),
            },
            'simple': {
                'format': '%(levelname)s %(message)s'
            },

            'logstash_async_fmt': {
                '()': 'logstash_async.formatter.LogstashFormatter',
                'ensure_ascii': False,
                'extra': {
                    'service_name': service_name,
                    'service_version': get_app_version(),
                },
                'extra_prefix': '',
                'fqdn': False,
                'message_type': logstash_settings.get('MESSAGE_TYPE') or 'logstash',
                'tags': tags,
            },
            'logstash_http_async_fmt': {
                '()': 'logstash_async.formatter.LogstashFormatter',
                'ensure_ascii': False,
                'extra': {
                    'service_name': service_name,
                    'service_version': get_app_version(),
                },
                'extra_prefix': '',
                'fqdn': False,
                'message_type': logstash_settings.get('AUDIT_MESSAGE_TYPE') or 'audit',
                'tags': tags,
            },
            'recaptcha_fmt': {
                '()': 'logstash_async.formatter.LogstashFormatter',
                'ensure_ascii': False,
                'extra': {
                    'service_name': service_name,
                    'service_version': get_app_version(),
                },
                'extra_prefix': '',
                'fqdn': False,
                'message_type': logstash_settings.get('RECAPTCHA_MESSAGE_TYPE') or 'recaptcha',
                'tags': tags,
            },
        },

        'handlers': {
            'console': {
                'level': 'DEBUG' if debug else 'ERROR',
                'class': 'logging.StreamHandler',
                'formatter': 'console',
            },
            'scripts-console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'average',
            },
            'sentry': {
                'level': 'ERROR',
                'class': 'raven.handlers.logging.SentryHandler',
                'client': setup_sentry_client(sentry_dsn, env=environment),
            },

            'logstash': {
                'level': 'DEBUG',
                'class': 'logstash_async.handler.AsynchronousLogstashHandler',
                'transport': 'logstash_async.transport.TcpTransport',
                'host': logstash_settings.get('HOST'),
                'port': logstash_settings.get('PORT'),
                'formatter': 'logstash_async_fmt',
                'database_path': None,  # in-memory buffer instead of (default) sqlite
                'event_ttl': 31,
            },

            'logstash-http': {
                'level': 'DEBUG',
                'class': 'logstash_async.handler.AsynchronousLogstashHandler',
                'transport': 'logstash_async.transport.TcpTransport',
                'host': logstash_settings.get('HOST'),
                'port': logstash_settings.get('PORT'),
                'formatter': 'logstash_http_async_fmt',
                'database_path': None,  # in-memory buffer instead of (default) sqlite
                'event_ttl': 31,
            },
            'recaptcha': {
                'level': 'DEBUG',
                'class': 'logstash_async.handler.AsynchronousLogstashHandler',
                'transport': 'logstash_async.transport.TcpTransport',
                'host': logstash_settings.get('HOST'),
                'port': logstash_settings.get('PORT'),
                'formatter': 'recaptcha_fmt',
                'database_path': None,
                'event_ttl': 31,
            },
        },

        'loggers': {
            # Настройки для logger = logging.getLogger()
            '': {
                'handlers': ['console', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },

            'MongoMonitor': {
                'handlers': ['console', 'logstash'],
                'level': 'INFO',
                'propagate': False,
            },

            # Gunicorn DEBUG
            'gunicorn.error': {
                'handlers': ['console', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },
            'gunicorn.access': {
                'handlers': ['console', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },

            # Внешние приложения
            'werkzeug': {
                'level': 'DEBUG' if debug else 'ERROR',
                'handlers': ['console'],
                'propagate': False,
            },

            'raven': {
                'level': 'ERROR',
                'handlers': ['console'],
                'propagate': False,
            },
            'zeep': {
                'level': 'ERROR',
                'handlers': ['console'],
                'propagate': False,
            },

            # Внутренние
            'observers_registration': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },
            'http-requests': {
                'handlers': ['console', 'sentry', 'logstash-http'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'audit': {
                'handlers': ['console', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'auth': {
                'handlers': ['console', 'logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'recaptcha': {
                'handlers': ['console', 'logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'celery_currency_rates_update': {
                'handlers': ['logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False
            },
            'astra_soap_client.astra_sync.clients': {
                'handlers': ['logstash'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'sirena_xml_client.client': {
                'handlers': ['logstash'],
                'level': 'DEBUG',
                'propagate': False
            },
            'sirena_client': {
                'handlers': ['logstash'],
                'level': 'DEBUG',
                'propagate': False
            },
            'tais_requests': {
                'handlers': ['logstash'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'AddServiceBaggageUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False,
            },
            'SaveOrderUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'DeferredSaveOrderUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SearchOrderAppContextUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SearchOrderUserContextUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SearchOrderInternalUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SendOrderToMonoAppUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False,
            },
            'HandleSplitUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False,
            },
            'deferred_order_save': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'request_cache': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SendOrderToAnalyticsUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'monoapp_geo_adapter': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'kafka::producer': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },
            'kafka::consumer': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG' if debug else 'ERROR',
                'propagate': False,
            },
            'SirenaInternalAdapter': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False,
            },
            'TaisInternalAdapter': {
                'handlers': ['logstash', 'console'],
                'level': 'INFO',
                'propagate': False
            },
            'AstraRegistrationDataEnrichmentAgent': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'DocumentsCommonNormalizer': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'sirena.rmq.transactions.listener': {
                'handlers': ['sentry', 'logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'sirena.rmq.client': {
                'handlers': ['sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'TelegramMessenger': {
                'handlers': ['sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'LoadModifiedOrdersUseCase': {
                'handlers': ['sentry', 'console', 'logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'SubmitOrderRefundRequestUseCase': {
                'handlers': ['logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'GetOrderDetailPriceUseCase': {
                'handlers': ['logstash'],
                'level': 'INFO',
                'propagate': False,
            },
            'BaseOpenOrders': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'recaptcha_failure': {
                'handlers': ['recaptcha', 'sentry'],
                'level': 'DEBUG',
                'propagate': False,
            },
            'SetAvailableActionsExpander': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'ERROR',
                'propagate': False,
            },
            'CeleryChangePDSentinel': {
                'handlers': ['logstash', 'sentry'],
                'level': 'DEBUG',
                'propagate': False
            },
            'JiraSDRefundLogging': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'PreDepartureFlightsHandlers': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'PdtsSsrUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'WithdrawGetAvailableSegmentsUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'propagate': False,
                'level': 'INFO'
            },
            'taisCeleryDeferredTasks': {
                'handlers': ['console', 'logstash', 'sentry'],
                'propagate': False,
                'level': 'INFO'
            },
            'InitiateOrderReleaseSeatsUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'propagate': False,
                'level': 'INFO'
            },
            'SubmitOrderReleaseSeatsUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'propagate': False,
                'level': 'INFO'
            },
            # Exchange flow
            'BaseExchangeableOrderUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'ExchangeOrderV2UseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'ExchangeOptionsUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'ExchangeConfirmUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'ExchangeStatusUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'ExchangePaymentUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'subscribers::payment': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "AddLoyaltyCardUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'OrderQueueIsNotEmptyErrorHandler': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'SirenaPassengersTitleNotFoundErrorHandler': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'exchange_logger': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            'AircraftBortChangedUseCase': {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "DegrSsrUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "DegrSsrGetTotalPriceUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "DegrSendSsrsUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "PdtsSsrGetTotalPriceUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "PdtsSendSsrsUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "OrderBookedHandler": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "ProcessSpecialServicesUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "UnSpecialServicesUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "HnSpecialServicesUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            },
            "BaseSpecialServicesUseCase": {
                'handlers': ['console', 'logstash', 'sentry'],
                'level': 'INFO',
                'propagate': False
            }
        }
    }

    clean_settings = clear_handlers(settings, sentry_dsn, logstash_settings)
    return clean_settings


try:
    from .config_logging_local import *  # noqa
except ImportError:
    pass
