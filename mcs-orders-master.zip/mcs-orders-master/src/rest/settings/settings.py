import ipaddress
import os
import logging.config

from celery.schedules import crontab

from libs.utils.tools.config import rewrite_config_from_vault
from rest.settings.logging import get_logging_settings


SERVICE_NAME = 'mcs-orders'

# Абсолютный путь к корню проекта
PROJECT_ROOT = os.path.abspath(os.path.join(__file__, '../../../../'))
SRC_ROOT = os.path.abspath(os.path.join(PROJECT_ROOT, 'src'))

JSON_RPC_API_PREFIX = 'jsonrpcapi'
HOST = '127.0.0.1'
PORT = 5000

SECRET_KEY = 'asd;fjkhpirutpiuyp608lcbakHBLJHVSCLOIYQOWI782349762398hcf'
MONGO_MONITOR_ENABLED: bool = False
DEBUG = False
IS_DEV = True
FLASK_ENV = 'development'
SSL_CONTEXT = None  # ('cert.pem', 'key.pem')
ACCESS_LIST = {
    'main_app': 'application_pwd'
}

# Белый список ip адресов
IP_WHITELIST = (
    # Тюмень
    ipaddress.IPv4Network("91.240.25.0/24"),
    # TAIS
    "89.249.25.73", "89.249.25.74", "89.249.25.94", "93.191.17.25",
    "109.238.243.194", "109.238.243.195", "109.238.243.218",
    "109.238.243.219", "109.238.243.244", "109.238.243.247",
    # Kode
    "93.158.194.123",
)

RECAPTCHA_CONFIG = {
    'g_recaptcha_secret': '6Lc_4asUAAAAADqmtJPmg76WkBnzqjd7rVg6Hcpb',
    'g_recaptcha_url': 'https://www.google.com/recaptcha/api/siteverify',
    'is_enabled': False,
    'recaptcha_min_score': 0.1,
}


ELASTIC_APM = {
    "SERVICE_NAME": "mcs-orders",
    "SERVER_URL": "https://apm-lb.utair.io",
    "ENVIRONMENT": "staging",
    "SECRET_TOKEN": "94d800a0-a1b3-42a4-8749-3ba067d4d2fc"
}


CURRENCY_RATES_SETTINGS = {
    'HOST': 'https://openexchangerates.org',
    'APP_ID': 'f7f2979b5ee0439b8687660e9abb33ea'
}


KAFKA_CONFIG = {
    'servers': [],
    'subscribe_topics': [],
    'service_name': SERVICE_NAME
}

# Включение/Выключениe публикаций эвентов в кафку
KAFKA_DISABLE_PUBLICATION = True

# Глобально включение асинхронных событий по заказам
RAISE_ALL_ORDER_EVENTS_ASYNC = True

# Обработка отсплитованных заказов, обновление из таис
HANDLE_SPLITS = True

# Включение/Выключение отправки заказов в моноапп
STREAM_ORDERS_TO_MONO_APP = True    # Автоматический поток заказов (событийно)
SEND_ORDER_TO_MONO_APP = True       # Возможность отправки через эндпоинт (order.internal.getOrderMonoAppStructure.v1)

DATABASE = {
    'default': {
        'dbms': 'mongodb',
        'host': '127.0.0.1',
        'port': 27017,
        'db': 'orders',
        'user': '',
        'password': '',
        'authSource': 'admin',
        'readPreference': 'primary'
    },
    # Главная база моно приложения
    # (больше не используется, находится тут как пример подключения к репликам)
    # 'utair_main': {
    #     'dbms': 'mongodb',
    #     'host': ['127.0.0.1', '127.0.0.1'],
    #     'port': [27017, 27017],
    #     'db': 'utair',
    #     'user': '',
    #     'password': '',
    #     'authSource': 'admin',
    #     'readPreference': 'primary'
    # },
    'redis': {
        'dbms': 'redis',
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    },
}

CELERY_BEAT_SCHEDULE = {
    'archive_orders': {
        'task': 'rest.applications.celery_app.tasks.archive_orders.archive_orders_job',
        'schedule': crontab(hour=0, minute=0)
    },
    'load_modified_orders': {
        'task': 'rest.applications.celery_app.tasks.load_modified_orders.load_modified_orders_task',
        'schedule': crontab(hour="*/2", minute=0)
    },
    'download-currency-rates': {
        'task': 'rest.applications.celery_app.tasks.currency_rates.download_actual_currency_rates',
        'schedule': crontab(hour=0, minute=0)
    },
    'save_queued_orders': {
        'task': 'rest.applications.celery_app.tasks.deferred_save.deferred_save_job',
        'schedule': float(30)
    },
    'disabled-passengers-task': {
        'task': 'rest.applications.celery_app.tasks.special_services.disabled_passengers',
        'schedule': crontab(minute='*/30')
    },
}
CELERY_TASK_ALWAYS_EAGER = False
# Исключить задачи селери, чтобы не выполнялись (используется для тестовых стендов)
CELERY_EXCLUDE = []

FLOWER_API = 'http://127.0.0.1:8888'
FLOWER_USER = 'utair'
FLOWER_PASSWORD = 'utair'

SENTRY_DSN = ''
LOGSTASH_SETTINGS = {
    'HOST': None,
    'PORT': None,
}

# Включение отложенного сохранения заказов
ENABLE_DEFERRED_SAVE: bool = True
# Включение сохранений транзакций из потока таис
ENABLE_TAIS_STREAM: bool = True

MONO_APP_JSONRPC = {
    "url": "http://localhost:8081/jsonrpc/",
    "username": "mcs-orders",
    "password": "FXVwZLlb0ljm9uM5F6PtE5KgkDHcANZf",
    "verify": False,
}

SERVICE_AGENT_APP_JSONRPC = {
    "url": "http://digital-repository-mcs-service-agent-production.srv.utair.io",
    "username": "mcs_orders",
    "password": "bna7PVMAJsiEd7so9LDLmtMBEWCiNcBn",
    "verify": False,
}

REQUEST_CACHING = {
    'enabled': True,
    'ttl': 60 * 60 * 24  # сутки
}

ASTRA_CONF = {
    'host': 'https://sirena.utair.io/swc-main/{}?wsdl',
    'login': 'utair_iOS_checkin',
    'password': 'awidG2PM56',
    'cache_dynamic_id_key_name': 'dynamic_id',
    'timeout': 15,
}


TAIS_CONFIG = {
    'url': 'https://tais-api.utair.ru/bitrix/components/travelshop/ibe.soap/travelshop_booking.php?wsdl',
    'shared_secret': 'cr56ust+g!fR6sWa',
    'login': 'api_prod',
    'password': 'VETaw8eprude'
}

SIRENA_APC = {
    'host': 'sirena.utair.io',
    'port': 34321,
    'clientid': 444,
    'cache_symmetric_key_name': 'sirena_key_name',
    'cache_symmetric_key_id_name': 'sirena_key_id_name',
    'private_key_path': os.path.join(PROJECT_ROOT, '.keys', 'sirena.pem'),
    'connection_timeout': 5,
    'read_timeout': 20,
}

JIRA_SERVICE_DESK = {
    "host": "https://sd.utair.ru/rest/",
    "username": "robot",
    "password": "uK@U@SZdD#7}",

    "refund_project_id": 10600,     # id проекта RETURN
    "refund_issue_type": 10801,     # Тип заявки, возврат брони

    "timeout": 30
}

SIRENA_RMQ = {
    'host': 'sirena.utair.io',
    'port': 34314,
    'login': 'crm.utair',
    'password': 'AZsHY5i6Q',
}

MCS_PAYMENTS = {
    "url": "https://digital-ms-mcs-payments-staging.dev.utair.io/jsonrpcapi",
    "username": "main_app",
    "password": "application_pwd",
}

REQUEST_AUDIT_ENABLED: bool = True

STORAGE_CONFIG = {
    "endpoint": "https://s3.utair.io",
    "bucket": "itinerary-receipts",
    "access_key_id": "zZ4g7nYilJmiOwjxR0Cq",
    "secret_key_id": "XSBWZYf0oERiwbcR8OHHOqZ6/TaivuCF/ggt44Ej",
    "directory": "temporary",
    "signed_link_expires_in": 600,
}
# UtairPaymentBot
TELEGRAM_CONFIG = {
    'api_key': '461754465:AAHkVXaJB_8FNQj6_9-G6FtGD-pvE8a6eOY',
    'api_url': 'https://api.telegram.org/bot',
    'default_chat_id': -1001417254413,
}
# JettyBot
TELEGRAM_JETTY_CONFIG = {
    'api_key': '188954685:AAEgHoYbhO9fOJ-WJ018ugrgg6rdvcR_nDg',
    'api_url': 'https://api.telegram.org/bot',
    'default_chat_id': -1001846204875,
}

# Включение/Выключение отсылки сообщений в телеграмм
ENABLE_TELEGRAM_MESSAGES: bool = True

EMARSYS_CHANGE_AIRCRAFT_EMAIL_NOTIFY = "dcs@utair.ru"

EMARSYS_CHANGE_AIRCRAFT_TYPE_CODE = "change_aircraft"

# Переопределение настроек
if os.getenv("VAULT_URL", None) and os.getenv("VAULT_TOKEN", None):
    rewrite_config_from_vault(
        os.getenv("VAULT_URL"),
        "microservices",
        SERVICE_NAME,
        os.getenv("VAULT_TOKEN"),
        globals(),
    )

try:
    from .local_settings import *  # noqa
except ImportError:
    pass

# Установка логирования
logging.config.dictConfig(get_logging_settings(
    SERVICE_NAME, DEBUG, SENTRY_DSN, LOGSTASH_SETTINGS, environment=FLASK_ENV,
))
