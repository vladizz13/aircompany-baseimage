import time

from pymongo.errors import OperationFailure
from event_engine import Event
from events.events.save import UpdateOrderEvent
from typing import Any, Union, Type, List, Optional
from adapter.sirena_adapter import SirenaInternalAdapter, SirenaPnrAndSurnameDontMatch
from domain import DomainOrder
from domain.order.data.contacts import DomainContact
from domain.types import ContactType, MatchTypes
from domain.types import TransactionSource
from libs.query_builder import AndQueryUnit, QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from use_cases.orders.save.normalize_order.normalizers.contacts import ContactsCommonNormalizer
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from .add_contacts_request import AdminAddContactsRequest
from .add_contatcs_response import AdminAddContactsResponse
from use_cases.orders.user.input_types.add import AddOrderInputFields
from use_cases.orders.exceptions.admin import ContactsAlreadyAddedError
from use_cases.orders.exceptions.user import UnableToBuildQueryError, OrderNotFoundError


class AdminAddContactsUseCase(BaseSearchOrderUseCase):
    """
    Юзкейс добавления контактов к заказу
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        sirena_adapter: SirenaInternalAdapter,
        internal_order_adapter: callable
    ):
        super().__init__(
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            sirena_adapter=sirena_adapter,
            mono_app_adapter=None,
        )

        # Доступные для юзкейса события
        self.events: List[Type[Event]] = [
            UpdateOrderEvent
        ]

    def __execute__(self, request: AdminAddContactsRequest, *args, **kwargs) -> AdminAddContactsResponse:
        query: AndQueryUnit = self.__build_search_query__(request.serialize_search_params())

        try:
            order: DomainOrder = self.order_repo.get_single(spec=query)
        except OperationFailure as e:
            self.logger.exception("Не удалось составить поисковый запрос: {}".format(str(e)))
            return AdminAddContactsResponse.build_from_exception(UnableToBuildQueryError())

        if not order:
            # Заказ не найден, пробуем найти в сиренагрс, если нашелся - сохраняем
            raw_sirena_order = self.__search_in_sirena__(request)
            order: [DomainOrder, None] = self.__save_new_order__(raw_sirena_order, TransactionSource.SIRENA_GRS.value)
            if not order:
                return AdminAddContactsResponse.build_from_exception(OrderNotFoundError())

        # Подготовка контактов
        new_contacts: List[DomainContact] = self.__create_contacts(request)
        new_contacts: List[DomainContact] = self.__normalize_contacts(new_contacts)
        if not new_contacts:
            return AdminAddContactsResponse.build_from_exception(
                ContactsAlreadyAddedError(message="Не удалось нормализировать контакты, либо они отсутвуют")
            )

        # Контакты
        existing_contacts: List[DomainContact] = list()

        for contact in order.data.contacts:
            # Если контакт уже присуствует - проверяем присваиваем ему новые confirmed
            if contact in new_contacts:
                new_contact: DomainContact = new_contacts[new_contacts.index(contact)]
                contact.confirmed = new_contact.confirmed
                contact.match_type = new_contact.match_type
            existing_contacts.append(contact)

        for contact in new_contacts:
            if contact in existing_contacts:
                continue
            order.data.contacts.append(contact)

        self.order_repo.update(order, OrdersQueryBuilder.get_by_order_uuid(order.data.order_uuid))
        self.__raise_event__(event=UpdateOrderEvent, payload=order.serialize())
        return AdminAddContactsResponse(order)

    @staticmethod
    def __define_contact_type(contact: str):
        """
        Определяем тип контакта
        :param contact:
        """
        if '@' in contact:
            return ContactType.MAIL.value
        return ContactType.PHONE.value

    def __normalize_contacts(self, contacts: List[DomainContact]) -> List[DomainContact]:
        for idx, contact in enumerate(contacts):
            if not contact.contact:
                del contacts[idx]
                continue
            contact.confirmed: bool = self.__is_confirmed(contact.confirmed)
            contact.type: str = self.__define_contact_type(contact.contact)
            contacts[idx]: DomainContact = ContactsCommonNormalizer.normalize_domain_contact(contact)
        return contacts

    @staticmethod
    def __is_confirmed(_input: Optional[Union[str, bool]] = None) -> bool:
        if _input is None:
            return False
        if isinstance(_input, bool):
            return _input
        if _input:  # AnyStr or True
            return True

    @staticmethod
    def __create_contacts(request: AdminAddContactsRequest) -> List[DomainContact]:
        contacts_data: List[dict] = request.contacts
        created_contacts: List[DomainContact] = list()
        created_time: float = time.time()
        for contact in contacts_data:
            created_contacts.append(
                DomainContact(
                    contact=contact.get("contact"),
                    confirmed=contact.get("confirmed", False),
                    match_type=MatchTypes.MANUAL.value,
                    created=created_time
                )
            )
        return created_contacts

    @staticmethod
    def __map_query_units__(param: str, value: Any) -> QueryUnit:
        """
        Мапим фильтры к подходящему поисковому запросу из OrdersQueryBuilder
        """
        map = {
            AddOrderInputFields.LAST_NAME.value: OrdersQueryBuilder.get_by_passenger_last_name,
            AddOrderInputFields.RLOC.value: OrdersQueryBuilder.get_by_order_rloc_regexp,
        }
        return map[param](value)

    def __search_in_sirena__(self, request: AdminAddContactsRequest) -> Union[None, dict]:
        """
        Поиск заказа в сирене
        """
        try:
            return self.sirena_adapter.search_order(rloc=request.rloc, last_name=request.last_name)
        except SirenaPnrAndSurnameDontMatch:
            return None
