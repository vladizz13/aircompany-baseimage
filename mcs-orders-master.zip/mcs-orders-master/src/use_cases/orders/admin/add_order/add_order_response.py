from base.use_case import BaseUseCaseResponse
from use_cases.orders.user.add_order.add_order_request import AddOrderRequest


class AdminAddOrderResponse(BaseUseCaseResponse):

    def __init__(self, value: 'AddOrderRequest' = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: 'AddOrderRequest') -> 'AddOrderRequest':
        return value
