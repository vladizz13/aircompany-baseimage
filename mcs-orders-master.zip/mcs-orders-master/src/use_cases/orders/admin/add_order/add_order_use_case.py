from mcs_oauth_client import DomainOauth

from base.use_case import BaseUseCase
from repositories.query_builders.order import OrdersQueryBuilder
from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.orders.user.add_order.add_order_request import AddOrderRequest
from .add_order_request import AdminAddOrderRequest
from .add_order_response import AdminAddOrderResponse


class AdminAddOrderUseCase(BaseUseCase):
    """
    Юзкейс добавления заказа пользователю
    * для админки
    """

    def __init__(self, order_repo, mono_app_adapter) -> None:
        super().__init__()
        self.order_repo = order_repo
        self.mono_app_adapter = mono_app_adapter

    def __execute__(self, request: 'AdminAddOrderRequest', *args, **kwargs) -> 'AdminAddOrderResponse':
        order = self.order_repo.get_single(OrdersQueryBuilder.get_by_order_uuid(request.order_uuid))
        if not order or not order.data.passengers:
            return AdminAddOrderResponse.build_from_exception(OrderNotFoundError())
        user = self.mono_app_adapter.get_user_by_user_id(request.user_id)
        fake_oauth = DomainOauth.deserialize(dict(user=user.serialize()))
        request = AddOrderRequest(rloc=order.data.rloc, last_name=order.data.passengers[0].last_name, oauth=fake_oauth)
        return AdminAddOrderResponse(value=request)
