from base.use_case import BaseUseCaseRequest


class AdminHideOrderRequest(BaseUseCaseRequest):

    def __init__(self, order_uuid: str = None, user_id: str = None):
        super().__init__()
        self.order_uuid = order_uuid
        self.user_id = user_id

    def is_valid(self, *args, **kwargs) -> 'AdminHideOrderRequest':
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
            'user_id': self.user_id,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None),
            user_id=data.get('user_id', None),
        )
