from base.use_case import BaseUseCaseResponse
from use_cases.orders.user.hide_order.hide_order_request import HideOrderRequest


class AdminHideOrderResponse(BaseUseCaseResponse):

    def __init__(self, value: 'HideOrderRequest' = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: 'HideOrderRequest' = None) -> 'HideOrderRequest':
        return value
