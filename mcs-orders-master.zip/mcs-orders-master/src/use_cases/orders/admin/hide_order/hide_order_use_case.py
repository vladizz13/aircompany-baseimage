from mcs_oauth_client import DomainOauth

from base.use_case import BaseUseCase
from .hide_order_request import AdminHideOrderRequest
from .hide_order_response import AdminHideOrderResponse
from use_cases.orders.user.hide_order.hide_order_request import HideOrderRequest


class AdminHideOrderUseCase(BaseUseCase):
    """
    Юзкейс удаления (скрытия) заказа пользователя
    * для админки
    """

    def __init__(self, mono_app_adapter) -> None:
        super().__init__()
        self.mono_app_adapter = mono_app_adapter

    def __execute__(self, request: 'AdminHideOrderRequest', *args, **kwargs) -> 'AdminHideOrderResponse':
        user = self.mono_app_adapter.get_user_by_user_id(request.user_id)
        fake_oauth = DomainOauth.deserialize(dict(user=user.serialize()))
        request = HideOrderRequest(order_uuid=request.order_uuid, oauth=fake_oauth, is_admin_panel=True)
        return AdminHideOrderResponse(value=request)
