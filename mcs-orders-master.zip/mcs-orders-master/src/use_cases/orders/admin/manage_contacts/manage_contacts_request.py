import re

from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.user import InvalidLastNameError, InvalidRlocError, InvalidInputFieldsError


class AdminManageContactsRequest(BaseOrderRequest):

    rloc_pattern = re.compile("^[0-9A-Z-/]+$")

    def __init__(self, rloc: str = None, last_name: str = None, contacts: list = None):
        super().__init__()
        self.rloc = rloc
        self.last_name = last_name
        self.contacts = contacts

    def is_valid(self, *args, **kwargs) -> "AdminManageContactsRequest":
        invalid_request = AdminManageContactsRequest()

        if not self.rloc or not bool(self.rloc_pattern.match(self.rloc)):
            invalid_request.add_error(InvalidRlocError())

        if not self.last_name:
            invalid_request.add_error(InvalidLastNameError())

        if not self.contacts:
            invalid_request.add_error(InvalidInputFieldsError(message="Не указаны контакты"))

        for contact in self.contacts:
            if 'contact' not in contact:
                invalid_request.add_error(InvalidInputFieldsError(message="Не указаны контакты"))

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize_search_params(self) -> dict:
        return {"rloc": self.rloc, "last_name": self.last_name}

    def serialize(self) -> dict:
        return {"rloc": self.rloc, "last_name": self.last_name, "contacts": self.contacts}

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            rloc=data.get("rloc", None),
            last_name=data.get("last_name", None),
            contacts=data.get("contacts", None),
        )
