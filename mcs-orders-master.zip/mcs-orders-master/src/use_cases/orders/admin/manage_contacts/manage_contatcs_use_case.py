from pymongo.errors import OperationFailure
from event_engine import Event
from events.events.save import UpdateOrderEvent
from typing import Any, Type, List, Optional
from domain import DomainOrder
from domain.order.data.contacts import DomainContact
from domain.types import ContactType
from libs.query_builder import AndQueryUnit, QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from .manage_contacts_request import AdminManageContactsRequest
from .manage_contatcs_response import AdminManageContactsResponse
from use_cases.orders.user.input_types.add import AddOrderInputFields
from use_cases.orders.exceptions.admin import ContactNotFoundError
from use_cases.orders.exceptions.user import UnableToBuildQueryError, OrderNotFoundError


class AdminManageContactsUseCase(BaseSearchOrderUseCase):
    """
    Юзкейс управления контактами в заказе
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository
    ):
        super().__init__(order_repo=order_repo, mono_app_adapter=None)

        # Доступные для юзкейса события
        self.events: List[Type[Event]] = [
            UpdateOrderEvent
        ]

    def __execute__(self, request: AdminManageContactsRequest, *args, **kwargs) -> AdminManageContactsResponse:
        query: AndQueryUnit = self.__build_search_query__(request.serialize_search_params())

        try:
            order: DomainOrder = self.order_repo.get_single(spec=query)
        except OperationFailure as e:
            self.logger.exception("Не удалось составить поисковый запрос: {}".format(str(e)))
            return AdminManageContactsResponse.build_from_exception(UnableToBuildQueryError())

        if not order:
            return AdminManageContactsResponse.build_from_exception(OrderNotFoundError())

        # Подготовка контактов
        new_contacts: List[DomainContact] = self.__create_contacts(request)
        new_contacts: List[DomainContact] = self.__normalize_contacts(new_contacts)
        if not new_contacts:
            return AdminManageContactsResponse.build_from_exception(
                ContactNotFoundError(message="Не удалось нормализировать контакты, либо они отсутвуют")
            )

        # Проверяем наличие контактов в броне
        for contact in new_contacts:
            if contact not in order.data.contacts:
                return AdminManageContactsResponse.build_from_exception(
                    ContactNotFoundError(message=f"Контакт {contact.contact} отсуствует в заказе")
                )

        for contact in order.data.contacts:
            if contact not in new_contacts:
                continue
            new_contact: DomainContact = new_contacts[new_contacts.index(contact)]
            contact.hide = self.__is_value_changed(contact.hide, new_contact.hide, to_bool=True)
            contact.confirmed = self.__is_value_changed(contact.confirmed, new_contact.confirmed, to_bool=True)

        self.order_repo.update(order, OrdersQueryBuilder.get_by_order_uuid(order.data.order_uuid))
        self.__raise_event__(event=UpdateOrderEvent, payload=order.serialize())
        return AdminManageContactsResponse(order)

    @staticmethod
    def __is_value_changed(
            current_value: Optional[bool],
            new_value: Optional[bool],
            to_bool: bool = False
    ):
        """
        Проверка на
        :param current_value: существующее значение
        :param new_value: новое значение
        :param to_bool: преобразовать в булево
        :return:
        """
        if new_value is None:
            return current_value

        if all([
            new_value != current_value,
            new_value is not None
        ]):
            new_field = bool(new_value) if to_bool else new_value
            return new_field
        current_field = bool(current_value) if to_bool else current_value
        return current_field

    @staticmethod
    def __define_contact_type(contact: str):
        """
        Определяем тип контакта для сравнения с имеющимися контактами в заказе
        :param contact:
        """
        if '@' in contact:
            return ContactType.MAIL.value
        return ContactType.PHONE.value

    def __normalize_contacts(self, contacts: List[DomainContact]) -> List[DomainContact]:
        """
        Нормализуем контакты для сравнения с имеющимися контактами в заказе
        """
        for idx, contact in enumerate(contacts):
            if not contact.contact:
                del contacts[idx]
                continue
            contact.type: str = self.__define_contact_type(contact.contact)
            # Не нормализуем контакт, так как подразумеваем, что передали существующий контакт
            # contacts[idx]: DomainContact = ContactsCommonNormalizer.normalize_domain_contact(contact)
        return contacts

    @staticmethod
    def __create_contacts(request: AdminManageContactsRequest) -> List[DomainContact]:
        """
        Создаем новые контакты для сравнения с имеющимися контактами в заказе
        """
        contacts_data: List[dict] = request.contacts
        created_contacts: List[DomainContact] = list()
        for contact in contacts_data:
            created_contacts.append(
                # Переданные поля по дефолту обязательно ставим None, для упрощения проверки в  __is_field_changed
                DomainContact(
                    contact=contact.get("contact"),
                    confirmed=contact.get("confirmed", None),
                    hide=contact.get('hide', None)
                )
            )
        return created_contacts

    @staticmethod
    def __map_query_units__(param: str, value: Any) -> QueryUnit:
        """
        Мапим фильтры к подходящему поисковому запросу из OrdersQueryBuilder
        """
        map = {
            AddOrderInputFields.LAST_NAME.value: OrdersQueryBuilder.get_by_passenger_last_name,
            AddOrderInputFields.RLOC.value: OrdersQueryBuilder.get_by_order_rloc_regexp,
        }
        return map[param](value)
