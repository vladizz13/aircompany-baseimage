from typing import List, Any, Type
import logging
import time
from domain import DomainOrder
from event_engine import Event, get_event_manager
from libs.db_gateway import get_db_gateway
from base.use_case import BaseUseCase
from base.use_case import BaseUseCaseRequest
from base.use_case import BaseUseCaseResponse
from rest.settings import settings


class BaseOrderResponse(BaseUseCaseResponse):

    def __init__(self, value=None):
        super().__init__(value)


class BaseOrderRequest(BaseUseCaseRequest):

    def __init__(self):
        super().__init__()

    @classmethod
    def deserialize(cls, data: dict):
        raise NotImplementedError()

    def serialize(self) -> dict:
        raise NotImplementedError()

    def is_valid(self, *args, **kwargs):
        raise NotImplementedError()


class BaseOrderUseCase(BaseUseCase):

    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        # События, доступные для вызова из юзкейсов начисления
        self.events: List[Type[Event]] = []

        self.__event_manger__ = None

    @property
    def event_manager(self):
        if self.__event_manger__ is None:
            self.__event_manger__ = get_event_manager(
                db_gateway=get_db_gateway(),
                redis_gateway=get_db_gateway('redis'),
                disable_publication=settings.KAFKA_DISABLE_PUBLICATION
            )
        return self.__event_manger__

    def __raise_event__(
            self,
            event: Type[Event],
            payload: Any,
            async_event: bool = True
    ):
        """
        Единая точка для вызова событий из юзкейсов сохранения заказа
        :param event: Класс события, будет проверен перед вызовом событий на наличие в self.events
        :param payload: Данные, которые будут отправлены в событие
        :param async_event: Асинхронная отправка события
        :return:
        """
        from rest.applications.celery_app.tasks.async_event import event_manager_handle

        async_event = async_event if async_event and settings.RAISE_ALL_ORDER_EVENTS_ASYNC else False
        if event not in self.events:
            raise ValueError('Unexpected event, available events are: {}'.format(
                [x.__name__ for x in self.events]
            ))
        composed_event = event(payload)

        if async_event:
            self.event_manager.raise_event_async(
                event=composed_event,
                async_task=event_manager_handle
            )
        else:
            self.event_manager.raise_event(
                event=composed_event
            )

    def __execute__(self, request: BaseOrderRequest, *args, **kwargs):
        raise NotImplementedError()

    @staticmethod
    def is_order_archived(order: DomainOrder) -> bool:
        """
        В сирене заказ становится архивом в течении 65 дней после вылета последнего сегмента
        Считаем, что заказ архивный, если прошло 64 дня, делаем скидку в один день
        """
        if not order.data.segments:
            return False

        one_day = 60 * 60 * 24
        sirena_archive_delta: int = 60 * 60 * 24 * 65  # 65 дней
        time_delta: int = sirena_archive_delta - one_day
        last_segment_departure: int = max([
            s.departure_timestamp for s in order.data.segments if s.departure_timestamp is not None
        ])
        if last_segment_departure < time.time() - time_delta:
            return True
        return False
