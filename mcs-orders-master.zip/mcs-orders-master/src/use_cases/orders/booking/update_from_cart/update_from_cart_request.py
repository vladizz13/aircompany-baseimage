from enum import Enum
from typing import Optional
from use_cases.orders.exceptions.booking import InvalidInputCartError
from use_cases.orders.base_order_use_case import BaseOrderRequest


class UpdateFromCartRequest(BaseOrderRequest):

    class CartTypes(Enum):
        DEFAULT = "DEFAULT"
        LAZY = "LAZY"
        ASYNC = "ASYNC"

    """
    cart_data:
    >>>   {
    >>>        "order_id": 123,
    >>>        "rloc": 123,
    >>>        "profile_card_number": None,
    >>>        "platform": None,
    >>>        "voucher": {
    >>>             "id": "123",
    >>>             "amount": 123
    >>>         },
    >>>        "discounts": [
    >>>             {
    >>>                 "type": "miles",
    >>>                 "amount": 1786,
    >>>                 "code": None,
    >>>                 "card_number": 1025061530
    >>>             },
    >>>             {
    >>>                 "type": "promo",
    >>>                 "amount": 1885,
    >>>                 "code": "utest100",
    >>>                 "card_number": None
    >>>             }
    >>>        ],
    >>>        "buyer": {
    >>>             "device_token": "any_str"
    >>>         },
    >>>         "utm": {
    >>>             "source": "source",
    >>>             "campaign": "campaign",
    >>>             "medium": "medium",
    >>>             "term": "term",
    >>>             "content": "content",
    >>>         }
    >>>    }
    """

    def __init__(
            self,
            cart_data: dict = None
    ):
        super().__init__()
        self.cart_data = cart_data

        self.order_id = cart_data.get('order_id', None)
        self.rloc = cart_data.get('rloc', None)
        self.discounts = cart_data.get('discounts', []) or list()
        self.profile_card_number = cart_data.get('profile_card_number', None)
        self.voucher = cart_data.get('voucher', {}) or dict()
        self.last_name = cart_data.get('last_name', None)
        self.buyer = cart_data.get('buyer', {}) or dict()
        self.platform = cart_data.get('platform', None)
        self.cart_type = cart_data.get('cart_type', None),
        self.meta_created = cart_data.get('meta_created', None)
        self.normalize_discounts()

    def is_valid(self, *args, **kwargs) -> 'UpdateFromCartRequest':
        if not self.order_id:
            self.add_error(InvalidInputCartError(message="Отсутсвует order_id"))
        return self

    def get_device_token(self) -> Optional[str]:
        return self.buyer.get('device_token', None)

    @property
    def partner_id(self):
        return self.cart_data.get("meta_search", dict()).get("sid", None)

    @property
    def partner_data(self):
        return self.cart_data.get("meta_search", dict()).get("data", None)

    @property
    def utm(self) -> dict:
        return self.cart_data.get('utm', dict())

    @property
    def should_check_tais_booking(self) -> bool:
        should_check = (
            self.CartTypes.LAZY.value,
            self.CartTypes.ASYNC.value
        )
        return self.cart_type in should_check

    def normalize_discounts(self):
        for discount in self.discounts:
            if discount.get("type") == "promo" and discount.get("code"):
                discount["code"] = discount["code"].upper()

    def serialize(self) -> dict:
        return {
            'cart_data': self.cart_data
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            cart_data=data.get('cart_data', {})
        )
