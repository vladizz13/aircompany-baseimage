from typing import Callable, Optional, Dict
import time
import uuid
import json
from domain.types import TransactionSource
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from .update_from_cart_request import UpdateFromCartRequest
from use_cases.orders.save.save_order.save_order_response import SaveOrderResponse
from ...exceptions.booking import UnableToFindOrderInTaisBookingError


from adapter.tais_adapter import TaisInternalAdapter


class UpdateFromCartUseCase(BaseOrderUseCase):
    """
    Юзкейс обновления/сохранения заказа из данных корзины букинга
    """
    def __init__(
            self,
            order_repo: GenericMongoRepository,
            tais_adapter: TaisInternalAdapter,
            order_save_func: Callable,
    ):
        super().__init__()
        self.order_repo = order_repo
        self.tais_adapter = tais_adapter
        self.order_save_func = order_save_func

    def __execute__(self, request: UpdateFromCartRequest, *args, **kwargs) -> SaveOrderResponse:

        tais_request = dict(
            sirena_sync=True,
            # Проверять только при асинхронной корзине
            check_booking=request.should_check_tais_booking,
        )
        if request.last_name:
            tais_request.update(dict(last_name=request.last_name))

        if request.rloc and request.last_name:
            tais_request.update(dict(rloc=request.rloc))
            orders = self.tais_adapter.search_orders(**tais_request)
            order: Optional[Dict] = orders[0] if orders else None
        else:
            tais_request.update(dict(order_id=request.order_id))
            order: Optional[Dict] = self.tais_adapter.search_order(**tais_request)

        if not order:
            return SaveOrderResponse.build_from_exception(UnableToFindOrderInTaisBookingError())

        additional_data: dict = self.prepare_additional_data_from_cart(request, order)
        order['additional_data']: dict = additional_data
        self.prepare_analytics_data_from_cart(request, order)

        save_response = self.order_save_func(
            raw_order=order,
            provider=TransactionSource.TAIS.value,
            received=time.time(),
            message_id=str(uuid.uuid4()),
            deferred_save=True,
            return_full_response=True
        )

        return save_response

    @staticmethod
    def prepare_additional_data_from_cart(request: UpdateFromCartRequest, raw_tais_transation: dict) -> dict:
        try:
            additional_data_origin = json.loads(raw_tais_transation.get("additional_data", ""))
        except TypeError:
            additional_data_origin = {}

        return {
            "discounts": request.discounts,
            "voucher": request.voucher,
            "profile_card_number": request.profile_card_number or additional_data_origin.get('profile_card_number'),
        }

    @staticmethod
    def prepare_analytics_data_from_cart(request: UpdateFromCartRequest, order: dict):
        order['device_token'] = request.get_device_token()
        order['platform'] = request.platform
        order['utm'] = request.utm
        order["created"] = request.meta_created
        order["partner_data"] = request.partner_data
        order["partner_id"] = request.partner_id
