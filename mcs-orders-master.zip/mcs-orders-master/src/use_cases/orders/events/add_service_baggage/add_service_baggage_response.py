from use_cases.orders.base_order_use_case import BaseOrderResponse


class AddServiceBaggageResponse(BaseOrderResponse):

    def __init__(self, value: str = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: str = None):
        return value
