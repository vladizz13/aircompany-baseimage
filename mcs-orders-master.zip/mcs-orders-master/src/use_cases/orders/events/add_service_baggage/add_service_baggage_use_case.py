from datetime import datetime
from typing import Dict, Optional, List, Type, Union

from sirena_xml_client.exceptions import SirenaDuplicateSvc, SirenaPnrAndSurnameDontMatch, SirenaPnrBusyError
from sirena_xml_client.types import ServiceForAdd

from adapter.sirena_adapter import SirenaInternalAdapter
from domain import DomainOrder
from domain.order.data.segment import DomainSegment
from domain.order.data.service import DomainService
from domain.order.meta.transaction_source import DomainTransactionSource
from domain.origin_transaction import DomainOriginTransaction
from domain.types import ServiceStatus, TransactionSource
from libs.redis_queues.list_queue import AlreadyLockedError
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.origin_transaction import OriginTransactionsQueryBuilder
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue
from .add_service_baggage_request import AddServiceBaggageRequest
from .add_service_baggage_response import AddServiceBaggageResponse
from use_cases.orders.exceptions.base import BaseAddServiceError


class AddServiceBaggageUseCase(BaseOrderUseCase):
    """
    Добавление заказу сервис багажа
    """

    LOCK_KEY_PREFIX = 'add-service-060'
    SERVICE_BAGGAGE_RFISC = 'O6O'

    def __init__(
        self,
        transaction_repo: GenericMongoRepository,
        sirena_adapter: SirenaInternalAdapter,
        send_message_func: Type[callable],
        internal_order_adapter: Type[InternalOrderAdapter],
        save_queue: SaveOrdersQueue,
    ):
        self.transaction_repo = transaction_repo
        self.sirena_adapter = sirena_adapter
        self.send_message = send_message_func
        self.internal_order_adapter = internal_order_adapter
        self.save_queue = save_queue

        # флаг показывает необходимость в добавлении новых(ой) услуг(и)
        self.should_add_service = False

        self.sirena_raw_order: Optional[Dict] = None

        self.services_to_add: List[ServiceForAdd] = list()

        super().__init__()

    def __execute__(self, request: AddServiceBaggageRequest, *args, **kwargs) -> AddServiceBaggageResponse:
        try:
            order: DomainOrder = request.order
            # TODO Кажется, что лок не нужен, так как он происходит на уровне celery-once (проверить)
            with self.save_queue.lock(key=self.__get_lock_key__(order), custom_key=True):
                # Проверяем, существует ли услуга в заказе, проставляем флаги
                self.check_existing_services(services=order.data.services, segments=order.data.segments)

                if not self.should_add_service:
                    # Добавление не требуется
                    return AddServiceBaggageResponse(value='Обновление не требуется')
                return self.add_services(order)
        except SirenaPnrBusyError as e:
            return AddServiceBaggageResponse.build_from_exception(e)
        except AlreadyLockedError as e:
            return AddServiceBaggageResponse.build_from_exception(
                BaseAddServiceError(message=f'Не удалось добавить сервисы: {str(e)}')
            )

    def add_services(self, order: DomainOrder) -> AddServiceBaggageResponse:
        """
        Добавление услуг
        """
        try:
            self.__get_sirena_raw_transaction__(order=order, from_repo=True)
        except SirenaPnrAndSurnameDontMatch:
            pass
        self.logger.info(f'{order.data.rloc}: извлекли сырую транзакцию из бд\n{self.sirena_raw_order}')
        if not self.sirena_raw_order:
            self.logger.info(f'{order.data.rloc}: Не удалось найти транзакцию.')
            return AddServiceBaggageResponse.build_from_exception(
                BaseAddServiceError(message='Не удалось найти заказ в сирене.')
            )
        if self.should_add_service:
            self.logger.info(f'{order.data.rloc}: зашли в блок "if self.should_add_service"')
            self.assign_sirena_ids(
                # Передаем карту айдишников { 'наш': 'сирена' }
                segment_ids=self.get_segment_ids(),
                passenger_ids=self.get_passenger_ids(),
            )
            try:
                self.logger.info(f'{order.data.rloc}: блок "if self.should_add_service":\nВызываем svc_add')
                result: Optional[Dict] = self.sirena_adapter.add_services(
                    rloc=order.data.rloc, services=self.services_to_add
                )
            except SirenaDuplicateSvc as e:
                # Сервисы уже добавлены
                message = f'[MCS] Услуга O6O для заказа {order.data.rloc} уже добавлена, {str(e)}'
                self.logger.info(
                    f'{order.data.rloc}: блок "if self.should_add_service": результат вызова svc_add:\n{message}'
                )
                return AddServiceBaggageResponse(value=message)
            if not result:
                message = f'[MCS] Что то пошло не так {order.data.rloc}. Услуга не добавилась O6O.\n'
                self.logger.info(
                    f'{order.data.rloc}: блок "if self.should_add_service":\n{message}\n'
                    f'(нет результата вызова svc_add) отправляем сообщение в телегу'
                )
                self.send_message.delay(message=message)
                return AddServiceBaggageResponse(value=message)

            self.send_message.delay(message=f'[MCS] Услуга O6O успешно добавлена {order.data.rloc}')

        return AddServiceBaggageResponse()

    def __get_lock_key__(self, order: DomainOrder) -> str:
        return f'{self.LOCK_KEY_PREFIX}-{order.data.rloc}'

    def assign_sirena_ids(self, segment_ids: Dict[str, str], passenger_ids: Dict[str, str]):
        for service in self.services_to_add:
            service.passenger_id = passenger_ids.get(service.passenger_id)
            service.segment_id = segment_ids.get(service.segment_id)

    def get_segment_ids(self) -> Dict[str, str]:
        """
        Получаем маппинг айди сегментов {'наш': 'сирена'}
        """
        segments: List[Dict] = self.sirena_raw_order['order']['pnr']['segments']['segment']
        ids_mapping: Dict = dict()
        local_segment_id: int = 0
        for segment in segments:
            ids_mapping.update({str(local_segment_id): segment['@id']})
            local_segment_id += 1
        return ids_mapping

    def get_passenger_ids(self) -> Dict[str, str]:
        """
        Получаем маппинг айди пассажиров {'наш': 'сирена'}
        """
        passengers: List[Dict] = self.sirena_raw_order['order']['pnr']['passengers']['passenger']
        ids_mapping: Dict = dict()
        # В нашей системе пассажиры начинаются с 1
        local_passenger_id: int = 1
        for passenger in passengers:
            ids_mapping.update({str(local_passenger_id): passenger['@id']})
            local_passenger_id += 1
        return ids_mapping

    def __get_sirena_raw_transaction__(self, order: DomainOrder, from_repo: bool = False) -> None:
        """
        Достаем сырую транзакцию от сирены в self.sirena_raw_order,
        если последняя транзакция от сирены была добавлена в заказ менее 5 минут назад - переиспользуем ее.
        """
        if not from_repo:
            self.sirena_raw_order = self.sirena_adapter.search_order(
                rloc=order.data.rloc, last_name=order.data.passengers[0].last_name, show_svc=True
            )
            return

        try:
            updated: List[DomainTransactionSource] = list()
            updated.extend([order.meta.created])
            updated.extend(order.meta.updated)
            updated.sort(key=lambda transaction: transaction.date, reverse=True)
            updated = list(filter(lambda u: u.provider == TransactionSource.SIRENA_GRS.value, updated))
            last_sirena_grs_transaction: DomainTransactionSource = updated[0]
        except (IndexError, AttributeError):
            self.sirena_raw_order = self.sirena_adapter.search_order(
                rloc=order.data.rloc, last_name=order.data.passengers[0].last_name, show_svc=True
            )
            return

        if (int(datetime.utcnow().timestamp()) - int(last_sirena_grs_transaction.date)) < 300:
            origin_transaction: DomainOriginTransaction = self.transaction_repo.get_single(
                OriginTransactionsQueryBuilder.get_by_transaction_uuid(
                    message_uuid=last_sirena_grs_transaction.message_id
                )
            )
            self.sirena_raw_order = origin_transaction.raw
        else:
            # Запрашивать сырую транзакцию нужно в любом случае, так как айдишники сегментов/пассажиров/сервисов
            # у нас и у сирены отличаются
            self.sirena_raw_order = self.sirena_adapter.search_order(
                rloc=order.data.rloc, last_name=order.data.passengers[0].last_name, show_svc=True
            )

    def check_existing_services(
        self,
        services: List[DomainService],
        segments: List[DomainSegment],
        now_timestamp: int = int(datetime.utcnow().timestamp()),
    ):
        """
        Проверяем на наличие существующих услуг
        """
        segments_by_id: Dict[str, DomainSegment] = {s.segment_id: s for s in segments}
        paxseg_to_add_svc = set()
        # собираем все сегменты у которых статус уже 060
        service_with_060_status = set()
        for service in services:
            if service.rfisc == self.SERVICE_BAGGAGE_RFISC:
                service_with_060_status.add(service.segment_id)
            service_segment: DomainSegment = segments_by_id.get(service.segment_id)

            if not service_segment:
                continue
            departure_timestamp: int = service_segment.departure_timestamp

            if all(
                (
                    service.rfisc in ['08A', '09P'],
                    service_segment.oak == 'UT',
                    service.status == ServiceStatus.HI.value,
                    departure_timestamp > now_timestamp,
                )
            ):
                paxseg_to_add_svc.add((service.passenger_id, service.segment_id))

        # проверка на то, есть ли у сегмента со статусом 08А сервис с 060?
        # если нет, то добавить.
        if paxseg_to_add_svc:
            for passenger_id, segment_id in sorted(paxseg_to_add_svc):
                if segment_id not in service_with_060_status:
                    # добавляем услугу только тем, у кого нет 060
                    self.services_to_add.append(self.get_request_dto(passenger_id, segment_id))
                    self.should_add_service = True

    def get_request_dto(self, passenger_id: Union[str, int], segment_id: Union[str, int]) -> ServiceForAdd:
        """
        Формирует объект данных для запроса в Сирену
        :param passenger_id:
        :param segment_id:
        :return:
        """
        return ServiceForAdd(
            passenger_id=passenger_id,
            segment_id=segment_id,
            rfic='A',
            rfisc=self.SERVICE_BAGGAGE_RFISC,
            emd='EMD-A',
            service_type='F',
            qtty=1,
        )
