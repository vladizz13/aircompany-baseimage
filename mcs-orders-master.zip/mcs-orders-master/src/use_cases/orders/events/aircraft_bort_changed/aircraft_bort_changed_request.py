from use_cases.orders.base_order_use_case import BaseOrderRequest
from datetime import datetime


class AircraftBortChangedRequest(BaseOrderRequest):

    def __init__(
        self,
        ak: str,
        departure_time_local_plan: datetime,
        flight_number: str,
        new_aircraft_bort: str,
        new_aircraft_type: str,
        old_aircraft_bort: str,
        old_aircraft_type: str,
        point_id: str,
    ):
        super().__init__()
        self.ak: str = ak
        self.departure_time_local_plan: datetime = departure_time_local_plan
        self.flight_number: str = flight_number
        self.new_aircraft_bort: str = new_aircraft_bort
        self.new_aircraft_type: str = new_aircraft_type
        self.old_aircraft_bort: str = old_aircraft_bort
        self.old_aircraft_type: str = old_aircraft_type
        self.point_id: str = point_id

    def is_valid(self, *args, **kwargs) -> 'AircraftBortChangedRequest':
        return self

    def serialize(self) -> dict:
        return {
            'ak': self.ak,
            'departure_time_local_plan': self.departure_time_local_plan,
            'flight_number': self.flight_number,
            'new_aircraft_bort': self.new_aircraft_bort,
            'new_aircraft_type': self.new_aircraft_type,
            'old_aircraft_bort': self.old_aircraft_bort,
            'old_aircraft_type': self.old_aircraft_type,
            'point_id': self.point_id,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            ak=data.get('ak', None),
            departure_time_local_plan=data.get('departure_time_local_plan', None),
            flight_number=data.get('flight_number', None),
            new_aircraft_bort=data.get('new_aircraft_bort', None),
            new_aircraft_type=data.get('new_aircraft_type', None),
            old_aircraft_bort=data.get('old_aircraft_bort', None),
            old_aircraft_type=data.get('old_aircraft_type', None),
            point_id=data.get('point_id', None),
        )
