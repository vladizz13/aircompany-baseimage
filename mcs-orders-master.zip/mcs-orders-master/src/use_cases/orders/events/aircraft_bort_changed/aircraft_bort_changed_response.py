from typing import Dict, List

from use_cases.orders.base_order_use_case import BaseOrderResponse


class AircraftBortChangedResponse(BaseOrderResponse):

    def __init__(self, value: List[Dict] = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: str = None):
        return value
