from typing import List, Dict, Optional
from domain import DomainOrder
from domain.types import OrderStatus, SegmentStatus, SsrsSsr, LoyaltyStatus, ServiceStatus
from domain.order.data.segment import DomainSegment
from domain.order.data.passenger import DomainPassenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from libs.query_builder import AndQueryUnit
from use_cases.orders.events.aircraft_bort_changed.aircraft_bort_changed_request import AircraftBortChangedRequest
from use_cases.orders.events.aircraft_bort_changed.aircraft_bort_changed_response import AircraftBortChangedResponse
from repositories.query_builders.order import OrdersQueryBuilder
from adapter.astra_adapter import AstraInternalAdapter
from adapter.monoapp.monoapp_adapter import MonoAppAdapter
from base.exception import ApplicationError
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin
from datetime import datetime
from libs.utils.debug.dict import deep_convert_dict
from libs.utils.regular_expressions import loyalty_status
from rest.settings.settings import EMARSYS_CHANGE_AIRCRAFT_TYPE_CODE, EMARSYS_CHANGE_AIRCRAFT_EMAIL_NOTIFY


class AircraftBortChangedUseCase(BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):
    """
    Выполняет сравнения характеристик мест+ на карте мест из астры
    """
    SEATS_PLUS_PRICE: int = 999
    SILVER_PASSENGER_SEAT_PLUS_PRICE: int = 699

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        astra_adapter: AstraInternalAdapter,
        monoapp_adapter: MonoAppAdapter
    ):
        self.order_repo: GenericMongoRepository = order_repo
        self.astra_adapter: AstraInternalAdapter = astra_adapter
        self.monoapp_adapter: MonoAppAdapter = monoapp_adapter
        super().__init__()

    def __execute__(self, request: AircraftBortChangedRequest, *args, **kwargs) -> AircraftBortChangedResponse:
        orders = self.find_orders(flight_number=request.flight_number, departure_time=request.departure_time_local_plan)

        if not orders:
            self.logger.info(f"Couldn't find orders by {request.flight_number} {request.departure_time_local_plan}")
            return AircraftBortChangedResponse()

        departure_date_str: str = request.departure_time_local_plan.strftime('%d-%m-%Y')
        departure_time_str: str = request.departure_time_local_plan.strftime('%H:%M')
        departure_timestamp = int(request.departure_time_local_plan.timestamp())
        str_seat_map: List = self.get_str_seat_map(request=request)

        passengers_to_return = dict()
        passengers_to_send_email: List[Dict] = list()
        for order in orders:
            passengers = self.get_seat_plus_passengers(order, departure_timestamp, request.flight_number)
            gold_status_passengers = self.get_status_gold_seat_number(order, request.flight_number, departure_timestamp)
            silver_status_passengers: Optional[List[Dict]] = self.get_status_silver_seat_number(
                order, request.flight_number, departure_timestamp
            )

            if gold_status_passengers:
                passengers_to_send_email.extend(gold_status_passengers)

            if silver_status_passengers:
                passengers_to_send_email.extend(silver_status_passengers)
            if not passengers:
                continue

            for passenger in passengers:
                try:
                    seat = list(passenger.values())
                    if seat[0] not in str_seat_map:
                        # Если мы уже отобрали паксов для отправки сообщ-я, повторно дублировать не нужно.
                        if next((True for p in passengers_to_send_email if p["seat_number"] == seat[0]), False):
                            continue
                        passengers_to_send_email.append({
                            "rloc": order.data.rloc,
                            "last_name": list(passenger.keys())[0],
                            "seat_number": seat[0]
                        })
                except IndexError:
                    continue

            passengers_to_return.update(
                {
                    "rloc": order.data.rloc,
                    "passengers": passengers
                }
            )

        if not passengers_to_send_email:
            return AircraftBortChangedResponse()

        try:
            self.send_email(
                passengers=passengers_to_send_email,
                departure_date=departure_date_str,
                departure_time=departure_time_str,
                flight_number=request.flight_number
            )
        except ApplicationError as e:
            self.logger.info(f"Couldn't send email due to error {e.message}. "
                             f"Flight_number {request.flight_number} "
                             f"departure time {departure_date_str} {departure_time_str} "
                             f"passengers with seat plus service are {passengers_to_send_email}")

        return AircraftBortChangedResponse(value=[passengers_to_return])

    def find_orders(self, departure_time: datetime, flight_number: str) -> List[DomainOrder]:
        """
        Поиск подходящих заказов
        """
        query = AndQueryUnit()
        segment: AndQueryUnit = OrdersQueryBuilder.get_by_segment(
            flight_number=flight_number,
            departure_utc_date=departure_time,
        )
        query.add(segment)

        status: AndQueryUnit = OrdersQueryBuilder.get_by_status(
            status=[OrderStatus.T.value, OrderStatus.A.value]
        )
        query.add(status)

        orders: List[DomainOrder] = self.order_repo.list(spec=query)
        return orders

    @classmethod
    def get_seat_plus_passengers(
        cls,
        order: DomainOrder,
        departure_timestamp: int,
        flight_number: str
    ) -> Optional[List[Dict]]:
        """
        Проверить заказ по БП:
        segment: HK/TK
        service: Есть "0B5" или "STR" в "HI". price "0B5" >= 1000р
        Вернуть карту, где key - last_name, value - номер места
        """
        if order.data.status not in [OrderStatus.T.value, OrderStatus.A.value]:
            return None

        passengers: Dict[str, DomainPassenger] = {p.passenger_id: p for p in order.data.passengers}
        segments: Dict[str, DomainSegment] = cls.get_segments(order, flight_number, departure_timestamp)

        seats_services = []
        for service in order.data.services:
            if all((
                any((
                    all((
                        service.rfisc == '0B5',
                        service.price >= cls.SEATS_PLUS_PRICE if service.price else 0
                    )),
                    service.rfisc == 'STR',
                )),
                service.status == ServiceStatus.HI.value,
                service.segment_id in segments.keys()
            )):
                seats_services.append(service.segment_id)

        if not all((segments, seats_services)):
            return None

        passengers_to_return = []
        for ssr in order.data.ssrs:
            if ssr.ssr == "SEAT" and ssr.segment_id in seats_services:
                passenger = passengers.get(ssr.passenger_id)
                if not passenger:
                    continue
                passengers_to_return.append({f'{passenger.last_name} {passenger.first_name}': ssr.text})

        return passengers_to_return

    def get_str_seat_map(self, request: AircraftBortChangedRequest) -> List:
        """
        Получить карту мест из астры.
        Вернуть словарь состоящий из ключа seatNumber и value rfisc
        """
        seat_map_response = self.astra_adapter.seat_map(
            departure_id=request.point_id,
            version=1
        )
        seat_map = deep_convert_dict(layer=seat_map_response)

        str_seat_map: List = []
        for cabin in seat_map.get("cabin", []):
            for seat in cabin.get("place", []):
                if seat.get("rfisc", "") == "STR":
                    str_seat_map.append(seat["seatNumber"])
        return str_seat_map

    def send_email(self, passengers: List[Dict], departure_date: str, departure_time: str, flight_number: str):
        self.monoapp_adapter.emarsys_send(
            type_code=EMARSYS_CHANGE_AIRCRAFT_TYPE_CODE,
            email_address=EMARSYS_CHANGE_AIRCRAFT_EMAIL_NOTIFY,
            data={
                "departure_date": departure_date,
                "departure_time": departure_time,
                "flight_number": flight_number,
                "passengers": passengers
            }
        )

    @classmethod
    def get_status_gold_seat_number(
        cls,
        order: DomainOrder,
        flight_number: str,
        departure_timestamp: int
    ) -> Optional[List[Dict]]:
        passengers: Dict[str, DomainPassenger] = {p.passenger_id: p for p in order.data.passengers}
        segments: Dict[str, DomainSegment] = cls.get_segments(order, flight_number, departure_timestamp)
        services_segment_id = []
        for service in order.data.services:
            if all((
                service.segment_id in segments.keys(),
                service.status == ServiceStatus.HI.value,
                any((
                    service.rfisc == '0B5',
                    service.rfisc == 'STR'
                ))
            )):
                services_segment_id.append(service.segment_id)

        if not all((segments, services_segment_id)):
            return None
        seat_numbers = {s.passenger_id: s.text for s in order.data.ssrs
                        if s.ssr == "SEAT" and s.segment_id in services_segment_id}

        gold_status_passengers = list()
        for ssr in order.data.ssrs:
            if all((
                ssr.ssr == SsrsSsr.FQTV.value,
                loyalty_status(ssr.text) == LoyaltyStatus.GOLD.value,
                ssr.segment_id in services_segment_id
            )):
                passenger = passengers.get(ssr.passenger_id)
                if not passenger:
                    continue
                gold_status_passengers.append(
                    {
                        "rloc": order.data.rloc,
                        "last_name": f'{passenger.last_name} {passenger.first_name}',
                        "seat_number": seat_numbers.get(ssr.passenger_id)
                    }
                )

        if not gold_status_passengers:
            return None

        return gold_status_passengers

    @classmethod
    def get_status_silver_seat_number(
            cls,
            order: DomainOrder,
            flight_number: str,
            departure_timestamp: int
    ) -> Optional[List[Dict]]:
        passengers: Dict[str, DomainPassenger] = {p.passenger_id: p for p in order.data.passengers}
        segments: Dict[str, DomainSegment] = cls.get_segments(order, flight_number, departure_timestamp)
        services_segment_id = []
        for service in order.data.services:
            if all((
                service.segment_id in segments.keys(),
                service.status == ServiceStatus.HI.value,
                service.rfisc == '0B5',
                service.price == cls.SILVER_PASSENGER_SEAT_PLUS_PRICE if service.price else 0
            )):
                services_segment_id.append(service.segment_id)

        if not all((segments, services_segment_id)):
            return None
        seat_numbers = {s.passenger_id: s.text for s in order.data.ssrs
                        if s.ssr == "SEAT" and s.segment_id in services_segment_id}

        silver_status_passengers = list()
        for ssr in order.data.ssrs:
            if all((
                ssr.ssr == SsrsSsr.FQTV.value,
                loyalty_status(ssr.text) == LoyaltyStatus.SILVER.value,
                ssr.segment_id in services_segment_id
            )):
                passenger = passengers.get(ssr.passenger_id)
                if not passenger:
                    continue
                silver_status_passengers.append(
                    {
                        "rloc": order.data.rloc,
                        "last_name": f'{passenger.last_name} {passenger.first_name}',
                        "seat_number": seat_numbers.get(ssr.passenger_id)
                    }
                )

        if not silver_status_passengers:
            return None

        return silver_status_passengers

    @staticmethod
    def get_segments(
        order: DomainOrder,
        flight_number: str,
        departure_timestamp: int
    ) -> Dict[str, DomainSegment]:
        return {
            s.segment_id: s for s in order.data.segments
            if all((
                s.flight_number == flight_number,
                s.departure_timestamp == departure_timestamp,
                s.status in [SegmentStatus.HK.value, SegmentStatus.TK.value],
            ))
        }
