from abc import abstractmethod
from typing import Any, Dict
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseMonoAppOrderExpander(AbstractChainHandler):
    """
    Базовый расширитель заказа для моноапп
    """
    def handle(self, order: Dict, request: Any = None):
        order = self.expand(order, request)
        return super().handle(order, request)

    @abstractmethod
    def expand(self, order: Dict, request: Any) -> Dict:
        raise NotImplementedError()
