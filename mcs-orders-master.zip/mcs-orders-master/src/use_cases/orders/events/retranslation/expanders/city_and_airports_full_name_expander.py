from typing import Any, Dict
from adapter.monoapp import MonoAppAdapter
from .base_expander import BaseMonoAppOrderExpander
import logging

logger = logging.getLogger('set_available_actions_expander')


class AirportAndCityFullNameExpander(BaseMonoAppOrderExpander):
    """
    Устанавливает флаги возможных действий с бронью (обмен,возврат,покупка доп услуг)
    """

    def __init__(
            self,
            mono_app_adapter: MonoAppAdapter
    ):
        self.mono_app_adapter = mono_app_adapter

    def expand(self, order: Dict, request: Any) -> Dict:
        order: Dict = self.__expand_airports__(order)
        order: Dict = self.__expand_cities__(order)
        return order

    def __expand_cities__(self, order: Dict) -> Dict:
        for segment in order["data"]["segments"]:
            segment["arrival_city_full_name"] = self.mono_app_adapter.get_city_full_name_by_iata(
                iata_code=segment["arrival_city_code"]
            )
            segment["departure_city_full_name"] = self.mono_app_adapter.get_city_full_name_by_iata(
                iata_code=segment["departure_city_code"]
            )
        return order

    def __expand_airports__(self, order: Dict) -> Dict:
        for segment in order["data"]["segments"]:
            segment["departure_airport_full_name"] = self.mono_app_adapter.get_airport_full_name_by_iata(
                iata_code=segment["departure_airport_code"]
            )
            segment["arrival_airport_full_name"] = self.mono_app_adapter.get_airport_full_name_by_iata(
                iata_code=segment["arrival_airport_code"]
            )
        return order
