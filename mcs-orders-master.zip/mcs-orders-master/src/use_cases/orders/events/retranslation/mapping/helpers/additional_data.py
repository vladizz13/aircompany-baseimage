from typing import Dict, List

"""
'additional_data': {
        'discount': {
            'type': {
                'type': 'string'
            },
            'amount': {
                'type': 'number'
            },
            'promo_code': {
                'type': 'string'
            },
            'card_number': {
                'type': 'string'
            }
        },
        },
        'profile_card_number': {
            'type': 'string'
        },
        'business_card_number': {
            'type': ['string', 'null'],
        },
        'pay_token': {
            'type': ['string', 'null']
        },
        'voucher': {
            'id': {'type': ['string', 'null']},
            'amount': {'type': ['number', 'null']},
        }
    }
"""


def get_additional_data(order: Dict):
    pos_data: Dict = order['pos_data']

    # В discounts отличается только один ключ "code" -> "promo_code"
    discounts: List[Dict] = order['price']['discount']
    for discount in discounts:
        discount['promo_code'] = discount.pop('code')

    # Перекладываем поле voucher
    voucher = order.get('price', {}).pop('voucher', {'id': None, 'amount': None})

    mapped_pos_data: Dict = dict(
        discounts=discounts,
        profile_card_number=pos_data['additional_data']['profile_card_number'],
        business_card_number=None,
        pay_token=pos_data['additional_data']['pay_token'],
        voucher=voucher,
        platform=order['analytics_data']['platform'],
        utm=order['analytics_data']['utm']
    )
    return mapped_pos_data
