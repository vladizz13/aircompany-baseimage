from typing import Dict, List
from domain.order.data.ticket import DomainTicket


def __pass_type_switch(pass_type: str) -> str:
    switch = {
        'ADULT': 'ADT',
        'INFANT': 'INF',
        'CHILD': 'CHD'
    }
    return switch[pass_type]


def __get_tickets(order: Dict) -> List[DomainTicket]:
    tickets: List[DomainTicket] = [DomainTicket.deserialize(t) for t in order['tickets']]
    return tickets
