from typing import Dict, List
from domain.types import ContactType, SirenaContactType
from domain.order.data.contacts import DomainContact


def __get_contacts(order: Dict) -> List[DomainContact]:
    contacts: List[DomainContact] = [DomainContact.deserialize(c) for c in order['contacts']]
    return contacts


def get_mail(order: Dict) -> List[str]:
    contacts: List[DomainContact] = __get_contacts(order)
    return [c.contact for c in contacts if c.type == ContactType.MAIL.value]


def get_phone(order: Dict) -> List[str]:
    contacts: List[DomainContact] = __get_contacts(order)
    return [c.contact for c in contacts if all([
        c.type == ContactType.PHONE.value,
        c.sirena_type not in SirenaContactType.AGENT_CONTACT.value
    ])]


def get_phone2(order: Dict) -> List[str]:
    contacts: List[DomainContact] = __get_contacts(order)
    return [c.contact for c in contacts if c.type == ContactType.OTHER.value]


def get_contact_info(order: Dict) -> List[Dict]:
    contacts: List[DomainContact] = __get_contacts(order)
    mapped_contacts: List[Dict] = list()
    for contact in contacts:
        mapped_contacts.append(dict(
            contact=contact.contact,
            confirmed=contact.confirmed if contact.confirmed else False,
            hide=contact.hide
        ))
    return mapped_contacts
