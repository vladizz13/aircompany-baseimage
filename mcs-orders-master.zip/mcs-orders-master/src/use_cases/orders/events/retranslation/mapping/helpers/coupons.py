from typing import List, Dict, Optional
from datetime import datetime
import time

"""
{
    "n": 1,
    "num": "2982428146479",
    "status": "R",
    "sac": null,
    "fare_code": "VSTD15OW",
    "op_comment": null,
    "pass_num": 1,
    "seg_num": 1,
    "itinerary": {
        "marketing": "UT-373",
        "operating": "UT-373",
        "rpi_status": "OK",
        "DepDate": "29.07.2020"
    },
    "coupon_money": {
        "fare": 2750,
        "tax": 592,
        "discount": 284,
        "created": 1595927542
    }
}
"""

UTAIR_DATE_FORMAT = '%d.%m.%Y'
UTAIR_TIME_FORMAT = '%H:%M:%S'
UTAIR_DATETIME_FORMAT = '{} {}'.format(UTAIR_DATE_FORMAT, UTAIR_TIME_FORMAT)


def get_coupons(order: Dict) -> List[Dict]:
    coupons: List[Dict] = order['coupons']
    if not coupons:
        return coupons

    mapped_coupons: List[Dict] = list()

    for coupon in coupons:
        actual_segment: Optional[Dict] = None
        segments: List[Dict] = sorted(coupon['flights'], key=lambda k: k['created'], reverse=True)
        if segments:
            actual_segment: Dict = segments[0]

        coupon: Dict = dict(
            n=coupon['number'],
            num=coupon['ticket'],
            status=coupon['status'],
            sac=coupon['sac'],
            fare_code=coupon['fare_code'],
            op_comment=coupon['op_comment'],
            pass_num=coupon['passenger_id'],
            seg_num=coupon['segment_id'],
            coupon_money=dict(
                fare=coupon['coupon_money']['fare'],
                tax=coupon['coupon_money']['tax'],
                discount=coupon['coupon_money']['discount'],
                created=int(time.time())
            ),
            itinerary=dict()
        )
        if actual_segment:
            try:
                dep_date: datetime = datetime.fromisoformat(actual_segment['departure_local_iso'])
            except ValueError:
                dep_date: datetime = datetime.strptime(actual_segment['departure_local_iso'], UTAIR_DATETIME_FORMAT)
            coupon['itinerary'] = dict(
                marketing=actual_segment['marketing'],
                operating=actual_segment['operating'],
                rpi_status=None,
                DepDate=dep_date.strftime('%d.%m.%Y')
            )

        mapped_coupons.append(coupon)
    return mapped_coupons
