from typing import List, Dict

"""
{
    "number": 1,
    "ticket": "2982428146732",
    "emd": null,
    "indicator": 2,
    "code": "MS",
    "amount": 669,
    "vendor": null,
    "account_num": null,
    "app_code": null,
    "exp_date": null,
    "free_text": "FF/UTXXXXXXXXXXXXXL"
}
"""


def get_fops(order: Dict) -> List[Dict]:
    fops: List[Dict] = order['fops']
    if not fops:
        return fops
    mapped_fops: List[Dict] = list()

    for fop in fops:
        if fop['coupon_id']:
            continue

        mapped_fops.append(dict(
            number=fop['fops_id'],
            ticket=fop['ticket'],
            emd=fop['emd'],
            indicator=fop['indicator'],
            code=fop['code'],
            amount=fop['amount'],
            vendor=fop['vendor'],
            account_num=fop['account_num'],
            app_code=fop['app_code'],
            exp_date=fop['exp_date'],
            free_text=fop['free_text'],
        ))
    return mapped_fops
