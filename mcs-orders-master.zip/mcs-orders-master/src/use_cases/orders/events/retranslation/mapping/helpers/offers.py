from typing import Dict, List

"""
{
    "segment_id": "0",
    "marketing_fare_code": "Оптимум эконом",
    "marketing_fare_code2": "OPTIMUM_NEW",
    "fare_code": "OSTD15OW",
    "sa": None
    "fare_services": [{
        "code": "PROP_CABIN_BAG",
        "name": "Ручная кладь 40&times;30&times;20см",
        "status": "INCLUDED",
        "value": "5 кг"
    }]
}
"""


def get_offers(order: Dict) -> List[Dict]:
    offers: List[Dict] = order['offers']
    if not offers:
        return offers
    mapped_offers: List[Dict] = list()

    for offer in offers:
        mapped_offers.append(dict(
            segment_id=offer['segment_id'],
            marketing_fare_code=offer['brand_code'],
            marketing_fare_code2=offer['brand_name'],
            fare_code=offer['fare_code'],
            # Обогатятся в моноаппе, данных об этих поля в сервисе нет
            fare_services=list(),
            sa=None
        ))
    return mapped_offers
