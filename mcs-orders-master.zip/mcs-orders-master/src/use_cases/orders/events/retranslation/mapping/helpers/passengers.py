from typing import Dict, List
from datetime import datetime
from dateutil.relativedelta import relativedelta
from .common import __pass_type_switch

"""
{
    "passenger_id": "1",
    "gender": "M",
    "last_name": "Галеева",
    "first_name": "Анна",
    "second_name": "Сергеевна",
    "birthday": "09.04.1998",
    "doctype": "ПС",
    "doccountry": "RU",
    "docnumber": "4518944856",
    "docs_first_name": "АННА СЕРГЕЕВНА",
    "docs_surname": "ГАЛЕЕВА",
    "pass_type": "ADT",
    "passenger_parent_id": null,
    "docexpiration": null,
    "ff_cardnumber": "1041620822",
    "id": "39137102",
    "age": 22
}
"""


def get_passengers(order: Dict) -> List[Dict]:
    passengers: List[Dict] = order['passengers']
    documents: Dict[str, Dict] = {d['passenger_id']: d for d in order['documents']}
    if not passengers:
        return passengers
    mapped_passengers: List[Dict] = list()

    for passenger in passengers:
        passenger_id: str = passenger['passenger_id']
        document: Dict = documents[passenger_id]

        first_name: str = passenger['first_name']
        last_name: str = passenger['last_name']
        second_name: str = passenger['second_name']
        birth_day: str = document['birthday']
        birth_day_datetime: datetime = datetime.strptime(birth_day, '%d.%m.%Y') if birth_day else None
        try:
            age: int = (
                    datetime.now() - relativedelta(years=birth_day_datetime.year)
            ).year if birth_day_datetime else None
        except ValueError:
            # 0 лет / младенец
            age: int = 0

        docs_first_name: str = f"{first_name.upper()}"
        if second_name:
            docs_first_name: str = f"{docs_first_name} {second_name.upper()}"

        mapped_passengers.append(dict(
            id=passenger['tais_passenger_id'],
            passenger_id=passenger_id,
            gender=passenger['gender'],
            last_name=passenger['last_name'],
            first_name=passenger['first_name'],
            second_name=passenger['second_name'],
            birthday=birth_day,
            doctype=document['doctype'],
            doccountry=document['doccountry'],
            docnumber=document['docnumber'],
            docs_first_name=docs_first_name,
            docs_surname=last_name.upper(),
            pass_type=__pass_type_switch(passenger['type']),
            passenger_parent_id=passenger['parent_id'],
            docexpiration=document['docexpiration'],
            ff_cardnumber=passenger['loyalty_cardnumber'],
            age=age,
        ))
    return mapped_passengers
