from typing import Dict, Optional, List


def get_term_id(order: Dict) -> Optional[str]:
    term_id: List[Dict] = sorted(order['pos_data']['term_id'], key=lambda k: k['created'])
    if not term_id:
        return None
    return term_id[0]['value']


def get_gds(order: Dict) -> List[Dict]:
    gds: Dict = order['pos_data']['gds']
    if not gds:
        return list()
    if not gds['value']:
        return list()
    return [gds]
