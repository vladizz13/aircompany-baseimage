from typing import Dict, List, Optional


def get_rloc_host(order: Dict) -> Optional[str]:
    rloc_host: List[Dict] = order['rloc_host']
    if not rloc_host:
        return None
    rloc_host: List[Dict] = sorted(order['rloc_host'], key=lambda k: k['created'])
    return rloc_host[0]['value']
