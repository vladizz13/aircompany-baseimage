from typing import Dict, List
import pytz
from datetime import datetime
from domain.types import StringBoolRepresentation

"""
{
    "id": null,
    "ak": "UT",
    "ak_full_name": "ЮТЭИР",
    "flight_number": "373",
    "departure_city_code": "MOW",
    "arrival_city_code": "MRV",
    "departure_city_full_name": "Москва",
    "arrival_city_full_name": "Минеральные Воды",
    "departure_airport_full_name": "Внуково",
    "arrival_airport_full_name": "Минеральные Воды",
    "departure_time": "09:55:00",
    "arrival_time": "12:10:00",
    "departure_airport_code": "VKO",
    "arrival_airport_code": "MRV",
    "departure_date": "29.07.2020",
    "arrival_date": "29.07.2020",
    "arrival_utc": "29.07.2020 09:10:00",
    "departure_utc": "29.07.2020 06:55:00",
    "arrival_unixtime": 1596013800,
    "departure_unixtime": 1596005700,
    "class": "Y",
    "rbd": "V",
    "standby": "N",
    "direction": "TO",
    "status": "XX",
    "seg_type": "inv",
    "segment_id": "1",
    "ns": 1,
    "duration": null,
    "oak": null,
    "oak_full_name": null,
    "plane_type": null,
    "plane_type_name": null,
    "layover_time": 0,
    "departure_hour": 9,
    "departure_weekday": "WE"
}
"""


def get_segments(order: Dict) -> List[Dict]:

    segments: List[Dict] = order['segments']
    if not segments:
        return segments

    remapped_segments: List[Dict] = list()
    for segment in segments:
        departure_local_iso: datetime = datetime.fromisoformat(segment['departure_local_iso'])
        arrival_local_iso: datetime = datetime.fromisoformat(segment['arrival_local_iso'])

        remapped = dict(
            id=segment['tais_segment_id'],
            segment_id=segment['segment_id'],
            ak=segment['ak'],
            ak_full_name=segment['ak_full_name'],
            flight_number=segment['flight_number'],
            departure_city_code=segment['departure_city_code'],
            arrival_city_code=segment['arrival_city_code'],
            departure_airport_code=segment['departure_airport_code'],
            arrival_airport_code=segment['arrival_airport_code'],
            rbd=segment['rbd'],
            standby=StringBoolRepresentation.TRUE.value if segment['standby'] else StringBoolRepresentation.FALSE.value,
            direction=segment['direction'],
            status=segment['status'],
            seg_type=segment['seg_type'],
            ns=segment['ns'],
            duration=segment['duration'],
            oak=segment['oak'],
            oak_full_name=segment['oak_full_name'],
            plane_type=segment['plane_type'],
            plane_type_name=segment['plane_type_name'],
            layover_time=segment['layover_time'],

            departure_time=departure_local_iso.time().__str__(),
            arrival_time=arrival_local_iso.time().__str__(),
            departure_date=departure_local_iso.strftime('%d.%m.%Y'),
            arrival_date=arrival_local_iso.strftime('%d.%m.%Y'),
            arrival_utc=arrival_local_iso.astimezone(pytz.utc).strftime('%d.%m.%Y %H:%M:%S'),
            departure_utc=departure_local_iso.astimezone(pytz.utc).strftime('%d.%m.%Y %H:%M:%S'),
            arrival_unixtime=segment['arrival_timestamp'],
            departure_unixtime=segment['departure_timestamp'],
            departure_hour=departure_local_iso.hour,
            departure_weekday=departure_local_iso.strftime('%A')[:2].upper(),

            # Поля ниже будут заполнены в цепочке нормализации
            departure_city_full_name=None,     # Get from MonoApp
            arrival_city_full_name=None,       # Get from MonoApp
            departure_airport_full_name=None,  # Get from MonoApp
            arrival_airport_full_name=None,    # Get from MonoApp
        )
        remapped['class'] = segment['class']
        remapped_segments.append(remapped)
    return remapped_segments
