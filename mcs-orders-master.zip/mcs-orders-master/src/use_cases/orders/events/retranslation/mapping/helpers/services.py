from typing import Dict, List
from domain.types import TicketMonetaryCode
from domain.order.data.service import DomainService
from domain.order.data.service_money import DomainServiceMoney


def get_services(order: Dict) -> List[Dict]:
    services: List[DomainService] = [
        DomainService.deserialize(s) for s in order['services']
    ]

    mapped_services: List[Dict] = list()

    for service in services:
        mapped_services.append(dict(
            provider=service.provider,
            type=service.add_method,
            type2=service.type,
            rfisc=service.rfisc,
            id=service.tais_id,
            description=service.description,
            price=service.price,
            max_count=None,
            count=service.count,
            freetext=None,
            passenger_id=service.passenger_id,
            segment_id=service.segment_id,
            applicability=None,
            ext_id=service.emd,
            link=service.link,
            pdf_link=service.pdf_link,
            status=service.status
        ))

    return mapped_services


def get_service_money(order: Dict) -> List[Dict]:
    service_money: List[DomainServiceMoney] = [
        DomainServiceMoney.deserialize(s) for s in order['service_money']
    ]

    mapped_service_money: List[Dict] = list()

    for sm in service_money:
        mapped_service_money.append(dict(
            number=sm.emd,
            taxes=None,
            monetary_info=[
                dict(
                    code=TicketMonetaryCode.TOTAL.value,
                    amount=sm.amount,
                    currency=sm.currency
                ),
                dict(
                    code=TicketMonetaryCode.BASE.value,
                    amount=sm.amount,
                    currency=sm.currency
                )
            ],
        ))

    return mapped_service_money
