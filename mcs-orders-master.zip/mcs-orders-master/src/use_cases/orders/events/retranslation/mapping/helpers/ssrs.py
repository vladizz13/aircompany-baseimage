from typing import Dict, List

"""
{
    "airline": "UT",
    "pass_num": 1,
    "qtty": 1,
    "seg_num": 1,
    "ssr": "OTHS",
    "status": "HK",
    "text": "FQTSTATUS BASIC"
},
"""


def get_ssrs(order: Dict) -> List[Dict]:
    ssrs: List[Dict] = order['ssrs']
    if not ssrs:
        return ssrs
    mapped_ssrs: List[Dict] = list()

    for ssr in ssrs:
        mapped_ssrs.append(dict(
            airline=ssr['airline'],
            pass_num=ssr['passenger_id'],
            qtty=ssr['count'],
            seg_num=ssr['segment_id'],
            ssr=ssr['ssr'],
            status=ssr['status'],
            text=ssr['text'],
        ))
    return mapped_ssrs
