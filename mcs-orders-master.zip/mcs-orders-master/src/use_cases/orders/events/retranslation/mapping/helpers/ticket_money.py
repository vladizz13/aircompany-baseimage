from typing import Dict, List
from domain.order.data.ticket import DomainTicket

from .common import __get_tickets

"""
"ticket_money": [{
    "number": "2982428146732",
    "fare_calc": "MOW UT MRV6500RUB6500END",
    "taxes": [{
        "code": "YR",
        "amount": 370,
        "category": "702"
    }, {
        "code": "YQ",
        "amount": 1000,
        "category": "702"
    }],
    "monetary_info": [{
        "code": "T",
        "amount": 1185,
        "currency": "RUB"
    }, {
        "code": "B",
        "amount": 6500,
        "currency": "RUB"
    }],
}]
"""


def __finalize(list_of_dicts: List[Dict]) -> List[Dict]:
    return __sort_result(__remove_duplicates(list_of_dicts))


def __remove_duplicates(list_of_dicts: List[Dict]) -> List[Dict]:
    return [dict(t) for t in {tuple(d.items()) for d in list_of_dicts}]


def __sort_result(list_of_dicts: List[Dict]) -> List[Dict]:
    list_of_dicts: List[Dict] = list(filter(lambda i: i['amount'] is not None, list_of_dicts))
    return sorted(list_of_dicts, key=lambda i: i['amount'], reverse=False)


def get_ticket_money(order: Dict) -> List[Dict]:
    tickets: List[DomainTicket] = __get_tickets(order)

    mapped_tickets: List[Dict] = list()

    for ticket in tickets:
        # Берем amount
        new_taxes: List[Dict] = list()
        taxes: List[Dict] = [t.serialize() for t in ticket.taxes]
        for tax in taxes:
            if tax['coupon_id']:
                continue
            if tax['code'] is None or tax['category'] is None:
                continue
            del tax['coupon_id']
            del tax['amount_rub']
            new_taxes.append(tax)

        new_monetary_info: List[Dict] = list()
        monetary_info: List[Dict] = [mi.serialize() for mi in ticket.monetary_info]
        for mi in monetary_info:
            if mi['coupon_id']:
                continue
            if mi['code'] is None:
                continue
            del mi['coupon_id']
            del mi['amount_rub']
            new_monetary_info.append(mi)
        mapped_tickets.append(dict(
            number=ticket.ticket,
            fare_calc=ticket.fare_calc,
            taxes=__finalize(new_taxes),
            monetary_info=__finalize(new_monetary_info)
        ))

    return mapped_tickets


def get_ticket_money_rub(order: Dict) -> List[Dict]:
    tickets: List[DomainTicket] = __get_tickets(order)

    mapped_tickets: List[Dict] = list()

    for ticket in tickets:
        # Берем amount_rub
        new_taxes: List[Dict] = list()
        taxes: List[Dict] = [t.serialize() for t in ticket.taxes]
        for tax in taxes:
            if tax['coupon_id']:
                continue
            if tax['code'] is None or tax['category'] is None:
                continue
            del tax['coupon_id']
            tax['amount'] = tax.pop('amount_rub')
            new_taxes.append(tax)

        new_monetary_info: List[Dict] = list()
        monetary_info: List[Dict] = [mi.serialize() for mi in ticket.monetary_info]
        for mi in monetary_info:
            if mi['coupon_id']:
                continue
            if mi['code'] is None:
                continue
            del mi['coupon_id']
            mi['amount'] = mi.pop('amount_rub')
            new_monetary_info.append(mi)

        mapped_tickets.append(dict(
            number=ticket.ticket,
            fare_calc=ticket.fare_calc,
            taxes=__finalize(new_taxes),
            monetary_info=__finalize(new_monetary_info)
        ))

    return mapped_tickets
