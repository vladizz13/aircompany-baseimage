from typing import Dict, List
from domain.types import CouponStatus, TicketMonetaryCode
from domain.order.data.ticket import DomainTicket
from domain.order.data.passenger import DomainPassenger
from domain.order.data.coupon import DomainCoupon
from .common import __pass_type_switch, __get_tickets

"""
{
    "docno": "2982428146732",
    "passcat": null,
    "fare": null,
    "taxes": null,
    "price_active": null,
    "psgid": "1",
    "refundable": null
}
"""


def __get_coupons(order: Dict) -> List[DomainCoupon]:
    coupons: List[DomainCoupon] = [DomainCoupon.deserialize(s) for s in order['coupons']]
    return coupons


def __is_returned(ticket_num: str, coupons: List[DomainCoupon]) -> bool:
    terminal_list: List[str] = list(CouponStatus.TERMINAL_LIST.value)
    terminal_list.remove(CouponStatus.F.value)
    for coupon in coupons:
        if all([
            coupon.ticket == ticket_num,
            coupon.status in terminal_list
        ]):
            return True
    return False


def __get_pass_cat_by_passenger_id(passenger_id: str, passengers: List[DomainPassenger]) -> str:
    for passenger in passengers:
        if passenger.passenger_id == passenger_id:
            return __pass_type_switch(str(passenger.type))


def __get_passengers(order: Dict) -> List[DomainPassenger]:
    return [DomainPassenger.deserialize(p) for p in order['passengers']]


def __get_price_active(ticket: DomainTicket) -> int:
    price: int = 0
    for info in ticket.monetary_info:
        if all([
            not info.coupon_id,
            info.code == TicketMonetaryCode.TOTAL.value
        ]):
            price = info.amount_rub
    return price


def get_tickets_active(order: Dict) -> List[Dict]:
    tickets: List[DomainTicket] = __get_tickets(order)
    coupons: List[DomainCoupon] = __get_coupons(order)
    passengers: List[DomainPassenger] = __get_passengers(order)

    mapped_tickets: List[Dict] = list()
    for ticket in tickets:
        if __is_returned(ticket.ticket, coupons):
            continue
        price_active: int = __get_price_active(ticket)
        mapped_tickets.append(dict(
            docno=ticket.ticket,
            passcat=__get_pass_cat_by_passenger_id(ticket.passenger_id, passengers),
            fare=None,
            taxes=None,
            price_active=price_active,
            psgid=ticket.passenger_id,
            refundable=None,
        ))

    return mapped_tickets


def get_tickets_returned(order: Dict) -> List[Dict]:
    tickets: List[DomainTicket] = __get_tickets(order)
    coupons: List[DomainCoupon] = __get_coupons(order)
    passengers: List[DomainPassenger] = __get_passengers(order)

    mapped_tickets: List[Dict] = list()
    for ticket in tickets:
        if not __is_returned(ticket.ticket, coupons):
            continue
        price_active: int = __get_price_active(ticket)
        mapped_tickets.append(dict(
            docno=ticket.ticket,
            passcat=__get_pass_cat_by_passenger_id(ticket.passenger_id, passengers),
            fare=None,
            taxes=None,
            price_active=price_active,
            psgid=ticket.passenger_id,
            refundable=None,
        ))

    return mapped_tickets
