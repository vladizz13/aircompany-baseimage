from libs.mapper.base_mapping import BaseMapping

from .helpers import get_rloc_host
from .helpers import get_segments
from .helpers import get_passengers
from .helpers import get_phone, get_phone2, get_mail, get_contact_info
from .helpers import get_offers
from .helpers import get_ssrs
from .helpers import get_fops
from .helpers import get_coupons
from .helpers import get_term_id, get_gds
from .helpers import get_tickets_returned, get_tickets_active
from .helpers import get_additional_data
from .helpers import get_ticket_money_rub, get_ticket_money
from .helpers import get_services, get_service_money


class MonoAppMapping(BaseMapping):

    mapping = {
        # Root fields:
        'order_id': 'order_id',
        'order_uuid': 'order_uuid',
        'order_key': 'order_key',
        'rloc': 'rloc',
        'payment_id': 'analytics_data.payment_id',
        'partner_id': 'analytics_data.partner_id',
        'device_token': 'analytics_data.device_token',
        'departure_point': 'departure_point',
        'arrival_point': 'arrival_point',
        'segment_count': 'segment_count',
        'partner_data': 'analytics_data.partner_data',
        'partner_data_ex': 'analytics_data.partner_data_ex',
        'tickets_price': 'price.tickets_price',
        'status': 'status',
        'owrt': 'owrt',
        'passenger_count': 'passenger_count',
        'booking_timestamp': 'analytics_data.first_segment_booking_time',
        'rloc_parent_gds': 'rloc_parent_gds',
        'full_price': 'price.full_price',
        'waiting_for_refund': 'waiting_for_refund',
        'timelimit': 'pos_data.timelimit',
        'transfer_start_time': 'departure_start_timestamp',
        'transfer_end_time': 'departure_end_timestamp',
        'pay_method_id': 'analytics_data.pay_method_id',
        'pay_method_code': 'analytics_data.pay_method_code',
        'pos_id': 'pos_data.pos_id',
        'agency': 'pos_data.agency',
        'sirena_id': 'sirena_id',
        'rloc_host': get_rloc_host,
        'term_id': get_term_id,

        # Отсутсвующие поля в сервисе:
        'location': None,  # 'Город создания pnr'
        'country': None,  # 'Страна создания pnr'
        'finalized': False,
        'partner_discount': None,
        'partner_discount_active': None,
        'canceled': None,
        'full_price_active': 0,

        # Nested fields:
        'gds': get_gds,
        'segments': get_segments,
        'passengers': get_passengers,
        'ctc_mail': get_mail,
        'ctc_phone': get_phone,
        'ctc_phone2': get_phone2,
        'contact_info': get_contact_info,
        'offers': get_offers,
        'ssrs': get_ssrs,
        'fops': get_fops,
        'coupons': get_coupons,
        'tickets_active': get_tickets_active,
        'tickets_returned': get_tickets_returned,
        'additional_data': get_additional_data,
        'ticket_money_rub': get_ticket_money_rub,
        'ticket_money': get_ticket_money,
        'service_money': get_service_money,
        'services': get_services,

    }
