from abc import abstractmethod
from typing import Any, Dict
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseMonoAppOrderNormalizer(AbstractChainHandler):
    """
    Базовый нормализатор заказа для моноапп
    """

    def handle(self, order: Dict, request: Any = None):
        order = self.normalize(order, request)
        return super().handle(order, request)

    @abstractmethod
    def normalize(self, order: Dict, request: Any) -> Dict:
        raise NotImplementedError()
