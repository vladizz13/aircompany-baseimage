from typing import Any, Dict, List
from datetime import datetime
from .base_normalizer import BaseMonoAppOrderNormalizer


class DatesMonoAppOrderValueTypesNormalizer(BaseMonoAppOrderNormalizer):
    """
    Нормализация дат
    """
    UTAIR_DATE_FORMAT = '%d.%m.%Y'
    UTAIR_TIME_FORMAT = '%H:%M:%S'

    UTAIR_DATETIME_FORMAT = '{} {}'.format(UTAIR_DATE_FORMAT, UTAIR_TIME_FORMAT)

    FALLBACK_DATE_FORMAT = '%d.%m.%y'
    FALLBACK_TIME_FORMAT = '%H:%M'
    FALLBACK_DATETIME_FORMAT = '{} {}'.format(FALLBACK_DATE_FORMAT, FALLBACK_TIME_FORMAT)

    def normalize(self, order: Dict, request: Any) -> Dict:
        normalizers: List[callable] = [
            self.__normalize_root_fields,
        ]
        [n(order) for n in normalizers]
        return order

    @staticmethod
    def __normalize_root_fields(order: Dict) -> Dict:
        if isinstance(order['data']['timelimit'], str):
            try:
                order['data']['timelimit'] = int(
                    datetime.strptime(
                        order['data']['timelimit'], DatesMonoAppOrderValueTypesNormalizer.UTAIR_DATETIME_FORMAT
                    ).timestamp())
            except ValueError:
                order['data']['timelimit'] = int(
                    datetime.strptime(
                        order['data']['timelimit'], DatesMonoAppOrderValueTypesNormalizer.FALLBACK_DATETIME_FORMAT
                    ).timestamp())
        if not order['data']['rloc_host']:
            del order['data']['rloc_host']
        return order
