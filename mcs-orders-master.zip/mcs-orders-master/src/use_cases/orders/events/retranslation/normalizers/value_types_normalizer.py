import re
from typing import Any, Dict, List
from domain.types import DocTypes
from .base_normalizer import BaseMonoAppOrderNormalizer


class MonoAppOrderValueTypesNormalizer(BaseMonoAppOrderNormalizer):
    """
    Нормализация типов данных заказа
    """

    def normalize(self, order: Dict, request: Any) -> Dict:
        normalizers: List[callable] = [
            self.__normalize_segments,
            self.__normalize_coupons,
            self.__normalize_ssrs,
            self.__normalize_passengers,
            self.__normalize_contacts
        ]
        [n(order) for n in normalizers]
        return order

    @staticmethod
    def has_cyrillic(text):
        return bool(re.search('[\u0400-\u04FF]', text))

    @staticmethod
    def __normalize_passengers(order: Dict) -> Dict:
        inverse_map = {v.lower(): k for k, v in DocTypes.cyrillic_types_map.value.items()}
        for passenger in order['data']['passengers']:
            if not passenger['doctype']:
                continue
            if MonoAppOrderValueTypesNormalizer.has_cyrillic(passenger['doctype']):
                continue
            passenger['doctype'] = inverse_map[passenger['doctype'].lower()] if passenger['doctype'] else None
        return order

    @staticmethod
    def __normalize_coupons(order: Dict) -> Dict:
        for coupon in order['data']['coupons']:
            coupon['pass_num'] = int(coupon['pass_num']) if coupon['pass_num'] else None

            if coupon['seg_num']:
                coupon['seg_num'] = int(coupon['seg_num'])

        return order

    @staticmethod
    def __normalize_contacts(order: Dict) -> Dict:
        contacts: List[Dict] = list()
        for contact in order['data']['contact_info']:
            if not contact.get('contact'):
                continue
            contacts.append(contact)
        order['data']['contact_info'] = contacts
        return order

    @staticmethod
    def __normalize_ssrs(order: Dict) -> Dict:
        for ssr in order['data']['ssrs']:
            ssr['pass_num'] = int(ssr['pass_num']) if ssr['pass_num'] else None
            ssr['seg_num'] = int(ssr['seg_num']) if ssr['seg_num'] else None
        return order

    @staticmethod
    def __normalize_segments(order: Dict) -> Dict:
        for segment in order['data']['segments']:

            if not segment['status']:
                del segment['status']

            if not segment['ns']:
                del segment['ns']

            if not segment['seg_type']:
                del segment['seg_type']
        return order
