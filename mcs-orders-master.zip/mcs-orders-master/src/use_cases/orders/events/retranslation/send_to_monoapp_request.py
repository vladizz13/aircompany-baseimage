from enum import Enum
from typing import Dict, Union
from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain import DomainOrder
from use_cases.orders.exceptions.retranslation import InvalidInputFieldsError


class SendOrderToMonoAppRequest(BaseOrderRequest):

    class RequestType(Enum):
        DOMAIN_ORDER = 0
        UUID_ORDER = 1

    def __init__(
            self,
            order: Union[DomainOrder, Dict, str] = None,
            send_to_mono_app: bool = False,
            discard_order_data: bool = False,
    ):
        super().__init__()
        self.request_type: str = ''
        self.order: [DomainOrder, str] = order
        self.send_to_mono_app = send_to_mono_app
        self.discard_order_data = discard_order_data
        self.resolve_request_type()

    def resolve_request_type(self):
        if isinstance(self.order, DomainOrder):
            self.request_type = self.RequestType.DOMAIN_ORDER
        elif isinstance(self.order, Dict):
            self.order = DomainOrder.deserialize(self.order)
            self.request_type = self.RequestType.DOMAIN_ORDER
        elif isinstance(self.order, str):
            self.request_type = self.RequestType.UUID_ORDER

    def is_valid(self, *args, **kwargs) -> 'SendOrderToMonoAppRequest':
        if self.discard_order_data and not self.send_to_mono_app:
            self.add_error(InvalidInputFieldsError(
                message="Use discard_order_data property only with send_to_mono_app"
            ))
        return self

    def serialize(self) -> dict:
        return {
            'order': self.order.serialize() if isinstance(self.order, DomainOrder) else self.order,
        }

    @classmethod
    def deserialize(cls, data: dict):
        if isinstance(data.get('order'), str):
            return cls(
                order=data.get('order')
            )
        else:
            cls(
                order=DomainOrder.deserialize(data.get('order', None)),
            )
