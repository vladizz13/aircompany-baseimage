from typing import Dict
from use_cases.orders.base_order_use_case import BaseOrderResponse


class SendOrderToMonoAppResponse(BaseOrderResponse):

    def __init__(self, value: Dict = None, discard_data: bool = False):
        super().__init__(self.serialize(value, discard_data))

    @staticmethod
    def serialize(value: Dict = None, discard_data: bool = False):
        if not discard_data:
            return value
        return {
            "success": True
        }
