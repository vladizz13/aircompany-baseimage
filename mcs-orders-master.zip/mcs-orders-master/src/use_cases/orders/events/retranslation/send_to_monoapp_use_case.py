import time
from fastjsonschema.exceptions import JsonSchemaException

try:
    from libs.validators.compiled_schemas.mono_app_schema import validate
except ImportError:
    # Скомпилируем на лету один раз
    from cli.utils.schema_compiler import SchemaCompiler
    SchemaCompiler().compile()
    from libs.validators.compiled_schemas.mono_app_schema import validate  # noqa

from typing import Dict, List, Optional, Type
from event_engine import Event
from domain import DomainOrder
from domain.order.meta.transaction_source import DomainTransactionSource
from domain.types import OrderStatus
from adapter.monoapp import MonoAppAdapter
from base.exception import ApplicationError

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder

from events.events.save import SendOrderToMonoAppEvent

from libs.mapper.mapper import Mapper, MapperError
from libs.chain_of_responsibility.chain import InitChainUnit

from ...events.retranslation.mapping.mono_app_mapping import MonoAppMapping
from ...base_order_use_case import BaseOrderUseCase

from ...exceptions.retranslation import MonoAppOrderRetranslationError
from ...save.deferred_save.deferred_save_queue import SaveOrdersQueue
from .send_to_monoapp_request import SendOrderToMonoAppRequest
from .send_to_monoapp_response import SendOrderToMonoAppResponse

from .expanders.city_and_airports_full_name_expander import AirportAndCityFullNameExpander

from .normalizers.value_types_normalizer import MonoAppOrderValueTypesNormalizer
from .normalizers.date_normalizer import DatesMonoAppOrderValueTypesNormalizer


class SendOrderToMonoAppUseCase(BaseOrderUseCase):
    """
    Ретрансляция заказа в моноапп
    """
    RETRANSLATION_LOCK_PREFIX = 'mono_app_retranslation'

    def __init__(
        self,
        save_order_queue: SaveOrdersQueue,
        mono_app_adapter: MonoAppAdapter,
        order_repo: GenericMongoRepository = None
    ):
        super().__init__()
        self.save_order_queue = save_order_queue
        self.mono_app_adapter = mono_app_adapter
        self.order_repo = order_repo

        self.events: List[Type[Event]] = [
            SendOrderToMonoAppEvent
        ]

    def __execute__(self, request: SendOrderToMonoAppRequest, *args, **kwargs) -> SendOrderToMonoAppResponse:
        order: Optional[DomainOrder] = self.get_order_based_on_request_type(request)
        if not order:
            return SendOrderToMonoAppResponse.build_from_exception(
                MonoAppOrderRetranslationError(
                    message="Order not found"
                )
            )

        # Проверяем можно ли отсылать в моноапп
        if not self.is_suitable_for_update(order):
            return SendOrderToMonoAppResponse.build_from_exception(
                MonoAppOrderRetranslationError(
                    message=f"Order is not suitable for mono_app: [status: {order.data.status}] "
                    f"not suitable or order is in save queue"
                )
            )

        # Создаем заказ для отправки
        try:
            mono_app_order: Dict = self.compile_order(order)
        except ApplicationError as e:
            self.logger.info(e.message)
            return SendOrderToMonoAppResponse.build_from_exception(
                MonoAppOrderRetranslationError(message=f"Unable to map order, reason {str(e.message)}")
            )

        # Прогоняем через цепочки
        try:
            self.__normalize_order__(mono_app_order)
            self.__expand_order__(mono_app_order)
        except ApplicationError as e:
            message: str = f"{e.message}, [{order.data.rloc}], reason: {str(e.inner_exception)}"
            self.logger.info(message)
            return SendOrderToMonoAppResponse.build_from_exception(
                MonoAppOrderRetranslationError(message=message)
            )

        # Провалидировать заказ на стороне сервиса
        is_valid, exception = self.__validate_order__(mono_app_order)
        if not is_valid:
            message: str = f"Unable to validate order [{order.data.rloc}], reason: {str(exception)}"
            self.logger.info(message)
            return SendOrderToMonoAppResponse.build_from_exception(
                MonoAppOrderRetranslationError(message=message)
            )

        if request.send_to_mono_app:
            # Послать эвент (кафка) на сохранение в моноапп
            self.__raise_event__(event=SendOrderToMonoAppEvent, payload=mono_app_order)

        return SendOrderToMonoAppResponse(value=mono_app_order, discard_data=request.discard_order_data)

    def get_order_based_on_request_type(
            self,
            request: SendOrderToMonoAppRequest
    ) -> Optional[DomainOrder]:
        """
        Получаем заказ в зависимости от типа запроса
        """
        if request.request_type == request.RequestType.DOMAIN_ORDER and request.order.is_valid:
            return request.order

        if request.request_type == request.RequestType.UUID_ORDER:
            if not self.order_repo:
                return None

            order: DomainOrder = self.order_repo.get_single(
                spec=OrdersQueryBuilder.get_by_order_uuid(request.order)
            )
            return order
        return None

    @staticmethod
    def get_retranslation_lock_key(key: str) -> str:
        return f"{SendOrderToMonoAppUseCase.RETRANSLATION_LOCK_PREFIX}-{key}"

    def is_suitable_for_update(self, order: DomainOrder) -> bool:
        """
        Проверяем подходит ли заказ для обновления
        Должен соотвествать правилам:
            - Заказ в статусе T/A
            - В очереди на сохранение заказа транзакция последняя
            - Очередь пустая
            - Очереди нет (non-deferred-save)
        Для того, чтобы убедиться, что все правила по очередям отрабатывают мы ставим
        отдельный лок во время сохранения заказа в очереди, ключем такого лока будет
        >>> self.get_retranslation_lock_key()
        Перед обработкой последнего заказа в очереди этот лок будет снят
        СМ таску:
        >>> from rest.applications.celery_app.tasks.deferred_save import deferred_save_task
        """
        if order.data.status not in [
            OrderStatus.T.value,
            OrderStatus.A.value,
        ]:
            return False

        return not self.save_order_queue.queue_is_active(
            self.get_retranslation_lock_key(order.data.rloc), custom_key=True
        )

    @staticmethod
    def compile_order(order: DomainOrder) -> Dict:
        """
        Мапим заказ в структуру моноаппа и добавляем метаданные
        """
        try:
            mapped_order: dict = Mapper.map(
                order.data.serialize(),
                mapping=MonoAppMapping(),
                log_level="fall_on_exception"
            )
        except MapperError as e:
            raise ApplicationError(message=f"Failed to map order [{order.data.rloc}], reason: {e}")
        # Всегда проставляем заказу статус T, так как с другими моноапп работать не умеет
        mapped_order['status'] = OrderStatus.T.value

        updated_meta: Optional[DomainTransactionSource] = order.meta.updated[-1] if order.meta.updated else None
        mono_app_order: Dict = dict(
            data=mapped_order,
            meta=dict(
                is_hidden_for=[i.serialize() for i in order.meta.is_hidden_for],
                sub_owners=[i.serialize() for i in order.meta.sub_owners],
                mcs_orders_tags=dict(
                    sent_at=time.time(),
                    last_transaction_time=updated_meta.date if updated_meta else order.meta.created.date,
                    last_transaction_uuid=updated_meta.message_id if updated_meta else order.meta.created.message_id,
                    last_transaction_provider=updated_meta.provider if updated_meta else order.meta.created.provider,
                    total_transactions=len(order.meta.updated) + 1,   # Плюс одна транзакция о создании
                    current_iteration=0,    # Будет инкрементированна при сохранении, плейсхолдер
                ),
                created=dict(
                    provider=order.meta.created.provider,
                    date=int(order.meta.created.date)
                )
            )
        )

        return mono_app_order

    @staticmethod
    def __normalize_order__(order: Dict) -> Dict:
        """
        Нормализуем типы данных в заказе
        """
        # Цепочка нормализаций
        chain = InitChainUnit()
        (
            chain
            .set_next(MonoAppOrderValueTypesNormalizer())
            .set_next(DatesMonoAppOrderValueTypesNormalizer())
        )
        try:
            chain.handle(order, request=None)
        except Exception as e:
            raise ApplicationError(inner_exception=e, message="Normalize error")
        return order

    def __expand_order__(self, order: Dict) -> Dict:
        """
        Добавляем отсуствующие после маппинга данные
        """
        chain = InitChainUnit()
        (
            chain
            .set_next(AirportAndCityFullNameExpander(mono_app_adapter=self.mono_app_adapter))
        )
        try:
            chain.handle(order, request=None)
        except Exception as e:
            raise ApplicationError(inner_exception=e, message="Expand error")
        return order

    @staticmethod
    def __validate_order__(order: Dict) -> (bool, Optional[Exception]):
        """ Json schema валидация заказа"""
        try:
            validate(order['data'])
            return True, None
        except JsonSchemaException as e:
            return False, e
