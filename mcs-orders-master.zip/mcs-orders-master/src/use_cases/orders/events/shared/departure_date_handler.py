from domain.order.data import DomainSegment


class GetDepartureDateMixin:
    """
    Формирует строку даты вылета для отправки в Сирену
    """

    def get_departure_date(self, segment: DomainSegment) -> str:
        """
        Формирует строку даты вылета для отправки в Сирену
        :param segment:
        :return:
        """
        departure_data = segment.departure_local_iso.split('T')[0].split('-')
        departure_data.reverse()
        departure_data = '.'.join(departure_data)
        return departure_data
