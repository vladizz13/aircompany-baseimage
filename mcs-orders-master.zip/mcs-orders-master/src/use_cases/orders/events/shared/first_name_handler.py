from domain.order.data import DomainPassenger


class GetDFirstNameMixin:
    """
    Формирует строку даты вылета для отправки в Сирену
    """

    def get_first_name(self, passenger: DomainPassenger) -> str:
        """
        Формирует строку даты вылета для отправки в Сирену
        Сирена требует явно указывать обращение к пассажиру (title)
        :param passenger:
        :return:
        """
        title = passenger.title if passenger.title else ""
        f_name = passenger.first_name.upper()
        if passenger.second_name:
            f_name = f'{f_name} {passenger.second_name.upper()}'
        f_name = f'{f_name} {title}'.rstrip()
        return f_name
