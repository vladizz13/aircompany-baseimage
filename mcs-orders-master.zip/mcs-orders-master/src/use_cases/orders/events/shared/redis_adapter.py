from libs.redis_queues.base import BaseRedisQueue
from redis import Redis, ResponseError
import json
from typing import List, Any, Dict


class RedisSsrsAdapter(BaseRedisQueue):

    ssrs_prefix = "ssrs-"

    def __init__(self, gateway: Redis):
        super(RedisSsrsAdapter, self).__init__(gateway=gateway)

    def __get_key__(self, key: str) -> str:
        """
        Составление ключа
        """
        return self.ssrs_prefix + key

    def get_values_by_key(self, key: str) -> List[Any]:
        """
        Получить все элементы очереди по ключу
        """
        _key = self.__get_key__(key)
        try:
            queued_items: List[Any] = self.__gateway__.lrange(_key, 0, -1)
        except ResponseError:
            queued_items: List[int] = self.__gateway__.get(_key)
        return queued_items

    def add_to_queue(self, key: str, value: List[Dict]):
        """
        Добавить значения в конец списка
        """
        _key = self.__get_key__(key)
        self.__gateway__.rpush(_key, *[json.dumps(data) for data in value])

    def remove_by_key(self, key: str):
        """
        Удалить значения по ключу
        """
        _key = self.__get_key__(key)
        self.__gateway__.delete(_key)

    def get_from_queue(self, key: str, count: int) -> List[Any]:
        """
        Удалить и вернуть элементы списка
        """
        _key = self.__get_key__(key)
        return self.__gateway__.lpop(_key, count)
