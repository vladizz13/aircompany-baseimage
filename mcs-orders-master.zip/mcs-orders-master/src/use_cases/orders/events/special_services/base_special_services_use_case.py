from datetime import datetime
from time import sleep
from typing import List, Dict, Optional, Set
from redis import Redis
from sirena_xml_client.exceptions import BaseSirenaError

from adapter.monoapp.monoapp_adapter import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.service_desk import JiraServiceDeskAdapter
from base.exception import ApplicationError
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.base_order_use_case import BaseUseCaseResponse
from use_cases.orders.base_order_use_case import BaseOrderUseCase

from domain import DomainOrder
from domain.order.data import DomainSegment
from domain.refunds import DomainRefund, DomainRefundPassengerData
from domain.order.data.passenger import DomainPassenger
from domain.order.data import DomainContact
from domain.types import ContactType, MatchTypes, SirenaContactType, JiraLabels, TypeCode

from libs.query_builder import AndQueryUnit
from repositories.query_builders import OrdersQueryBuilder

from use_cases.orders.exceptions.user import OrderNotFoundError
from sirena_xml_client.types import PassengersForReleaseSeats, SegmentsForReleaseSeats


class RedisSpecialServicesUseCase(BaseOrderUseCase):

    def __init__(
        self,
        redis: Redis
    ):
        super().__init__()
        self.redis = redis

    @staticmethod
    def _value_prefix():
        return "order_uuid:"

    @classmethod
    def create_set_value(cls, order_uuid: str) -> str:
        _value: str = f'{cls._value_prefix()}{order_uuid}'
        return _value

    @staticmethod
    def get_key() -> str:
        _key: str = "ssr-special-services"
        return _key

    @classmethod
    def get_value_without_prefix(cls, value: str) -> str:
        prefix, _value = value.split(cls._value_prefix())
        return _value

    def remove_special_services_from_set(self, value: str):
        _key = self.get_key()
        self.redis.srem(_key, value)

    def redis_set_value(self, key: str, value: str):
        self.redis.sadd(key, value)

    def get_values_by_key(self, _key: str) -> Set[str]:
        return self.redis.smembers(_key)


class BaseSpecialServicesUseCase(RedisSpecialServicesUseCase):
    def __init__(
        self,
        mono_app_adapter: MonoAppAdapter,
        redis: Redis,
        order_repo: GenericMongoRepository,
        sirena_adapter: Optional[SirenaInternalAdapter] = None,
        jira_adapter: Optional[JiraServiceDeskAdapter] = None,
        refunds_repo: GenericMongoRepository = None
    ):
        super().__init__(redis=redis)
        self.mono_app_adapter = mono_app_adapter
        self.order_repo = order_repo
        self.sirena_adapter = sirena_adapter
        self.jira_adapter: JiraServiceDeskAdapter = jira_adapter
        self.refunds_repo: GenericMongoRepository = refunds_repo

    def __execute__(self, request: BaseOrderRequest, *args, **kwargs) -> BaseUseCaseResponse:
        raise NotImplementedError()

    def create_email_template(self, order: DomainOrder, type_code: str) -> Dict:
        email: Optional[str] = self.get_email(order.data.contacts)
        dob: Dict[str, str] = {d.passenger_id: d.birthday for d in order.data.documents}

        cities_name: Dict[str, str] = self.__get_cities_name(segments=order.data.segments)

        data = {
            "data": {
                'rloc': order.data.rloc.split('/')[0],
                'passengers': [{
                    "last_name": p.last_name,
                    "first_name": p.first_name,
                    "second_name": p.second_name if p.second_name else "",
                    "birthday": dob.get(p.passenger_id)
                    } for p in order.data.passengers
                ],
                'segments': [
                    {
                        "flight": f'{s.ak}{s.flight_number}' if s.ak else s.flight_number,
                        "departure_date": datetime.fromisoformat(s.departure_local_iso).strftime('%d.%m.%Y'),
                        "departure": f"{cities_name.get(s.departure_city_code, '')} {s.departure_airport_code}",
                        "arrival": f"{cities_name.get(s.arrival_city_code, '')} {s.arrival_airport_code}"
                    } for s in order.data.segments
                ]
            },
            'type_code': type_code,
            'email_address': email,
        }
        return data

    def __get_cities_name(self, segments: List[DomainSegment]) -> Dict[str, str]:
        city_codes = [(s.departure_city_code, s.arrival_city_code) for s in segments]
        unique_cities = (element for code in city_codes for element in code)

        cities_with_airport = {}
        for _city in unique_cities:
            try:
                city = self.mono_app_adapter.get_city_full_name_by_iata(iata_code=_city)
            except ApplicationError:
                # не падаем
                city = ""
            cities_with_airport.update({_city: city})
        return cities_with_airport

    @staticmethod
    def get_email(contacts: List[DomainContact]) -> Optional[str]:
        """ Найти подходящий email-адрес"""
        for contact in contacts:
            if all((
                contact.type == ContactType.MAIL.value,
                contact.match_type == MatchTypes.AUTO.value,
                not contact.hide
            )):
                return contact.contact

    def send_email(self, type_code: str, email_address: str, data: Dict):
        self.mono_app_adapter.emarsys_send(
            type_code=type_code,
            email_address=email_address,
            data=data
        )

    def get_order_by_order_uuid(self, order_uuid: str) -> DomainOrder:
        query: AndQueryUnit = OrdersQueryBuilder.get_by_order_uuid(order_uuid)
        order: DomainOrder = self.order_repo.get_single(query)
        if order:
            return order
        raise OrderNotFoundError()

    @staticmethod
    def get_phone_number(contacts: List[DomainContact]) -> Optional[str]:
        for contact in contacts:
            if all((
                contact.type == ContactType.PHONE.value,
                not contact.hide,
                contact.sirena_type not in SirenaContactType.AGENT_CONTACT.value
            )):
                return contact.contact
        return None

    def store_refund_in_db(
        self,
        order_refund_id: str,
        order: DomainOrder,
        passengers_to_refund: List[DomainPassenger],
        involuntary: bool = True,
    ):
        """ Сохранить успешную заявку на возврат заказа в бд"""
        datetime_utc = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        contact = self.get_phone_number(contacts=order.data.contacts)

        refund_passengers: List[DomainRefundPassengerData] = []
        for p in passengers_to_refund:
            refund_passengers.append(DomainRefundPassengerData(
                passenger_id=p.passenger_id,
                first_name=p.first_name,
                last_name=p.last_name,
                second_name=p.second_name,
                type=p.type
            ))

        order_refund = DomainRefund(
            passengers=refund_passengers,
            order_uuid=order.data.order_uuid,
            involuntary=involuntary,
            datetime_utc=datetime_utc,
            order_refund_id=order_refund_id,
            contact=contact
        )

        self.refunds_repo.create(order_refund)

    def release_seats(self, order: DomainOrder):
        retry_count = 4
        for i in range(retry_count):
            # Превысили максимальное кол-во повторов.
            if i + 1 == retry_count:
                raise BaseSirenaError()

            try:
                res = self.sirena_adapter.release_seats(
                    rloc=order.data.rloc,
                    surname=order.data.passengers[0].last_name,
                    passengers=self.__create_release_seats_passengers(
                        passengers=order.data.passengers
                    ),
                    segments=self.create_release_seats_segments(order.data.segments)
                )
                if not res:
                    sleep(3)
                    continue
                return res
            except BaseSirenaError:
                sleep(3)
                continue

    @staticmethod
    def create_release_seats_segments(segments: List[DomainSegment]) -> List[SegmentsForReleaseSeats]:
        _segments: List[SegmentsForReleaseSeats] = list()
        for s in segments:
            _segments.append(
                SegmentsForReleaseSeats(
                    company=s.ak,
                    flight=s.flight_number,
                    departure=s.departure_airport_code,
                    arrival=s.arrival_airport_code,
                    departure_date=datetime.fromisoformat(s.departure_local_iso).strftime('%d.%m.%Y'),
                )
            )
        return _segments

    @staticmethod
    def compose_first_name(passenger: DomainPassenger) -> str:
        first_name = passenger.first_name
        if second_name := passenger.second_name:
            first_name = f"{first_name.capitalize()} {second_name.capitalize()}"
        return first_name

    def __create_release_seats_passengers(self, passengers: List[DomainPassenger]) -> List[PassengersForReleaseSeats]:
        _passengers: List[PassengersForReleaseSeats] = list()
        for p in passengers:
            _passengers.append(
                PassengersForReleaseSeats(
                    first_name=self.compose_first_name(p),
                    last_name=p.last_name
                )
            )
        return _passengers

    def __fallback__(self, order: DomainOrder):
        """
        Если не удалось сдать места после всех ретраев, в процессе отказа спец обслуживания,
        создадим заявку в jira с соотв-ей меткой и удалим заказ из редиса, иначе он там может остаться навсегда.
        """
        try:
            order_refund_id = self.jira_adapter.apply_for_refund(
                order_uuid=order.data.order_uuid,
                is_involuntary=True,
                labels=[JiraLabels.SPECIAL_SERVICE_DENIED.value, JiraLabels.RELEASE_SEATS_FAILED.value, ]
            )["key"]
        except ApplicationError as e:
            # не падаем, сохраним попытку в БД для дальнейшего дебага
            self.logger.info(f'Не удалось создать заявку в jira по заказу {order.data.order_uuid} ошибка {str(e)}')
            order_refund_id = ""

        self.store_refund_in_db(
            order_refund_id=order_refund_id,
            order=order,
            passengers_to_refund=order.data.passengers,
            involuntary=True
        )

        email_template: Dict = self.create_email_template(
            order=order, type_code=TypeCode.SPECIAL_SERVICE_SSR_NOT_CONFIRMED.value
        )
        self.send_email(**email_template)

        value: str = self.create_set_value(order_uuid=order.data.order_uuid)
        self.remove_special_services_from_set(value=value)
