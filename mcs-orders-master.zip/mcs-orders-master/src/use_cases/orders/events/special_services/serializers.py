from typing import Optional, List
from pydantic import BaseModel


class Passenger(BaseModel):
    passenger_id: str
    first_name: str
    last_name: str
    second_name: Optional[str]


class Segment(BaseModel):
    segment_id: str


class UnSpecialServicesSerializer(BaseModel):
    rloc: str
    last_name: str
    passengers: List[Passenger]
    segments: List[Segment]


class HnSpecialServicesSerializer(BaseModel):
    rloc: str
    last_name: str
    passengers: List[Passenger]
    segments: List[Segment]
