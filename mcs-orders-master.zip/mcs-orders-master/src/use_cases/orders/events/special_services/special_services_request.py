from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.user import InvalidOrderUUIDError


class ProcessSpecialServicesRequest(BaseOrderRequest):

    def __init__(
        self,
        special_services_key: str,
    ):
        super().__init__()
        self.special_services_key: str = special_services_key

    def is_valid(self, *args, **kwargs) -> 'ProcessSpecialServicesRequest':
        return self

    def serialize(self) -> dict:
        return {
            'special_services_key': self.special_services_key
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            special_services_key=data.get('special_services_key', None)
        )


class HkSpecialServicesRequest(BaseOrderRequest):

    def __init__(
        self,
        order_uuid: str,
    ):
        super().__init__()
        self.order_uuid: str = order_uuid

    def is_valid(self, *args, **kwargs) -> 'HkSpecialServicesRequest':
        if not self.order_uuid:
            self.add_error(InvalidOrderUUIDError())
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None)
        )


class UnSpecialServicesRequest(BaseOrderRequest):

    def __init__(
        self,
        order_uuid: str
    ):
        super().__init__()
        self.order_uuid: str = order_uuid

    def is_valid(self, *args, **kwargs) -> 'UnSpecialServicesRequest':
        if not self.order_uuid:
            self.add_error(InvalidOrderUUIDError())
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None)
        )


class HnSpecialServicesRequest(BaseOrderRequest):

    def __init__(
        self,
        order_uuid: str
    ):
        super().__init__()
        self.order_uuid: str = order_uuid

    def is_valid(self, *args, **kwargs) -> 'HnSpecialServicesRequest':
        if not self.order_uuid:
            self.add_error(InvalidOrderUUIDError())
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None)
        )
