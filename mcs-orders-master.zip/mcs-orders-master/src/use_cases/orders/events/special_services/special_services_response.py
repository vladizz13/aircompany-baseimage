from typing import Dict
from use_cases.orders.base_order_use_case import BaseOrderResponse


class ProcessSpecialServicesResponse(BaseOrderResponse):

    def __init__(self, value: Dict = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: Dict = None):
        return value
