import uuid
from time import time
from datetime import datetime
from typing import Dict, List, Set, Type
from redis import Redis
from libs.query_builder import AndQueryUnit
from repositories.query_builders import OrdersQueryBuilder
from domain import DomainOrder
from domain.order.data import DomainSSR
from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter, BaseSirenaError
from domain.types import SsrStatus, SsrPassengerType, TypeCode, TransactionSource, JiraLabels
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from base.exception import ApplicationError
from .special_services_request import (
    ProcessSpecialServicesRequest,
    HkSpecialServicesRequest,
    HnSpecialServicesRequest,
    UnSpecialServicesRequest
)
from .special_services_response import ProcessSpecialServicesResponse
from .base_special_services_use_case import BaseSpecialServicesUseCase
from rest.applications.celery_app.tasks.special_services import confirmed_service, canceled_service, requested_service
from adapter.service_desk import JiraServiceDeskAdapter
from use_cases.orders.exceptions.user import OrderNotFoundError
from adapter.service_desk.exceptions import JiraSDBaseError
from use_cases.orders.exceptions.refund import FailedRegisterRefundInServiceDeskError


class ProcessSpecialServicesUseCase(BaseSpecialServicesUseCase):
    # Не будем ставить селери задачи сразу, чтобы избежать ошибки SirenaPnrBusy
    COUNTDOWN = 5

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            redis: Redis,
            mono_app_adapter: MonoAppAdapter,
            internal_order_adapter: Type[InternalOrderAdapter],
            sirena_adapter: SirenaInternalAdapter = SirenaInternalAdapter,
    ):
        super().__init__(
            mono_app_adapter=mono_app_adapter,
            redis=redis,
            order_repo=order_repo,
            sirena_adapter=sirena_adapter
        )
        self.internal_order_adapter = internal_order_adapter

    def __execute__(self, request: ProcessSpecialServicesRequest, *args, **kwargs) -> ProcessSpecialServicesResponse:
        special_services: Set[str] = self.get_values_by_key(request.special_services_key)
        if not special_services:
            return ProcessSpecialServicesResponse(value={"status": "ok"})

        self.logger.info(f'special_services order uuids are {special_services}')

        for special_service in special_services:

            order_uuid: str = self.get_value_without_prefix(value=special_service)

            query: AndQueryUnit = self.build_query(order_uuid)

            try:
                order: DomainOrder = self.order_repo.get_single(spec=query)
            except OrderNotFoundError:
                self.logger.info(f'Не удалось найти заказ {order_uuid=}')
                continue

            if not order:
                self.logger.exception(f'Не удалось найти заказ {order_uuid=}')
                continue

            # Обновляем заказ свежими данными из Сирены
            try:
                sirena_raw: Dict = self.get_data_from_sirena(order.data.rloc, order.data.passengers[0].last_name)
                self.update_order(sirena_raw)
            except (ApplicationError, BaseSirenaError):
                continue

            try:
                order: DomainOrder = self.order_repo.get_single(spec=query)
            except OrderNotFoundError:
                self.logger.info(f'Не удалось найти заказ {order_uuid=}')
                continue

            if not order:
                self.logger.exception(f'Не удалось найти заказ {order_uuid=}')
                continue

            ssrs = self.get_special_services_ssrs(order)

            if not ssrs:
                # странно, если сюда попадем, потому что мы работаем с заказами, у которых есть соответ-ие ссрки
                self.logger.exception(f'В заказе {order_uuid=} не найдены сср спец обслуживания')
                continue

            self.strategy(ssrs, order)

        return ProcessSpecialServicesResponse(value={"status": "ok"})

    @staticmethod
    def build_query(order_uuid: str) -> AndQueryUnit:
        query: AndQueryUnit = AndQueryUnit()
        query.add(OrdersQueryBuilder.get_by_order_uuid(order_uuid))
        return query

    @staticmethod
    def get_special_services_ssrs(order: DomainOrder) -> List[DomainSSR]:
        ssrs: List[DomainSSR] = [s for s in order.data.ssrs if s.ssr in SsrPassengerType.SPECIAL_SERVICE_PASSENGERS.value] # noqa
        return ssrs

    @staticmethod
    def has_canceled_ssr(ssrs: List[DomainSSR]) -> bool:
        return next((True for ssr in ssrs if ssr.status == SsrStatus.UN.value), False)

    @staticmethod
    def is_all_ssrs_processed(ssrs: List[DomainSSR]) -> bool:
        """
        По бизнес правилам считаем сср обработанной тогда, когда сср перешла в статус
        подтвержденная или отклоненная, HK и UN соответственно.
        """
        for s in ssrs:
            if s.status not in [SsrStatus.HK.value, SsrStatus.UN.value]:
                return False
        return True

    def strategy(self, ssrs: List[DomainSSR], order: DomainOrder):
        """
        Если в заказе 2 и более ссрки, то проверим есть ли среди них отмененная.
        Если есть сср в статусе UN, то отменяем заказ целиком.
        Запускаем таску один раз.
        """
        # если есть отмененная ссрка и не прошло 6 часов, то не будем ждать, сразу отменим заказ
        if self.has_canceled_ssr(ssrs=ssrs) and not self.is_created_date_expired(order=order):
            self.canceled_service(order=order)
            return

        # если не все заявки обработаны и не прошло больше 6 часов
        if not self.is_all_ssrs_processed(ssrs) and not self.is_created_date_expired(order):
            # пропускаем этот заказ, вернемся к нему через 30 минут (иначе будем отправлять письма повторно)
            return

        # прошло больше 6 часов
        if self.is_created_date_expired(order):
            self.requested_service(order=order)
            return

        for ssr in ssrs:
            if ssr.status == SsrStatus.UN.value:
                self.canceled_service(order=order)
                return
        self.confirmed_service(order=order)

    @classmethod
    def confirmed_service(cls, order: DomainOrder):
        confirmed_service.apply_async((order.data.order_uuid, ), countdown=cls.COUNTDOWN)

    @classmethod
    def canceled_service(cls, order: DomainOrder):
        canceled_service.apply_async((order.data.order_uuid, ), countdown=cls.COUNTDOWN)

    @classmethod
    def requested_service(cls, order: DomainOrder):
        requested_service.apply_async((order.data.order_uuid, ), countdown=cls.COUNTDOWN)

    @staticmethod
    def is_created_date_expired(order: DomainOrder) -> bool:
        six_hours: int = 60 * 60 * 6
        created_date: int = int(order.meta.created.date)
        now: int = int(datetime.now().timestamp())
        if (now - created_date) > six_hours:
            return True

        return False

    def get_data_from_sirena(self, rloc: str, passenger_last_name: str) -> Dict:
        """
        Получает данные заказа из Сирены
        :param rloc:
        :param passenger_last_name:
        :return:
        """
        try:
            sirena_raw_transaction: Dict = self.sirena_adapter.search_order(
                rloc=rloc, last_name=passenger_last_name, show_originator=True
            )
        except BaseSirenaError:
            raise BaseSirenaError()
        return sirena_raw_transaction

    def update_order(self, sirena_raw_transaction: Dict):
        """
        Обновляет данными из Сирены заказ в бд
        :param sirena_raw_transaction: сырые данные заказа
        :return:
        """
        self.internal_order_adapter.save(
            raw_order=sirena_raw_transaction,
            provider=TransactionSource.SIRENA_GRS.value,
            received=time(),
            message_id=str(uuid.uuid4()),
            deferred_save=False,
            return_full_response=True,
        )


class HkSpecialServicesUseCase(BaseSpecialServicesUseCase):
    """
    Логика работы с подтвержденной услугой (HK)
    """
    def __init__(
        self,
        order_repo: GenericMongoRepository,
        redis: Redis,
        mono_app_adapter: MonoAppAdapter
    ):
        super().__init__(mono_app_adapter=mono_app_adapter, redis=redis, order_repo=order_repo)

    def __execute__(self, request: HkSpecialServicesRequest, *args, **kwargs) -> ProcessSpecialServicesResponse:
        """
        Отправить письмо.
        Удалить данные из редиса.
        """
        order: DomainOrder = self.get_order_by_order_uuid(order_uuid=request.order_uuid)
        info_to_send: Dict = self.create_email_template(
            order=order, type_code=TypeCode.SPECIAL_SERVICE_SSR_CONFIRMED.value
        )
        self.send_email(**info_to_send)

        value: str = self.create_set_value(order_uuid=order.data.order_uuid)
        self.remove_special_services_from_set(value=value)

        return ProcessSpecialServicesResponse(value={"status": "ok"})


class HnSpecialServicesUseCase(BaseSpecialServicesUseCase):
    """
    Логика работы с услугой в обработке (Hn)
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        redis: Redis,
        mono_app_adapter: MonoAppAdapter,
        sirena_adapter: SirenaInternalAdapter,
        jira_adapted: JiraServiceDeskAdapter,
        refunds_repo: GenericMongoRepository
    ):
        super().__init__(
            mono_app_adapter=mono_app_adapter,
            redis=redis,
            order_repo=order_repo,
            sirena_adapter=sirena_adapter,
            jira_adapter=jira_adapted,
            refunds_repo=refunds_repo
        )

    def __execute__(self, request: HnSpecialServicesRequest, *args, **kwargs) -> ProcessSpecialServicesResponse:
        """
        Сдать места
        Создать заявку в жиру
        Сохранить заявку в БД
        Отправить письмо
        Удалить данные из редиса
        """
        order: DomainOrder = self.get_order_by_order_uuid(order_uuid=request.order_uuid)

        try:
            self.release_seats(order=order)
        except (BaseSirenaError, ApplicationError) as e:
            self.logger.info(f'Не удалось сдать места по заказу {order.data.order_uuid} ошибка: {str(e)}')
            self.__fallback__(order=order)
            return ProcessSpecialServicesResponse(value={"status": "ok"})

        try:
            order_refund_id: str = self.jira_adapter.apply_for_refund(
                order_uuid=order.data.order_uuid,
                is_involuntary=True,
                labels=[JiraLabels.SPECIAL_SERVICE_DENIED.value]
            )["key"]
        except JiraSDBaseError as e:
            self.logger.info(f'Не удалось создать заявку в jira по заказу {order.data.order_uuid}')
            return ProcessSpecialServicesResponse.build_from_exception(
                FailedRegisterRefundInServiceDeskError(
                    message=e.message
                ))

        self.store_refund_in_db(
            order_refund_id=order_refund_id,
            order=order,
            passengers_to_refund=order.data.passengers,
            involuntary=True
        )

        email_template: Dict = self.create_email_template(
            order=order, type_code=TypeCode.SPECIAL_SERVICE_SSR_NOT_CONFIRMED.value
        )
        self.send_email(**email_template)

        value: str = self.create_set_value(order_uuid=order.data.order_uuid)
        self.remove_special_services_from_set(value=value)

        return ProcessSpecialServicesResponse(value={"status": "ok"})


class UnSpecialServicesUseCase(BaseSpecialServicesUseCase):
    """
    Логика работы с услугой, которые находятся в обработке (UN)
    """
    def __init__(
        self,
        order_repo: GenericMongoRepository,
        redis: Redis,
        mono_app_adapter: MonoAppAdapter,
        sirena_adapter: SirenaInternalAdapter,
        jira_adapted: JiraServiceDeskAdapter,
        refunds_repo: GenericMongoRepository
    ):
        super().__init__(
            mono_app_adapter=mono_app_adapter,
            redis=redis,
            order_repo=order_repo,
            sirena_adapter=sirena_adapter,
            jira_adapter=jira_adapted,
            refunds_repo=refunds_repo
        )

    def __execute__(self, request: UnSpecialServicesRequest, *args, **kwargs) -> ProcessSpecialServicesResponse:
        """
        Сдать места
        Сохранить заявку в БД
        Создать заявку в жиру
        Отправить письмо
        Удалить данные из редиса
        """
        order: DomainOrder = self.get_order_by_order_uuid(order_uuid=request.order_uuid)

        try:
            self.release_seats(order=order)
        except (BaseSirenaError, ApplicationError) as e:
            self.logger.info(f'Не удалось сдать места по заказу {order.data.order_uuid} ошибка: {str(e)}')
            self.__fallback__(order=order)
            return ProcessSpecialServicesResponse(value={"status": "ok"})

        try:
            order_refund_id: str = self.jira_adapter.apply_for_refund(
                order_uuid=order.data.order_uuid,
                is_involuntary=True,
                labels=[JiraLabels.SPECIAL_SERVICE_DENIED.value]
            )["key"]
        except JiraSDBaseError as e:
            self.logger.info(f'Не удалось создать заявку в jira по заказу {order.data.order_uuid}')
            return ProcessSpecialServicesResponse.build_from_exception(
                FailedRegisterRefundInServiceDeskError(
                    message=e.message
                ))

        self.store_refund_in_db(
            order_refund_id=order_refund_id,
            order=order,
            passengers_to_refund=order.data.passengers,
            involuntary=True
        )

        email_template: Dict = self.create_email_template(
            order=order, type_code=TypeCode.SPECIAL_SERVICE_SSR_NOT_CONFIRMED.value
        )
        self.send_email(**email_template)

        value: str = self.create_set_value(order_uuid=order.data.order_uuid)
        self.remove_special_services_from_set(value=value)

        return ProcessSpecialServicesResponse(value={"status": "ok"})
