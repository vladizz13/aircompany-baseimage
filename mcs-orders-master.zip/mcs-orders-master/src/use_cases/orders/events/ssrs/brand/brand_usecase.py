from typing import List, Dict, Optional

from domain import DomainOrder
from domain.order.data.segment import DomainSegment
from domain.order.data.passenger import DomainPassenger
from domain.order.data.coupon import DomainCoupon
from domain.order.data.ssr import DomainSSR
from base.exception import ApplicationError
from domain.types import OrderStatus, SegmentStatus, OAK, BrandName, PassengerCategory, SsrPassengerType, GDS
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.events.ssrs.brand.brand_request import BrandSsrRequest
from use_cases.orders.events.ssrs.brand.brand_response import BrandSsrResponse
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from use_cases.orders.save.expand_order.expanders.offers_expander import OffersExpander


class BrandSsrUseCase(BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):
    """
    Во все заказы, вылетающие из городов, где нет Астры (сейчас это Стамбул и Занзибар)
    вносит SSR с указанием бренда.
    """

    def __init__(
        self,
    ):

        self.coupon_map: Dict[str, DomainCoupon] = dict()
        super().__init__()

    def __execute__(self, request: BrandSsrRequest, *args, **kwargs) -> BrandSsrResponse:
        try:
            if not request.order.data.coupons or not any((
                request.order.data.rloc.endswith(f"/{GDS.SIRENA.value}"),
                request.order.data.rloc.endswith(f"/{GDS.SIRENA_V2.value}"),
            )):
                return BrandSsrResponse()

            self.coupon_map = self.create_coupon_map(request.order.data.coupons)
            res = self.add_ssr_with_brand(request)
            return BrandSsrResponse(value=res)
        except ApplicationError as e:
            return BrandSsrResponse.build_from_exception(e)

    def add_ssr_with_brand(self, request: BrandSsrRequest):
        """
        Для каждой новой брони:
        Если статус брони (data.status) T или A, и, есть сегмент (статус HK или TK)
        с вылетом из Занзибара или Стамбула (ZNZ и IST, соот-но) и Дубай:
            ( + https://jira.utair.ru/browse/UTBCKN-3150)
            Добавлять ремарку с привязкой к конкретному сегменту:
            add_ssr({'regnum': '8F4MPC', 'surname':'Тест',"ssr":{"@type":"ИНФР","@text":"MINIMUM",
            "unit":[
            {"name":"ЕКАТЕРИНА ВЛАДИМИРОВНА", "surname":"Тест", "company":"UT", "flight":"437", "date":"28.04.2021"}
            ]}})
            Добавлять ремарку к каждому пассажиру.
            Для этого можно отправить несколько запросов или в 1 запросе указать несколько unit: 1 юнит на 1 пассажира.
            Бренд получаем из купона пассажира, прогоняем через расширитель и получаем оффер по коду тарифа -
            берем подстроку от начала до "_".
            То есть из OPTIMUM_NEW получаем просто OPTIMUM.
            Можем добавлять только тарифы MINIMUM, OPTIMUM, PREMIUM, BUSINESS.
            Если у нас распознан другой тариф - просто не добавляем ремарку.
            Сирена не позволит добавить две одинаковых ремарки, поэтому можно для простоты пытаться добавить ремарку
            каждый раз при обновлении брони. На дубль нам в ответ просто придет ошибка. Игнорируем ошибку.

        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        order: DomainOrder = request.order

        if order.data.status not in (OrderStatus.T.value, OrderStatus.A.value):
            return

        segments = [
            segment for segment in order.data.segments
            if all((
                segment.status in SegmentStatus.CONFIRMED_LIST.value,
                segment.departure_airport_code in (
                    'ZNZ', 'IST', 'LED', 'EVN', 'DXB', 'DWC'
                )
            ))
        ]

        if not segments:
            return

        ssrs: List[Dict] = list()
        ssrs_with_brand = []
        for s in order.data.ssrs:
            if s.ssr == "CKIN":
                ssrs_with_brand.append(s)

        for segment in segments:
            ssrs.extend(self.create_ssr_per_segment(order.data.passengers, segment, ssrs_with_brand))

        if not ssrs:
            return

        return {
            "rloc": order.data.rloc,
            "last_name": order.data.passengers[0].last_name,
            "ssrs": ssrs,
            "order_uuid": order.data.order_uuid
        }

    @classmethod
    def create_coupon_map(cls, coupons: List[DomainCoupon]) -> Dict[str, DomainCoupon]:
        _map: Dict[str, DomainCoupon] = dict()
        for coupon in coupons:
            _map[f"{coupon.passenger_id}{coupon.segment_id}"] = coupon
        return _map

    def get_coupon(self, passenger: DomainPassenger, segment: DomainSegment) -> Optional[DomainCoupon]:
        return self.coupon_map.get(f"{passenger.passenger_id}{segment.segment_id}")

    def create_ssr_per_segment(
            self,
            passengers: List[DomainPassenger],
            segment: DomainSegment,
            ssrs_with_brand: List[DomainSSR]
    ):
        units: List[Dict] = list()
        brand: Optional[str] = None
        ssrs_pax_with_brand = [s for s in ssrs_with_brand if s.segment_id == segment.segment_id]

        for passenger in passengers:
            if passenger.type == PassengerCategory.INFANT.value:
                continue
            if passenger.first_name.upper() in SsrPassengerType.STRETCHER_PASSENGER.value + SsrPassengerType.BAGGAGE.value: # noqa
                continue
            unit = {
                "name": self.get_first_name(passenger),
                "surname": passenger.last_name,
                "company": OAK.UT.value,
                "flight": segment.flight_number,
                "date": self.get_departure_date(segment),
            }
            coupon: Optional[DomainCoupon] = self.get_coupon(passenger, segment)
            if not coupon:
                continue
            branded_offer = OffersExpander.create_brand_offer_by_coupon(
                coupon=coupon
            )
            if not branded_offer:
                continue

            if branded_offer.brand_name not in (
                    BrandName.MINIMUM_NEW.value,
                    BrandName.OPTIMUM_NEW.value,
                    BrandName.PREMIUM_NEW.value,
                    BrandName.BUSINESS_NEW.value
            ):
                continue

            brand = branded_offer.brand_name.split('_')[0]
            if not brand:
                continue

            if next((s for s in ssrs_pax_with_brand if s.text == brand and s.passenger_id == passenger.passenger_id),
                    None):
                continue
            units.append(unit)

        if not brand or not units:
            return []

        return [{'ssr_type': "ИНФР", 'text': brand, 'units': units}]
