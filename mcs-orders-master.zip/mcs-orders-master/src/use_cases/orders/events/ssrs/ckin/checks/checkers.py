import re
from typing import List, Union, Optional, Set, Tuple, FrozenSet

from domain import DomainOrder
from datetime import datetime
from libs.utils.tools.date import get_age_from_date
from domain.types import BrandName, ServiceStatus, SsrPassengerType, SegmentStatus, Direction
from domain.order.data.ssr import DomainSSR
from domain.order.data.service import DomainService
from domain.order.data.segment import DomainSegment
from domain.order.data.document import DomainDocument
from domain.order.data.ticket import DomainTicket
from domain.order.data.passenger import DomainPassenger
from domain.order.data.coupon import DomainCoupon
from use_cases.orders.save.expand_order.expanders.offers_expander import OffersExpander


class AddChkinSsrChecker:
    def __init__(self, order: DomainOrder):
        self.order: DomainOrder = order

    def check_premium_and_euro_tariff(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры с тарифом Евробизнес и Премиум
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainCoupon] = []
        for item in self.order.data.coupons:
            branded_offer = OffersExpander.create_brand_offer_by_coupon(coupon=item)
            if not branded_offer:
                continue
            if branded_offer.brand_name in (
                BrandName.PREMIUM_NEW.value,
                BrandName.PREMIUM_CORP.value,
                BrandName.PREMIUM_PLUS.value,
                BrandName.PREMIUM_HELI.value,
                BrandName.BUSINESS_NEW.value
            ):
                pax.append(item)
        if not pax:
            return None
        return self.get_pax_and_seg(data=pax, order=self.order)

    _FQTV_RE = re.compile(r'^UT(\d+)(\.(\w+))?')  # UT{card_number}.{LEVEL}

    def _get_fqtv_level(self, ssr_text: str):
        match = self._FQTV_RE.match(ssr_text or '')
        if match:
            return match.group(3)

    def check_status_gold_card(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры владельцы карт Status Gold.
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainSSR] = []
        for item in self.order.data.ssrs:
            if item.ssr == "FQTV" and self._get_fqtv_level(item.text) == "GOLD":
                pax.append(item)
            # Старый признак. С 03.04.2023 не будет добавляться, но Сирене не настолько доверяем, чтобы заигнорить.
            if item.ssr == "OTHS" and item.text == "FQTSTATUS GOLD":
                pax.append(item)
        if not pax:
            return None
        return self.get_pax_and_seg(data=pax, order=self.order)

    def check_status_silver_card(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры владельцы карт Status Silver
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainSSR] = []
        for item in self.order.data.ssrs:
            if item.ssr == "FQTV" and self._get_fqtv_level(item.text) == "SILVER":
                pax.append(item)
            # Старый признак. С 03.04 не будет добавляться, но Сирене не настолько доверяем, чтобы заигнорить.
            if item.ssr == "OTHS" and item.text == "FQTSTATUS SILVER":
                pax.append(item)
        if not pax:
            return None
        return self.get_pax_and_seg(data=pax, order=self.order)

    def check_seats(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры, купившие Место+
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainService] = []
        for item in self.order.data.services:
            if item.rfisc == "STR" and item.status == ServiceStatus.HI.value:
                pax.append(item)
            elif item.price:
                if all((item.rfisc == "0B5", item.price > 1000, item.status == ServiceStatus.HI.value)):
                    pax.append(item)
        if not pax:
            return None

        return self.get_pax_and_seg(data=pax, order=self.order)

    def check_class(self) -> Optional[FrozenSet[Tuple[str, str]]]:
        """
        Пассажиры с наиболее дорогим классом обслуживания и служебники
        :return: {('passenger_id', 'segment_id')}
        """
        segments: List[DomainSegment] = []
        for item in self.order.data.segments:
            if item.rbd in ["Y", "S", "T", "E", "G", "N", "Q"]:
                segments.append(item)

        if not segments:
            return None
        return self.get_pax(order=self.order, segments=segments)

    def check_appropriate_ssrs(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Проверяем на наличие подходящих по БП ssr.
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainSSR] = []
        ssrs = (
            SsrPassengerType.DISABLED_PASSENGERS.value +
            SsrPassengerType.INADMISSIBLE_PASSENGERS.value +
            SsrPassengerType.DEPORTED_PASSENGERS.value +
            SsrPassengerType.UNACCOMPANIED_PASSENGERS.value +
            SsrPassengerType.FEDERAL_PASSENGERS.value
        )
        for item in self.order.data.ssrs:
            if item.ssr in ssrs:
                pax.append(item)
        if not pax:
            return None
        return self.get_pax_and_seg(data=pax, order=self.order)

    def check_eighteen_age_passenger(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Несовершеннолетние пассажиры
        :return: {('passenger_id', 'segment_id')}
        """
        pax: List[DomainDocument] = []
        for item in self.order.data.documents:
            if not item.birthday:
                continue
            # fixme: разве нужен сегодняшний возраст, а не на дату вылета?
            if get_age_from_date(datetime.strptime(item.birthday, '%d.%m.%Y')) < 18:
                pax.append(item)
        if not pax:
            return None

        return self.get_segments(order=self.order, data=pax)

    def check_transfer_passengers(self) -> Optional[FrozenSet[Tuple[str, str]]]:
        """
        Трансферные пассажиры
        :return: {('passenger_id', 'segment_id')}
        """
        direction_to = [d for d in self.order.data.segments
                        if d.direction == Direction.TO.value and d.status != SegmentStatus.XX.value]
        direction_back = [d for d in self.order.data.segments
                          if d.direction == Direction.BACK.value and d.status != SegmentStatus.XX.value]
        available_segments = []
        if len(direction_to) >= 2:
            available_segments.extend(direction_to)
        if len(direction_back) >= 2:
            available_segments.extend(direction_back)
        if not available_segments:
            return None
        return self.get_pax(order=self.order, segments=available_segments)

    def check_passengers_with_kids(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры с детьми
        :return: {('passenger_id', 'segment_id')}
        """
        parent_ids = {d.parent_id for d in self.order.data.passengers if d.parent_id is not None}
        adults_without_kids: List[DomainPassenger] = []
        for item in self.order.data.passengers:
            if item.parent_id is None and item.passenger_id not in parent_ids:
                adults_without_kids.append(item)
        pax_to_add = [x for x in self.order.data.passengers if x not in adults_without_kids]
        if not pax_to_add:
            return None
        return self.get_segments(order=self.order, data=pax_to_add)

    def check_grouped_passenger(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры, оформленные в группе от 3-х человек
        :return: {('passenger_id', 'segment_id')}
        """
        if len(self.order.data.passengers) < 3:
            return None

        return self.get_segments(order=self.order, data=self.order.data.passengers)

    def check_adult_passengers(self) -> Optional[Set[Tuple[str, str]]]:
        """
        Пассажиры преклонного возраста (60 лет и старше)
        :return: {('passenger_id', 'segment_id')}
        """
        pax_to_add: List[DomainDocument] = []
        for item in self.order.data.documents:
            if not item.birthday:
                continue
            # fixme: разве нужен сегодняшний возраст, а не на дату вылета?
            if get_age_from_date(datetime.strptime(item.birthday, '%d.%m.%Y')) >= 60:
                pax_to_add.append(item)
        if not pax_to_add:
            return None
        return self.get_segments(order=self.order, data=pax_to_add)

    @staticmethod
    def get_pax(order: DomainOrder, segments: List[DomainSegment]) -> FrozenSet[Tuple[str, str]]:
        """
        Получить всех пассажиров по переданным сегментам
        """
        return frozenset([tuple((p.passenger_id, s.segment_id)) for p in order.data.passengers for s in segments
                          if s.status in SegmentStatus.CONFIRMED_LIST.value])

    @staticmethod
    def get_pax_and_seg(
            data: Union[List[DomainSSR], List[DomainService], List[DomainCoupon]],
            order: DomainOrder
    ) -> Set[Tuple[str, str]]:
        segments = [s.segment_id for s in order.data.segments if s.status in SegmentStatus.CONFIRMED_LIST.value]
        pax_to_add = set()
        for i in data:
            if any((
                i.passenger_id is not None,
                i.segment_id is not None
            )) and i.segment_id in segments:
                pax_to_add.add((i.passenger_id, i.segment_id))
        return pax_to_add

    @staticmethod
    def get_segments(
            order: DomainOrder,
            data: Union[List[DomainTicket], List[DomainPassenger], List[DomainDocument]]
    ) -> Set[Tuple[str, str]]:
        """
        Получить все сегменты переданных пассажиров
        """
        pax_to_add = set()
        for p in order.data.segments:
            if p.status not in SegmentStatus.CONFIRMED_LIST.value:
                continue
            for s in data:
                pax_to_add.add((s.passenger_id, p.segment_id))
        return pax_to_add
