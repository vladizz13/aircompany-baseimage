from typing import Dict

from use_cases.orders.base_order_use_case import BaseOrderResponse


class CkinSsrResponse(BaseOrderResponse):

    def __init__(self, value: Dict = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: Dict = None):
        if not value:
            return value
        rloc = value.get('rloc')
        order_uuid = value.get('order_uuid')
        last_name = value.get('last_name')
        ssrs = value.get('ssrs')
        return {
            'rloc': rloc,
            'order_uuid': order_uuid,
            'last_name': last_name,
            'ssrs': ssrs
        }
