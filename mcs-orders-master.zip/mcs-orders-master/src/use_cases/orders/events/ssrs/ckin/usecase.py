from typing import List, Dict, Optional, Set, Tuple
from adapter.sirena_adapter import SirenaInternalAdapter
from domain import DomainOrder
from domain.types import OrderStatus, GDS, PassengerCategory, OAK, SsrPassengerType
from domain.order.data.passenger import DomainPassenger
from base.exception import ApplicationError
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.events.ssrs.ckin.request import CkinSsrRequest
from use_cases.orders.events.ssrs.ckin.response import CkinSsrResponse
from use_cases.orders.events.ssrs.ckin.checks.checkers import AddChkinSsrChecker
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin


class CkinSsrUseCase(BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):
    """
    SSR 'CKIN' для ряда категорий пассажиров
    """
    def __init__(
            self,
            sirena_adapter: SirenaInternalAdapter,
    ):
        self.sirena_adapter = sirena_adapter
        super().__init__()

    def __execute__(self, request: CkinSsrRequest, *args, **kwargs) -> CkinSsrResponse:
        try:
            res = self.add_ckin_ssr_status(request)
            return CkinSsrResponse(value=res)
        except ApplicationError as e:
            return CkinSsrResponse.build_from_exception(e)

    def add_ckin_ssr_status(self, request: CkinSsrRequest) -> Optional[Dict]:
        """
        Добавление ssr типа CKIN - коммерчески важный пассажир
        :param request:
        :return:
        """
        order: DomainOrder = request.order
        if order.data.status not in [OrderStatus.T.value, OrderStatus.A.value]:
            return None

        if not any((
            order.data.rloc.endswith(f"/{GDS.SIRENA.value}"),
            order.data.rloc.endswith(f"/{GDS.SIRENA_V2.value}")
        )):
            return None

        cheked_data: Optional[Set[Tuple[str, str]]] = self.perform_checks(order=order)
        if not cheked_data:
            return None

        prepared_data: List[Dict] = self.prepare_data_for_sirena(order=order, pax_to_add=cheked_data)
        if not prepared_data[0].get("units", None):
            return None

        return {
            "rloc": order.data.rloc,
            "last_name": prepared_data[0]["units"][0]["surname"],
            "ssrs": prepared_data,
            "order_uuid": order.data.order_uuid
        }

    @staticmethod
    def perform_checks(order: DomainOrder):
        """
        Производит все, необходимые по бп, проверки
        :param order:
        :return: {('passenger_id', 'segment_id')}
        """

        cheker = AddChkinSsrChecker(order=order)
        cheker_results = (
            cheker.check_premium_and_euro_tariff(),
            cheker.check_status_gold_card(),
            cheker.check_status_silver_card(),
            cheker.check_seats(),
            cheker.check_class(),
            cheker.check_appropriate_ssrs(),
            cheker.check_eighteen_age_passenger(),
            cheker.check_transfer_passengers(),
            cheker.check_grouped_passenger(),
            cheker.check_passengers_with_kids(),
            cheker.check_adult_passengers(),
        )
        # pas_id, seg_id
        founded_pax = set()
        for check in cheker_results:
            if check is not None:
                for i in check:
                    founded_pax.add(i)
        # Пассажиры в БД с CKIN. Им проставлять не надо.
        pax_with_ckin: Set[Tuple[str, str]] = set((s.passenger_id, s.segment_id) for s in order.data.ssrs
                                                  if s.ssr == "CKIN" and s.text == "CIP КОММЕРЧЕСКИ ВАЖНЫЙ ПАССАЖИР")

        pax_to_add = founded_pax - pax_with_ckin

        return pax_to_add

    def prepare_data_for_sirena(self, order: DomainOrder, pax_to_add: Set[Tuple[str, str]]) -> List[Dict]:
        """
        :return: [{
            "ssr_type": "CKIN",
            "text": "CIP Коммерчески важный пассажир",
            "unit": [
                {
                    "name": "IVAN",
                    "surname": "PETROV",
                    "company": "AF",
                    "flight": "4427",
                    "departure": "MOW",
                    "arrival": "PAR",
                    "date": "25.06.2014"
                }
            ]
        }]
        """
        units = []

        paxs: Dict[str, DomainPassenger] = {
            p.passenger_id: p for p in order.data.passengers
            if all((
                p.first_name.upper() not in SsrPassengerType.STRETCHER_PASSENGER.value + SsrPassengerType.BAGGAGE.value,
                p.type != PassengerCategory.INFANT.value
            ))
        }
        for passenger_id, segment_id in pax_to_add:
            segment = next((
                seg for seg in order.data.segments
                if all((seg.segment_id == segment_id, seg.ak == OAK.UT.value, seg.oak in [OAK.UT.value, None]))
            ), None)
            pax = paxs.get(passenger_id, None)
            if not all((pax, segment)):
                continue
            units.append({
                "surname": self.sirena_adapter.format_string(pax.last_name),
                "name": self.sirena_adapter.format_string(self.get_first_name(pax)),
                "company": segment.ak,
                "flight": segment.flight_number,
                "departure": segment.departure_city_code,
                "arrival": segment.arrival_city_code,
                "date": self.get_departure_date(segment),
            })
        prepared_data = [{
            "ssr_type": "CKIN",
            "text": "CIP Коммерчески важный пассажир",
            "units": units
        }]
        return prepared_data
