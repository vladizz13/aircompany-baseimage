from typing import List, Dict, Optional, Type, Any
import json
from enum import Enum
from adapter.sirena_adapter import SirenaInternalAdapter
from base.exception import ApplicationError
from domain import DomainOrder
from domain.types import (
    PassengerCategory, UtairCabinClass, SsrsSsr, CouponStatus,
    SsrsText, OrderStatus, SegmentStatus, SegmentStatusVisual, FareCode, GDS
)
from domain.order.data.passenger import DomainPassenger
from domain.order.data.segment import DomainSegment
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from libs.query_builder import AndQueryUnit
from use_cases.orders.events.ssrs.degr.request import DegrSsrRequest, DegrSendSsrsUseCaseRequest, DegrGetPriceRequest
from use_cases.orders.events.ssrs.degr.response import DegrSsrResponse, DegrSendSsrsUseCaseResponse
from repositories.query_builders.order import OrdersQueryBuilder
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin
from datetime import datetime
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.applications.celery_app.tasks.add_ssrs import degr_ssrs_get_price
from use_cases.orders.events.shared.redis_adapter import RedisSsrsAdapter
from use_cases.orders.exceptions.base import BaseLoyaltyError
from sirena_xml_client.exceptions import (
    BaseSirenaError,
    SirenaMessageTimedOutError,
    SirenaPnrAndSurnameDontMatch,
    SirenaPnrBusyError,
    SirenaPassengersTitleNotFoundError,
    SirenaDuplicateSsr,
)


class TaskStatus(Enum):
    PENDING = "PENDING"
    SUCCESS = "SUCCESS"
    RETRY = "RETRY"
    FAILURE = "FAILURE"


class BaseDegrSSRUseCase(BaseOrderUseCase):
    def __init__(
        self,
        redis_adapter: RedisSsrsAdapter,
    ):
        self.redis_adapter: RedisSsrsAdapter = redis_adapter
        self._key = None
        super().__init__()

    def __execute__(self, request, *args, **kwargs):
        raise NotImplementedError()

    def set_key(self, departure_time: int, flight_number: str):
        self._key = f"degr-{flight_number}-{departure_time}"

    def set_ssrs_to_store(self, ssr_request: List[Dict]):
        self.redis_adapter.add_to_queue(key=self._key, value=ssr_request)

    def get_degr_ssrs(self) -> List[Dict]:
        degr_ssrs = self.redis_adapter.get_values_by_key(key=self._key)
        degr_ssrs_data = [json.loads(data) for data in degr_ssrs]
        return degr_ssrs_data

    def remove_degr_ssrs(self):
        self.redis_adapter.remove_by_key(key=self._key)

    def get_degr_from_queue(self, count: int) -> List[Any]:
        ssrs = self.redis_adapter.get_from_queue(key=self._key, count=count)
        ssrs_data = [json.loads(data) for data in ssrs]
        return ssrs_data

    def change_ssr_status(self, ssr: Dict, status: str):
        degr_ssrs = self.get_degr_ssrs()
        for s in degr_ssrs:
            if all((
                s["order_uuid"] == ssr["order_uuid"],
                s["ticket_number"] == ssr["ticket_number"]
            )):
                s["status"] = status
        self.remove_degr_ssrs()
        self.set_ssrs_to_store(ssr_request=degr_ssrs)


class DegrSsrUseCase(BaseDegrSSRUseCase):
    """
    SSR Degr - самые "дешевые" пассажиры на рейсе.
    Получаем все заказы из БД. Фильтруем и оставляем нужные заказы по БП.
    Составляем payload'ы для добавления ssrs.
    Сохраняем payload'ы d redis.
    Вызываем задачу для расчета стоимости по каждому payload'у
    """
    def __init__(
        self,
        sirena_adapter: SirenaInternalAdapter,
        order_repo: GenericMongoRepository,
        internal_order_adapter: Type[InternalOrderAdapter],
        redis_adapter: RedisSsrsAdapter,
    ):
        self.sirena_adapter = sirena_adapter
        self.order_repo: GenericMongoRepository = order_repo
        self.internal_order_adapter: Type[InternalOrderAdapter] = internal_order_adapter
        super().__init__(redis_adapter=redis_adapter)

    def __execute__(self, request: DegrSsrRequest, *args, **kwargs) -> DegrSsrResponse:
        orders = self.__find_orders(flight_number=request.flight_number, departure_time=request.departure_time)
        departure_time = int(request.departure_time.timestamp())
        self.set_key(departure_time=departure_time, flight_number=request.flight_number)

        ourder_uuids = []
        ssr_request = []
        for order in orders:
            excluded_order = self.__exclude_order(
                order=order, flight_number=request.flight_number, departure_time=request.departure_time
            )
            if not excluded_order:
                continue

            ourder_uuids.append(excluded_order.data.order_uuid)

            segment_ids = [s.segment_id for s in excluded_order.data.segments]
            for item in excluded_order.data.coupons:
                if item.segment_id not in segment_ids:
                    continue
                ssr_payload: Optional[Dict] = self.__create_ssr_payload(
                    order=excluded_order,
                    ticket_number=item.ticket,
                    segment_id=item.segment_id,
                    passenger_id=item.passenger_id
                )
                if not ssr_payload:
                    self.logger.info(f"Couldn't create ssr payload for rloc: {excluded_order.data.rloc}"
                                     f"passenger_id: {item.passenger_id} segment_id: {item.segment_id}")
                    continue

                ssr_request.append(ssr_payload)

        self.logger.info(f'Total orders length to add DEGR ssrs for {request.flight_number} {request.departure_time} is'
                         f' {len(ourder_uuids)}. Order uuids to work with are: {ourder_uuids=}')

        if not ssr_request:
            return DegrSsrResponse()

        self.set_ssrs_to_store(ssr_request=ssr_request)

        degr_ssrs_get_price.apply_async(
            (request.flight_number, departure_time)
        )
        return DegrSsrResponse(value=request.serialize())

    def __find_orders(self, departure_time: datetime, flight_number: str) -> List[DomainOrder]:
        """
        Поиск подходящих заказов
        """
        query = AndQueryUnit()
        segment: AndQueryUnit = OrdersQueryBuilder.get_by_segment(
            flight_number=flight_number,
            departure_utc_date=departure_time,
            segment_class=UtairCabinClass.ECONOMY
        )
        query.add(segment)
        pass_types: AndQueryUnit = OrdersQueryBuilder.get_by_passenger_type([PassengerCategory.ADULT])
        query.add(pass_types)

        order_status: AndQueryUnit = OrdersQueryBuilder.get_by_status([
            OrderStatus.T.value,
            OrderStatus.A.value
        ])
        query.add(order_status)

        orders: List[DomainOrder] = self.order_repo.list(spec=query)
        return orders

    def __exclude_order(
        self,
        order: DomainOrder,
        departure_time: datetime,
        flight_number: str
    ) -> Optional[DomainOrder]:
        """
        В заказе нет ssr животные
        Визуальный статус сегмента data.segmets.status_visual: "active" или "registered"
        Статус сегмента data.segments.status: "HK" или "TK"
        Использовать только сегменты с классом эконом
        """
        if not any((
            order.data.rloc.endswith(f"/{GDS.SIRENA.value}"),
            order.data.rloc.endswith(f"/{GDS.SIRENA_V2.value}")
        )):
            return None

        departure_timestamp = int(departure_time.timestamp())
        # Составляем карту подходящих сегментов
        segments: Dict[str, DomainSegment] = {
            s.segment_id: s for s in order.data.segments
            if all((
                s.flight_number == flight_number,
                s.class_ == UtairCabinClass.ECONOMY.value,
                s.departure_timestamp == departure_timestamp,
                s.status in [SegmentStatus.HK.value, SegmentStatus.TK.value],
                s.status_visual in [SegmentStatusVisual.ACTIVE.value, SegmentStatusVisual.REGISTERED.value]
            ))
        }

        for ssr in order.data.ssrs:
            if all((
                ssr.segment_id in segments.keys(),
                ssr.ssr in [SsrsSsr.PETC.value, SsrsSsr.CKIN.value]
            )):
                # На сегменте есть услуга перевозки животного, удаляем его
                del segments[ssr.segment_id]

        for coupon in order.data.coupons:
            if coupon.segment_id not in segments.keys():
                continue

            if any((
                coupon.fare_code == FareCode.CHARTER.value,
                coupon.status not in [CouponStatus.C.value, CouponStatus.O.value]
            )):
                del segments[coupon.segment_id]

        if not segments:
            self.logger.info(f"No suitable segments found for: {order.data.rloc}")
            return None

        for index, segment in enumerate(order.data.segments):
            if not segments.get(segment.segment_id):
                del order.data.segments[index]

        return order

    @staticmethod
    def __create_ssr_payload(
        order: DomainOrder,
        ticket_number: str,
        segment_id: str,
        passenger_id: str
    ) -> Optional[Dict]:
        passenger: DomainPassenger = next((p for p in order.data.passengers if p.passenger_id == passenger_id), None)
        segment: DomainSegment = next((s for s in order.data.segments if s.segment_id == segment_id), None)
        if not any((passenger, segment)):
            return None

        payload = {
            "rloc": order.data.rloc,
            "order_uuid": order.data.order_uuid,
            "last_name": order.data.passengers[0].last_name,
            "ticket_number": ticket_number,
            "status": TaskStatus.PENDING.value,
            "passenger_id": passenger_id,
            "segment_id": segment_id
        }

        return payload


class DegrSsrGetTotalPriceUseCase(BaseDegrSSRUseCase, BaseOrderUseCase):
    """
    Вытаскиваем payload'ы из redis'а. По каждому payload'у получаем стоимость.
    Если при попытке расчета стоимости произошла ошибка, переходим к следующему payload'y.
    Сортируем ssrs_payloads по возрастанию. Сохраняем под тем же ключом в redis.
    Ключ должен быть таким же - менять нельзя.
    Если при попытке расчета произошла ошибка, celery сделает ретрай только для тех, у кого была ошибка.
    """
    def __init__(
        self,
        redis_adapter: RedisSsrsAdapter,
        internal_order_adapter: Type[InternalOrderAdapter],
    ):
        self.internal_order_adapter: Type[InternalOrderAdapter] = internal_order_adapter
        super().__init__(redis_adapter=redis_adapter)

    def __execute__(self, request: DegrGetPriceRequest, *args, **kwargs) -> DegrSsrResponse:
        self.set_key(departure_time=request.departure_time, flight_number=request.flight_number)
        ssrs_payload: List[Dict] = self.get_degr_ssrs()

        has_error: bool = False
        for price in ssrs_payload:
            # Если есть total_price, рассчитывать повторно не нужно.
            if price.get("total_price"):
                continue
            total_price: Optional[int] = self.__get_total_price(
                ticket=price.get("ticket_number"),
                last_name=price.get("last_name")
            )
            # Если не удалось получить стоимость - переходим к след заказу. Попробуем рассчитать после ретрая.
            if not total_price:
                has_error = True
                continue
            price["total_price"] = total_price

        self.remove_degr_ssrs()
        sorted_ssrs = self.sort_by_total_price(ssrs_payload)
        self.set_ssrs_to_store(ssr_request=sorted_ssrs)

        self.logger.info(f'Prices of sorted orders to add ssrs: {sorted_ssrs}')

        if has_error:
            return DegrSsrResponse.build_from_exception(BaseLoyaltyError())

        return DegrSsrResponse(value=request.serialize())

    def __get_total_price(self, ticket: str, last_name: str) -> Optional[int]:
        """
        Получаем total_price по купонам
        """
        try:
            data = self.internal_order_adapter.get_order_detail_price(
                ticket_number=ticket,
                last_name=last_name
            )
        except ApplicationError as e:
            self.logger.info(f"Unable to calculate order price for {ticket=}, {e.message}")
            return None

        total = data.get("tickets", {}).get(ticket, {}).get('total', 999999)
        coupons_count = data.get("tickets", {}).get(ticket, {}).get('coupons_count', 1)

        total_price = total / coupons_count

        return total_price

    @staticmethod
    def sort_by_total_price(ssrs_request: List[Dict]):
        sorted_passengers = sorted(ssrs_request, key=lambda d: int(d.get("total_price", 999999)), reverse=False)
        return sorted_passengers


class DegrSendSsrsUseCase(BaseDegrSSRUseCase, BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):
    """
    По переданному значению вытаскиваем из redis'а payload'ы для добавления сср.
    Сср добавляем в том же потоке.
    У каждой ссрки есть статус. Дефолтный PENDING. Если после добавления получили ошибку, то меняем статус на
    RETRY, райзим ошибку. Селери сделает ретрай всей задачи, флоу повторяется.
    Если после добавления сср получили в ответе от сирены ошибку и статус ссрки RETRY, тогда
    меняем статус на FAILURE и переходим к добавлению следующей ссрки. То есть для каждой ссрки у нас по одному ретраю.
    Если сср добавлена успешно, то меняем статус на SUCCESS.

    По БП нужно добавить сср DEGR 10ым пассажирам.
    По завершению нужно удалить данные DEGR из redis.
    """
    # TODO текущая реализация очень похожа на возможность хранения результатов в celery backend.
    #  Но в таком случае получаем ошибку OOM.
    def __init__(
        self,
        redis_adapter: RedisSsrsAdapter,
        sirena_adapter: SirenaInternalAdapter,
        order_repo: GenericMongoRepository,
    ):
        super().__init__(redis_adapter=redis_adapter)
        self.sirena_adapter = sirena_adapter
        self.order_repo = order_repo

    def __execute__(self, request: DegrSendSsrsUseCaseRequest, *args, **kwargs) -> DegrSendSsrsUseCaseResponse:
        self.set_key(flight_number=request.flight_number, departure_time=request.departure_time)

        passengers_to_add_ssr = self.get_degr_ssrs()

        self.logger.info(f'Passengers to add ssrs {passengers_to_add_ssr}')

        success_ssrs = [p for p in passengers_to_add_ssr if p.get("status") == TaskStatus.SUCCESS.value]
        if len(success_ssrs) >= 10:
            self.remove_degr_ssrs()
            return DegrSendSsrsUseCaseResponse(value=request.serialize())

        index: int = len(success_ssrs) + 1 if len(success_ssrs) > 0 else 1
        for ssr in passengers_to_add_ssr:
            ssr_status: str = ssr.get("status")
            # Если статус сср success/failure нам с таким делать нечего
            if ssr_status in [TaskStatus.SUCCESS.value, TaskStatus.FAILURE.value]:
                continue

            order_uuid: str = ssr.get('order_uuid')
            order: DomainOrder = self.__find_orders(order_uuid=order_uuid)
            if not order:
                self.logger.info(f'Не удалось найти заказ {order_uuid=}')
                continue

            ssr_request: Dict = self.__create_ssr_payload(order=order, ssr=ssr)
            ssr_request["ssrs"][0]["text"] = f'{index} {ssr_request["ssrs"][0]["text"]}'

            if not ssr_request:
                self.logger.info(f'Не удалось составить ssr для заказа {order_uuid=} {ssr["last_name"]}')
                continue

            try:
                self.sirena_adapter.add_ssr_to_order(
                    rloc=ssr_request["rloc"],
                    last_name=ssr_request["last_name"],
                    ssrs=ssr_request["ssrs"]
                )
                self.change_ssr_status(ssr=ssr, status=TaskStatus.SUCCESS.value)
            except (SirenaPnrBusyError, SirenaMessageTimedOutError):
                if ssr_status == TaskStatus.PENDING.value:
                    self.change_ssr_status(ssr=ssr, status=TaskStatus.RETRY.value)
                    raise
                if ssr_status == TaskStatus.RETRY.value:
                    self.change_ssr_status(ssr=ssr, status=TaskStatus.FAILURE.value)
                    continue
            except (BaseSirenaError, SirenaPnrAndSurnameDontMatch, SirenaPassengersTitleNotFoundError, SirenaDuplicateSsr): # noqa
                continue

            index += 1
            if index >= 11:
                self.remove_degr_ssrs()
                return DegrSendSsrsUseCaseResponse(value=request.serialize())

    def __create_ssr_payload(
        self,
        order: DomainOrder,
        ssr: Dict
    ) -> Optional[Dict]:
        passenger_id: str = ssr.get('passenger_id')
        segment_id: str = ssr.get('segment_id')

        passenger: DomainPassenger = next((p for p in order.data.passengers if p.passenger_id == passenger_id), None)
        segment: DomainSegment = next((s for s in order.data.segments if s.segment_id == segment_id), None)
        if not any((passenger, segment)):
            return None

        ssr["ssrs"] = [
            {
                "text": SsrsText.DOWNGRADE.value,
                "ssr_type": SsrsSsr.DEGR.value,
                "units": [{
                    "surname": self.sirena_adapter.format_string(passenger.last_name),
                    "name": self.sirena_adapter.format_string(self.get_first_name(passenger)),
                    "company": segment.ak,
                    "flight": segment.flight_number,
                    "departure": segment.departure_city_code,
                    "arrival": segment.arrival_city_code,
                    "date": self.get_departure_date(segment),
                }]
            }
        ]

        return ssr

    def __find_orders(self, order_uuid: str) -> DomainOrder:
        query: AndQueryUnit = OrdersQueryBuilder.get_by_order_uuid(order_uuid)
        order: DomainOrder = self.order_repo.get_single(query)
        return order
