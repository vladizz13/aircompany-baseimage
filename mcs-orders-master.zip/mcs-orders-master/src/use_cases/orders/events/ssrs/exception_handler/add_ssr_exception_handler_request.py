from typing import List, Dict
from base.use_case import BaseUseCaseRequest


class ExceptionHandlerRequest(BaseUseCaseRequest):

    def __init__(
        self,
        order_uuid: str = None,
        rloc: str = None,
        last_name: str = None,
        ssrs: List[Dict] = None,
    ):
        super().__init__()
        self.order_uuid = order_uuid
        self.rloc = rloc
        self.last_name = last_name
        self.ssrs = ssrs

    def is_valid(self, *args, **kwargs) -> 'ExceptionHandlerRequest':
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
            'rloc': self.rloc,
            'last_name': self.last_name,
            'ssrs': self.ssrs,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None),
            rloc=data.get('rloc', None),
            last_name=data.get('last_name', None),
            ssrs=data.get('ssrs', None),
        )
