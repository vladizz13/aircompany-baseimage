from base.use_case import BaseUseCaseResponse
from use_cases.orders.events.ssrs.exception_handler.add_ssr_exception_handler_request import ExceptionHandlerRequest


class ExceptionHandlerResponse(BaseUseCaseResponse):

    def __init__(self, value: 'ExceptionHandlerRequest' = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: 'ExceptionHandlerRequest' = None) -> 'ExceptionHandlerRequest':
        return value
