from typing import Optional
from domain import DomainOrder
from domain.types import TransactionSource
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from libs.db_gateway import get_db_gateway
from domain.order.meta.transaction_source import DomainTransactionSource
from repositories.query_builders.origin_transaction import OriginTransactionsQueryBuilder
from domain.origin_transaction import DomainOriginTransaction
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from rest.applications.celery_app.tasks.update_from_sirena import update_from_sirena_grs
import logging
from base.use_case import BaseUseCase
from .add_ssr_exception_handler_request import ExceptionHandlerRequest
from .add_ssr_exception_handler_response import ExceptionHandlerResponse
from use_cases.orders.exceptions.user import OrderNotFoundError, PassengersNotFoundError
from use_cases.orders.exceptions.save import OriginTransactionNotFoundError
from use_cases.orders.exceptions.search import OrderTransactionNotFoundError


class SirenaPassengersTitleNotFoundErrorHandler(BaseUseCase, GetDFirstNameMixin):

    def __init__(
        self,
        order_repo: GenericMongoRepository = None,
        origin_transaction_repo: GenericMongoRepository = None
    ):
        self.order_repo: GenericMongoRepository = order_repo
        self.origin_transaction_repo: GenericMongoRepository = origin_transaction_repo
        self.logger = logging.getLogger(self.__class__.__name__)

    def __execute__(self, request: ExceptionHandlerRequest, *args, **kwargs) -> ExceptionHandlerResponse:
        """
        Получаем данные обращения из последней транзакции сирены.
        Создаем повторную отправку сср в сирену с измененными 'name'. Туда добавляется title.
        """

        order: Optional[DomainOrder] = self.__get_order(order_uuid=request.order_uuid)
        if not order:
            self.logger.info(f'Заказ {str(request.order_uuid)} не был найден')
            return ExceptionHandlerResponse.build_from_exception(OrderNotFoundError())

        try:
            origin_transaction = self.__get_last_sirena_grs_transaction(order=order)
        except OriginTransactionNotFoundError:
            return ExceptionHandlerResponse.build_from_exception(OrderNotFoundError())

        if not origin_transaction:
            return ExceptionHandlerResponse.build_from_exception(OrderTransactionNotFoundError())

        gds_pax = origin_transaction.raw.get("order").get("pnr").get("passengers").get("passenger")
        if not gds_pax:
            self.logger.info(f'Пассажиры от сирены грс не были найдены для заказа {str(request.order_uuid)}')
            return ExceptionHandlerResponse.build_from_exception(PassengersNotFoundError())

        gds_pax_cart = {p["doc"] + p["birthdate"]: p for p in gds_pax}

        passengers_doc = {d.passenger_id: d for d in order.data.documents}
        order_passengers = []
        for p in order.data.passengers:
            order_passengers.append({
                "name": self.get_first_name(passenger=p),
                "surname": p.last_name.upper(),
                "docnumber": passengers_doc.get(p.passenger_id).docnumber,
                "birthday": passengers_doc.get(p.passenger_id).birthday
            })

        for d in request.ssrs[0]["units"]:
            for p in order_passengers:
                if not all((
                    d["name"].upper() == p["name"].upper(),
                    d["surname"].upper() == p["surname"].upper(),
                )):
                    continue
                try:
                    d["name"] = gds_pax_cart.get(p["docnumber"] + p["birthday"])["name"]
                except TypeError:
                    self.logger.info(f'Пассажир {p} не был найден')
                    continue

        if not request.ssrs:
            self.logger.info(f'Не удалось создать payload для добавления ssrs. Order_uuid {request.order_uuid}')
            return ExceptionHandlerResponse.build_from_exception(PassengersNotFoundError())

        return ExceptionHandlerResponse(request)

    def __get_order(self, order_uuid: str) -> Optional[DomainOrder]:
        if not self.order_repo:
            self.order_repo = GenericMongoRepository(
                instance=DomainOrder,
                gateway=get_db_gateway()
            )
        order: Optional[DomainOrder] = self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(order_uuid)
        )
        return order

    def __get_last_sirena_grs_transaction(self, order: DomainOrder) -> DomainOriginTransaction:
        transactions = list()
        transactions.append(order.meta.created)
        transactions.extend(order.meta.updated)

        sirena_transaction = [
            t for t in transactions if t.provider == TransactionSource.SIRENA_GRS.value
        ]
        if not sirena_transaction:
            self.logger.info(f'Транзакции от сирены грс не были найдены для заказа {str(order.data.order_uuid)}')
            raise OriginTransactionNotFoundError()

        sirena_transaction.sort(key=lambda x: x.date)
        last_transaction: DomainTransactionSource = sirena_transaction[-1]

        if not self.origin_transaction_repo:
            self.origin_transaction_repo = GenericMongoRepository(
                gateway=get_db_gateway(),
                instance=DomainOriginTransaction
            )
        origin_transaction = self.origin_transaction_repo.get_single(
            OriginTransactionsQueryBuilder.get_by_transaction_uuid(last_transaction.message_id)
        )

        return origin_transaction


class OrderQueueIsNotEmptyErrorHandler(BaseUseCase):

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def __execute__(self, request: ExceptionHandlerRequest, *args, **kwargs) -> ExceptionHandlerResponse:
        self.logger.info(f"""Ошибка при попытке принудительного обновления заказа после добавления сср.
                         order_uuid: {request.order_uuid} Request: {request.serialize()}""")
        is_deferred = False
        update_from_sirena_grs.apply_async(
            (request.order_uuid, is_deferred),
            countdown=60 * 2
        )
        return ExceptionHandlerResponse(request)
