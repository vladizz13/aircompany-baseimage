from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.base import BaseValidationError
from datetime import datetime


class PdtsSsrRequest(BaseOrderRequest):

    def __init__(
            self,
            departure_time: datetime,
            flight_number: str
    ):
        super().__init__()
        self.departure_time: datetime = departure_time
        self.flight_number: str = flight_number

    def is_valid(self, *args, **kwargs) -> 'PdtsSsrRequest':
        if not self.departure_time:
            self.add_error(BaseValidationError(message="Invalid departure_time"))
            return self
        if not self.flight_number:
            self.add_error(BaseValidationError(message="Invalid flight_number"))
            return self
        return self

    def serialize(self) -> dict:
        return {
            'departure_time': self.departure_time,
            'flight_number': self.flight_number,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            departure_time=data.get('departure_time', None),
            flight_number=data.get('flight_number', None)
        )


class PdtsGetPriceRequest(BaseOrderRequest):

    def __init__(
            self,
            departure_time: int,
            flight_number: str,
    ):
        super().__init__()
        self.departure_time: int = departure_time
        self.flight_number: str = flight_number

    def is_valid(self, *args, **kwargs) -> 'PdtsGetPriceRequest':
        if not self.departure_time:
            self.add_error(BaseValidationError(message="Invalid departure_time"))
            return self
        if not self.flight_number:
            self.add_error(BaseValidationError(message="Invalid flight_number"))
            return self
        return self

    def serialize(self) -> dict:
        return {
            'departure_time': self.departure_time,
            'flight_number': self.flight_number
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            departure_time=data.get('departure_time', None),
            flight_number=data.get('flight_number', None),
        )


class PdtsSendSsrsUseCaseRequest(BaseOrderRequest):

    def __init__(
            self,
            departure_time: int,
            flight_number: str,
    ):
        super().__init__()
        self.departure_time: int = departure_time
        self.flight_number: str = flight_number

    def is_valid(self, *args, **kwargs) -> 'PdtsSendSsrsUseCaseRequest':
        if not self.departure_time:
            self.add_error(BaseValidationError(message="Invalid departure_time"))
            return self
        if not self.flight_number:
            self.add_error(BaseValidationError(message="Invalid flight_number"))
            return self
        return self

    def serialize(self) -> dict:
        return {
            'departure_time': self.departure_time,
            'flight_number': self.flight_number
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            departure_time=data.get('departure_time', None),
            flight_number=data.get('flight_number', None),
        )
