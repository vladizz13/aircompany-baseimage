from typing import Dict

from use_cases.orders.base_order_use_case import BaseOrderResponse


class PdtsSsrResponse(BaseOrderResponse):

    def __init__(self, value: Dict = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: str = None):
        return value


class PdtsSendSsrsUseCaseResponse(BaseOrderResponse):

    def __init__(self, value: Dict = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: str = None):
        return value
