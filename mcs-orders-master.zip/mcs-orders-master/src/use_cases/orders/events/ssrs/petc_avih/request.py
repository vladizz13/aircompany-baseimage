from domain import DomainOrder
from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.base import BaseValidationError


class AddAnimalsSSRRequest(BaseOrderRequest):

    def __init__(self, order: DomainOrder = None):
        super().__init__()
        self.order: DomainOrder = order

    def is_valid(self, *args, **kwargs) -> 'AddAnimalsSSRRequest':
        if not self.order or not self.order.is_valid:
            self.add_error(BaseValidationError(message="Order is not valid"))
        return self

    def serialize(self) -> dict:
        return {'order': self.order.serialize()}

    @classmethod
    def deserialize(cls, data: dict):
        return cls(order=DomainOrder.deserialize(data.get('order', {})))
