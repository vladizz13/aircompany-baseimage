from base.exception import ApplicationError
from domain import DomainOrder
from domain.types import (
    ServiceStatus,
    OAK,
    Agencies,
    ServiceRFISCs,
    SpecialServiceTypes,
    SpecServiceTypeDescr,
    service_ssr_map,
    SsrPassengerType,
    GDS
)
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.events.ssrs.petc_avih.request import AddAnimalsSSRRequest
from use_cases.orders.events.ssrs.petc_avih.response import AddAnimalsSSRResponse
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin


class AddAnimalsSSRUseCase(BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):
    """
    Во все заказы, вылетающие из городов, где нет Астры (сейчас это Стамбул и Занзибар)
    вносит SSR с указанием бренда.
    """

    def __init__(
        self
    ):
        super().__init__()

    def __execute__(self, request: AddAnimalsSSRRequest, *args, **kwargs) -> AddAnimalsSSRResponse:
        try:
            res = self.add_animal_ssr(request)
            return AddAnimalsSSRResponse(value=res)
        except ApplicationError as e:
            return AddAnimalsSSRResponse.build_from_exception(e)

    def add_animal_ssr(self, request: AddAnimalsSSRRequest):
        """
        Если в заказе, купленном через агентство 02ТЮМ, есть услуга с RFISC "0BT"/"0BS" в статусе "HI", но отсутствует
        SSR "PETC"/"AVIH" ("ЖВТК"/"ЖВТБ"), связанный с тем же пассажиром и сегментом, что и услуга,
        то выполнить добавление SSR.

        :param request:
        :return:
        """
        order: DomainOrder = request.order
        if order.data.pos_data.agency not in Agencies.UT_SITE.value:
            return None
        if not any((
            order.data.rloc.endswith(f"/{GDS.SIRENA.value}"),
            order.data.rloc.endswith(f"/{GDS.SIRENA_V2.value}")
        )):
            return None
        services = [
            service for service in order.data.services
            if service.rfisc in (ServiceRFISCs.OBT.value, ServiceRFISCs.OBS.value)
            and service.status == ServiceStatus.HI.value
        ]
        for service in services:
            transfer_animal_ssr = [
                ssr for ssr in order.data.ssrs
                if all((
                    ssr.ssr in (
                        SpecialServiceTypes.PETC.name,
                        SpecialServiceTypes.PETC.value,
                        SpecialServiceTypes.AVIH.name,
                        SpecialServiceTypes.AVIH.value
                    ),
                    ssr.passenger_id == service.passenger_id,
                    ssr.segment_id == service.segment_id
                ))
            ]
            if transfer_animal_ssr:
                continue
            passengers = [
                passenger for passenger in order.data.passengers
                if passenger.passenger_id == service.passenger_id and passenger.first_name.upper() not in
                SsrPassengerType.STRETCHER_PASSENGER.value + SsrPassengerType.BAGGAGE.value
            ]
            ssrs_to_reg = []
            for passenger in passengers:
                segment = [
                    segment for segment in order.data.segments
                    if segment.segment_id == service.segment_id
                ]
                segment = segment[0]

                ssr_type = service_ssr_map[service.rfisc]

                ssrs_to_reg.append({
                    'ssr_type': ssr_type,
                    'text': SpecServiceTypeDescr[ssr_type].value,
                    'units': {
                        "name": self.get_first_name(passenger),
                        "surname": passenger.last_name,
                        "company": OAK.UT.value,
                        "flight": segment.flight_number,
                        "departure": segment.departure_city_code,
                        "arrival": segment.arrival_city_code,
                        "date": self.get_departure_date(segment),
                    }
                })

            if not ssrs_to_reg:
                return None

            return {
                "rloc": order.data.rloc,
                "last_name": order.data.passengers[0].last_name,
                "ssrs": ssrs_to_reg,
                "order_uuid": order.data.order_uuid
            }
