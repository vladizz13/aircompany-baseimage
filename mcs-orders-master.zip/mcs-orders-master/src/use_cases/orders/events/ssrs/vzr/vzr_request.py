from typing import List, Dict
from domain import DomainOrder
from domain.order.data.passenger import DomainPassenger
from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.base import BaseValidationError


class VzrSsrRequest(BaseOrderRequest):

    def __init__(
        self,
        passengers: List[Dict],
        order: DomainOrder = None,
    ):
        super().__init__()
        self.passengers: List[Dict] = passengers
        self.order: DomainOrder = order

    def is_valid(self, *args, **kwargs) -> 'VzrSsrRequest':
        if not self.order or not self.order.is_valid:
            self.add_error(
                BaseValidationError(message="Order is not valid")
            )
        return self

    def serialize(self) -> dict:
        return {
            'order': self.order.serialize(),
            'passengers': self.passengers
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order=DomainOrder.deserialize(data.get('order', dict())),
            passengers=[p for p in DomainPassenger.deserialize(data.get('passengers', dict()))]
        )
