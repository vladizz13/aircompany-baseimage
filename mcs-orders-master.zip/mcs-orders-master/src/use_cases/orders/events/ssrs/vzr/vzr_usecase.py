from typing import Dict, List, Set

from time import time
from datetime import datetime
from domain import DomainOrder
from domain.order.data import DomainSegment
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.events.ssrs.vzr.vzr_request import VzrSsrRequest
from use_cases.orders.events.ssrs.vzr.vzr_response import VzrSsrResponse
from use_cases.orders.events.shared.departure_date_handler import GetDepartureDateMixin
from use_cases.orders.events.shared.first_name_handler import GetDFirstNameMixin
from domain.types import BrandName, ServiceStatus


class VzrSsrUseCase(BaseOrderUseCase, GetDFirstNameMixin, GetDepartureDateMixin):

    def __init__(
        self,
    ):
        super().__init__()

    def __execute__(self, request: VzrSsrRequest, *args, **kwargs) -> VzrSsrResponse:
        vzr_texts: List[str] = self.get_vzr_texts(request.order)
        if not vzr_texts and not self.is_vzr_available(request.order):
            return VzrSsrResponse()

        ssr_requests: List[Dict] = self.create_vzr_requests(vzr_texts, request.order, request.passengers)
        if not ssr_requests:
            return VzrSsrResponse()
        return VzrSsrResponse(value={
            "order_uuid": request.order.data.order_uuid,
            "rloc": request.order.data.rloc,
            "last_name": request.order.data.passengers[0].last_name,
            "ssrs": ssr_requests
        })

    @staticmethod
    def get_vzr_texts(order: DomainOrder) -> List[str]:
        hours_72: int = 60 * 60 * 72
        segment_map: Dict[str, DomainSegment] = {s.segment_id: s for s in order.data.segments}
        vzr_texts: Set[str] = set()

        if any((
            service.rfisc == 'VZR' and service.status == ServiceStatus.HI.value
            for service in order.data.services
        )):
            segments = [segment_map[o.segment_id] for o in order.data.offers if o.brand_name in (
                BrandName.OPTIMUM_NEW.value,
                BrandName.MINIMUM_NEW.value
            )]
            segments: List[DomainSegment] = [
                s for s in segments if (s.departure_timestamp - time()) > hours_72
            ]
            for segment in segments:
                vzr_texts.add(f"разрешен вынужд. возврат для сегмента {segment.departure_city_code}-"
                              f"{segment.arrival_city_code}. эксперимент")

        return list(vzr_texts)

    @staticmethod
    def is_vzr_available(order: DomainOrder) -> bool:
        try:
            _tickets_source = order.data.tickets[0].issue_datetime
        except IndexError:
            _tickets_source = None

        try:
            _segment_source = order.data.segments[0].booking_timestamp
        except IndexError:
            _segment_source = None

        _root_source = order.data.analytics_data.first_segment_booking_time

        if not any((_tickets_source, _segment_source, _root_source)):
            # Если нигде данных нет, то опускаем эту проверку
            return False
        book_time: int = _tickets_source or _segment_source or _root_source
        book_datetime = datetime.fromtimestamp(book_time)
        return book_datetime >= datetime(2022, 6, 28)

    def create_vzr_requests(
        self,
        vzr_texts: List[str],
        order: DomainOrder,
        passengers: List[Dict]
    ) -> List[Dict]:
        ssr_text: Set[str] = {ssr.text for ssr in order.data.ssrs}
        requests: List[Dict] = list()
        for text in vzr_texts:
            if text in ssr_text:
                # Второй раз не добавляем сущ. ремарку
                continue

            for passenger in passengers:
                requests.append({
                    "ssr_type": "OTHS",
                    "text": text,
                    "units": [{
                        "name": self.compose_first_name(passenger),
                        "surname": passenger["last_name"].capitalize(),
                    }]
                })

        return requests

    @staticmethod
    def compose_first_name(passenger: Dict) -> str:
        first_name = passenger["first_name"]
        if first_name == "Cbbg":
            return first_name
        if second_name := passenger["second_name"]:
            first_name = f"{first_name.capitalize()} {second_name.capitalize()}"
        return first_name
