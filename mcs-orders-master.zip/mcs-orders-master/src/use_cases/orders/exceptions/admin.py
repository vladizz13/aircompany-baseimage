from .base import BaseSearchOrderError


class ContactsAlreadyAddedError(BaseSearchOrderError):
    """
    Контакты уже были добавлены в заказ
    """
    status = 400
    code = 10701
    message = 'Contacts already added'
    error_type = 'order'


class ContactNotFoundError(BaseSearchOrderError):
    """
    Контакт не найден в заказе
    """
    status = 400
    code = 10702
    message = 'Contact not found'
    error_type = 'order'
