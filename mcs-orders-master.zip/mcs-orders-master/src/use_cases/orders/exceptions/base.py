from base.exception import ApplicationError


class BaseSaveOrderError(ApplicationError):
    """
    Базовая ошибка сохранения заказа
    """
    status = 200
    code = 10000
    message = "Unable to save order"


class BaseValidationError(ApplicationError):
    """
    Базовая ошибка валидации реквеста
    """
    status = 200
    message = "Unable to validate request"


class BaseSearchOrderError(ApplicationError):
    """
    Базовая ошибка получения заказа
    """
    status = 400
    code = 10100
    message = "Unable to find order"
    error_type = 'search'


class BaseUserOrderError(ApplicationError):
    """
    Базовая ошибка работы пользователя с заказом
    """
    status = 400
    code = 10300
    message = "Unable to interact with order"
    error_type = 'order_interaction'


class BaseBookingError(ApplicationError):
    """
    Базовая ошибка взаимодействия с сервисом букинга
    """
    status = 400
    code = 10400
    message = "Unable to interact with booking service or cart"
    error_type = "booking"


class BaseUpdateOrderError(ApplicationError):
    """
    Базовая ошибка обновления заказа
    """
    status = 400
    code = 10500
    message = "Unable to update order"
    error_type = "update"


class BaseLoyaltyError(ApplicationError):
    """
    Базовая ошибка скоупа работы с лояльностью
    """
    status = 400
    code = 10600
    message = "Loyalty scope error"
    error_type = "loyalty"


class BaseMonoAppRetransalationError(ApplicationError):
    """
    Базовая ошибка ретрансляции заказа в моноапп
    """
    status = 400
    code = 10700
    message = "Unable to send order to MonoApp"
    error_type = "mono_app"


class BaseAddServiceError(ApplicationError):
    """
    Ошибка добавления услуг
    """
    status = 400
    code = 10800
    message = "Unable to add services to order"
    error_type = "event"


class BaseGetItineraryReceiptError(ApplicationError):
    """
    Ошибка получения файла машрута-квитанции
    """
    status = 400
    code = 1000
    message = 'Unable to get link to download itinerary-receipt'
    error_type = 'itinerary-receipt'


class BaseOrderRefundError(ApplicationError):
    """
    Ошибка получения данных для начала процедуры возврата
    """
    status = 400
    code = 1100
    message = 'Unable to handle order refund'
    error_type = 'refund order'


class BaseSegmentWithdrawError(ApplicationError):
    """
    Ошибка получения данных для начала процедуры возврата
    """
    status = 400
    code = 1150
    message = 'Unable handle withdraw for segment'
    error_type = 'withdraw segment'


class BaseChangePDError(ApplicationError):
    """
    Ошибка изменения, в заказе, перс. данных пассажира
    """
    status = 400
    code = 1200
    message = 'Unable to change your personal data'
    error_type = 'change personal data'


class NoContactsFoundError(ApplicationError):
    """
    В броне нет подходящих, для обратной связи, контактных данных.
    """

    status = 400
    code = 999
    message = "No contacts found"


class BaseAddSSRwithBrandError(ApplicationError):
    """
    Ошибка добавления SSR с указанием бренда
    """
    status = 400
    code = 10850
    message = "Unable to add a ssr to an order"
    error_type = "event"


class BaseExchangeError(ApplicationError):
    """
    Ошибка обмена заказа
    """
    status = 400
    code = 10900
    message = "Unable to process exchange"
    error_type = "exchange"


class BaseOriginTransactionError(ApplicationError):
    """
    Базовая ошибка при работе с транзакциями
    """
    status = 400
    code = 10901
    message = "Unable to find transaction"
    error_type = "transaction error"
