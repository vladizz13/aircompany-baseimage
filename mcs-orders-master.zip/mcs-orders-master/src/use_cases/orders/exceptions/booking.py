from .base import BaseBookingError, BaseValidationError

"""
Ошибки, связанные с взаимодействием с букингом / корзиной
зарезервированные коды 10400 - 10499
"""


class InvalidInputCartError(BaseValidationError):
    """
    Неверные данные корзины
    """
    status = 200
    code = 10401
    message = 'Invalid input cart'


class UnableToFindOrderInTaisBookingError(BaseBookingError):
    """
    Не удалось найти заказ
    """
    status = 200
    code = 10402
    message = 'Unable to find order in tais'
