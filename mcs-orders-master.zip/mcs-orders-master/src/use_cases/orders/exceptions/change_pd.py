from .base import BaseChangePDError

"""
Ошибки, специфичные для процесса изменения перс. данных пассажира
зарезервированные коды 1200 - 1299
"""


class PDHadAlreadyBeenChangedError(BaseChangePDError):
    """
    У пассажира, ранее, уже изменялись перс. данные
    """

    code = 1201
    message = "Pax data had already been changed"


class CantChangeForeignTicketError(BaseChangePDError):
    """
    Нет возможности изменять данные билетов сторонних авиакомпаний
    """

    code = 1202
    message = "Can't change tickets from no UT seance"


class PassengerNotFoundError(BaseChangePDError):
    """
    Не найден пассажир по указанному passenger_id
    """

    code = 1203
    message = "Passenger not found"


class CheckPointsOfSaleError(BaseChangePDError):
    """
    Не подходящий пунктом продаж
    """

    code = 1204
    message = "Pos_id isn't valid for changing pax data"


class CheckTransportersError(BaseChangePDError):
    """
    Перевозчик не UTair
    """

    code = 1205
    message = "Segments isn't valid for changing pax data"


class CouldntGetOrderDataFromSirenaError(BaseChangePDError):
    """
    Не удалось получить данные от Сирены
    """

    code = 1206
    message = "Couldn't get order's data from Sirena"


class BadCouponsStatusesError(BaseChangePDError):
    """
    У билета есть купоны не в статусе 'O'/'F'/'C'
    """

    code = 1207
    message = "Not only 'O'/'F' coupons in PNR"


class PaxCheckedInError(BaseChangePDError):
    """
    У билета есть купон в статусе C
    """

    code = 1208
    message = "Pax had been checked in"


class NoActiveCouponsError(BaseChangePDError):
    """
    Не найдено ни одного активного купона
    """

    code = 1209
    message = "No active coupons for changing pax data"


class NoActiveSegmentsError(BaseChangePDError):
    """
    Не найдено ни одного активного сегмента
    """

    code = 1210
    message = "No active segments for changing pax data"


class HasInsuranceError(BaseChangePDError):
    """
    Есть страховка
    """

    code = 1211
    message = "Order has insurance"


class CanChangeOnlyTwoFieldsError(BaseChangePDError):
    """
    Изменить можно не более 2х полей
    """

    code = 1212
    message = "Can change only 2 fields"


class TryingToChangeTheSameDataError(BaseChangePDError):
    """
    Попытка изменить данные на те же самые
    """

    code = 1213
    message = "Trying to change the same data."


class CouldntChangePDByBirthdayError(BaseChangePDError):
    """
    Изменился возрастной тип пассажира
    """

    code = 1214
    message = "Can't change pax type by birthday"


class MissingChangePDReqDataError(BaseChangePDError):
    """
    В Redis отсутствуют данные по указанному attempt_id
    """
    code = 1216
    message = "Have no data by this attempt_id"


class CouldntCallBlQueryError(BaseChangePDError):
    """
    Заказ уже подготовлен для изменения данных, ожидается оплата.
    """
    code = 1217
    message = "The order is already prepared and waiting for payment confirmation"


class NoUTTicketsInPNRError(BaseChangePDError):
    """
    Отсуствуют билеты UT
    """
    code = 1218
    message = "No UT tickets in PNR"


class ChangingFieldsIsProhibited(BaseChangePDError):
    """
    Изменение полей запрещено
    """
    code = 1219
    message = "Changing fields is prohibited"


class ChangesAreBlockedByExchangedSegment(BaseChangePDError):
    """
    Обмененный сегмент блокирует изменения
    """
    code = 1220
    message = "Changes are blocked by exchanged segment"
