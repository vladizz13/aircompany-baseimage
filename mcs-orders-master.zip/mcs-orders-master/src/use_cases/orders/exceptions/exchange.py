from domain.exchange import DomainExchange
from .base import BaseExchangeError


class ExchangeIsNotAllowedError(BaseExchangeError):
    """
    Для брони обмен не возможен
    """
    status = 422
    code = 10901
    message = "Exchange is not allowed for order"


class ExchangeRetryNeededError(BaseExchangeError):
    """
    Не удалось инициировать обмен, нужно попробовать позже
    """
    status = 423
    code = 10902
    message = "Unable to process exchange, please retry later"


class ClaimedOrderNotFoundError(BaseExchangeError):
    status = 500
    code = 10903
    message = "Order not found after claim"


class NoExchangeableSegmentsError(BaseExchangeError):
    status = 400
    code = 10904
    message = "No segments for exchange"


class NoExchangeablePassengersError(BaseExchangeError):
    status = 400
    code = 10905
    message = "No passengers for exchange"


class InvalidExchangeablePassengerError(BaseExchangeError):
    status = 400
    code = 10906
    message = "Passenger with id {passenger_id} not exchangeable"

    def __init__(self, passenger_id: str):
        super().__init__(message=self.message.format(passenger_id=passenger_id))


class NoAdultsError(BaseExchangeError):
    status = 400
    code = 10907
    message = "A child cannot be the only passenger"


class PassengerRegisteredError(BaseExchangeError):
    status = 400
    code = 10908
    message = "It is necessary to cancel the registration"


class InvalidExchangeableSegmentError(BaseExchangeError):
    status = 400
    code = 10909
    message = "Segment with id {segment_id} not exchangeable"

    def __init__(self, segment_id: str):
        super().__init__(message=self.message.format(segment_id=segment_id))


class PassengerCategoryChangedError(BaseExchangeError):
    status = 400
    code = 10910
    message = "The age category has changed"


class InternationalFlightError(BaseExchangeError):
    status = 400
    code = 10911
    message = "Exchange of international flights is not possible"


class InvalidTransferSegments(BaseExchangeError):
    status = 400
    code = 10912
    message = "Invalid transfer segments sequence"


class AirportChangeNotImplemented(BaseExchangeError):
    status = 400
    code = 10913
    message = "Airport change not implemented"


class NoExchangeOptions(BaseExchangeError):
    status = 400
    code = 10914
    message = "No exchange options"


class SegmentConnectWithPreviousError(BaseExchangeError):
    status = 400
    code = 10915
    message = "Segment doesn't connect with previous by time"


class ExchangeNotFound(BaseExchangeError):
    status = 404
    code = 10915
    message = "Exchange transaction not found"


class CouponNormalizationError(BaseExchangeError):
    status = 500
    code = 10916
    message = "Unable to normalize coupons"


class InconsistentPassengersAfterExchange(BaseExchangeError):
    status = 500
    code = 10917
    message = "Inconsistent passengers after exchange"


class InconsistentSegmentsAfterExchange(BaseExchangeError):
    status = 500
    code = 10918
    message = "Inconsistent segments after exchange"


class SimilarExchangeSucceedError(BaseExchangeError):
    status = 400
    code = 10919
    message = "The exchange has already been completed"


class SimilarExchangeBeingProcessedError(BaseExchangeError):
    status = 400
    code = 10920
    message = "The exchange being processed"

    def __init__(self, exchange: DomainExchange, blocked: bool):
        super().__init__(data={
            'blocked': blocked,
            'exchange': {
                'exchange_id': str(exchange.exchange_uuid),
                'status': str(exchange.status),
                'price': exchange.price.serialize() if exchange.price else None,
            },
        })


class InvalidExchangeStatus(BaseExchangeError):
    status = 400
    code = 10921
    message = "Invalid exchange status"


class ExchangeReleasedFirstError(BaseExchangeError):
    status = 400
    code = 10922
    message = "Exchange of released segments required"


class UnexpectedCurrencyError(BaseExchangeError):
    status = 500
    code = 10923
    message = "Unexpected currency"


class UnexpectedPriceError(BaseExchangeError):
    status = 500
    code = 10924
    message = "Unexpected price"


class AlreadyDividedError(BaseExchangeError):
    status = 500
    code = 10925
    message = "Order already divided"


class UnexpectedTransactionError(BaseExchangeError):
    status = 500
    code = 10926
    message = "Unexpected Transaction"


class UnexpectedPaymentStateError(BaseExchangeError):
    status = 500
    code = 10927
    message = "Unexpected payment state"


class UnexpectedPaymentDataError(BaseExchangeError):
    status = 500
    code = 10928
    message = "Unexpected payment data"


class NewTicketNotFound(BaseExchangeError):
    status = 500
    code = 10929
    message = "New ticket from get_itin_data not found"


class SirenaSearchOrderError(BaseExchangeError):
    status = 500
    code = 10930
    message = "Sirena search order error"


class ServiceAgentSearchServiceError(BaseExchangeError):
    status = 500
    code = 10931
    message = "Service agent search service error"


class MCSPaymentConfirmError(BaseExchangeError):
    status = 500
    code = 10932
    message = "MCS payment confirm error"


class CancelPaymentError(BaseExchangeError):
    status = 400
    code = 10933
    message = "Invalid cancel payment"


class CannotBeProcessedError(BaseExchangeError):
    status = 400
    code = 10934
    message = "Cannot be processed. contact support"


class NotValidConfirmPrice(BaseExchangeError):
    status = 500
    code = 10935
    message = "Not valid confirm price"
