from astra_soap_client import PassengerHaveNotBeenFound
from base.exception import ApplicationError


class PassengerHaveNotBeenFoundInternalError(PassengerHaveNotBeenFound, ApplicationError):
    """
    Пассажир не найден в астре
    """
    status = 400
    code = 19400
    message = 'Passenger have not been found'
    error_type = 'order'
