from .base import BaseGetItineraryReceiptError

"""
Ошибки, связанные со скоупом получения машрута-квитанции
зарезервированные коды 1000 - 1024
"""


class FailedToRequestTaisError(BaseGetItineraryReceiptError):
    """
    Ошибка в запросе к Tais
    """

    code = 1001
    message = "Failed to request Tais"


class FailedToRequestSirenaGRSError(BaseGetItineraryReceiptError):
    """
    Ошибка в запросе к SirenaGRS
    """

    code = 1002
    message = "Failed to request SirenaGRS"


class TicketDecodeError(BaseGetItineraryReceiptError):
    """
    Ошибка расшифровки файла
    """

    code = 1003
    message = "Unable to decode file"


class DownloadURLGenerationError(BaseGetItineraryReceiptError):
    """
    Не удалось сгенерировать URL для скачивания маршрутной квитанции.
    """

    code = 1004
    message = "Order not found in database nor in SirenaGRS"


class CanReturnAvailableActionError(BaseGetItineraryReceiptError):
    """
    Не удалось вернуть МК заказа из-за соответствующего параметра can_return
    """

    code = 1005
    message = "Unable to print mk"
