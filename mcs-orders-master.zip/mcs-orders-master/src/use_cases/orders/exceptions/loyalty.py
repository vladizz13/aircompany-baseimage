from .base import BaseLoyaltyError, BaseValidationError

"""
Ошибки, связанные со скоупом лояльности
зарезервированные коды 10600 - 10699
"""


class InvalidLoyaltyRequest(BaseValidationError):
    """
    Неверный запрос
    """
    code = 10601
    message = 'Invalid request'


class AllSegmentAreFlownError(BaseLoyaltyError):
    """
    Все сегменты заказа пролетаны
    """
    code = 10602
    message = 'All segments are flown'


class OrderNotFoundError(BaseLoyaltyError):
    """
    Не удалось найти заказ в базе и в SirenaGRS
    """
    code = 10603
    message = "The order was not found in the database or in SirenaGRS"


class FailedToRequestSirenaGRSError(BaseLoyaltyError):
    """
    Ошибка в запросе к SirenaGRS
    """
    code = 10604
    message = "Failed to request SirenaGRS"
