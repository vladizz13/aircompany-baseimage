from .base import BaseOrderRefundError

"""
Ошибки, связанные со скоупом оформления возврата
зарезервированные коды 1100 - 1149
"""


class NoRefundsPossibleError(BaseOrderRefundError):
    """
    Для брони возврат не возможен
    """
    status = 422
    code = 1101
    message = "Refund is not allowed for order"


class NoOpenCouponsError(BaseOrderRefundError):
    """
    В броне нет активных купонов, для возможного возврата
    """
    code = 1102
    message = "No open coupons in order"


class InputDataValidationError(BaseOrderRefundError):
    """
    Ошибка валидации входных данных.
    """
    code = 1104
    message = "Incorrect input data"


class InvalidContactError(BaseOrderRefundError):
    """
    Не удалось расшифровать телефонный номер
    """
    status = 422
    code = 1105
    message = "Failed to decode phone number"


class AlreadyCheckedInError(BaseOrderRefundError):
    """
    Пассажир(ы) уже зарегистрирован(ы) на рейс
    """
    status = 422
    code = 1106
    message = "Passengers already checked-in"


class NoInvoluntaryRefundPossibleError(BaseOrderRefundError):
    """
    Нельзя добровольно вернуть билет, если для брони доступен только вынужденный возврат
    """
    status = 422
    code = 1107
    message = "Involuntary refund is not allowed for order"


class LonelyInfantError(BaseOrderRefundError):
    """
    Нельзя снять места, оставив единственным пассажиром младенца.
    """
    status = 422
    code = 1108
    message = "A child cannot be the only passenger"


class SendVerificationCodeError(BaseOrderRefundError):
    """
    Возникли проблемы при вызове API smsc.ru
    """
    code = 1109
    message = "Error then calling API of smsc.ru"


class RefundAlreadyRegisteredError(BaseOrderRefundError):
    """
    Заявка на возврат заказа уже была успешна зарегистрирована
    """
    status = 422
    code = 1110
    message = "Request for order refund already exists"


class IncorrectPassengersDataError(BaseOrderRefundError):
    """
    Полученные данные о пассажирах не совпадают с оригинальными данными о пассажирах
    """
    status = 422
    code = 1111
    message = "Received passengers data does not match the original passengers data"


class MissingAttemptIdError(BaseOrderRefundError):
    """
    Отсутствует attempt_id
    """
    code = 1112
    message = "Missing attempt_id"


class MissingVerificationCodeError(BaseOrderRefundError):
    """
    Отсутствует код верификации
    """
    code = 1113
    message = "Missing verification code"


class WrongVerificationCodeError(BaseOrderRefundError):
    """
    Неверно введен код подтверждения
    """
    status = 422
    code = 1114
    message = "Wrong verification code"


class MissingOrderRefundDataError(BaseOrderRefundError):
    """
    В Redis отсутствуют данные по указанному attempt_id
    """
    status = 421
    code = 1116
    message = "Have no data by this attempt_id"


class OnlyVZFopsInOrderError(BaseOrderRefundError):
    status = 400
    code = 1119
    message = "Only VZ fop in order"


class FailedRegisterRefundInServiceDeskError(BaseOrderRefundError):
    """
    Не удалось оформить заявку на возврат
    """
    status = 400
    code = 1120
    message = "Failed to register order in service desk"


class FailedToReleaseSeatsError(BaseOrderRefundError):
    """
    Не удалось снять места в сирене
    """
    status = 400
    code = 1121
    message = "Failed to release seats"


class FailedToDivideOrderError(BaseOrderRefundError):
    """
    Не удалось разделить места в сирене
    """
    status = 400
    code = 1123
    message = "Failed to divide order"
