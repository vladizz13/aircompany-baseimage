from .base import BaseMonoAppRetransalationError, BaseValidationError

"""
Ошибки, связанные с ретрансляцией заказа в моноапп
зарезервированные коды 10600 - 10799
"""


class MonoAppOrderRetranslationError(BaseMonoAppRetransalationError):
    """
    Все сегменты заказа пролетаны
    """
    code = 10701
    message = "Unable to send order to MonoApp"


class InvalidInputFieldsError(BaseValidationError):
    """
    Неверная транзакция
    """
    status = 200
    code = 10702
    message = 'Invalid input fields'
