from .base import BaseValidationError, BaseSaveOrderError

"""
Ошибки, связанные с сохранением заказа
зарезервированные коды 10000 - 10099
"""


class InvalidInputTransactionError(BaseValidationError):
    """
    Неверная транзакция
    """
    status = 200
    code = 10002
    message = 'Invalid input transaction'


class InvalidProviderSourceError(BaseValidationError):
    """
    Неверный провайдер транзакции
    """
    code = 10003
    message = 'Invalid provider source'


class InvalidReceivedTimestampError(BaseValidationError):
    """
    Неверная дата получения транзакции
    """
    code = 10004
    message = 'Invalid transaction received timestamp'


class InvalidMessageIDError(BaseValidationError):
    """
    Неверный идентификатор транзакции
    """
    code = 10005
    message = 'Invalid transaction message ID'


class UnableToNormalizeOrderError(BaseSaveOrderError):
    """
    Не удалось нормализовать заказ
    """
    code = 10010
    message = "Unable to normalize order"


class UnableToMapOrderError(BaseSaveOrderError):
    """
    Не удалось смапить заказ
    """
    code = 10011
    message = "Unable to map order"


class OrderSkippedError(BaseSaveOrderError):
    """
    Заказ был пропущен
    """
    code = 10012
    message = "Order skipped and was not saved"


class UnableToValidateOrderError(BaseSaveOrderError):
    """
    Не удалось валидировать заказ
    """
    code = 10013
    message = "Order validation error"


class UnableToExpandOrderError(BaseSaveOrderError):
    """
    Не удалось расширить заказ
    """
    code = 10014
    message = "Order expanding error"


class UnableToDeserializeOrderModelError(BaseSaveOrderError):
    """
    Не удалось десериализовать модель
    """
    code = 10015
    message = "Unable to deserialize model"


class UnableToMergeOrderError(BaseSaveOrderError):
    """
    Не не удалось смерджить заказы
    """
    code = 10016
    message = "Unable to merge orders"


# edge-cases

class UnableToProcessSirenaGRSEdgeCase(BaseSaveOrderError):
    """
    Не удалось обработать edge-case от SirenaGRS
    """
    code = 10070
    message = "Unable to process SirenaGRS edge-case"


# archive orders

class InvalidTimestampError(BaseValidationError):
    """
    Неверная дата отсчета архивации
    """
    code = 10080
    message = 'Invalid timestamp'

# ReSave


class ReSaveOrderError(BaseSaveOrderError):
    """
    Не удалось перемапить заказ
    """
    code = 10080
    message = "Unable to resave order"


class OrderSavingBlockedByAnother(BaseSaveOrderError):
    """
    Заказ уже сохраняется другим процессом
    """
    code = 10081
    message = "Order saving blocked by another order"


class OriginTransactionNotFoundError(BaseSaveOrderError):
    """
    Не удалось найти транзакцию заказа
    """
    code = 10081
    message = "Order's transaction not found"
