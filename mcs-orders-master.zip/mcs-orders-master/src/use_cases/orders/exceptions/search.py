from .base import BaseValidationError, BaseSearchOrderError, BaseOriginTransactionError
from ..search.input_types.common import AvailableLanguages

"""
Ошибки, связанные с получением заказа
зарезервированные коды 10100 - 10199
"""


class BaseSearchValidationError(BaseValidationError):
    """
    Базовая ошибка валидации заказа при поиске
    """
    status = 400
    error_type = 'order_search'


class InvalidOauthRequestError(BaseSearchValidationError):
    """
    Некорректный Oauth user
    """
    code = 10100
    message = "Incorrect oauth user"


class InvalidInputFiltersError(BaseSearchValidationError):
    """
    Некорректные фильтры
    """
    code = 10101
    message = 'Incorrect input filters'


class InvalidSearchRequestError(BaseSearchValidationError):
    """
    Некорректный поисковый запрос
    """
    code = 10102
    message = 'Incorrect search request'


class InvalidInputFieldsError(BaseSearchValidationError):
    """
    Некорректные поля для сериализации
    """
    code = 10103
    message = 'Incorrect input fields'


class UnableToBuildQueryError(BaseSearchOrderError):
    """
    Не удалось построить запрос и найти заказ
    """
    status = 400
    code = 10110
    message = 'Unable to build query'


class SearchQueryIsTooBroadError(InvalidSearchRequestError):
    """
    Слишком широкий поисковый запрос / Мало данных
    """
    status = 400
    code = 10111
    message = 'Search query is too broad'


class InvalidInputSortersError(BaseSearchValidationError):
    """
    Некорректные сортировки
    """
    code = 10112
    message = 'Incorrect input sorters. Only hyphens, dots and alphanums are available'


class InvalidInputLanguage(BaseSearchValidationError):
    """
    Некорректные языки для перевода заказа
    """
    code = 10113
    message = 'Incorrect language requested, available languages are: {}'.format(
        str([i.value for i in AvailableLanguages])
    )


class OrderRefundsSearchError(BaseSearchOrderError):
    """
    Ошибка, связанная с поиском заявок на возврат
    """
    status = 404
    code = 10114
    message = 'Refunds not found'


class OrderTransactionNotFoundError(BaseOriginTransactionError):
    """
    Транзакция по заказу не была найдена
    """
    status = 404
    code = 10115
    message = "Order's transaction not found"
