from .base import BaseValidationError, BaseUpdateOrderError

"""
Ошибки, связанные с обновлением заказа
зарезервированные коды 10500 - 10599
"""


class InvalidOrderUUIDError(BaseValidationError):
    """
    Неверный uuid заказа
    """
    status = 200
    code = 10502
    message = 'Invalid input transaction'


class OrderNotFoundError(BaseUpdateOrderError):
    """
    Не удалось найти заказ в базе
    """
    code = 10503
    message = "Order not found in database"


class SirenaGRSOrderNotFoundError(BaseUpdateOrderError):
    """
    Не удалось найти заказ в SirenaGRS
    """
    code = 10504
    message = "SirenaGRS: order not found"


class OrderQueueIsNotEmptyError(BaseUpdateOrderError):
    """
    У заказа имеется очередь на сохранение, в данный момент обновление не возможно
    """
    code = 10505
    message = "Order's queue is not empty. Updating from sirenaGRS is not possible now. Try again in 15sec."


class UnableToUpdateUnpayedOrder(BaseUpdateOrderError):
    """
    Невозможно обновить неоплаченный заказ
    """
    code = 10506
    message = "Unable to update unpayed order"
