from .base import BaseValidationError, BaseSearchOrderError

"""
Ошибки, связанные с работой пользователя с заказом
(Удаление, добавление, итд)
зарезервированные коды 10300 - 10399
"""


class BaseOrderInteractionValidationError(BaseValidationError):
    """
    Базовая ошибка валидации запроса для работы пользователя с
    заказом
    """
    status = 400
    error_type = 'order'


class InvalidLastNameError(BaseOrderInteractionValidationError):
    """
    Некорректная фамилия
    """
    code = 10300
    message = "Incorrect input last_name"


class InvalidRlocError(BaseOrderInteractionValidationError):
    """
    Некорректный RLOC
    """
    code = 10301
    message = 'Incorrect input rloc'


class InvalidSearchRequestError(BaseOrderInteractionValidationError):
    """
    Некорректный поисковый запрос
    """
    code = 10302
    message = 'Incorrect search request'


class InvalidInputFieldsError(BaseOrderInteractionValidationError):
    """
    Некорректные поля для сериализации
    """
    code = 10303
    message = 'Incorrect input fields'


class UnableToBuildQueryError(BaseSearchOrderError):
    """
    Не удалось построить запрос и найти заказ
    """
    status = 400
    code = 10304
    message = 'Unable to build query'
    error_type = 'order'


class OrderNotFoundError(BaseSearchOrderError):
    """
    Не удалось найти заказ
    """
    status = 404
    code = 10305
    message = 'Order not found'
    error_type = 'order'


class OrderWithOpenRegistrationNotFoundError(BaseSearchOrderError):
    """
    Не удалось найти заказ с открытой регистрацией
    """
    status = 400
    code = 10310
    message = 'Order with open registration not found'
    error_type = 'order'


class OrderAlreadyAddedError(BaseSearchOrderError):
    """
    Заказ уже добавлен пользователю
    """
    status = 400
    code = 10306
    message = 'Order already added'
    error_type = 'order'


class InvalidOrderUUIDError(BaseSearchOrderError):
    """
    Некорректный uuid заказа
    """
    status = 400
    code = 10307
    message = 'Incorrect order uuid'
    error_type = 'order'


class MissingOrderUUIDError(BaseSearchOrderError):
    """
    Отсутствует uuid заказа
    """
    status = 400
    code = 10308
    message = 'Missing order uuid'
    error_type = 'serialization'


class MissingPassengerIDError(BaseSearchOrderError):
    """
    Отсутствует passenger_id заказа
    """
    status = 400
    code = 10309
    message = 'Missing passenger id'
    error_type = 'serialization'


class OrderWithOnlineRegistrationNotFoundError(BaseSearchOrderError):
    """
    у заказа запрещена онлайн регистрация
    """
    status = 400
    code = 10311
    message = 'Order with online registration not found'
    error_type = 'order'


class PassengersNotFoundError(BaseSearchOrderError):
    """
    Пассажиры не были найдены
    """
    status = 400
    code = 10312
    message = 'Passengers not found'
    error_type = 'search'
