from .base import BaseSegmentWithdrawError

"""
Ошибки, связанные с функционалом оформления возврата
зарезервированные коды 1150 - 1199
"""


class NoAvailableSegmentsFoundError(BaseSegmentWithdrawError):
    """
    Для брони аннулирование невозможно
    """
    status = 422
    code = 1151
    message = "No segments for releasing"


class CouldntGetOrderDataFromSirenaError(BaseSegmentWithdrawError):
    """
    Не удалось получить данные от Сирены
    """
    status = 422
    code = 1152
    message = "Couldn't get order's data from Sirena"


class CouldntGetClaimError(BaseSegmentWithdrawError):
    code = 1156
    message = "Some error in claim process"


class LonelyInfantError(BaseSegmentWithdrawError):
    """
    Нельзя аннулировать места, оставив единственным пассажиром младенца или ребенка.
    """
    status = 422
    code = 1153
    message = "A child cannot be the only passenger"


class IncorrectPassengersDataError(BaseSegmentWithdrawError):
    """
    Полученные данные о пассажирах не совпадают с оригинальными данными о пассажирах
    """
    status = 422
    code = 1154
    message = "Received passengers data does not match the original passengers data"


class PassengerNotFoundError(BaseSegmentWithdrawError):
    """
    Не найден пассажир по указанному passenger_id
    """
    status = 422
    code = 1155
    message = "Passenger not found"


class MissingAttemptIdError(BaseSegmentWithdrawError):
    """
    Отсутствует attempt_id
    """
    status = 422
    code = 1156
    message = "Missing attempt_id"


class MissingVerificationCodeError(BaseSegmentWithdrawError):
    """
    Отсутствует код верификации
    """
    status = 422
    code = 1157
    message = "Missing verification code"


class MissingOrderUuidError(BaseSegmentWithdrawError):
    """
    Отсутствует uuid заказа
    """
    status = 422
    code = 1158
    message = 'Missing order uuid'
    error_type = 'serialization'


class ExpiredReleaseSeatsDataError(BaseSegmentWithdrawError):
    """
    Отсутствует uuid заказа
    """
    status = 422
    code = 1159
    message = 'Response timeout expired'


class InvalidCodeError(BaseSegmentWithdrawError):
    """
    Неверный attempt_id
    """
    status = 422
    code = 1160
    message = 'Invalid code'


class FailedToDivideOrderError(BaseSegmentWithdrawError):
    """
    Не удалось разделить места в сирене
    """
    status = 400
    code = 1161
    message = "Failed to divide order"


class FailedToReleaseSeatsError(BaseSegmentWithdrawError):
    """
    Не удалось снять места в сирене
    """
    status = 400
    code = 1162
    message = "Failed to release seats"


class PassengersCheckedInError(BaseSegmentWithdrawError):
    """
    Есть зарегистрированные на рейс пассажиры
    """
    status = 400
    code = 1163
    message = "It is necessary to cancel the registration"


class DepartureTimestampError(BaseSegmentWithdrawError):
    """
    Осталось менее 40 минут до планового вылета
    """
    status = 400
    code = 1164
    message = "Less than 40 minutes before departure"
