from typing import Optional

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from domain.exchange import DomainExchange
from domain.types import ExchangeStatus
from libs.messages.telegram import TelegramMessenger

from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase

from use_cases.orders.exchange.shared.cancel_exchange import CancelExchangeService
from use_cases.orders.exceptions.exchange import InvalidExchangeStatus, CancelPaymentError
from use_cases.orders.exchange.send_telegram.message_generators import SendWarningVoidRequiredGenerator

from .cancel_request import ExchangeCancelRequest
from .cancel_response import ExchangeCancelResponse


class ExchangeCancelUseCase(BaseExchangeUseCase):
    """
    Отмена обмена
    """
    __internal_sirena_adapter: SirenaInternalAdapter

    def __init__(
        self,
        exchange_repo: GenericMongoRepository,
        internal_payments_adapter: PaymentsInternalAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
        messenger: Optional[TelegramMessenger] = None,
    ):
        self.__internal_sirena_adapter = internal_sirena_adapter
        super().__init__(
            exchange_repo=exchange_repo, internal_payments_adapter=internal_payments_adapter, messenger=messenger
        )

    def __execute__(self, request: ExchangeCancelRequest, *args, **kwargs) -> ExchangeCancelResponse:
        self.logger.info(f'Cancel exchange {request.exchange_uuid}')
        exchange = self._get_exchange(request.exchange_uuid)
        if exchange.status.is_new():
            self._set_status(exchange, ExchangeStatus.EXPIRED)
            self._update_exchange(exchange)
        elif exchange.status.is_pending():
            self._pending_cancel(exchange)
        elif exchange.status.is_wait_receipt():
            self._wait_receipt_cancel(exchange)
        else:
            raise InvalidExchangeStatus()
        return ExchangeCancelResponse(exchange=exchange)

    def _pending_cancel(self, exchange: DomainExchange):
        payment = self.internal_payments_adapter.get(uuid=exchange.payment.transaction)
        if not payment:
            self._set_status(exchange, ExchangeStatus.EXPIRED)
            self._update_exchange(exchange)
            return
        state = payment.transaction.get('state') or ''
        if state == 'created':
            self.__void_payment(exchange)
            self._set_status(exchange, ExchangeStatus.CANCELED)
            self._update_exchange(exchange)
            return
        elif state in ('expired', 'cancelled', 'declined'):
            self._set_status(exchange, ExchangeStatus.CANCELED)
            self._update_exchange(exchange)
            return
        raise CancelPaymentError()

    def _wait_receipt_cancel(self, exchange: DomainExchange):
        try:
            CancelExchangeService(
                exchange=exchange,
                internal_sirena_adapter=self.__internal_sirena_adapter,
                internal_payments_adapter=self.internal_payments_adapter,
                messenger=self.__messenger,
            ).run()
            exchange.status = exchange.status.CANCELED
        except Exception as ex:
            self.logger.exception(str(ex))
            exchange.status = exchange.status.ERROR
        self._update_exchange(exchange)

    def __void_payment(self, exchange: DomainExchange) -> None:
        # TODO: Allow Payment Void
        # self.internal_payments_adapter.void(uuid=exchange.payment.transaction)

        if self.messenger:
            self.messenger.send_message(
                SendWarningVoidRequiredGenerator(exchange=exchange).generate_msg()
            )
