import logging
import time
from typing import Union, List, Optional, Set
from uuid import UUID

from sirena_xml_client.exceptions import SirenaPnrAndSurnameDontMatch
from sirena_xml_client.types import PaymentCost

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.service_agent import ServiceAgentAdapter
from base.exception import ApplicationError
from base.use_case import BaseUseCaseRequest, BaseUseCaseResponse
from domain import DomainOrder
from domain.exchange import (
    DomainExchangeRefundedServices, DomainExchangePrice, DomainExchangeRefundedService, DomainExchange,
)
from domain.order.data import DomainService
from domain.types import SegmentStatus, CouponStatus, ExchangeOrderState, ExchangeStatus, RefundServiceStatus
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.exceptions.exchange import (
    ServiceAgentSearchServiceError, UnexpectedCurrencyError, SirenaSearchOrderError,
)
from use_cases.orders.exceptions.update import OrderQueueIsNotEmptyError
from use_cases.orders.exchange.shared.consts import CURRENCY_PRICE_MAP
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase
from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.sale_parts import to_list
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue


class ExchangeClearSegmentsRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]

    def __init__(self, exchange_uuid: Union[str, UUID]):
        super().__init__()
        self.exchange_uuid = exchange_uuid

    def is_valid(self, *args, **kwargs) -> 'ExchangeClearSegmentsRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
        }

    @classmethod
    def deserialize(cls, data: dict) -> 'ExchangeClearSegmentsRequest':
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
        )


class ExchangeClearSegmentsResponse(BaseUseCaseResponse):
    pass


class ExchangeClearSegmentsUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    """
    При обмене зачищаем заказ от услуг и сегментов
    """
    def __init__(
            self,
            order_repo: GenericMongoRepository,
            exchange_repo: GenericMongoRepository,
            internal_order_adapter: InternalOrderAdapter,
            internal_sirena_adapter: SirenaInternalAdapter,
            internal_payments_adapter: PaymentsInternalAdapter,
            service_agent_adapter: ServiceAgentAdapter,
            save_order_queue: SaveOrdersQueue,
            messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.service_agent_adapter = service_agent_adapter
        self.save_order_queue = save_order_queue
        self.logger = logging.getLogger('exchange_logger')

    def __execute__(self, request: ExchangeClearSegmentsRequest, *args, **kwargs) -> ExchangeClearSegmentsResponse:
        exchange = self._get_exchange(request.exchange_uuid)
        try:
            result = self._clear(exchange)
        except Exception as ex:
            result = False
            self.logger.exception(str(ex))
            self._cancel(exchange=exchange, ex=ex)
        return ExchangeClearSegmentsResponse(value=dict(result=result))

    def _enriche_service(self, service: DomainService) -> DomainExchangeRefundedService:
        stype = service.type
        if not stype:
            try:
                additional_service = self.service_agent_adapter.get_service_by_guid(service.guid)
                if not additional_service:
                    raise ServiceAgentSearchServiceError()
                stype = additional_service.service_type
            except Exception:
                self.logger.error(f'Can not enriche service {service.guid}')

        return DomainExchangeRefundedService(
            guid=service.guid,
            rfisc=service.rfisc,
            count=service.count,
            description=service.description,
            passenger_id=service.passenger_id,
            segment_id=service.segment_id,
            type_=stype,
        )

    def _clear(self, exchange):
        self.logger.info(f'ExchangeClearSegmentsUseCase for {exchange.exchange_uuid}')

        # Обновляем заказ и достаем отмененные сегменты и услуги
        order = self._get_updated_order(order_uuid=exchange.order_uuid)
        canceled_segment_ids: List[str] = [
            s.segment_id
            for s in order.data.segments
            if s.status == SegmentStatus.XX.value
        ]
        services_to_refund: List[DomainService] = [
            s for s in order.data.services
            if s.segment_id in canceled_segment_ids
        ]

        # Если не осталось услуг к возврату - возврат завершен
        if not services_to_refund:
            exchange.refunded_services_status = RefundServiceStatus.COMPLETE
            self._update_exchange(exchange)

        if not canceled_segment_ids:
            self.logger.info('ExchangeClearSegmentsUseCase not canceled segments')
            return True

        # Возврат услуг
        if services_to_refund:
            try:
                refund_price = self._refund_services(order, services_to_refund)
                exchange.refunded_services_status = RefundServiceStatus.COMPLETE
            except Exception as ex:
                self.logger.exception(ex)
                refund_price = None
                exchange.refunded_services_status = RefundServiceStatus.ERROR
            exchange.refunded_services = DomainExchangeRefundedServices(
                services=[self._enriche_service(s) for s in services_to_refund],
                price=refund_price,
            )
            self._update_exchange(exchange)

        # Удаление сегментов в сирене
        sirena_order = self._get_sirena_order(order=order)
        canceled_sirena_segment_ids: List[str] = [
            seg['@id']
            for seg in to_list(sirena_order['order']['pnr']['segments']['segment'])
            if seg['status']['@text'] == SegmentStatus.XX.value
        ]
        if canceled_sirena_segment_ids:
            try:
                self.internal_sirena_adapter.remove_segments(
                    rloc=order.data.rloc,
                    last_name=order.data.passengers[0].last_name,
                    segment_ids=canceled_sirena_segment_ids,
                )
            except Exception as ex:
                self.logger.exception(ex)
                return True

        try:
            # Обновление заказа, после удаления сегментов в сирене
            self.internal_order_adapter.update_from_sirena_grs(order.data.order_uuid)
        except OrderQueueIsNotEmptyError:
            # Значит заказ уже в очереди на обновление
            pass
        return True

    def _get_sirena_order(self, order: DomainOrder) -> dict:
        """
        Получение заказа из сирены (нужны ид сегментов из сирены)

        Код из use_cases.orders.update.sirenagrs_force_update_use_case.SirenaGRSForceUpdateUseCase.search_in_sirena
        """
        # Пробуем найти по всем уникальным фамилиям в броне, так как если произошел сплит, а броня в базе не обновлена
        # в сирене заказ не найдется по первому пассажиру
        unique_passenger_last_names: Set[str] = {i.last_name for i in order.data.passengers if i is not None}
        for last_name in unique_passenger_last_names:
            try:
                return self.internal_sirena_adapter.search_order(rloc=order.data.rloc, last_name=last_name)
            except (SirenaPnrAndSurnameDontMatch, ApplicationError):
                pass
        raise SirenaSearchOrderError()

    def _get_updated_order(self, order_uuid) -> DomainOrder:
        """
        При получении заказа с обработкой ошибки конфликта обновления:
        Order's queue is not empty. Updating from sirenaGRS is not possible now. Try again in 15sec
        """
        try:
            order = self._get_order(order_uuid=order_uuid, update_existing=True)
        except OrderQueueIsNotEmptyError:
            order = self._get_order(order_uuid=order_uuid, update_existing=False)
            # Делаем попытки с интервалом. Далее работаем с обновленным заказом
            # В ином случае работаем с тем что есть (т.к. подтверждение заказа уже совершенно)
            for attempt in range(30):
                self.logger.error(f'Conflict OrderQueueIsNotEmptyError for: {order_uuid} attempt: {attempt}')
                time.sleep(1)
                # Проверяем заказ в очереди обновления
                if not self.save_order_queue.queue_is_active(order.data.rloc):
                    order = self._get_order(order_uuid=order_uuid, update_existing=False)
                    break

        return order

    def _refund_services(
        self, order: DomainOrder, services_to_refund: List[DomainService]
    ) -> Optional[DomainExchangePrice]:
        status_response = self.internal_sirena_adapter.get_flown_status(
            rloc=order.data.rloc,
            last_name=order.data.passengers[0].last_name,
        )
        emds_to_refund: List[str] = [s.emd for s in services_to_refund]
        sirena_services = [
            s for s in self._get_to_list(status_response, 'svc')
            if s['@ec_stat'] == CouponStatus.O.value and f'{s["@accode"]}{s["@number"]}' in emds_to_refund
        ]

        svc_ids_to_refund = [s['@id'] for s in sirena_services]
        start_refund_response = self.internal_sirena_adapter.start_services_refund(
            rloc=order.data.rloc,
            services=svc_ids_to_refund,
            involuntary=True,
        )

        refund_price = DomainExchangePrice(
            currency=start_refund_response['cost']['@curr'],
            amount=float(start_refund_response['cost']['text'])
        )
        if refund_price.currency not in CURRENCY_PRICE_MAP:
            raise UnexpectedCurrencyError()

        self.internal_sirena_adapter.confirm_services_refund(
            rloc=order.data.rloc,
            services=svc_ids_to_refund,
            cost=PaymentCost(
                currency=refund_price.currency,
                amount=f'{refund_price.amount:.2f}'
            ),
            involuntary=True,
        )
        return refund_price

    def _cancel(self, exchange: DomainExchange, ex: Exception):
        """
        Отмена обмена в случае ошибок
        """
        if exchange.status.is_terminal():
            return
        try:
            self.internal_sirena_adapter.cancel_exchange(rloc=exchange.order.locator, last_name=exchange.order.surname,)
            exchange.order.state = ExchangeOrderState.CANCELED
            self._cancel_payment(exchange)
        except Exception as ex:
            self.logger.exception(ex)
        self._set_status(exchange, ExchangeStatus.ERROR)
        exchange.set_error(ex)
        self._update_exchange(exchange)
