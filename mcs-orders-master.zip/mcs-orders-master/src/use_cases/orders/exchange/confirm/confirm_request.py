from uuid import UUID
from typing import Union, List

from base.use_case import BaseUseCaseRequest

from base.exception import ApplicationError
from domain.exchange import DomainExchangeFlight


class ExchangeConfirmRequest(BaseUseCaseRequest):
    order_uuid: Union[str, UUID]
    passenger_ids: List[str]
    flights: List[DomainExchangeFlight]

    def __init__(
            self,
            order_uuid: Union[str, UUID],
            passenger_ids: List[str],
            flights: List[dict],
    ):
        super().__init__()
        self.order_uuid = order_uuid
        self.passenger_ids = passenger_ids
        self.flights = [DomainExchangeFlight.deserialize(f) for f in flights]

    def is_valid(self, *args, **kwargs) -> 'ExchangeConfirmRequest':
        try:
            UUID(str(self.order_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid order uuid"))

        if not self.passenger_ids:
            self.add_error(ApplicationError(code=400, message="Passengers required"))

        if not self.flights:
            self.add_error(ApplicationError(code=400, message="Flights required"))

        self.__validate_flights(self.flights)

        return self

    def __validate_flights(self, flights: List[DomainExchangeFlight]) -> None:
        segment_ids = set()
        segment_count = 0

        for flight in flights:
            if not flight.segments:
                self.add_error(ApplicationError(code=400, message="Segment ids required"))

            segment_ids |= set(flight.segments)
            segment_count += len(flight.segments)

            if not flight.exchange:
                self.add_error(ApplicationError(code=400, message="Exchange data required for every flight"))
                if not all([bool(s.subclass) for s in flight.exchange]):
                    self.add_error(ApplicationError(code=400, message="Subclass required for exchange flights"))

        if len(segment_ids) != segment_count:
            self.add_error(ApplicationError(code=400, message="Inconsistent segment IDs"))

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
            'passenger_ids': self.passenger_ids,
            'flights': [f.serialize() for f in self.flights],
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid'),
            passenger_ids=data.get('passenger_ids', []),
            flights=data.get('flights', []),
        )
