from typing import List, Optional

from sirena_xml_client.exceptions import BaseSirenaError, SirenaResponseError
from sirena_xml_client.types import ExchangePassenger

from adapter.monoapp import MonoAppAdapter
from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

from domain import DomainOrder
from domain.currency_rates import DomainCurrencyRates
from domain.exchange import DomainExchangeFlight, DomainFlightOptionError, DomainExchange, DomainExchangeSegment
from domain.types import ExchangeFlow
from libs.messages.telegram import TelegramMessenger
from repositories.query_builders.exchange import ExchangeQueryBuilder
from rest.interfaces.external_exchange_order_adapter import ExternalExchangeOrderAdapter
from libs.utils.threads import bulk_requests

from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase

from use_cases.orders.exchange.shared.types import ExchangeablePassenger, ExchangeableFlight
from use_cases.shared.calculate_price import CalculatePriceResponse, CalculatePrice

from .confirm_request import ExchangeConfirmRequest
from .confirm_response import ExchangeConfirmResponse

from use_cases.orders.exceptions.exchange import ExchangeRetryNeededError
from use_cases.orders.exchange.shared.enrich_exchange_segments import EnrichExchangeSegments
from use_cases.orders.exchange.shared.sirena_requests.pricing_route_request import PricingRouteBuilder
from use_cases.orders.exchange.shared.variant_data_combiner import VariantDataCombiner
from use_cases.orders.exceptions.exchange import PassengerCategoryChangedError, NoExchangeOptions
from use_cases.orders.exchange.shared.check_exists_exchanges import CheckExistsExchanges
from use_cases.orders.save.utils.currency_rates import CurrencyRates


class ExchangeConfirmUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    """
    Подтверждение обмена
    """

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            exchange_repo: GenericMongoRepository,
            internal_order_adapter: InternalOrderAdapter,
            internal_sirena_adapter: SirenaInternalAdapter,
            internal_payments_adapter: PaymentsInternalAdapter,
            mono_app_adapter: MonoAppAdapter,
            currency_adapter: CurrencyRates,
            messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.mono_app_adapter = mono_app_adapter
        self.currency_adapter = currency_adapter

    def __execute__(self, request: ExchangeConfirmRequest, *args, **kwargs) -> ExchangeConfirmResponse:
        self.logger.info(f'Confirm exchange for {request.order_uuid}')

        order = self._get_order(order_uuid=str(request.order_uuid), update_existing=False)
        self._check_exists_exchange(order=order)
        exchangeable_flights = self._get_exchangeable_flights(order)
        self._validate_released(exchangeable_flights, [s_id for f in request.flights for s_id in f.segments])

        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)
        selected_passengers, left_passengers = self._get_selected_passengers(
            exchangeable_passengers, request.passenger_ids
        )
        if not self._is_category_persisted(
                selected_passengers, [s.flight_date for f in request.flights for s in f.exchange]
        ):
            raise PassengerCategoryChangedError()

        calc_response: CalculatePriceResponse = self.__get_exchange_price(
            order=order,
            passengers=selected_passengers,
            exchangeable_flights=exchangeable_flights,
            flights=request.flights,
        )

        (cities_by_airports, cities_tz, _, _) = self._enrich_airports(
            self.mono_app_adapter, request.flights
        )

        segments = [segment for flight in request.flights for segment in flight.exchange]
        pricing_route_responses = self._pricing_route(segments, exchangeable_passengers)
        EnrichExchangeSegments(
            segments=segments,
            pricing_route_responses=pricing_route_responses,
            flights=request.flights,
            cities_by_airports=cities_by_airports,
            cities_tz=cities_tz,
            variant_data_combiner=VariantDataCombiner(mono_app_adapter=self.mono_app_adapter),
        ).run()

        contacts = self._get_exchange_contacts(order)

        exchange = self._create_exchange(
            order=order,
            contacts=contacts,
            passengers=selected_passengers,
            flights=request.flights,
            price=calc_response.exchange_price,
            flow=ExchangeFlow.MANUAL if calc_response.is_manual else ExchangeFlow.AUTO,
        )

        self.logger.info(
            f'Created exchange transaction({exchange.exchange_uuid}) for {order.data.rloc}, '
            f'cost is {calc_response.exchange_price}'
        )

        return ExchangeConfirmResponse(exchange=exchange)

    @classmethod
    def _update_segments_subclass(cls, flights: List[DomainExchangeFlight], exchange_data: dict):
        exchange_segments = []
        segments_data = cls._get_to_list(exchange_data.get('segments', {}), 'segment')
        for s in segments_data:
            exchange_segments += cls._get_to_list(s, 'desired')

        origin_segments = []
        for flight in flights:
            origin_segments += flight.exchange

        for origin, data in zip(origin_segments, exchange_segments):
            origin.subclass = data.get('subclass', {}).get('text')

    def __get_exchange_price(
            self,
            order: DomainOrder,
            passengers: List[ExchangeablePassenger],
            exchangeable_flights: List[ExchangeableFlight],
            flights: List[DomainExchangeFlight]
    ) -> CalculatePriceResponse:
        exchange_segments, original_flights = self._get_exchange_segments(
            exchangeable_flights, flights, skip_subclass=False
        )

        if not (passengers and exchange_segments):
            raise ValueError('Passengers in segments required')

        try:
            response: dict = self.internal_sirena_adapter.exchange_pricing(
                rloc=order.data.rloc,
                passengers=[ExchangePassenger(
                    last_name=p.passenger.last_name,
                    first_name=p.passenger.first_name,
                    second_name=p.passenger.second_name,
                ) for p in passengers],
                segments=exchange_segments,
            )
        except (BaseSirenaError, SirenaResponseError) as ex:
            self.logger.exception(ex)
            raise ExchangeRetryNeededError()
        except Exception as ex:
            self.logger.exception(ex)
            response = {}

        if not response or not self._get_to_list(response.get('segments', {}), 'segment'):
            raise NoExchangeOptions(
                data=dict(error_flights=[
                    DomainFlightOptionError(
                        flight_id=str(flight.flight_id),
                        flight_date=flight.exchange[0].flight_date,
                        departure=flight.exchange[0].departure_airport,
                        arrival=flight.exchange[-1].arrival_airport,
                    ).serialize()
                    for flight in flights
                ])
            )

        self._update_segments_subclass(flights, response)
        currency_rate: DomainCurrencyRates = self.currency_adapter.get_actual_currency_rates()
        return CalculatePrice(
            order=order,
            original_flights=original_flights,
            exchange_pricing_response=response,
            currency_rate=currency_rate,
            mono_app_adapter=self.mono_app_adapter,
        ).run()

    def _pricing_route(
            self,
            segments: List[DomainExchangeSegment],
            exchangeable_passengers: List[ExchangeablePassenger],
    ) -> list:
        """
        Получение вариантов перелета из сирены
        """
        if not len(segments):
            return []

        requests = PricingRouteBuilder.get_requests(segments, exchangeable_passengers)

        try:
            return bulk_requests(self.internal_sirena_adapter.client.get_pricing_route, requests)
        except (BaseSirenaError, SirenaResponseError) as ex:
            self.logger.exception(ex)
            if ex.http_code == 500:
                raise ExchangeRetryNeededError()
        except Exception as ex:
            self.logger.exception(ex)
        return []

    def _check_exists_exchange(self, order: DomainOrder):
        existing_exchanges: List[DomainExchange] = self.exchange_repo.list(
            spec=ExchangeQueryBuilder.get_exchange_by_order_uuid(order.data.order_uuid),
            sort=[('_id', -1)]
        )
        if not existing_exchanges:
            return None
        return CheckExistsExchanges(
            existing_exchanges=existing_exchanges,
            cancel_exchange_callback=ExternalExchangeOrderAdapter().cancel_order_exchange,
        ).run()
