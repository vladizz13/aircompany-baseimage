from datetime import date
from uuid import UUID
from typing import Union, List

from pydantic import BaseModel

from base.use_case import BaseUseCaseRequest

from base.exception import ApplicationError


class FlightExchangeData(BaseModel):
    flight_id: int
    segment_ids: List[str]
    flight_date: date
    departure_city: str
    arrival_city: str


class ExchangeOptionsRequest(BaseUseCaseRequest):
    order_uuid: Union[str, UUID]
    passenger_ids: List[str]
    flights: List[FlightExchangeData]

    def __init__(
            self,
            order_uuid: Union[str, UUID],
            passenger_ids: List[str],
            flights: List[FlightExchangeData]
    ):
        super().__init__()
        self.order_uuid = order_uuid
        self.passenger_ids = passenger_ids
        self.flights = flights

    def is_valid(self, *args, **kwargs) -> 'ExchangeOptionsRequest':
        try:
            UUID(str(self.order_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid order uuid"))

        if not self.passenger_ids:
            self.add_error(ApplicationError(code=400, message="Passengers required"))

        if not self.flights:
            self.add_error(ApplicationError(code=400, message="Flights required"))

        self.__validate_flights(self.flights)

        return self

    def __validate_flights(self, flights: List[FlightExchangeData]) -> None:
        segment_ids = set()
        segment_count = 0

        today = date.today()

        for flight in flights:
            if not flight.segment_ids:
                self.add_error(ApplicationError(code=400, message="Segment ids required"))

            segment_ids |= set(flight.segment_ids)
            segment_count += len(flight.segment_ids)

            if flight.flight_date < today:
                self.add_error(ApplicationError(code=400, message="Segment dates must be in future"))

        if len(segment_ids) != segment_count:
            self.add_error(ApplicationError(code=400, message="Inconsistent segment IDs"))

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
            'passenger_ids': self.passenger_ids,
            'flights': [f.dict() for f in self.flights],
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid'),
            passenger_ids=data.get('passenger_ids', []),
            flights=data.get('flights', []),
        )
