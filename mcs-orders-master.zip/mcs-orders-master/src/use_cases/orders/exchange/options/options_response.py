from typing import List, Dict
from pydantic.main import BaseModel

from base.use_case import BaseUseCaseResponse
from domain.exchange import DomainExchangePrice

from use_cases.orders.exchange.shared.types import (
    CancelableService, ExchangeVariantSegmentLanding,
)
from use_cases.orders.exchange.options.types import (
    ExchangeFlightVariants, ExchangeVariantSegment, ExchangeSegmentPoint, ExchangeFlight
)


class ExchangeVariant(BaseModel):
    flight_id: int
    variant_id: int

    def serialize(self) -> dict:
        return {
            'flight_id': self.flight_id,
            'variant_id': self.variant_id,
        }


class ExchangeOption(BaseModel):
    variants: List[ExchangeVariant]
    price: DomainExchangePrice

    class Config:
        arbitrary_types_allowed = True

    def serialize(self) -> dict:
        return {
            'variants': [v.serialize() for v in self.variants],
            'price': self.price.serialize(),
        }


class ExchangeOptionsResponse(BaseUseCaseResponse):
    def __init__(
        self,
        flight_variants: List[ExchangeFlightVariants],
        options: List[ExchangeOption],
        services: List[CancelableService],
        cities: Dict[str, str],
        airports: Dict[str, str]
    ):
        super().__init__(self.serialize(flight_variants, options, services, cities, airports))

    @classmethod
    def serialize(
        cls,
        flight_variants: List[ExchangeFlightVariants],
        options: List[ExchangeOption],
        services: List[CancelableService],
        cities: Dict[str, str],
        airports: Dict[str, str]
    ) -> dict:
        return {
            'flights': [{
                'flight': cls.__serialize_exchange_flight(fv.flight),
                'variants': [{
                    'variant_id': v.variant_id,
                    'segments': [cls.__serialize_variant_segment(s, cities, airports) for s in v.segments],
                } for v in fv.variants],
            } for fv in flight_variants],
            'options': [o.serialize() for o in options],
            'services': [s.serialize() for s in services],
        }

    @classmethod
    def __serialize_exchange_flight(cls, flight: ExchangeFlight) -> dict:
        return {
            'flight_id': flight.flight_id,
            'segment_ids': [s.segment_id for s in flight.segments],
            'flight_date': flight.flight_date.isoformat(),
            'departure_city': flight.departure_city,
            'arrival_city': flight.arrival_city,
        }

    @classmethod
    def __serialize_variant_segment(
        cls,
        segment: ExchangeVariantSegment,
        cities: Dict[str, str],
        airports: Dict[str, str]
    ) -> dict:
        return {
            'airline': segment.airline,
            'flight_number': segment.flight_number,
            'departure': cls.__serialize_point(segment.departure, cities, airports),
            'arrival': cls.__serialize_point(segment.arrival, cities, airports),
            'craft': segment.craft,
            'landings': [cls._serialize_landing(landing) for landing in segment.landings],
        }

    @staticmethod
    def __serialize_point(point: ExchangeSegmentPoint, cities: Dict[str, str], airports: Dict[str, str]) -> dict:
        return {
            'airport_code': point.airport_code,
            'airport_name': airports.get(point.airport_code),
            'city_code': point.city_code,
            'city_name': cities.get(point.city_code),
            'local': point.local.isoformat(),
        }

    @staticmethod
    def _serialize_landing(landing: ExchangeVariantSegmentLanding):
        return {
            'id': landing.id,
            'city': landing.city,
            'time': landing.time,
            'airport': landing.airport,
        }
