from itertools import product
from collections import defaultdict
from datetime import datetime, date, timezone, timedelta
from typing import List, Dict, Tuple, Optional, Set

from utair.clients.external.sirena.base.models.base_client_response import ResponseModelABC
from utair.clients.external.sirena.exceptions import BaseSirenaError
from utair.clients.external.sirena.requests.common import (
    Passenger, RequestParams, AnswerParams, PaymentDocument, ExchangePassenger, ExchangeSegments
)
from utair.clients.external.sirena.requests.exchange_pricing import ExchangePricingRequest
from utair.clients.external.sirena.requests.get_pricing_route import GetPricingRoute, PricingRouteSegment

from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.sirena_bulk_adapter import SirenaAdapter
from domain import DomainOrder
from domain.currency_rates import DomainCurrencyRates
from domain.exchange import DomainFlightOptionError, DomainExchange
from domain.order.data import DomainSegment
from domain.types import PassengerCategory
from libs.utils.tools.date import time_to_seconds, parse_sirena_bad_date, parse_sirena_bad_datetime
from repositories.query_builders.exchange import ExchangeQueryBuilder
from rest.interfaces.external_exchange_order_adapter import ExternalExchangeOrderAdapter

from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.types import ExchangeablePassenger, ExchangeableFlight
from use_cases.orders.exchange.shared.consts import (
    ALLOWED_COUNTRY, CATEGORY_AGES, SIRENA_CATEGORY_MAPPING
)

from use_cases.orders.exceptions.exchange import (
    BaseExchangeError,
    InvalidExchangeableSegmentError, PassengerCategoryChangedError, InvalidTransferSegments,
    AirportChangeNotImplemented, NoExchangeOptions, SegmentConnectWithPreviousError,
)
from use_cases.shared.calculate_price import CalculatePriceResponse, CalculatePrice

from use_cases.orders.exchange.options.options_request import ExchangeOptionsRequest, FlightExchangeData
from use_cases.orders.exchange.options.options_response import ExchangeOptionsResponse, ExchangeOption, ExchangeVariant
from use_cases.orders.exchange.options.consts import PRICING_MAX_RESULTS, PRICING_CODES_MAP, PRICING_SIRENA_MAX_RESULTS
from use_cases.orders.exchange.options.types import ExchangeFlight, ExchangeFlightVariants, ExchangeFlightVariant, \
    ExchangeVariantSegment, ExchangeSegmentPoint, SegmentMapper
from use_cases.orders.exchange.shared.mappers.exchange_segments import ExchangeSegmentsMapper
from use_cases.orders.exchange.shared.check_exists_exchanges import CheckExistsExchanges
from use_cases.orders.exchange.shared.parse_sirena_time import parse_sirena_time
from use_cases.orders.exchange.shared.variant_data_combiner import VariantDataCombiner
from use_cases.orders.save.utils.currency_rates import CurrencyRates


class ExchangeOptionsUseCase(BaseExchangeableOrderUseCase):
    """
    Получение вариантов обмена
    """
    airports: Dict[str, str]
    cities: Dict[str, str]
    segment_mapper: Optional[SegmentMapper]

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            exchange_repo: GenericMongoRepository,
            internal_order_adapter: InternalOrderAdapter,
            internal_sirena_adapter: SirenaInternalAdapter,
            sirena_adapter: SirenaAdapter,
            mono_app_adapter: MonoAppAdapter,
            currency_adapter: CurrencyRates,
    ):
        super().__init__(
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        self.mono_app_adapter = mono_app_adapter
        self.exchange_repo = exchange_repo
        self.airports = {}
        self.cities = {}
        self.segment_mapper = None
        self.sirena_adapter = sirena_adapter
        self.currency_adapter = currency_adapter

    def __execute__(self, request: ExchangeOptionsRequest, *args, **kwargs) -> ExchangeOptionsResponse:
        self.logger.info(f'Collecting available exchange options for {request.order_uuid}')

        order = self._get_order(order_uuid=str(request.order_uuid), update_existing=False)
        self._check_exists_exchange(order=order)
        exchangeable_flights = self._get_exchangeable_flights(order)
        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)

        exchange_flights = self.__get_exchange_flights(exchangeable_flights, request.flights)
        self.segment_mapper = self._generage_segment_mapper(exchangeable_flights, exchange_flights)
        self._validate_released(exchangeable_flights, [s_id for f in request.flights for s_id in f.segment_ids])
        self._validate_dates()
        self.__validate_flights(exchange_flights)

        selected_passengers, _ = self._get_selected_passengers(exchangeable_passengers, request.passenger_ids)
        self.logger.info(f'Retrieved {len(selected_passengers)} selected passengers in {order.data.rloc}')

        if not self._is_category_persisted(selected_passengers, [f.flight_date for f in request.flights]):
            raise PassengerCategoryChangedError()

        self.logger.info(f'Acquiring available routes for {order.data.rloc}')
        flight_variants = self.__get_flight_variants(exchange_flights, selected_passengers)

        options = self.__get_options(order, flight_variants, selected_passengers)
        self.logger.info(f'Found {len(options)} exchange combinations for {order.data.rloc}')

        available_variants = self.__get_available_variants(flight_variants, options)

        segment_ids: List[str] = [s_id for f in request.flights for s_id in f.segment_ids]
        services = self._get_cancelable_services(order, segment_ids, request.passenger_ids)
        self.logger.info(f'Found {len(services)} cancelable services for {order.data.rloc}')

        return ExchangeOptionsResponse(
            flight_variants=available_variants,
            options=options,
            services=services,
            cities=self.cities,
            airports=self.airports,
        )

    def _generage_segment_mapper(
        self,
        exchangeable_flights: List[ExchangeableFlight],
        exchange_flights: List[ExchangeFlight]
    ):
        # Маппер получения выбранного рейса
        select_flight: Dict[str: ExchangeFlight] = {
            select_segment.segment_id: select_flight
            for select_flight in exchange_flights
            for select_segment in select_flight.segments
        }
        all_segments = [s for f in exchangeable_flights for s in f.segments]
        # Маппер получения следующего сегмента
        next_segment = {
            all_segments[index].segment_id: all_segments[index + 1]
            for index in range(len(all_segments))
            if index != (len(all_segments) - 1)
        }
        # Маппер получения предыдущего сегмента
        prev_segment = {
            all_segments[index].segment_id: all_segments[index - 1]
            for index in range(len(all_segments))
            if index != 0
        }
        return SegmentMapper(
            select_flight=select_flight,
            next_segment=next_segment,
            prev_segment=prev_segment,
        )

    def _validate_dates(self) -> None:
        """
        Проверяем что дата выбранного сегмента не раньше предыдущего сегмента
        """
        for segment_id, select_flight in self.segment_mapper.select_flight.items():
            prev_date = self._get_prev_date(select_flight.segments[0].segment_id)
            next_date = self._get_next_date(select_flight.segments[-1].segment_id)
            if (prev_date and prev_date > select_flight.flight_date) \
                    or (next_date and next_date < select_flight.flight_date):
                raise SegmentConnectWithPreviousError(
                    data=dict(
                        error_flights=[
                            DomainFlightOptionError(
                                flight_id=str(select_flight.flight_id),
                                flight_date=select_flight.flight_date,
                                departure=select_flight.departure_city,
                                arrival=select_flight.arrival_city,
                            ).serialize()
                        ]
                    )
                )

    def _get_prev_date(self, segment_id):
        prev_segment = self.segment_mapper.prev_segment.get(segment_id)
        if not prev_segment:
            return
        if prev_segment.segment_id in self.segment_mapper.select_flight:
            return self.segment_mapper.select_flight[prev_segment.segment_id].flight_date
        return datetime.fromtimestamp(prev_segment.arrival_timestamp).date()

    def _get_next_date(self, segment_id):
        next_segment = self.segment_mapper.next_segment.get(segment_id)
        if not next_segment:
            return
        if next_segment.segment_id in self.segment_mapper.select_flight:
            return self.segment_mapper.select_flight[next_segment.segment_id].flight_date
        return datetime.fromtimestamp(next_segment.departure_timestamp).date()

    def __validate_flights(self, exchange_flights: List[ExchangeFlight]) -> None:
        airports = set()

        for flight in exchange_flights:
            if (
                flight.departure_city != flight.segments[0].departure_city_code
                or flight.arrival_city != flight.segments[-1].arrival_city_code
            ):
                raise AirportChangeNotImplemented()

            for segment in flight.segments:
                airports.add(segment.departure_airport_code)
                airports.add(segment.arrival_airport_code)

    def __get_flight_variants(
            self,
            exchange_flights: List[ExchangeFlight],
            selected_passengers: List[ExchangeablePassenger]
    ) -> List[ExchangeFlightVariants]:
        passenger_categories: Dict[PassengerCategory, int] = defaultdict(int)
        for passenger in selected_passengers:
            passenger_categories[passenger.category] += 1
        requests_ = [self._pricing_route_request(flight, passenger_categories) for flight in exchange_flights]
        responses = self._pricing_route(requests_)

        flight_variants: List[ExchangeFlightVariants] = []
        for response, flight in zip(responses, exchange_flights):
            if isinstance(response.error, BaseSirenaError):
                self._raise_not_options(flights=[flight])
            elif isinstance(response.error, Exception):
                self.logger.exception(response)
                raise BaseExchangeError()

            variants_data = response.data.get('variant', [])
            self.__filter_variants_by_flights(variants_data, flight)
            variants_data = self._filter_variants_by_datetime(variants_data, flight)
            if not variants_data:
                self._raise_not_options(flights=[flight])

            variants_data = sorted(variants_data, key=lambda item: time_to_seconds(item['segmentTransferTime']['text']))
            variants_data = variants_data[:PRICING_MAX_RESULTS]

            flight_variants.append(ExchangeFlightVariants(
                flight=flight,
                variants=[
                    ExchangeFlightVariant(
                        variant_id=idx,
                        segments=self.__parse_variant_segments(
                            variant_segments=v['flight'],
                            original_segments=flight.segments
                        ),
                    )
                    for idx, v in enumerate(variants_data)
                ]
            ))
        return flight_variants

    def __get_options(
        self,
        order: DomainOrder,
        flight_variants: List[ExchangeFlightVariants],
        selected_passengers: List[ExchangeablePassenger]
    ) -> List[ExchangeOption]:
        options: List[ExchangeOption] = []
        passengers = [ExchangePassenger(
            last_name=p.passenger.last_name,
            first_name=p.passenger.first_name,
            second_name=p.passenger.second_name,
        ) for p in selected_passengers]

        data_requests = []
        sirena_requests = []
        for option_idx, variant_combination in enumerate(product(*[fv.variants for fv in flight_variants])):
            exchange_segments: List[ExchangeSegments] = []
            exchange_variants: List[ExchangeVariant] = []
            original_flights: List[List[DomainSegment]] = []

            if not self._valid_variant_option(variant_combination):
                continue

            for idx, flight_variant in enumerate(variant_combination):
                flight = flight_variants[idx].flight

                if self._combinations_has_copy(
                    original_segments=flight.segments,
                    desired_segments=flight_variant.segments,
                ):
                    continue

                exchange_segments.extend(
                    ExchangeSegmentsMapper().run(
                        original_segments=flight.segments,
                        desired_segments=flight_variant.segments
                    )
                )
                exchange_variants.append(ExchangeVariant(
                    flight_id=flight.flight_id,
                    variant_id=flight_variant.variant_id
                ))
                original_flights.append(flight.segments)

            if not exchange_segments:
                continue

            self.logger.info(f'Requesting pricing for option {option_idx}')
            data_requests.append(dict(
                original_flights=original_flights,
                exchange_variants=exchange_variants,
                exchange_segments=exchange_segments,
            ))
            sirena_requests.append(
                ExchangePricingRequest(
                    rloc=order.data.rloc,
                    last_name=passengers[0].last_name,
                    payment_documents=PaymentDocument(form_pay='KI'),
                    passengers=passengers,
                    segments=exchange_segments,
                    involuntary=False,
                )
            )

        if not data_requests:
            self._raise_not_options(flights=[flight_variant.flight for flight_variant in flight_variants])

        responses = self._exchange_pricing(sirena_requests=sirena_requests)
        currency_rate: DomainCurrencyRates = self.currency_adapter.get_actual_currency_rates()
        for response, request_data in zip(responses, data_requests):
            original_flights = request_data['original_flights']
            exchange_variants = request_data['exchange_variants']
            exchange_segments = request_data['exchange_segments']
            if not response:
                if isinstance(response.error, BaseSirenaError):
                    original_route = ", ".join([
                        f'{o.airline}{o.flight_number} {o.flight_date.isoformat()}'
                        for s in exchange_segments for o in s.original
                    ])
                    desired_route = ", ".join([
                        f'{o.airline}{o.flight_number} {o.flight_date.isoformat()}'
                        for s in exchange_segments for o in s.desired
                    ])
                    self.logger.error(f'Option {original_route} -> {desired_route} unavailable')
                    continue
                elif isinstance(response.error, Exception):
                    self.logger.exception(response.error)
                    continue
            response_data = response.data
            if not response_data:
                self.logger.error('No exchange pricing')
                continue

            response: CalculatePriceResponse = CalculatePrice(
                order=order,
                original_flights=original_flights,
                exchange_pricing_response=response_data,
                currency_rate=currency_rate,
                mono_app_adapter=self.mono_app_adapter,
            ).run()
            self.logger.info(f'Price is  {response.exchange_price.amount} {response.exchange_price.currency}')
            options.append(ExchangeOption(variants=exchange_variants, price=response.exchange_price))

        if not options:
            self._raise_not_options(flights=[flight_variant.flight for flight_variant in flight_variants])

        return options

    def _combinations_has_copy(
        self,
        original_segments: List[DomainSegment],
        desired_segments: List[ExchangeVariantSegment]
    ):
        for o in original_segments:
            for d in desired_segments:
                if all([
                    o.flight_number == d.flight_number,
                    datetime.fromisoformat(o.departure_local_iso).date() == d.departure.local.date(),
                ]):
                    return True

        return False

    def _valid_variant_option(self, variant_combination):
        variant_segments: Dict[str, ExchangeVariantSegment] = {
            s.segment_id: s
            for v in variant_combination
            for s in v.segments
        }
        for segment_id, variant_segment in variant_segments.items():
            # Если сегмент варианта пересекается с предыдущим сегментом (выбранным или неизменным)
            prev_segment = self.segment_mapper.prev_segment.get(segment_id)
            if prev_segment:
                if prev_segment.segment_id in variant_segments:
                    prev_datetime = variant_segments[prev_segment.segment_id].arrival.local
                else:
                    prev_datetime = datetime.fromisoformat(prev_segment.arrival_local_iso)
                if (prev_datetime + timedelta(hours=1)) > variant_segment.departure.local:
                    return False

            # Если сегмент варианта пересекается со следующим сегментом (выбранным или неизменным)
            next_segment = self.segment_mapper.next_segment.get(segment_id)
            if next_segment:
                if next_segment.segment_id in variant_segments:
                    next_datetime = variant_segments[next_segment.segment_id].departure.local
                else:
                    next_datetime = datetime.fromisoformat(next_segment.departure_local_iso)
                # Обязательно соблюдаем интервал в час между сегментами
                if (variant_segment.arrival.local + timedelta(hours=1)) > next_datetime:
                    return False
        return True

    def __parse_variant_segments(
        self,
        variant_segments: List[dict],
        original_segments: List[DomainSegment]
    ) -> List[ExchangeVariantSegment]:
        variant_combiner = VariantDataCombiner(mono_app_adapter=self.mono_app_adapter)
        return [
            ExchangeVariantSegment(
                segment_id=original_segment.segment_id,
                airline=variant_segment['company'],
                flight_number=variant_segment['num'],
                departure=self.__build_segment_point(flight=variant_segment, code='origin'),
                arrival=self.__build_segment_point(flight=variant_segment, code='destination'),
                craft=variant_segment['airplane'],
                landings=variant_combiner.get_landings(variant_segment),
            )
            for variant_segment, original_segment in zip(variant_segments, original_segments)
        ]

    def __build_segment_point(self, flight: dict, code: str) -> ExchangeSegmentPoint:
        airport_code = flight[code]['text'] if isinstance(flight[code], dict) else flight[code]
        city = self.mono_app_adapter.extended_find_city_by_iata(iata_code=airport_code)
        airport = next((a for a in city.get('airports', []) if a['code'] == airport_code), {})

        self.cities[city.get('code')] = city.get('name_translations', {}).get(ALLOWED_COUNTRY.lower())
        self.airports[airport_code] = airport.get('name_translations', {}).get(ALLOWED_COUNTRY.lower())

        return ExchangeSegmentPoint(
            airport_code=airport_code,
            city_code=city.get('code'),
            local=parse_sirena_time(flight, PRICING_CODES_MAP[code], tz_code=city.get('time_zone')),
        )

    @classmethod
    def __get_exchange_flights(
        cls, exchangeable: List[ExchangeableFlight], selected: List[FlightExchangeData]
    ) -> List[ExchangeFlight]:
        exchangeable_segments: Dict[int, List[DomainSegment]] = {f.flight_id: f.segments for f in exchangeable}
        exchange_flights: List[ExchangeFlight] = []

        previous_transfer = None
        for flight_data in selected:
            transfer_from, segments, transfer_to = cls.__get_exchange_flight(
                exchangeable_segments[flight_data.flight_id], flight_data.segment_ids, flight_data.flight_date,
            )

            if previous_transfer and previous_transfer == segments[0]:
                raise InvalidTransferSegments()
            previous_transfer = transfer_to

            exchange_flights.append(ExchangeFlight(
                flight_id=flight_data.flight_id,
                segments=segments,
                transfer_from=transfer_from,
                transfer_to=transfer_to,
                flight_date=flight_data.flight_date,
                departure_city=flight_data.departure_city,
                arrival_city=flight_data.arrival_city
            ))

        return exchange_flights

    @staticmethod
    def __get_exchange_flight(
        exchangeable: List[DomainSegment], selected: List[str], select_flight_date: date,
    ) -> Tuple[Optional[DomainSegment], List[DomainSegment], Optional[DomainSegment]]:
        first_segment_idx = next((index for index, s in enumerate(exchangeable) if s.segment_id == selected[0]), None)
        if first_segment_idx is None:
            raise InvalidExchangeableSegmentError(selected[0])

        # Ошибка, если выбрано больше сегментов чем есть
        if len(selected[1:]) > len(exchangeable[first_segment_idx + 1:]):
            raise InvalidTransferSegments()

        segments: List[DomainSegment] = exchangeable[first_segment_idx:first_segment_idx + len(selected)]
        # Ошибка, если сегменты в некорректном порядке
        for idx, segment in enumerate(segments):
            if segment.segment_id != selected[idx]:
                raise InvalidTransferSegments()

        # Выбран для обмена сегмент не первый и дата предыдущего сегмента равна выбранному первому
        transfer_from = ExchangeOptionsUseCase._get_near_segment(
            near_segment_id=first_segment_idx - 1,
            exchangeable=exchangeable,
            select_flight_date=select_flight_date,
        )
        # Выбран для обмена сегмент не последний и дата следующего сегмента равна выбранному последнему
        transfer_to = ExchangeOptionsUseCase._get_near_segment(
            near_segment_id=first_segment_idx + len(segments),
            exchangeable=exchangeable,
            select_flight_date=select_flight_date,
        )
        return transfer_from, segments, transfer_to

    @staticmethod
    def _get_near_segment(near_segment_id: int, exchangeable: List[DomainSegment], select_flight_date: date):
        # Выбран первый сегмент
        if near_segment_id < 0:
            return
        # Выбран последний сегмент
        if near_segment_id >= len(exchangeable):
            return
        near_segment = exchangeable[near_segment_id]
        # Дата совпала с ближайшим сегментом, значит отправляем время границы
        if datetime.fromisoformat(near_segment.departure_local_iso).date() == select_flight_date:
            return near_segment

    def _filter_variants_by_datetime(self, variants_data, flight):
        filtered_variants_data = []
        for variant in variants_data:
            is_valid = True
            for f, origin_segment in zip(variant['flight'], flight.segments):
                # Проверяем пересечение с предыдущим сегментом, если он не выбран
                prev_segment = self.segment_mapper.prev_segment.get(origin_segment.segment_id)
                if prev_segment and prev_segment.segment_id not in self.segment_mapper.select_flight:
                    variant_departure_datetime = parse_sirena_bad_datetime(f["deptdate"]["text"], f['depttime'])
                    if self._is_cross_dates(
                        datetime.fromisoformat(prev_segment.departure_local_iso),
                        variant_departure_datetime,
                    ):
                        self.logger.info(f'Not valid variant for prev_segment: {origin_segment.segment_id}')
                        is_valid = False
                        continue
                # Проверяем пересечение со следующим сегментом, если он не выбран
                next_segment = self.segment_mapper.next_segment.get(origin_segment.segment_id)
                if next_segment and next_segment.segment_id not in self.segment_mapper.select_flight:
                    variant_arrival_datetime = parse_sirena_bad_datetime(f["arrvdate"]["text"], f['arrvtime'])
                    if self._is_cross_dates(
                        variant_arrival_datetime,
                        datetime.fromisoformat(next_segment.departure_local_iso),
                    ):
                        self.logger.info(f'Not valid variant for next_segment: {origin_segment.segment_id}')
                        is_valid = False
                        continue
            if is_valid:
                filtered_variants_data.append(variant)
        return filtered_variants_data

    @staticmethod
    def __filter_variants_by_flights(variants: List[dict], current_flight: ExchangeFlight) -> None:
        """
        Исключаем варианты где:
        - перелет = тому, что мы обмениваем
        - количество сегментов не совпадает todo: пока сирена не умеет обменивать 2 сегмента на 1
        """
        keys: Set[str] = {
            ':'.join(
                f'{datetime.fromisoformat(s.departure_local_iso).date()}{s.ak}{s.flight_number}'
                for s in current_flight.segments
            )
        }
        for idx in reversed(range(len(variants))):
            variant = variants[idx]
            key = ":".join(
                [
                    f'{parse_sirena_bad_date(f["deptdate"]["text"])}{f["company"]}{f["num"]}'
                    for f in variant['flight']
                ]
            )
            if key in keys or len(variant['flight']) != len(current_flight.segments):
                del variants[idx]
                continue
            keys.add(key)

    def _is_cross_dates(self, date_1: datetime, date_2: datetime):
        """
        Пересечение дат сегментов
        """
        date_1 = date_1.replace(tzinfo=timezone.utc)
        date_2 = date_2.replace(tzinfo=timezone.utc)
        return date_1 > date_2

    def __get_available_variants(
        self, flight_variants: List[ExchangeFlightVariants], options: List[ExchangeOption]
    ) -> List[ExchangeFlightVariants]:
        available: List[ExchangeFlightVariants] = []

        valid_variants = set(
            (variant.flight_id, variant.variant_id)
            for option in options
            for variant in option.variants
        )

        for flight_variant in flight_variants:
            available_variants: List[ExchangeFlightVariant] = [
                variant
                for variant in flight_variant.variants
                if (flight_variant.flight.flight_id, variant.variant_id) in valid_variants
            ]
            if not available_variants:
                self._raise_not_options(flights=[flight_variant.flight])
            available.append(ExchangeFlightVariants(
                flight=flight_variant.flight,
                variants=available_variants
            ))

        return available

    def _raise_not_options(self, flights: List[ExchangeFlight]):
        raise NoExchangeOptions(
            data=dict(
                error_flights=[
                    DomainFlightOptionError(
                        flight_id=str(flight.flight_id),
                        flight_date=flight.flight_date,
                        departure=flight.departure_city,
                        arrival=flight.arrival_city,
                    ).serialize()
                    for flight in flights
                ]
            )
        )

    def _check_exists_exchange(self, order: DomainOrder):
        existing_exchanges: List[DomainExchange] = self.exchange_repo.list(
            spec=ExchangeQueryBuilder.get_exchange_by_order_uuid(order.data.order_uuid),
            sort=[('_id', -1)]
        )
        if not existing_exchanges:
            return None
        return CheckExistsExchanges(
            existing_exchanges=existing_exchanges,
            cancel_exchange_callback=ExternalExchangeOrderAdapter().cancel_order_exchange,
        ).run()

    def _exchange_pricing(self, sirena_requests: List[ExchangePricingRequest]) -> List[ResponseModelABC]:
        """
        Вынесено для тестов
        """
        return self.sirena_adapter.send_batch_request(sirena_requests)

    def _pricing_route(self, sirena_requests: List[GetPricingRoute]) -> List[ResponseModelABC]:
        """
        Вынесено для тестов
        """
        return self.sirena_adapter.send_batch_request(sirena_requests)

    def _pricing_route_request(
        self,
        flight: ExchangeFlight,
        categories: Dict[PassengerCategory, int]
    ) -> GetPricingRoute:
        segment = PricingRouteSegment(
            departure=flight.departure_city,
            arrival=flight.arrival_city,
            departure_date=flight.flight_date,
            company=flight.segments[0].ak,
            service_class=flight.segments[0].class_,
            time_from=flight.transfer_from.arrival_timestamp if flight.transfer_from else None,
            time_till=flight.transfer_to.departure_timestamp if flight.transfer_to else None,
            # Рейс без стыковок. То ищем прямые
            direct=len(flight.segments) == 1,
        )
        passengers = [
            Passenger(
                code=SIRENA_CATEGORY_MAPPING[category],
                age=CATEGORY_AGES[category],
                count=str(count),
            )
            for category, count in categories.items()
        ]
        return GetPricingRoute(
            segments=[segment],
            passengers=passengers,
            special_services=dict(ssrs=dict(ssr=[])),
            request_params=RequestParams(
                fingering_order='differentFlightsCombFirst',
                max_results=PRICING_SIRENA_MAX_RESULTS,
                mix_scls=True,
                mix_ac=False,
            ),
            answer_params=AnswerParams(show_flighttime=True, show_available=True),
        )
