from datetime import date, datetime
from typing import NamedTuple, List, Optional, Dict

from domain.order.data import DomainSegment

from use_cases.orders.exchange.shared.types import ExchangeVariantSegmentLanding


class ExchangeFlight(NamedTuple):
    flight_id: int
    segments: List[DomainSegment]
    transfer_from: Optional[DomainSegment]
    transfer_to: Optional[DomainSegment]
    flight_date: date
    departure_city: str
    arrival_city: str


class ExchangeSegmentPoint(NamedTuple):
    airport_code: str
    city_code: str
    local: datetime


class ExchangeVariantSegment(NamedTuple):
    segment_id: str
    airline: str
    flight_number: str
    departure: ExchangeSegmentPoint
    arrival: ExchangeSegmentPoint
    craft: str
    landings: List[ExchangeVariantSegmentLanding]


class ExchangeFlightVariant(NamedTuple):
    variant_id: int
    segments: List[ExchangeVariantSegment]


class ExchangeFlightVariants(NamedTuple):
    flight: ExchangeFlight
    variants: List[ExchangeFlightVariant]


class SegmentMapper(NamedTuple):
    select_flight: Dict[str, ExchangeFlight]
    next_segment: Dict[str, DomainSegment]
    prev_segment: Dict[str, DomainSegment]
