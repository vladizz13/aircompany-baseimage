from uuid import UUID
from typing import Union, Optional

from mcs_payments_client import MoneyPaymentMeta
from mcs_payments_client.payment_types import State as PaymentState

from base.use_case import BaseUseCaseRequest

from base.exception import ApplicationError


class ExchangePaymentRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]
    transaction_uuid: Union[str, UUID]
    state: PaymentState

    def __init__(
        self,
        exchange_uuid: Union[str, UUID],
        transaction_uuid: Union[str, UUID],
        state: PaymentState,
        meta: Optional[MoneyPaymentMeta] = None
    ):
        super().__init__()
        self.exchange_uuid = exchange_uuid
        self.transaction_uuid = transaction_uuid
        self.state = state
        self.meta = meta

    def is_valid(self, *args, **kwargs) -> 'ExchangePaymentRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))

        try:
            UUID(str(self.transaction_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid transaction uuid"))

        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
            'transaction_uuid': self.transaction_uuid,
            'state': self.state.value,
            'meta': self.meta.serialize() if self.meta else None,
        }

    @classmethod
    def deserialize(cls, data: dict) -> 'ExchangePaymentRequest':
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
            transaction_uuid=data.get('transaction_uuid'),
            state=PaymentState(data.get('state')),
            meta=MoneyPaymentMeta.deserialize(data['meta']) if data.get('meta') else None,
        )
