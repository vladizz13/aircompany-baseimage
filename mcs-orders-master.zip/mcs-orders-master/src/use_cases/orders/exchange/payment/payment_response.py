from domain.exchange import DomainExchange

from base.use_case import BaseUseCaseResponse


class ExchangePaymentResponse(BaseUseCaseResponse):
    def __init__(self, exchange: DomainExchange):
        super().__init__(self.serialize(exchange))

    @classmethod
    def serialize(cls, exchange: DomainExchange) -> dict:
        return exchange.serialize()
