import time
from uuid import UUID
from typing import List, Dict, Optional, Union

from mcs_payments_client import MoneyPaymentMeta
from sirena_xml_client.types import ExchangePassenger, PaymentDocument, PaymentCost
from mcs_payments_client.payment_types import State as PaymentState
from utair.clients.external.sirena.requests.common import ExchangeSegments

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

from domain import DomainOrder
from domain.exchange import (
    DomainExchange, DomainExchangeFlight, DomainExchangePrice, DomainExchangePaymentMeta, DomainExchangeOrder,
    DomainSSRRequest,
)
from domain.receipts_data import DomainReceiptsData
from domain.order.data import DomainSegment
from domain.types import ExchangeStatus, ExchangeOrderState
from libs.messages.telegram import TelegramMessenger

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_exchange_order_adapter import InternalExchangeOrderAdapter
from rest.interfaces.internal_order_adapter import InternalOrderAdapter

from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase
from use_cases.orders.exchange.shared.types import ExchangeableFlight, ExchangeablePassenger
from use_cases.orders.exchange.shared.consts import PROVIDER_CODE

from .payment_request import ExchangePaymentRequest
from .payment_response import ExchangePaymentResponse

from use_cases.orders.exceptions.exchange import (
    CouponNormalizationError, InconsistentPassengersAfterExchange,
    InconsistentSegmentsAfterExchange, AlreadyDividedError, UnexpectedPriceError, UnexpectedTransactionError,
    UnexpectedPaymentStateError, InvalidExchangeStatus, UnexpectedPaymentDataError
)
from sirena_xml_client.exceptions import SirenaPnrBusyError, SirenaInterchangeNotFinished, SirenaEdifactMessageTimedOut

from use_cases.orders.exchange.shared.cancel_exchange import CancelExchangeService
from use_cases.orders.exchange.shared.mappers.exchange_segments import ExchangeSegmentsMapper
from use_cases.orders.exchange.shared.replace_ssr import ReplaceSSR


class ExchangePaymentUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    """
    Обновление статуса платежа
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        exchange_repo: GenericMongoRepository,
        internal_order_adapter: InternalOrderAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
        internal_payments_adapter: PaymentsInternalAdapter,
        internal_exchange_order_adapter: InternalExchangeOrderAdapter,
        messenger: Optional[TelegramMessenger] = None,

    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.internal_exchange_order_adapter = internal_exchange_order_adapter

    def __execute__(self, request: ExchangePaymentRequest, *args, **kwargs) -> ExchangePaymentResponse:
        self.logger.info(f'Starting payment processing for {request.exchange_uuid} exchange')

        exchange = self._get_exchange(request.exchange_uuid)

        try:
            self.__process_payment(exchange, request.transaction_uuid, request.state, request.meta)
        except Exception as ex:
            self.logger.exception(ex)
            raise

        return ExchangePaymentResponse(exchange=exchange)

    def __process_payment(
        self,
        exchange: DomainExchange,
        transaction_uuid: Union[str, UUID],
        state: PaymentState, meta: Optional[MoneyPaymentMeta]
    ) -> None:
        if exchange.payment.state == state.value:
            return

        self.logger.info(
            f'Processing {exchange.exchange_uuid}({exchange.status}) payment: {exchange.payment.state} -> {state.value}'
        )

        if exchange.payment.transaction != str(transaction_uuid):
            raise UnexpectedTransactionError()

        prev_status = exchange.payment.state
        exchange.payment.state = state.value
        self._update_exchange(exchange)

        if state == PaymentState.ARCHIVED:
            pass
        elif state == PaymentState.CONFIRMED:
            self._process_payment_confirmed(exchange=exchange)
        elif state == PaymentState.HELD:
            try:
                self.__do_exchange(exchange, meta)
            except Exception as ex:
                self.logger.exception(ex)
                self.__handle_exception(exchange, ex)
        elif state == PaymentState.CANCELLED:
            self.__cancel_exchange(exchange, ExchangeStatus.CANCELED)
            self._update_exchange(exchange)
        elif state == PaymentState.EXPIRED and prev_status == PaymentState.HELD.value:
            if exchange.status in [ExchangeStatus.COMPLETE, ExchangeStatus.WAIT_RECEIPT, ExchangeStatus.PROCESSING]:
                self.internal_exchange_order_adapter.send_error_payment_expired(
                    exchange_uuid=exchange.exchange_uuid,
                    data=dict(
                        prev_status=exchange.status.value,
                        current_status=ExchangeStatus.ERROR.value,
                    )
                )
                self._set_status(exchange, ExchangeStatus.ERROR)
            else:
                self._set_status(exchange, ExchangeStatus.EXPIRED)
            self._update_exchange(exchange)
        elif state == PaymentState.EXPIRED:
            self.__cancel_exchange(exchange, ExchangeStatus.EXPIRED)
            self._update_exchange(exchange)
        else:
            raise UnexpectedPaymentStateError()

    def _process_payment_confirmed(self, exchange: DomainExchange):
        """
        Если от АПШ получили CONFIRMED, а обмен оказался зависшим (в случаях ручного вмешательства)
        """
        if exchange.status == ExchangeStatus.PROCESSING:
            self.internal_exchange_order_adapter.exchange_clear_segments(exchange_uuid=exchange.exchange_uuid)
        if not exchange.status.is_complete():
            self._set_status(exchange, ExchangeStatus.COMPLETE)
            self._update_exchange(exchange)

    def __do_exchange(self, exchange: DomainExchange, meta: Optional[MoneyPaymentMeta]):
        if not exchange.status == ExchangeStatus.PENDING:
            raise InvalidExchangeStatus()

        if not meta:
            raise UnexpectedPaymentDataError()

        self.logger.info(f'Pricing {exchange.exchange_uuid} exchange ...')
        order = self._get_order(order_uuid=exchange.order_uuid, update_existing=False)
        exchangeable_flights = self._get_exchangeable_flights(order)
        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)
        selected_passengers, left_passengers = self._get_selected_passengers(
            exchangeable_passengers, exchange.passengers
        )
        exchange_segments = self.__get_exchange_segments(exchangeable_flights, exchange.flights)
        exchange_pricing_response = self.__sirena_pricing(
            order=order,
            passengers=selected_passengers,
            exchange_segments=exchange_segments,
        )
        self.logger.info(f'Starting {exchange.exchange_uuid} exchange processing...')
        exchange.old_receipts_data = self._get_receipts_data(order=order)

        self._set_status(exchange, ExchangeStatus.PROCESSING)
        exchange.payment.meta = DomainExchangePaymentMeta(
            provider_code=PROVIDER_CODE,
            first_six=meta.first_six,
            last_four=meta.last_four,
            auth_code=meta.auth_code,
            acquiring_bank=meta.acquiring_bank.value,
        )

        self._update_exchange(exchange)

        self.__normalize_coupons(order, exchange)
        if left_passengers:
            if exchange.divided_order_uuid:
                raise AlreadyDividedError()
            # Запоминаем ssr которые необходимо перенести после сплита
            ssr_requests: Optional[List[DomainSSRRequest]] = ReplaceSSR(
                order=order,
                exchange=exchange,
                ssr_type='FQTV',
                logger=self.logger,
                segment_status_visual='active',
            ).run()
            order = self._split_order(order, selected_passengers)
            old_exchangeable_flights = exchangeable_flights
            exchangeable_flights = self._get_exchangeable_flights(order)
            exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)

            self.__validate_passengers(exchangeable_passengers, selected_passengers)
            selected_passengers, left_passengers = exchangeable_passengers, []

            self.__update_exchange_after_split(
                exchange=exchange,
                ssr_requests=ssr_requests,
                order=order,
                passengers=selected_passengers,
                flights=self.__rebuild_exchange_flights(
                    old_exchangeable_flights=old_exchangeable_flights,
                    old_flights=exchange.flights,
                    new_exchangeable_flights=exchangeable_flights,
                )
            )

        start_exchange_response = self.__sirena_exchange_start(
            order, exchange, selected_passengers, exchange_segments
        )
        self.__sirena_exchange_confirm(
            exchange=exchange,
            order=order,
            passengers=selected_passengers,
            start_exchange_response=start_exchange_response,
        )
        exchange.order.state = ExchangeOrderState.CONFIRMED
        self._set_status(exchange, ExchangeStatus.WAIT_RECEIPT)
        self._update_exchange(exchange)

        self.internal_exchange_order_adapter.exchange_clear_segments(exchange_uuid=exchange.exchange_uuid)
        from rest.applications.celery_app.tasks.exchange import wait_emd_fast_task
        wait_emd_fast_task.delay(
            exchange_uuid=exchange.exchange_uuid,
            exchange_pricing_response=exchange_pricing_response,
        )

    def __normalize_coupons(self, order: DomainOrder, exchange: DomainExchange) -> None:
        normalized_coupons = self._normalize_coupons(
            order=order,
            passenger_ids=exchange.passengers,
            segment_ids=[s_id for f in exchange.flights for s_id in f.segments]
        )

        if normalized_coupons:
            exchange.normalized_coupons = normalized_coupons
            self._update_exchange(exchange)
            if not all([n['success'] for n in normalized_coupons]):
                raise CouponNormalizationError()

    def __update_exchange_after_split(
        self,
        exchange: DomainExchange,
        order: DomainOrder,
        passengers: List[ExchangeablePassenger],
        flights: List[DomainExchangeFlight],
        ssr_requests: Optional[List[DomainSSRRequest]],
    ) -> None:
        exchange.divided_order_uuid = exchange.order_uuid
        exchange.order_uuid = order.data.order_uuid
        exchange.passengers = [p.passenger.passenger_id for p in passengers]
        exchange.flights = flights
        exchange.ssr_requests = ssr_requests
        self._update_exchange(exchange)

    def __sirena_exchange_start(
        self,
        order: DomainOrder,
        exchange: DomainExchange,
        passengers: List[ExchangeablePassenger],
        segments: List[ExchangeSegments],
    ) -> dict:

        self.logger.info(f'Starting AUTO exchange for {exchange.exchange_uuid}')
        start_exchange_response = self.internal_sirena_adapter.start_exchange(
            rloc=order.data.rloc,
            passengers=[ExchangePassenger(
                last_name=p.passenger.last_name,
                first_name=p.passenger.first_name,
                second_name=p.passenger.second_name,
            ) for p in passengers],
            segments=segments,
            payment=PaymentDocument(
                payment_form='KI',
                payment_type=PROVIDER_CODE,
                payment_number=exchange.payment.number,
                auth_code=exchange.payment.meta.auth_code,
            )
        )
        exchange.order = DomainExchangeOrder(
            locator=order.data.rloc,
            surname=passengers[0].passenger.last_name,
            state=ExchangeOrderState.STARTED,
        )
        self._update_exchange(exchange)
        return start_exchange_response

    def __cancel_exchange(self, exchange: DomainExchange, status: ExchangeStatus) -> bool:
        try:
            canceled = CancelExchangeService(
                exchange=exchange,
                internal_sirena_adapter=self.internal_sirena_adapter,
                internal_payments_adapter=self.internal_payments_adapter,
                messenger=self.messenger,
            ).run()
        except Exception as ex:
            self.logger.exception(ex)
            canceled = False
        self._set_status(exchange, status)
        return canceled

    def __handle_exception(self, exchange: DomainExchange, error: Exception) -> None:
        try:
            self.__cancel_exchange(exchange, ExchangeStatus.ERROR)
        except Exception as ex:
            self.logger.exception(ex)

        self._set_status(exchange, ExchangeStatus.ERROR)
        exchange.set_error(error)
        self._update_exchange(exchange)

        raise error

    @classmethod
    def __rebuild_exchange_flights(
        cls,
        old_exchangeable_flights: List[ExchangeableFlight],
        old_flights: List[DomainExchangeFlight],
        new_exchangeable_flights: List[ExchangeableFlight],
    ) -> List[DomainExchangeFlight]:
        mapped_old_exchangeable_flights = {f.flight_id: f for f in old_exchangeable_flights}
        new_flights: List[DomainExchangeFlight] = []

        for old_flight in old_flights:
            new_flights.append(cls.__get_new_exchange_flight(
                old_flight=old_flight,
                old_exchangeable_flight=mapped_old_exchangeable_flights[old_flight.flight_id],
                new_exchangeable_flights=new_exchangeable_flights
            ))

        return new_flights

    @staticmethod
    def __validate_passengers(new: List[ExchangeablePassenger], old: List[ExchangeablePassenger]) -> None:
        if len(new) != len(old):
            raise InconsistentPassengersAfterExchange()

        old_passengers = [p.passenger for p in old]
        for passenger in new:
            if passenger.passenger not in old_passengers:
                raise InconsistentPassengersAfterExchange()

    @staticmethod
    def __get_new_exchange_flight(
        old_flight: DomainExchangeFlight,
        old_exchangeable_flight: ExchangeableFlight,
        new_exchangeable_flights: List[ExchangeableFlight]
    ) -> DomainExchangeFlight:
        new_flight: Optional[ExchangeableFlight] = None

        for flight in new_exchangeable_flights:
            if flight.segments == old_exchangeable_flight.segments:
                new_flight = flight
                break

        if not new_flight:
            raise InconsistentSegmentsAfterExchange()

        new_segments: List[str] = []
        mapped_old_segments = {s.segment_id: s for s in old_exchangeable_flight.segments}
        for old_segment_id in old_flight.segments:
            new_segment: Optional[DomainSegment] = None

            for segment in new_flight.segments:
                if segment == mapped_old_segments[old_segment_id]:
                    new_segment = segment
                    break

            if not new_segment:
                raise InconsistentSegmentsAfterExchange()

            new_segments.append(new_segment.segment_id)

        return DomainExchangeFlight(
            flight_id=new_flight.flight_id,
            segments=new_segments,
            exchange=old_flight.exchange
        )

    @staticmethod
    def __get_exchange_segments(
            exchangeable_flights: List[ExchangeableFlight], flights: List[DomainExchangeFlight]
    ) -> List[ExchangeSegments]:
        exchange_segments: List[ExchangeSegments] = []
        mapped_exchangeable: Dict[int, ExchangeableFlight] = {
            f.flight_id: f for f in exchangeable_flights
        }
        for flight in flights:
            exchangeable_flight: ExchangeableFlight = mapped_exchangeable[flight.flight_id]
            # это видимо, чтобы порядок соблюсти
            flight_segments: dict[str, DomainSegment] = {s.segment_id: s for s in exchangeable_flight.segments}
            original_segments = [flight_segments[s_id] for s_id in flight.segments]
            exchange_segments.extend(
                ExchangeSegmentsMapper(is_desired_subclass=True).run(
                    original_segments=original_segments,
                    desired_segments=flight.exchange,
                )
            )
        return exchange_segments

    def __sirena_exchange_confirm(self, exchange, order, passengers, start_exchange_response) -> dict:
        price = DomainExchangePrice(
            amount=float(start_exchange_response['cost']['text']),
            currency=start_exchange_response['cost']['@curr'],
        )
        # Если цена изменилась в меньшую сторону, мы можем дельту вернуть клиенту
        if price > exchange.price:
            raise UnexpectedPriceError()
        exchange.price = price

        if not exchange.payment.meta:
            raise UnexpectedPaymentStateError()

        # Бывают случаи когда не с первого раза сирена может принять подтверждение(
        for attempt in range(10):
            self.logger.info(f'Confirming exchange for {exchange.exchange_uuid} (attempt:{attempt})')
            try:
                return self.internal_sirena_adapter.confirm_exchange(
                    rloc=order.data.rloc,
                    last_name=passengers[0].passenger.last_name,
                    cost=PaymentCost(
                        currency=price.currency,
                        amount=f'{price.amount:.2f}',
                    ),
                    payment=PaymentDocument(
                        payment_form='KI',
                        payment_type=PROVIDER_CODE,
                        payment_number=exchange.payment.number,
                        auth_code=exchange.payment.meta.auth_code,
                    )
                )
            except (SirenaPnrBusyError, SirenaInterchangeNotFinished, SirenaEdifactMessageTimedOut):
                time.sleep(3)
                continue

    def __sirena_pricing(
            self,
            order: DomainOrder,
            passengers: List[ExchangeablePassenger],
            exchange_segments: List[ExchangeSegments]
    ):
        return self.internal_sirena_adapter.exchange_pricing(
            rloc=order.data.rloc,
            passengers=[ExchangePassenger(
                last_name=p.passenger.last_name,
                first_name=p.passenger.first_name,
                second_name=p.passenger.second_name,
            ) for p in passengers],
            segments=exchange_segments,
        )

    def _get_receipts_data(self, order: DomainOrder) -> DomainReceiptsData:
        try:
            response = self.internal_sirena_adapter.get_receipts_data(
                rloc=order.data.rloc,
                last_name=order.data.passengers[0].last_name,
            )
            return DomainReceiptsData.deserialize_by_raw(raw=response)
        except Exception as ex:
            self.logger.info(f'Error save old_receipts_data ({ex})')
