import logging
from uuid import UUID
from typing import Union, Optional

from mcs_payments_client import RequestFlight, RequestSegment

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from base.use_case import BaseUseCaseRequest, BaseUseCaseResponse

from base.exception import ApplicationError
from domain import DomainOrder
from domain.exchange import DomainExchange
from domain.types import ExchangeStatus
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_exchange_order_adapter import InternalExchangeOrderAdapter
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.exceptions.exchange import MCSPaymentConfirmError
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase
from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.sale_parts import to_list
from mcs_payments_client.payment_types import State as PaymentState


class ExchangePaymentConfirmRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]

    def __init__(
            self,
            exchange_uuid: Union[str, UUID],
            exchange_pricing_response: dict,
    ):
        super().__init__()
        self.exchange_uuid = exchange_uuid
        self.exchange_pricing_response = exchange_pricing_response

    def is_valid(self, *args, **kwargs) -> 'ExchangePaymentConfirmRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
            'exchange_pricing_response': self.exchange_pricing_response,
        }

    @classmethod
    def deserialize(cls, data: dict) -> 'ExchangePaymentConfirmRequest':
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
            exchange_pricing_response=data.get('exchange_pricing_response'),
        )


class ExchangePaymentConfirmResponse(BaseUseCaseResponse):
    def __init__(self, exchange: DomainExchange):
        super().__init__(self.serialize(exchange))

    @classmethod
    def serialize(cls, exchange: DomainExchange) -> dict:
        return exchange.serialize()


class ExchangePaymentConfirmUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    def __init__(
            self,
            order_repo: GenericMongoRepository,
            exchange_repo: GenericMongoRepository,
            internal_order_adapter: InternalOrderAdapter,
            internal_sirena_adapter: SirenaInternalAdapter,
            internal_payments_adapter: PaymentsInternalAdapter,
            messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.logger = logging.getLogger('exchange_logger')

    def __execute__(self, request: ExchangePaymentConfirmRequest, *args, **kwargs) -> ExchangePaymentConfirmResponse:
        self.logger.info(f'ExchangePaymentConfirmUseCase for {request.exchange_uuid} exchange')
        exchange = self._get_exchange(request.exchange_uuid)
        if self._is_skip_flow(exchange=exchange):
            return ExchangePaymentConfirmResponse(exchange=exchange)
        order = self._get_order(str(exchange.order_uuid), update_existing=False)
        exchange_pricing_response = request.exchange_pricing_response
        try:
            self._payments_confirm(
                order=order,
                exchange=exchange,
                exchange_pricing_response=exchange_pricing_response,
            )
        except Exception as ex:
            self.logger.exception(str(ex))
            raise MCSPaymentConfirmError()

        if exchange.status == ExchangeStatus.PROCESSING:
            InternalExchangeOrderAdapter.exchange_clear_segments(exchange_uuid=exchange.exchange_uuid)
        self._set_status(exchange, ExchangeStatus.COMPLETE)
        self._update_exchange(exchange)

        return ExchangePaymentConfirmResponse(exchange=exchange)

    def _is_skip_flow(self, exchange: DomainExchange) -> bool:
        if exchange.status not in [exchange.status.WAIT_RECEIPT, exchange.status.PROCESSING]:
            return True
        if exchange.payment.state != PaymentState.HELD.value:
            return True
        return False

    def _get_point(self, seg: dict, direction: str):
        # TODO: Временный фикс, в последствии при сериализации ответа от сирены останется строка
        value = seg.get(direction)
        if isinstance(value, str):
            return value

        return value.get('text')

    def _payments_confirm(
            self,
            order: DomainOrder,
            exchange: DomainExchange,
            exchange_pricing_response: dict,
    ):
        self.logger.info(f'Payment confirm {exchange.exchange_uuid}')
        segments = []
        for seg_dict in to_list(exchange_pricing_response['segments']['segment']):
            for seg in to_list(seg_dict['desired']):
                segments.append(RequestSegment(
                    departure_point=self._get_point(seg, 'departure'),
                    departure_country='RU',
                    arrival_point=self._get_point(seg, 'arrival'),
                    arrival_country='RU',
                ))
        flight_rloc = order.data.rloc.split('/')[0]
        self.internal_payments_adapter.confirm(
            uuid=exchange.payment.transaction,
            sale_parts=exchange.payment.sale_parts,
            exchange_income_parts=exchange.payment.exchange_income_parts,
            exchange_refund_parts=exchange.payment.exchange_refund_parts,
            flight=RequestFlight(
                rloc=flight_rloc,
                segments=segments
            ),
            request_id=UUID(exchange.payment.confirm_request_id),
        )
