from abc import ABCMeta, abstractmethod
from typing import Optional

from domain import DomainOrder
from domain.exchange import DomainExchange


class MessageGeneratorBase(metaclass=ABCMeta):

    def __init__(self, exchange: DomainExchange, order: DomainOrder, data: Optional[dict] = None) -> None:
        super().__init__()
        self.exchange = exchange
        self.order = order
        self.data = data or {}

    @abstractmethod
    def generate_msg(self) -> str:
        raise NotImplementedError()

    def _get_invoice_id(self):
        return self.exchange.payment.invoice if self.exchange.payment else 'Not found'

    def _get_last_name(self):
        return self.order.data.passengers[0].last_name


class SendErrorWaitEMDMessageGenerator(MessageGeneratorBase):

    def generate_msg(self) -> str:
        return f"""
Ошибка обмена: не удалось получить EMD на штраф/таксу или новые билеты
Заказ {self.order.data.rloc} {self._get_last_name()}
Обмен {self.exchange.exchange_uuid}
Платеж {self._get_invoice_id()}
        """


class SendErrorPaymentConfirmMessageGenerator(MessageGeneratorBase):

    def generate_msg(self) -> str:
        return f"""
Ошибка обмена: не удается подтвердить платеж
Заказ {self.order.data.rloc} {self._get_last_name()}
Обмен {self.exchange.exchange_uuid}
Платеж {self._get_invoice_id()}
        """


class SendErrorPaymentExpiredMessageGenerator(MessageGeneratorBase):

    def generate_msg(self) -> str:
        return f"""
Обмен выполнен, но деньги вернулись плательщику
Заказ {self.order.data.rloc} {self._get_last_name()}
Обмен {self.exchange.exchange_uuid}, статус {self.data.get('prev_status')}->{self.data.get('current_status')}
Платеж {self._get_invoice_id()}
        """


class SendWarningVoidRequiredGenerator:
    __exchange: DomainExchange

    def __init__(self, exchange: DomainExchange):
        self.__exchange = exchange

    def __generate_order(self) -> str:
        order = self.__exchange.order

        if not order:
            return "???"

        return f'<a href="https://admin.utair.io/orders/list/{self.__exchange.order_uuid}">{order.locator}</a>'

    def __generate_exchange(self) -> str:
        exchange_uuid = self.__exchange.exchange_uuid

        return f'<a href="https://admin.utair.io/orders/exchanges/{exchange_uuid}">{exchange_uuid}</a>'

    def __generate_payment(self) -> str:
        payment = self.__exchange.payment

        if not payment:
            return "???"

        return f'<a href=" https://admin.utair.io/payments/{payment.transaction}">{payment.invoice}</a>'

    def generate_msg(self) -> str:
        return f"""
Попытка <b>отмены оплаты</b> обмена
Заказ {self.__generate_order()}
Обмен {self.__generate_exchange()}
Платеж {self.__generate_payment()}
        """
