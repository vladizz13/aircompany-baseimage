from typing import Union
from uuid import UUID

from base.exception import ApplicationError
from base.use_case import BaseUseCaseRequest


class ExchangeSendErrorRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]
    data: dict

    def __init__(
        self,
        exchange_uuid: Union[str, UUID],
        data: dict,
    ):
        super().__init__()
        self.exchange_uuid = exchange_uuid
        self.data = data

    def is_valid(self, *args, **kwargs) -> 'ExchangeSendErrorRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
            'data': self.data,
        }

    @classmethod
    def deserialize(cls, data: dict) -> 'ExchangeSendErrorRequest':
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
            data=data.get('data'),
        )
