from typing import Type
from logging import getLogger

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from base.use_case import BaseUseCase, BaseUseCaseResponse

from domain import DomainOrder
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders import OrdersQueryBuilder
from repositories.query_builders.exchange import ExchangeQueryBuilder
from use_cases.orders.exceptions.exchange import ExchangeNotFound

from use_cases.orders.exchange.send_telegram.message_generators import MessageGeneratorBase
from use_cases.orders.exchange.send_telegram.request import ExchangeSendErrorRequest


class ExchangeSendErrorUseCase(BaseUseCase):
    __messenger: TelegramMessenger
    __exchange_repo: GenericMongoRepository
    __order_repo: GenericMongoRepository
    __internal_payments_adapter: PaymentsInternalAdapter
    __message_generator: Type[MessageGeneratorBase]

    def __init__(
        self,
        messenger: TelegramMessenger,
        exchange_repo: GenericMongoRepository,
        order_repo: GenericMongoRepository,
        message_generator: Type[MessageGeneratorBase],
    ):
        self.__messenger = messenger
        self.__exchange_repo = exchange_repo
        self.__order_repo = order_repo
        self.__message_generator = message_generator
        self.__logger = getLogger("exchange_logger")

    def __execute__(self, request: ExchangeSendErrorRequest, *args, **kwargs) -> BaseUseCaseResponse:
        exchange = self.__exchange_repo.get_single(
            spec=ExchangeQueryBuilder.get_exchange_by_uuid(str(request.exchange_uuid))
        )

        if not exchange:
            raise ExchangeNotFound()

        order: DomainOrder = self.__order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(exchange.order_uuid)
        )

        self.__logger.info(
            f'SendErrorWaitEMDUseCase for {exchange.order_uuid} order (chat:{self.__messenger.chat_id})'
        )

        message = self.__message_generator(exchange=exchange, order=order, data=request.data).generate_msg()
        self.__messenger.send_message(message=message)
        return BaseUseCaseResponse(value=dict(result=True))
