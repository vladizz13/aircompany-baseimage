from typing import Optional

from domain.types import ExchangeOrderState
from mcs_payments_client.payment_types import State as PaymentState

from libs.messages.telegram import TelegramMessenger
from use_cases.orders.exchange.send_telegram.message_generators import SendWarningVoidRequiredGenerator


class CancelExchangeService:
    """
    Отмена обмена в сирене и в платежном шлюзе
    """
    __messenger: Optional[TelegramMessenger]

    def __init__(
        self,
        exchange,
        internal_sirena_adapter,
        internal_payments_adapter,
        messenger: Optional[TelegramMessenger] = None,
    ) -> None:
        super().__init__()
        self.exchange = exchange
        self.internal_sirena_adapter = internal_sirena_adapter
        self.internal_payments_adapter = internal_payments_adapter
        self.__messenger = messenger

    def run(self) -> bool:
        if self.exchange.status.is_terminal():
            return True

        if not self.__cancel_sirena():
            return False

        return self.__cancel_payment()

    def __cancel_sirena(self) -> bool:
        if not self.exchange.order:
            return True

        if self.exchange.order.state == ExchangeOrderState.CANCELED:
            return True

        if self.exchange.order.state == ExchangeOrderState.STARTED:
            self.internal_sirena_adapter.cancel_exchange(
                rloc=self.exchange.order.locator,
                last_name=self.exchange.order.surname,
            )
            self.exchange.order.state = ExchangeOrderState.CANCELED
            return True

        return False

    def __cancel_payment(self) -> bool:
        if not self.exchange.payment:
            return True

        if self.exchange.payment.state == PaymentState.HELD.value:
            self.__void_payment()

            return True

        return False

    def __void_payment(self) -> None:
        # TODO: Allow Payment Void
        # self.internal_payments_adapter.void(uuid=self.exchange.payment.transaction)

        if self.__messenger:
            self.__messenger.send_message(
                SendWarningVoidRequiredGenerator(exchange=self.exchange).generate_msg()
            )
