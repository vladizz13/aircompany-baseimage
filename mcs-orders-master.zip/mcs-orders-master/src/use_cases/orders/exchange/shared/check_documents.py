from typing import Dict

from domain.order.data import DomainPassenger
from domain.receipts_data import DomainReceiptsData


class CheckDocuments:
    """
    Проверка наличия всех документов
    """
    def __init__(
            self,
            receipts_data: DomainReceiptsData,
            pax_by_ticket_mapper: Dict[str, DomainPassenger],
            exchange_passenger_ids: list[str]
    ) -> None:
        super().__init__()
        self.receipts_data = receipts_data
        self.pax_by_ticket_mapper = pax_by_ticket_mapper
        self.exchange_passenger_ids = exchange_passenger_ids

    def run(self):
        paxes_infants = set()
        paxes_with_new_tickets = set()
        for form in self.receipts_data.ticket_forms:
            pax: DomainPassenger = self.pax_by_ticket_mapper[form.old_ticket]
            if pax.is_infant():
                paxes_infants.add(form.passenger_id)
            if pax.passenger_id in self.exchange_passenger_ids:
                paxes_with_new_tickets.add(form.passenger_id)
        paxes_with_yo = set(
            form.passenger_id
            for form in self.receipts_data.yo_forms
            if form.passenger_id in paxes_with_new_tickets
        )
        paxes_with_penalty = set(
            form.passenger_id
            for form in self.receipts_data.penalty_forms
            if form.passenger_id in paxes_with_new_tickets
        )
        return all([
            len(paxes_with_new_tickets) == len(self.exchange_passenger_ids),
            len(paxes_with_yo) == len(self.exchange_passenger_ids) - len(paxes_infants),  # младенцы без штрафов
            len(paxes_with_penalty) == len(self.exchange_passenger_ids) - len(paxes_infants),  # младенцы без штрафов
        ])
