from domain.exchange import DomainExchange
from domain.types import ExchangeStatus
from use_cases.orders.exceptions.exchange import SimilarExchangeBeingProcessedError


class CheckExistsExchanges:

    def __init__(
            self,
            existing_exchanges: list[DomainExchange],
            cancel_exchange_callback: callable,
    ) -> None:
        super().__init__()
        self.existing_exchanges = existing_exchanges
        self.cancel_exchange = cancel_exchange_callback

    def run(self) -> bool:
        blocking_exchanges: list[DomainExchange] = []
        not_blocking_exchanges: list[DomainExchange] = []

        for exchange in self.existing_exchanges:
            if exchange.status in (ExchangeStatus.WAIT_RECEIPT, ExchangeStatus.PROCESSING, ExchangeStatus.ERROR):
                blocking_exchanges.append(exchange)
                continue
            elif exchange.status in (ExchangeStatus.NEW, ):
                self.cancel_exchange(exchange.exchange_uuid)
            elif exchange.status in (ExchangeStatus.PENDING, ):
                not_blocking_exchanges.append(exchange)
                continue

        error_exchanges = blocking_exchanges or not_blocking_exchanges
        if error_exchanges:
            raise SimilarExchangeBeingProcessedError(error_exchanges[0], blocked=bool(blocking_exchanges))
        return True
