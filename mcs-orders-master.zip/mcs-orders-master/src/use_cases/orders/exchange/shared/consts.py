from dateutil.relativedelta import relativedelta

from mcs_payments_client.payment_types import PaymentProvider

from domain.types import SegmentStatusVisual, PassengerCategory, CompanyPPR, ExchangeStatus


ALLOWED_COUNTRY = 'RU'
ALLOWED_ISSUE_DATE_DURATION = relativedelta(years=1)
ALLOWED_POS_IDS = (
    CompanyPPR.WEBSITE.value,
    CompanyPPR.VOICE_IVR.value,
    CompanyPPR.WEBSITE_AND_CALLCENTER.value,
    CompanyPPR.WEBSITE_AVIASALES.value,
    CompanyPPR.WEBSITE_SKYSCANNER.value,
    CompanyPPR.SIRENA_CLIENT444.value,
    CompanyPPR.TARIFICATION_EXPERIMENTS.value,
)
DISALLOWED_PASSENGER_FIRST_NAMES = (
    'Cbbg',
)
EXCHANGEABLE_SEGMENT_STATUSES = (
    SegmentStatusVisual.ACTIVE.value,
    SegmentStatusVisual.DISABLED.value,
    SegmentStatusVisual.RELEASED.value,
    SegmentStatusVisual.REGISTERED.value,
)
DOB_FORMAT = '%d.%m.%Y'
SHORT_DATE_FORMAT = '%d.%m.%y'
SIRENA_DATE_TIME_FORMAT = '%d.%m.%y %H:%M'
TRANSFER_LAYOVER_SECONDS = 24 * 60 * 60
CATEGORY_AGES = {
    PassengerCategory.ADULT: 12,
    PassengerCategory.CHILD: 2,
    PassengerCategory.INFANT: 0,
}
TICKET_DOC_TYPE = 'etick'

CURRENCY_PRICE_MAP = {
    'RUB': {
        'penalty': 6000,
        'reduce': 4000,
    },
    'EUR': {
        'penalty': 80,
        'reduce': 50,
    },
}

PROVIDER = PaymentProvider.CLOUD_PAYMENTS
PROVIDER_CODE = 'CA'
ALLOWED_CONTACT_MAIL = 'mail'
ALLOWED_CONTACT_PHONE = 'phone'

EXCHANGE_STATUS_PRIORITY = {
    ExchangeStatus.COMPLETE: 1,
    ExchangeStatus.WAIT_RECEIPT: 2,
    ExchangeStatus.PROCESSING: 3,
    ExchangeStatus.PENDING: 4,
    ExchangeStatus.NEW: 5,
}

SIRENA_CATEGORY_MAPPING = {
    PassengerCategory.ADULT: 'ADT',
    PassengerCategory.CHILD: 'CNN',
    PassengerCategory.INFANT: 'INF',
}
