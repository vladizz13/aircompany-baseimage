from typing import List, Dict

from domain.exchange import DomainExchangeSegment, DomainExchangeFlight, DomainExchangeLanding, DomainFlightOptionError
from use_cases.orders.exceptions.exchange import NoExchangeOptions
from use_cases.orders.exchange.shared.parse_sirena_time import parse_sirena_time
from use_cases.orders.exchange.shared.variant_data_combiner import VariantDataCombiner


class EnrichExchangeSegments:
    """
    Обогащение сегментов обмена
    """

    def __init__(
            self,
            segments: List[DomainExchangeSegment],
            pricing_route_responses: List[dict],
            flights: List[DomainExchangeFlight],
            cities_by_airports: Dict[str, str],
            cities_tz: Dict[str, str],
            variant_data_combiner: VariantDataCombiner,
    ) -> None:
        super().__init__()
        self.segments = segments
        self.pricing_route_responses = pricing_route_responses
        self.flights = flights
        self.cities_by_airports = cities_by_airports
        self.cities_tz = cities_tz
        self.variant_data_combiner = variant_data_combiner

    def run(self):
        if not self.pricing_route_responses:
            return None

        no_options_segments = set()
        for segment, response in zip(self.segments, self.pricing_route_responses):
            variant_flight = self.variant_data_combiner.get_first_flight(response)
            variant_response = self.variant_data_combiner.run(flight=variant_flight)
            if not variant_response:
                no_options_segments.add(segment.key)
                continue

            segment.arrival_city = self.cities_by_airports.get(segment.arrival_airport)
            segment.departure_city = self.cities_by_airports.get(segment.departure_airport)
            segment.duration = variant_response.duration
            segment.landings = [
                DomainExchangeLanding(
                    id=item.id,
                    city=item.city,
                    time=item.time,
                    airport=item.airport
                ) for item in variant_response.landings
            ]

            dep_tz = self.cities_tz.get(segment.departure_city)
            if dep_tz:
                dep_local = parse_sirena_time(variant_response.flight, 'dept', tz_code=dep_tz)
                segment.departure_local = dep_local.isoformat()

            arr_tz = self.cities_tz.get(segment.arrival_city)
            if arr_tz:
                arr_local = parse_sirena_time(variant_response.flight, 'arrv', tz_code=arr_tz)
                segment.arrival_local = arr_local.isoformat()

        if no_options_segments:
            error_flights = [
                DomainFlightOptionError(
                    flight_id=str(flight.flight_id),
                    flight_date=segment.flight_date,
                    departure=self.cities_by_airports.get(segment.departure_airport),
                    arrival=self.cities_by_airports.get(segment.arrival_airport),
                ).serialize()
                for flight in self.flights
                for segment in flight.exchange
                if segment.key in no_options_segments
            ]
            raise NoExchangeOptions(
                data=dict(
                    error_flights=error_flights
                )
            )
