import logging

from abc import ABCMeta
from datetime import timedelta
from typing import Union, List, Dict, Tuple, Optional
from uuid import UUID

from mcs_payments_client import RequestCustomer
from mcs_payments_client.payment_types import OperationTypes, Currency, State as PaymentState
from utair.clients.external.sirena.requests.common import ExchangeSegments

from adapter.monoapp import MonoAppAdapter
from adapter.payments.payments_adapter import PaymentsInternalAdapter
from base.use_case import BaseUseCase
from domain import DomainOrder
from domain.exchange import (
    DomainExchange, DomainExchangePayment, DomainExchangePrice,
    DomainExchangeFlight, DomainExchangeBuyer,
)
from domain.order.data import DomainSegment
from domain.types import ExchangeStatus, ExchangeFlow
from libs.messages.telegram import TelegramMessenger

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.exchange import ExchangeQueryBuilder

from use_cases.orders.exceptions.exchange import (
    ExchangeNotFound, InvalidExchangeStatus, SimilarExchangeBeingProcessedError
)
from use_cases.orders.exchange.send_telegram.message_generators import SendWarningVoidRequiredGenerator
from use_cases.orders.exchange.shared.consts import (
    ALLOWED_COUNTRY, PROVIDER,
    EXCHANGE_STATUS_PRIORITY
)
from use_cases.orders.exchange.shared.mappers.exchange_segments import ExchangeSegmentsMapper
from use_cases.orders.exchange.shared.types import ExchangeablePassenger, ExchangeableFlight


class BaseExchangeUseCase(BaseUseCase, metaclass=ABCMeta):
    messenger: Optional[TelegramMessenger]

    def __init__(
        self,
        exchange_repo: GenericMongoRepository,
        internal_payments_adapter: PaymentsInternalAdapter,
        messenger: Optional[TelegramMessenger] = None,
    ):
        self.logger = logging.getLogger(self.__class__.__name__)

        self.exchange_repo = exchange_repo
        self.internal_payments_adapter = internal_payments_adapter
        self.messenger = messenger

    def _create_exchange(
        self,
        order: DomainOrder,
        contacts: dict,
        passengers: List[ExchangeablePassenger],
        flights: List[DomainExchangeFlight],
        price: DomainExchangePrice,
        flow: ExchangeFlow,
    ) -> DomainExchange:
        exchange = DomainExchange.create(
            order_uuid=order.data.order_uuid,
            buyer=DomainExchangeBuyer(**contacts),
            passengers=[p.passenger.passenger_id for p in passengers],
            flights=flights,
            flow=flow,
            price=price,
        )
        self.exchange_repo.create(exchange)

        return exchange

    def _get_exchange(self, exchange_uuid: Union[str, UUID]) -> DomainExchange:
        exchange = self.exchange_repo.get_single(spec=ExchangeQueryBuilder.get_exchange_by_uuid(str(exchange_uuid)))

        if not exchange:
            raise ExchangeNotFound()

        return exchange

    def _update_exchange(self, exchange: DomainExchange) -> None:
        self.exchange_repo.update(
            item=exchange,
            spec=ExchangeQueryBuilder.get_exchange_by_uuid(exchange_uuid=exchange.exchange_uuid),
            upsert=False,
        )

    @staticmethod
    def _get_exchange_segments(
            exchangeable_flights: List[ExchangeableFlight],
            flights: List[DomainExchangeFlight],
            skip_subclass: bool = False,
    ) -> Tuple[List[ExchangeSegments], List[List[DomainSegment]]]:
        exchange_segments: List[ExchangeSegments] = []
        original_flights: List[List[DomainSegment]] = []

        mapped_exchangeable: Dict[int, ExchangeableFlight] = {
            f.flight_id: f for f in exchangeable_flights
        }

        for flight in flights:
            flight_segments: Dict[str, DomainSegment] = {
                s.segment_id: s for s in mapped_exchangeable[flight.flight_id].segments
            }
            original_segments: List[DomainSegment] = [flight_segments[s_id] for s_id in flight.segments]

            exchange_segments.extend(
                ExchangeSegmentsMapper(is_desired_subclass=not skip_subclass).run(
                    original_segments=original_segments,
                    desired_segments=flight.exchange
                )
            )
            original_flights.append(original_segments)

        return exchange_segments, original_flights

    @staticmethod
    def __get_exchange_sorting(exchange: DomainExchange):
        return EXCHANGE_STATUS_PRIORITY.get(exchange.status)

    def _create_payment(self, order: DomainOrder, exchange: DomainExchange, success_url: str, fail_url: str) -> None:
        if exchange.status.is_canceled():
            raise InvalidExchangeStatus()

        if exchange.status.is_processing():
            raise SimilarExchangeBeingProcessedError(exchange, blocked=True)

        if exchange.status == ExchangeStatus.PENDING:
            payment = self.internal_payments_adapter.get(uuid=exchange.payment.transaction)
            if payment:
                state = payment.transaction.get('state') or ''
                if state == 'created':
                    return None

                if state not in ('expired', 'cancelled', 'refunded', 'declined'):
                    raise SimilarExchangeBeingProcessedError(exchange, blocked=False)
        hold_request_id = self.internal_payments_adapter.get_request_id()
        confirm_request_id = self.internal_payments_adapter.get_request_id()
        order_rloc = order.data.rloc.split('/')[0]
        hold_data = self.internal_payments_adapter.hold(
            operation_type=OperationTypes.EXCHANGE,
            customer=RequestCustomer(email=exchange.buyer.mail, phone=exchange.buyer.phone),
            amount=exchange.price.amount,
            currency=Currency(exchange.price.currency),
            success_url=success_url,
            failure_url=fail_url,
            description=f'Оплата обмена заказа {order_rloc}',
            provider=PROVIDER,
            free_data={
                'exchange_uuid': exchange.exchange_uuid,
            },
            request_id=hold_request_id,
            confirm_ttl=timedelta(hours=72),
        )

        exchange.payment = DomainExchangePayment(
            state=PaymentState.CREATED.value,
            invoice=hold_data.invoice_id,
            transaction=str(hold_data.transaction_uuid),
            payment_url=hold_data.redirect_url,
            success_url=success_url,
            fail_url=fail_url,
            hold_request_id=str(hold_request_id),
            confirm_request_id=str(confirm_request_id),
        )
        self._set_status(exchange, ExchangeStatus.PENDING)
        self._update_exchange(exchange)

    def _cancel_payment(self, exchange: DomainExchange) -> bool:
        if not exchange.payment:
            return True

        if exchange.payment.state == PaymentState.HELD.value:
            try:
                self.__void_payment(exchange)
            except Exception as ex:
                self.logger.exception(ex)
                return False

            return True

        return False

    @staticmethod
    def _set_status(exchange: DomainExchange, status: ExchangeStatus) -> None:
        # TODO: Notify
        exchange.status = status

    @staticmethod
    def _enrich_airports(
        mono_app_adapter: MonoAppAdapter, flights: List[DomainExchangeFlight]
    ) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, str], Dict[str, str]]:
        airport_codes = set()

        for flight in flights:
            for segment in flight.exchange:
                airport_codes.add(segment.departure_airport)
                airport_codes.add(segment.arrival_airport)

        cities_by_airports: Dict[str, str] = {}
        cities_tz: Dict[str, str] = {}
        airports: Dict[str, str] = {}
        cities: Dict[str, str] = {}

        for code in airport_codes:
            city = mono_app_adapter.extended_find_city_by_iata(iata_code=code)

            cities_by_airports[code] = city.get('code')
            airport = next((a for a in city.get('airports', []) if a['code'] == code), {})

            airports[code] = airport.get('name_translations', {}).get(ALLOWED_COUNTRY.lower())
            cities[city.get('code')] = city.get('name_translations', {}).get(ALLOWED_COUNTRY.lower())

            cities_tz[city.get('code')] = city.get('time_zone')

        return cities_by_airports, cities_tz, airports, cities

    def __void_payment(self, exchange: DomainExchange) -> None:
        # TODO: Allow Payment Void
        # self.internal_payments_adapter.void(uuid=exchange.payment.transaction)

        if self.messenger:
            self.messenger.send_message(
                SendWarningVoidRequiredGenerator(exchange=exchange).generate_msg()
            )
