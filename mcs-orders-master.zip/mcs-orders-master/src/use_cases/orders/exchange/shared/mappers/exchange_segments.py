from datetime import datetime
from typing import List, Union

from utair.clients.external.sirena.requests.common import ExchangeSegments, ExchangeSegment

from domain.exchange import DomainExchangeSegment
from domain.order.data import DomainSegment
from use_cases.orders.exchange.options.types import ExchangeVariantSegment


SEGMENT = Union[DomainSegment, ExchangeVariantSegment, DomainExchangeSegment]


class ExchangeSegmentsMapper:
    """
    Маппинг сегментов для отправки в сирену
    """

    def __init__(self, is_desired_subclass=False) -> None:
        super().__init__()
        # Если требуется в desired сегменты передавать subclass
        self.is_desired_subclass = is_desired_subclass

    def run(
        self,
        original_segments: List[SEGMENT],
        desired_segments: List[SEGMENT],
    ) -> List[ExchangeSegments]:
        exchange_segments = []
        if len(original_segments) == len(desired_segments):
            # Если количество сегментов не меняется, то делаем разбивку
            for original_segment, desired_segment in zip(original_segments, desired_segments):
                exchange_segments.append(self._serialize_exchange_segments([original_segment], [desired_segment]))
        else:
            # Если количество сегментов изменилось, то отправляем связкой
            exchange_segments.append(self._serialize_exchange_segments(original_segments, desired_segments))
        return exchange_segments

    def _serialize_exchange_segments(
        self,
        original_segments: List[SEGMENT],
        desired_segments: List[SEGMENT],
    ) -> ExchangeSegments:
        return ExchangeSegments(
            original=[self._serialize_segment(s, is_desired=False) for s in original_segments],
            desired=[self._serialize_segment(s, is_desired=True) for s in desired_segments]
        )

    def _serialize_segment(self, segment: SEGMENT, is_desired: bool) -> ExchangeSegment:
        subclass = None
        if is_desired and self.is_desired_subclass:
            subclass = getattr(segment, 'subclass', None)

        if isinstance(segment, DomainSegment):
            return ExchangeSegment(
                airline=segment.ak,
                flight_number=segment.flight_number,
                flight_date=datetime.fromisoformat(segment.departure_local_iso).date(),
                departure_code=segment.departure_airport_code,
                arrival_code=segment.arrival_airport_code,
                subclass=subclass,
            )
        elif isinstance(segment, ExchangeVariantSegment):
            return ExchangeSegment(
                airline=segment.airline,
                flight_number=segment.flight_number,
                flight_date=segment.departure.local.date(),
                departure_code=segment.departure.airport_code,
                arrival_code=segment.arrival.airport_code,
                subclass=subclass,
            )
        elif isinstance(segment, DomainExchangeSegment):
            return ExchangeSegment(
                airline=segment.airline,
                flight_number=segment.flight_number,
                flight_date=segment.flight_date,
                departure_code=segment.departure_airport,
                arrival_code=segment.arrival_airport,
                subclass=subclass,
            )
        raise Exception(f'type: {type(segment)} not support')
