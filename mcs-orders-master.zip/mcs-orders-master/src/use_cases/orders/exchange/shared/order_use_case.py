import json
import uuid
import logging
import re

from abc import ABCMeta
from collections import defaultdict
from typing import List, Dict, Tuple
from time import time
from datetime import datetime, timezone, date
from operator import attrgetter
from dateutil.relativedelta import relativedelta
from mcs_oauth_client.domain.user import DomainUser

from sirena_xml_client.exceptions import BaseSirenaError
from sirena_xml_client.types import PaymentPassenger

from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

from domain import DomainOrder
from domain.order.data import DomainSegment, DomainDocument, DomainCoupon, DomainPassenger
from domain.types import (
    GDS, TransactionSource, CouponStatus, PassengerCategory, SegmentStatusVisual, ServiceStatus
)
from libs.query_builder import AndQueryUnit

from rest.interfaces.internal_order_adapter import InternalOrderAdapter

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder

from use_cases.orders.exchange.shared.types import ExchangeablePassenger, ExchangeableFlight, CancelableService

from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.orders.exceptions.exchange import (
    BaseExchangeError,
    ExchangeIsNotAllowedError, ClaimedOrderNotFoundError, InvalidExchangeablePassengerError, NoAdultsError,
    NoExchangeableSegmentsError, NoExchangeablePassengersError, PassengerRegisteredError, ExchangeReleasedFirstError,
    UnexpectedCurrencyError, UnexpectedPriceError
)


from base.use_case import BaseUseCase

from use_cases.orders.exchange.shared.consts import (
    ALLOWED_ISSUE_DATE_DURATION, ALLOWED_POS_IDS, DISALLOWED_PASSENGER_FIRST_NAMES, EXCHANGEABLE_SEGMENT_STATUSES,
    TRANSFER_LAYOVER_SECONDS, CATEGORY_AGES, DOB_FORMAT, TICKET_DOC_TYPE, CURRENCY_PRICE_MAP, ALLOWED_CONTACT_MAIL,
    ALLOWED_CONTACT_PHONE,
)


class BaseExchangeableOrderUseCase(BaseUseCase, metaclass=ABCMeta):
    TIME_PATTERN = re.compile(r'^(\d+)\:(\d+)')
    PHONE_PATTERN = re.compile(r"^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$")
    EMAIL_PATTERN = re.compile(r'([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,15})')

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        internal_order_adapter: InternalOrderAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
    ):
        self.logger = logging.getLogger(self.__class__.__name__)

        self.order_repo = order_repo
        self.internal_order_adapter = internal_order_adapter
        self.internal_sirena_adapter = internal_sirena_adapter

    def _get_order(self, order_uuid: str, update_existing: bool) -> DomainOrder:
        spec: AndQueryUnit = AndQueryUnit()

        spec.add(OrdersQueryBuilder.get_by_order_uuid(order_uuid))
        order = self.order_repo.get_single(spec=spec)

        if not order:
            raise OrderNotFoundError()
        if not self.__is_exchange_allowed(order):
            order_str = json.dumps(order.data.serialize(), ensure_ascii=False, indent=2)
            extra_msg = dict(data={'order': order_str, 'rloc': order.data.rloc})
            self.logger.info(f'ExchangeIsNotAllowedError: {order.data.order_uuid}', extra=extra_msg)
            raise ExchangeIsNotAllowedError()

        if order.data.rloc.split('/')[1] in (GDS.SIRENA.value, GDS.SIRENA_V2.value):
            if update_existing:
                self.internal_order_adapter.update_from_sirena_grs(order_uuid)
                self.logger.info(f'Updated {order.data.rloc} from sirena')
        else:
            try:
                order_uuid = self.__claim_order(order)
            except (BaseSirenaError, BaseExchangeError) as ex:
                raise ex
            except Exception as ex:
                self.logger.exception(ex)
                raise BaseExchangeError()
            self.logger.info(f'Claimed {order.data.rloc} to sirena')
        return self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(str(order_uuid))
        )

    def _normalize_coupons(self, order: DomainOrder, passenger_ids: List[str], segment_ids: List[str]) -> List[dict]:
        self.logger.info(f'Normalizing {order.data.rloc} coupons')
        coupons: List[DomainCoupon] = [
            c for c in order.data.coupons if c.segment_id in segment_ids and c.passenger_id in passenger_ids
        ]

        if any([c.status == CouponStatus.C.value for c in coupons]):
            raise PassengerRegisteredError()

        normalized_statuses: List[dict] = []

        for coupon in coupons:
            if coupon.status == CouponStatus.U.value:
                success = self.__normalize_coupon_status(coupon)
                normalized_statuses.append({
                    'ticket': coupon.ticket,
                    'number': coupon.number,
                    'success': success,
                })
                if not success:
                    break

        return normalized_statuses

    def _split_order(self, order: DomainOrder, passengers: List[ExchangeablePassenger]) -> DomainOrder:
        self.logger.info(f'Splitting {len(passengers)} passengers from {order.data.rloc}')

        response = self.internal_sirena_adapter.divide_order(
            rloc=order.data.rloc,
            surname=order.data.passengers[0].last_name,
            passengers=self.__build_payment_passengers([p.passenger for p in passengers])
        )
        order_uuid = self.__save_from_sirena(
            locator=response.get('regnum', {}).get('text'),
            last_name=passengers[0].passenger.last_name,
        )

        return self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(str(order_uuid))
        )

    def _update_order(self, order: DomainOrder) -> None:
        self.order_repo.update(order, OrdersQueryBuilder.get_by_order_uuid(order.data.order_uuid))

    @classmethod
    def _get_exchangeable_passengers(
            cls, order: DomainOrder, flights: List[ExchangeableFlight]
    ) -> List[ExchangeablePassenger]:
        segments = [s for f in flights for s in f.segments]
        first_active_segment = next((s for s in segments), None)

        if not first_active_segment:
            raise ExchangeIsNotAllowedError()

        segment_ids = [s.segment_id for s in segments]
        registered_passenger_ids = [
            c.passenger_id for c in order.data.coupons
            if c.status == CouponStatus.C.value and c.segment_id in segment_ids
        ]
        documents: Dict[str, DomainDocument] = {d.passenger_id: d for d in order.data.documents}
        departure_date = datetime.fromtimestamp(first_active_segment.departure_timestamp, tz=timezone.utc).date()

        exchangeable_passengers: List[ExchangeablePassenger] = []
        for passenger in order.data.passengers:
            document = documents[passenger.passenger_id]
            dob = datetime.strptime(document.birthday, DOB_FORMAT).date()

            exchangeable_passengers.append(ExchangeablePassenger(
                passenger=passenger,
                document=document,
                dob=dob,
                category=cls.__calculate_category(departure_date, dob),
                registered=passenger.passenger_id in registered_passenger_ids,
            ))

        if not exchangeable_passengers:
            raise NoExchangeablePassengersError()

        return exchangeable_passengers

    @classmethod
    def _is_category_persisted(
        cls, selected_passengers: List[ExchangeablePassenger], flight_dates: List[date]
    ) -> bool:
        sorted_dates = sorted(flight_dates)

        for passenger in selected_passengers:
            if passenger.category != cls.__calculate_category(sorted_dates[0], passenger.dob):
                return False

            if (
                sorted_dates[-1] != sorted_dates[0]
                and passenger.category != cls.__calculate_category(sorted_dates[-1], passenger.dob)
            ):
                return False

        return True

    @classmethod
    def _get_selected_passengers(
            cls, exchangeable: List[ExchangeablePassenger], selected: List[str]
    ) -> Tuple[List[ExchangeablePassenger], List[ExchangeablePassenger]]:
        selected_passengers: List[ExchangeablePassenger] = []
        exchangeable: Dict[str, ExchangeablePassenger] = {p.passenger.passenger_id: p for p in exchangeable}

        for passenger_id in selected:
            if passenger_id not in exchangeable:
                raise InvalidExchangeablePassengerError(passenger_id)

            selected_passengers.append(exchangeable.pop(passenger_id))

        left_passengers = list(exchangeable.values())

        if not (cls.__is_children_valid(selected_passengers) and cls.__is_children_valid(list(left_passengers))):
            raise NoAdultsError()

        return selected_passengers, left_passengers

    @staticmethod
    def _get_exchangeable_flights(order: DomainOrder) -> List[ExchangeableFlight]:
        flight_id: int = 0
        flight_segments: List[DomainSegment] = []
        exchangeable: List[ExchangeableFlight] = []

        for segment in sorted(order.data.segments, key=attrgetter('departure_timestamp')):
            if segment.status_visual not in EXCHANGEABLE_SEGMENT_STATUSES:
                continue

            if flight_segments and not (
                flight_segments[-1].arrival_airport_code == segment.departure_airport_code
                and segment.departure_timestamp - flight_segments[-1].arrival_timestamp < TRANSFER_LAYOVER_SECONDS
                and segment.arrival_airport_code != flight_segments[-1].departure_airport_code
            ):
                exchangeable.append(ExchangeableFlight(
                    flight_id=flight_id,
                    segments=flight_segments,
                ))
                flight_id += 1
                flight_segments = []

            flight_segments.append(segment)

        if flight_segments:
            exchangeable.append(ExchangeableFlight(
                flight_id=flight_id,
                segments=flight_segments,
            ))

        if not exchangeable:
            raise NoExchangeableSegmentsError()

        if (
            len(exchangeable) == 1
            and len(exchangeable[0].segments) > 1
            and exchangeable[0].segments[0].departure_airport_code == exchangeable[0].segments[-1].arrival_airport_code
        ):
            return [ExchangeableFlight(
                flight_id=i,
                segments=[s],
            ) for i, s in enumerate(exchangeable[0].segments)]

        return exchangeable

    @staticmethod
    def _validate_released(exchangeable: List[ExchangeableFlight], selected: List[str]) -> None:
        for flight in exchangeable:
            for segment in flight.segments:
                if segment.status_visual == SegmentStatusVisual.RELEASED.value and segment.segment_id not in selected:
                    raise ExchangeReleasedFirstError()

    @staticmethod
    def _get_points_reference(
        mono_app_adapter: MonoAppAdapter,
        segments: List[DomainSegment]
    ) -> Tuple[Dict[str, str], Dict[str, str]]:
        airport_codes = set()
        city_codes = set()

        for segment in segments:
            airport_codes.add(segment.departure_airport_code)
            airport_codes.add(segment.arrival_airport_code)
            city_codes.add(segment.departure_city_code)
            city_codes.add(segment.arrival_city_code)

        airports: Dict[str, str] = {}
        cities: Dict[str, str] = {}

        for code in airport_codes:
            airports[code] = mono_app_adapter.get_airport_full_name_by_iata(iata_code=code)
        for code in city_codes:
            cities[code] = mono_app_adapter.get_city_full_name_by_iata(iata_code=code)

        return airports, cities

    def __claim_order(self, order: DomainOrder) -> str:
        claim_data = self.internal_sirena_adapter.claim(
            ticket_number=order.data.tickets[0].ticket,
            flight_number=order.data.segments[0].flight_number,
        )
        return self.__save_from_sirena(locator=claim_data.get('rloc'), last_name=claim_data.get('last_name'))

    def __save_from_sirena(self, locator: str, last_name: str) -> str:
        sirena_raw_transaction = self.internal_sirena_adapter.search_order(
            rloc=locator, last_name=last_name, show_originator=True
        )

        if not sirena_raw_transaction:
            raise ClaimedOrderNotFoundError()

        result = self.internal_order_adapter.save(
            raw_order=sirena_raw_transaction,
            provider=str(TransactionSource.SIRENA_GRS.value),
            received=time(),
            message_id=str(uuid.uuid4()),
            deferred_save=False,
            return_full_response=False,
        )

        return result['order_uuid']

    def __normalize_coupon_status(self, coupon: DomainCoupon) -> bool:
        if coupon.status != CouponStatus.U.value:
            raise ValueError(f'Invalid coupon status for normalization: {coupon.status}')

        try:
            response = self.internal_sirena_adapter.change_status_coupon(
                doc_type=TICKET_DOC_TYPE,
                doc_number=coupon.ticket,
                coupon_number=str(coupon.number),
                coupon_status=CouponStatus.O.value,
            )
        except BaseSirenaError:
            return False

        return 'ok' in response

    @classmethod
    def __is_exchange_allowed(cls, order: DomainOrder) -> bool:
        return (
            order.data.available_actions.can_change
            and order.data.pos_data.pos_id in ALLOWED_POS_IDS
            and cls.__is_passengers_allowed(order)
            and cls.__is_issue_date_allowed(order)
        )

    @staticmethod
    def __build_user_filters(user: DomainUser) -> dict:
        user_filters = dict(user_id=user.user_id)

        if user.email and user.channels.email.verified:
            user_filters.update(email=user.email)

        if user.phone and user.channels.phone.verified:
            user_filters.update(phone=user.phone)

        return user_filters

    @staticmethod
    def __is_issue_date_allowed(order: DomainOrder) -> bool:
        min_allowed_date = datetime.now(tz=timezone.utc) - ALLOWED_ISSUE_DATE_DURATION
        active_coupons = [c for c in order.data.coupons if c.status not in CouponStatus.TERMINAL_LIST.value]
        active_tickets = [c.ticket for c in active_coupons]

        issue_date_present = False
        for ticket in order.data.tickets:
            if ticket.ticket not in active_tickets:
                continue

            if ticket.issue_datetime is None:
                continue

            issue_date_present = True
            if datetime.fromtimestamp(ticket.issue_datetime, tz=timezone.utc) > min_allowed_date:
                return True

        if issue_date_present:
            return False

        active_segment_ids = [c.segment_id for c in active_coupons]
        for segment in order.data.segments:
            if segment.segment_id not in active_segment_ids:
                continue

            if (
                segment.booking_timestamp
                and datetime.fromtimestamp(segment.booking_timestamp, tz=timezone.utc) > min_allowed_date
            ):
                return True

        return False

    @staticmethod
    def __is_passengers_allowed(order: DomainOrder) -> bool:
        for passenger in order.data.passengers:
            if passenger.first_name in DISALLOWED_PASSENGER_FIRST_NAMES:
                return False

        return True

    @staticmethod
    def __is_children_valid(passengers: List[ExchangeablePassenger]) -> bool:
        if not passengers:
            return True

        category_count = defaultdict(int)
        for passenger in passengers:
            category_count[passenger.category] += 1

        if category_count[PassengerCategory.ADULT] < 1:
            return False

        if category_count[PassengerCategory.CHILD] > category_count[PassengerCategory.ADULT] * 2:
            return False

        if category_count[PassengerCategory.INFANT] > category_count[PassengerCategory.ADULT]:
            return False

        return True

    @staticmethod
    def __calculate_category(departure: date, dob: date) -> PassengerCategory:
        age = relativedelta(departure, dob).years

        if age >= CATEGORY_AGES[PassengerCategory.ADULT]:
            return PassengerCategory.ADULT

        if CATEGORY_AGES[PassengerCategory.ADULT] > age >= CATEGORY_AGES[PassengerCategory.CHILD]:
            return PassengerCategory.CHILD

        return PassengerCategory.INFANT

    @staticmethod
    def _get_to_list(data: dict, key: str) -> List[dict]:
        value = data.get(key, [])

        if not isinstance(value, list):
            value = [value]

        return value

    @staticmethod
    def __reduce_price(price: float, currency: str, taxes: List[dict]) -> float:
        if currency not in CURRENCY_PRICE_MAP:
            raise UnexpectedCurrencyError()

        penalty = next((p for p in taxes if p.get('@penalty') == "true"), None)
        if not penalty:
            return price

        if penalty['value']['@currency'] != currency:
            raise UnexpectedCurrencyError()

        penalty_price = float(penalty['value']['text'])
        if penalty_price != CURRENCY_PRICE_MAP[currency]['penalty']:
            raise UnexpectedPriceError()

        price = price - CURRENCY_PRICE_MAP[currency]['reduce']

        if price < 0:
            raise UnexpectedPriceError()

        return price

    @staticmethod
    def __build_payment_passengers(passengers: List[DomainPassenger]) -> List[PaymentPassenger]:
        payment_passengers: List[PaymentPassenger] = []
        for passenger in passengers:
            first_name = passenger.first_name.capitalize()
            if passenger.second_name:
                first_name = f"{first_name} {passenger.second_name.capitalize()}"

            payment_passengers.append(PaymentPassenger(
                first_name=first_name,
                last_name=passenger.last_name.capitalize()
            ))

        return payment_passengers

    @staticmethod
    def _get_cancelable_services(
            order: DomainOrder, segment_ids: List[str], passenger_ids: List[str]
    ) -> List[CancelableService]:
        services: List[CancelableService] = []

        for service in order.data.services:
            if (
                    service.segment_id in segment_ids
                    and service.passenger_id in passenger_ids
                    and service.status == ServiceStatus.HI.value
            ):
                services.append(CancelableService(
                    guid=service.guid,
                    rfisc=service.rfisc,
                    count=service.count,
                    description=service.description,
                    passenger_id=service.passenger_id,
                    segment_id=service.segment_id,
                ))

        return services

    @classmethod
    def _get_exchange_contacts(
        cls,
        order: DomainOrder
    ) -> dict:
        contacts = {}
        for contact in order.data.contacts:
            if all([
                contact.type == ALLOWED_CONTACT_PHONE,
                cls.PHONE_PATTERN.match(contact.contact),
                contact.type not in contacts,
            ]) or all([
                contact.type == ALLOWED_CONTACT_MAIL,
                cls.EMAIL_PATTERN.match(contact.contact),
                contact.type not in contacts,
            ]):
                contacts.update({contact.type: contact.contact})

        if not contacts:
            raise ExchangeIsNotAllowedError()

        return contacts
