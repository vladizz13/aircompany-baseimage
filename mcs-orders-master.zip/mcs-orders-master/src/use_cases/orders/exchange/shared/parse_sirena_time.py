from datetime import datetime

import pytz

from use_cases.orders.exchange.shared.consts import SIRENA_DATE_TIME_FORMAT


def parse_sirena_time(variant_flight: dict, code: str, tz_code: str) -> datetime:
    flight_date = variant_flight[f'{code}date']['text']
    flight_time = variant_flight[f'{code}time']
    point_time = datetime.strptime(f'{flight_date} {flight_time}', SIRENA_DATE_TIME_FORMAT)
    if tz_code:
        point_time = pytz.timezone(tz_code).localize(point_time)
    return point_time
