from logging import Logger
from typing import List, Dict, Optional

from domain import DomainOrder
from domain.exchange import DomainExchange, DomainSSRRequest
from domain.order.data import DomainPassenger
from use_cases.orders.exchange.shared.consts import DOB_FORMAT


class ReplaceSSR:

    def __init__(
            self,
            exchange: DomainExchange,
            order: DomainOrder,
            ssr_type: str,
            logger: Logger,
            segment_status_visual: str,
    ) -> None:
        super().__init__()
        self.exchange = exchange
        self.order = order
        self.ssr_type = ssr_type
        self.logger = logger
        self.segment_status_visual = segment_status_visual

    def run(self) -> Optional[List[DomainSSRRequest]]:
        self.logger.info(f'ReplaceSSR for {self.exchange.exchange_uuid} order')
        requests = []
        exchanged_segments = self._get_exchanged_segments()
        ssrs_for_add = self._get_ssrs_for_add(exchanged_segments=exchanged_segments)
        if not ssrs_for_add:
            return None

        last_name = None
        passengers_by_id = {p.passenger_id: p for p in self.order.data.passengers}
        for p_id, text in ssrs_for_add.items():
            passenger = passengers_by_id.get(p_id)
            if not passenger:
                continue
            if not last_name:
                last_name = passenger.last_name
            requests.append(
                DomainSSRRequest.deserialize(dict(
                    ssr_type=self.ssr_type,
                    text=text,
                    units=self._get_units(passenger=passenger)
                ))
            )
        return requests

    def _get_exchanged_segments(self) -> List[str]:
        exchanged_segments = [
            segment.segment_id
            for segment in self.order.data.segments
            if segment.status_visual == self.segment_status_visual
        ]
        if not exchanged_segments:
            self.logger.info(f'ReplaceSSR not exchanged_segments order_uuid: {self.order.data.order_uuid}')
        return exchanged_segments

    def _get_ssrs_for_add(self, exchanged_segments: List[str]) -> Dict[str, str]:
        ssrs_for_add = dict()
        for ssr in self.order.data.ssrs:
            if all([
                ssr.passenger_id in self.exchange.passengers,
                ssr.segment_id in exchanged_segments,
                ssr.ssr == self.ssr_type,
                ssr.status == 'HK'
            ]):
                ssrs_for_add[ssr.passenger_id] = ssr.text
        return ssrs_for_add

    def _get_units(self, passenger: DomainPassenger):
        name = ' '.join([x for x in (passenger.first_name, passenger.second_name) if x])
        return [
            dict(
                name=name,
                surname=passenger.last_name,
                company=segment.airline,
                flight=segment.flight_number,
                departure=segment.departure_airport,
                arrival=segment.arrival_airport,
                date=segment.flight_date.strftime(DOB_FORMAT),
            )
            for flight in self.exchange.flights
            for segment in flight.exchange
        ]
