import logging
from decimal import Decimal
from collections import namedtuple, defaultdict
from typing import Dict, Tuple, Union, List

from mcs_payments_client import RequestSaleItem, RequestPaymentPart, RequestTaxPosition
from mcs_payments_client.payment_types import PaymentOwner, PaymentPartType, GoodType

from domain.order.data import DomainPassenger
from domain.receipts_data import DomainReceiptsData

YO_CODE = 'УО'  # кириллица!

Tax = namedtuple('Tax', 'code value is_penalty is_yo is_dues')
Payment = namedtuple('Payment', 'fop value')
logger = logging.getLogger('ExchangePaymentUseCase')


def to_list(item: Union[dict, list]) -> list:
    if not isinstance(item, list):
        item = [item]
    return item


class TicketResult:

    def __init__(self, ticket: str, invoice_id: str, old_ticket: str) -> None:
        super().__init__()
        self.ticket = ticket
        self.invoice_id = invoice_id
        self.old_ticket = old_ticket
        self.pax_name: str = ''  # ФИО пассажира
        self.loyalty_card: str = ''

        self.new_rate: Decimal = Decimal()  # Тарифы по всем сегментам нового билета
        self.old_rate: Decimal = Decimal()  # Тарифы по всем сегментам старого билета

        self.air_payment_sum = 0
        self.air_taxes: dict = {}  # Таксы Доплаты по тарифу
        self.taxes_yo: dict = {}  # Таксы сгруппированные по сборам
        self.taxes_penalty: dict = {}  # Таксы сгруппированные по штрафам
        self.exchange_income_taxes: dict = defaultdict(Decimal)  # Таксы прихода (положительные + новый тариф + сбор)
        self.exchange_refund_taxes: dict = defaultdict(Decimal)  # Таксы возврата (отрицательные + старый тариф)
        self.exchange_refund_payments: List[tuple] = []  # Оплата по тарифу
        self.exchange_income_payments: List[tuple] = []  # Оплата по тарифу

        self.all_taxes: list = []
        self.all_payments: list = []

    def add_new_rate(self, value: Decimal) -> None:
        """
        Рассчет тарифа нового билета
        *сумма всех price['fare']['value']['text']
        """
        self.new_rate += value

    def update_taxes_yo(self, taxes: List[Tax], yo_numbers_by_value: dict):
        for tax in taxes:
            if tax.is_yo:
                receipts_number = yo_numbers_by_value[tax.value].pop()
                self.taxes_yo[receipts_number] = tax.value

    def update_taxes_penalty(self, taxes: List[Tax], penalty_numbers_by_value: dict):
        value = sum([tax.value for tax in taxes if tax.is_penalty])
        if value:
            penalty_number = penalty_numbers_by_value[value].pop()
            self.taxes_penalty[penalty_number] = value

    def update_all_taxes(self, taxes: List[Tax]):
        self.all_taxes.extend(taxes)

    def update_all_payments(self, payments: List[Payment]):
        self.all_payments.extend(payments)

    def set_pax_name(self, pax_name: str) -> None:
        self.pax_name = pax_name

    def set_loyalty_card(self, loyalty_card: str) -> None:
        self.loyalty_card = loyalty_card or '0'

    def finally_calc(self):
        """
        Финальные рассчеты
        """
        self.old_rate = self._calc_old_rate()

        self.air_taxes = self._calc_sale_part_taxes()
        self.air_payment_sum = self._calc_sale_part_payment_money()

        self.exchange_refund_taxes = self._calc_refund_taxes()
        self.exchange_income_taxes = self._calc_income_taxes(self.exchange_refund_taxes)
        self._calc_taxes_penalty(self.exchange_income_taxes)

        # Милли/бонусы
        delta_sum = self._calc_delta_sum()
        self.exchange_refund_payments = self._calc_exchange_payments(self.exchange_refund_taxes, delta_sum)
        self.exchange_income_payments = self._calc_exchange_payments(self.exchange_income_taxes, delta_sum)

    def _calc_delta_sum(self) -> Decimal:
        result = sum(
            payment.value
            for payment in self.all_payments
            if payment.fop in ['FF', 'VZ'] and payment.value > 0
        )
        return Decimal(str(result))

    def _calc_old_rate(self) -> Decimal:
        return sum(
            payment.value
            for payment in self.all_payments
            if payment.fop not in ['CA', 'НА']
        )

    def _calc_sale_part_payment_money(self) -> Decimal:
        return sum(
            value
            for value in self.air_taxes.values()
            if value > 0
        )

    def _calc_sale_part_taxes(self) -> Dict[str, Decimal]:
        result = defaultdict(Decimal)
        result['ТАРИФ'] = abs(self.new_rate) - abs(self.old_rate)
        for tax in self.all_taxes:
            if tax.is_dues:
                result[tax.code] += tax.value
        # Уменьшаем тариф, если сумма такс отрицательная
        air_taxes_sum: Decimal = sum(value for value in result.values())
        if air_taxes_sum < Decimal('0'):
            result['ТАРИФ'] -= abs(air_taxes_sum)
        return result

    def _calc_income_taxes(self, refund_taxes) -> Dict[str, Decimal]:
        income_taxes = defaultdict(Decimal)
        for tax in self.all_taxes:
            if tax.is_penalty or tax.is_yo:
                continue
            if tax.value > 0:
                income_taxes[tax.code] += tax.value
        income_taxes['ТАРИФ'] = self.new_rate
        # Берем меньшие значения. Т.к в приход не можем засчитать больше чем он оплатил
        income_taxes = {
            code: min([refund_taxes.get(code, Decimal('0')), income_taxes[code]])
            for code in income_taxes
        }
        refund_sum = sum([tax_amount for tax_amount in refund_taxes.values()])
        income_sum = sum([tax_amount for tax_amount in income_taxes.values()])
        income_taxes['СБОР ЗА ИЗМЕНЕНИЕ УСЛОВИЙ ПЕРЕВОЗКИ'] = refund_sum - income_sum
        return income_taxes

    def _calc_refund_taxes(self) -> Dict[str, Decimal]:
        refund_taxes = defaultdict(Decimal)
        for tax in self.all_taxes:
            if tax.is_penalty or tax.is_yo:
                continue
            if tax.value < 0:
                refund_taxes[tax.code] += abs(tax.value)
        refund_taxes['ТАРИФ'] = self.old_rate
        return refund_taxes

    def _calc_taxes_penalty(self, income_taxes: Dict[str, Decimal]):
        diff_sum: Decimal = income_taxes['СБОР ЗА ИЗМЕНЕНИЕ УСЛОВИЙ ПЕРЕВОЗКИ']
        for key in self.taxes_penalty.keys():
            if diff_sum <= Decimal('0'):
                break
            amount: Decimal = min([diff_sum, self.taxes_penalty[key]])
            self.taxes_penalty[key] -= amount
            diff_sum -= amount

    def _calc_exchange_payments(self, taxes, delta_sum: Decimal) -> List[Tuple[PaymentPartType, Decimal]]:
        sum_ = sum([tax_amount for tax_amount in taxes.values()])
        return [
            (PaymentPartType.MONEY, Decimal(str(sum_)) - delta_sum),
            (PaymentPartType.DELTA, delta_sum),
        ]


class ProcessTicketResult:
    def __init__(
            self,
            exchange_pricing_response: dict,
            receipts_data: DomainReceiptsData,
            pax_by_ticket_mapper: Dict[str, DomainPassenger],
            invoice_id: str,
    ) -> None:
        super().__init__()
        self.exchange_pricing_response = exchange_pricing_response
        self.receipts_data = receipts_data
        self.pax_by_ticket_mapper = pax_by_ticket_mapper
        self.invoice_id = invoice_id

    def run(self) -> List[TicketResult]:
        # Из сирены
        tickets_by_pax: dict = self.receipts_data.get_tickets_by_pax()
        yo_numbers_by_pax: dict = self.receipts_data.get_yo_numbers_by_pax()
        penalty_number_by_pax: dict = self.receipts_data.get_penalty_numbers_by_pax()

        results = {}
        for price in to_list(self.exchange_pricing_response['prices']['price']):
            payments_list: List[Payment] = [
                self._serialize_payment(payment_)
                for payment_ in to_list(price['payment_info']['payment'])
            ]
            taxes_list: List[Tax] = self._get_taxes_list(price)
            pax_key = str(price["@passenger-id"])
            ticket, old_ticket = tickets_by_pax[pax_key]
            order_pax = self.pax_by_ticket_mapper[old_ticket]
            result = self._get_current_result(results, ticket, old_ticket)
            result.add_new_rate(Decimal(price['fare']['value']['text']))
            result.set_pax_name(order_pax.get_fio())
            result.set_loyalty_card(order_pax.loyalty_cardnumber)
            result.update_taxes_yo(taxes_list, yo_numbers_by_pax.get(pax_key))
            result.update_taxes_penalty(taxes_list, penalty_number_by_pax.get(pax_key))
            result.update_all_taxes(taxes_list)
            result.update_all_payments(payments_list)
        results_list = []
        for result in results.values():
            result.finally_calc()
            results_list.append(result)
        return results_list

    def _get_current_result(self, results, ticket, old_ticket):
        if ticket not in results:
            results[ticket] = TicketResult(
                ticket=ticket,
                invoice_id=self.invoice_id,
                old_ticket=old_ticket,
            )
        return results[ticket]

    def _serialize_payment(self, payment: dict) -> Payment:
        fop = payment['@fop']
        value = Decimal(str(payment['text']))
        return Payment(fop, value)

    def _serialize_tax(self, tax: dict) -> Tax:
        """
        tax_code: Код таксы
        tax_value: Сумма таксы
        is_yo: Это штраф YO
        is_penalty: Это штраф обмена
        is_dues: Это просто сбор (=не штраф)
        """
        tax_code = tax['code']['text'] if isinstance(tax['code'], dict) else tax['code']
        tax_value = Decimal(str(tax['value']['text']))
        is_penalty = bool(tax.get('@penalty'))
        is_yo = tax_code in [YO_CODE]
        is_dues = not any([is_penalty, is_yo])
        return Tax(tax_code, tax_value, is_penalty, is_yo, is_dues)

    def _get_taxes_list(self, price: dict):
        if 'taxes' not in price:
            return []
        return [self._serialize_tax(tax_) for tax_ in to_list(price['taxes']['tax'])]


class PartGenerator:

    def __init__(self, results: List[TicketResult]):
        super().__init__()
        self.results = results

    def generate_sale_parts(self) -> List[RequestSaleItem]:
        sale_parts = []
        for result in self.results:
            sale_parts.append(self._sale_part_air_ticket(result))
            sale_parts.extend(self._sale_part_exchange_penalty(result))
            sale_parts.extend(self._sale_part_exchange_tax(result))
        return self._filtered_parts(sale_parts)

    def generate_exchange_income_parts(self) -> List[RequestSaleItem]:
        parts = [
            self._exchange_income_part(result)
            for result in self.results
        ]
        return self._filtered_parts(parts)

    def generate_exchange_refund_parts(self) -> List[RequestSaleItem]:
        parts = [
            self._exchange_refund_part(result)
            for result in self.results
        ]
        return self._filtered_parts(parts)

    def _filtered_parts(self, parts: List[RequestSaleItem]) -> List[RequestSaleItem]:
        # Фильтруем части оплаты (убираем все части с нулевой суммой)
        return [part for part in parts if part.get_total_payments_amount()]

    def _sale_part_air_ticket(self, result: TicketResult) -> RequestSaleItem:
        return RequestSaleItem(
            good_type=GoodType.AIR_TICKET,
            number=result.ticket,
            passenger=result.pax_name,
            description="Доплата по тарифу",
            payments=[
                RequestPaymentPart(
                    type_=PaymentPartType.MONEY,
                    amount=result.air_payment_sum,
                    data=result.loyalty_card,
                    invoice_id=result.invoice_id,
                )
            ],
            tax_positions=self._serialize_taxes(result.air_taxes),
        )

    def _sale_part_exchange_penalty(self, result: TicketResult) -> List[RequestSaleItem]:
        result_parts = []
        for number, amount in result.taxes_penalty.items():
            if not amount:
                continue
            result_parts.append(
                RequestSaleItem(
                    good_type=GoodType.EXCHANGE_PENALTY,
                    number=number,
                    passenger=result.pax_name,
                    description="ПЛАТА ПРИ ИЗМЕНЕНИИ",
                    payments=[
                        RequestPaymentPart(
                            type_=PaymentPartType.MONEY,
                            amount=amount,
                            data=result.loyalty_card,
                            invoice_id=result.invoice_id,
                        )
                    ],
                    tax_positions=[
                        RequestTaxPosition(
                            name="СБОР ЗА ИЗМЕНЕНИЕ УСЛОВИЙ ПЕРЕВОЗКИ",
                            amount=amount,
                            owner=PaymentOwner.AIR_COMPANY,
                        )
                    ]
                )
            )
        return result_parts

    def _sale_part_exchange_tax(self, result: TicketResult) -> List[RequestSaleItem]:
        result_parts = []
        for number, amount in result.taxes_yo.items():
            if not amount:
                continue
            result_parts.append(
                RequestSaleItem(
                    good_type=GoodType.EXCHANGE_TAX,
                    number=number,
                    passenger=result.pax_name,
                    description="Сбор за дист.оформление обмена",
                    payments=[
                        RequestPaymentPart(
                            type_=PaymentPartType.MONEY,
                            amount=amount,
                            data=result.loyalty_card,
                            invoice_id=result.invoice_id,
                        )
                    ],
                    tax_positions=[
                        RequestTaxPosition(
                            name=YO_CODE,
                            amount=amount,
                            owner=PaymentOwner.AGENCY,
                        )
                    ]
                )
            )
        return result_parts

    def _exchange_income_part(self, result: TicketResult) -> RequestSaleItem:
        return RequestSaleItem(
            good_type=GoodType.AIR_TICKET,
            number=result.ticket,
            passenger=result.pax_name,
            description="Часть стоимости нового билета",
            payments=self._serialize_payments(result.exchange_income_payments, result),
            tax_positions=self._serialize_taxes(result.exchange_income_taxes),
        )

    def _exchange_refund_part(self, result: TicketResult) -> RequestSaleItem:
        return RequestSaleItem(
            good_type=GoodType.AIR_TICKET,
            number=result.old_ticket,
            passenger=result.pax_name,
            description="Стоимость старого билета",
            payments=self._serialize_payments(result.exchange_refund_payments, result),
            tax_positions=self._serialize_taxes(result.exchange_refund_taxes),
        )

    def _serialize_taxes(self, taxes: dict, owner: PaymentOwner = PaymentOwner.AIR_COMPANY):
        return [
            RequestTaxPosition(name=tax_code, amount=tax_amount, owner=owner)
            for tax_code, tax_amount in taxes.items()
            if tax_amount > 0
        ]

    def _serialize_payments(self, payments: List[tuple], result: TicketResult):
        return [
            RequestPaymentPart(
                type_=type_,
                amount=amount,
                data=result.loyalty_card,
                invoice_id=result.invoice_id,
            )
            for type_, amount in payments
            if amount > 0
        ]
