from collections import defaultdict
from typing import Dict, List

from sirena_xml_client.types import PricingRouteSegment, PricingRoutePassenger

from domain.exchange import DomainExchangeSegment
from domain.types import PassengerCategory
from use_cases.orders.exchange.options.consts import PRICING_SIRENA_MAX_RESULTS
from use_cases.orders.exchange.shared.consts import SHORT_DATE_FORMAT, SIRENA_CATEGORY_MAPPING, CATEGORY_AGES
from use_cases.orders.exchange.shared.types import ExchangeablePassenger


class PricingRouteBuilder:
    """
    Билд запроса к сирене (на получение вариантов)
    """
    @classmethod
    def get_requests(
            cls,
            segments: List[DomainExchangeSegment],
            exchangeable_passengers: List[ExchangeablePassenger],
            max_results: int = 0,
    ) -> List[dict]:
        if not len(segments):
            return []
        passenger_categories: Dict[PassengerCategory, int] = defaultdict(int)
        for passenger in exchangeable_passengers:
            passenger_categories[passenger.category] += 1
        return [
            cls.get_request(segment, passenger_categories, max_results)
            for segment in segments
        ]

    @classmethod
    def get_request(
            cls,
            segment: DomainExchangeSegment,
            categories: Dict[PassengerCategory, int],

            max_results: int,
    ) -> dict:
        if not max_results:
            max_results = PRICING_SIRENA_MAX_RESULTS
        return dict(
            segments=[PricingRouteSegment(
                departure=segment.departure_airport,
                arrival=segment.arrival_airport,
                ﬂight=segment.flight_number,
                date=segment.flight_date.strftime(SHORT_DATE_FORMAT),
                company=segment.airline,
            )],
            passengers=[PricingRoutePassenger(
                passenger_type=SIRENA_CATEGORY_MAPPING[category],
                count=str(count),
                age=CATEGORY_AGES[category],
            ) for category, count in categories.items()],
            fingering_order='differentFlightsCombFirst',
            show_flighttime=True,
            show_available=True,
            max_results=max_results,
            mix_scls=True,
            mix_ac=False,
        )
