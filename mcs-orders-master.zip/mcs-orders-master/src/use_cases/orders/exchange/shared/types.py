from datetime import date
from pydantic.main import BaseModel
from typing import List, NamedTuple

from domain.order.data import DomainSegment, DomainPassenger, DomainDocument
from domain.types import PassengerCategory


class ExchangeablePassenger(NamedTuple):
    passenger: DomainPassenger
    document: DomainDocument
    dob: date
    category: PassengerCategory
    registered: bool


class ExchangeableFlight(NamedTuple):
    flight_id: int
    segments: List[DomainSegment]


class CancelableService(BaseModel):
    guid: str
    rfisc: str
    count: int
    description: str
    passenger_id: str
    segment_id: str

    def serialize(self) -> dict:
        return {
            'guid': self.guid,
            'rfisc': self.rfisc,
            'count': self.count,
            'description': self.description,
            'passenger_id': self.passenger_id,
            'segment_id': self.segment_id,
        }


class ExchangeVariantSegmentLanding(NamedTuple):
    id: str
    city: str
    time: str
    airport: str
