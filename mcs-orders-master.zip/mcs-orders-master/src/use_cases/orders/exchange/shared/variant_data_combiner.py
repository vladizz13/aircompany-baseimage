import re
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel

from use_cases.orders.exchange.shared.sale_parts import to_list
from use_cases.orders.exchange.shared.types import ExchangeVariantSegmentLanding


class VariantDataCombinerResponse(BaseModel):
    duration: int
    flight: dict
    landings: List[ExchangeVariantSegmentLanding]


class VariantDataCombiner:
    TIME_PATTERN = re.compile(r'^(\d+)\:(\d+)')

    def __init__(self, mono_app_adapter) -> None:
        super().__init__()
        self.mono_app_adapter = mono_app_adapter

    def run(self, flight: dict) -> Optional[VariantDataCombinerResponse]:
        if not flight:
            return None
        return VariantDataCombinerResponse(
            duration=self._get_duration(flight),
            flight=flight,
            landings=self.get_landings(flight)
        )

    @classmethod
    def get_first_flight(cls, response: dict) -> dict:
        """
        Извлечь первый рейс (когда в запросе запрашивает только один вариант)
        @param response: Ответ от сирены
        @return: Вариант рейса
        """
        variants_data = response.get('answer', {}).get('pricing_route', {}).get('variant')
        if not variants_data:
            return {}
        variant = variants_data[0]
        flights = variant.get('flight')
        if not flights:
            return {}
        return flights[0]

    def get_landings(self, flight) -> List[ExchangeVariantSegmentLanding]:
        landings = []
        if 'n_landings' in flight:
            last_leg = None
            leg_index = 0
            for leg in to_list(flight['legs']['leg']):
                if last_leg is None:
                    last_leg = leg
                    continue
                airport_code = last_leg['arr']['text']
                city = self.mono_app_adapter.extended_find_city_by_iata(iata_code=airport_code)
                landings.append(ExchangeVariantSegmentLanding(
                    id=str(leg_index),
                    city=city['name_translations']['ru'],
                    time=self._calc_landing_time(last_leg['arr']['@time_utc'], leg['dep']['@time_utc']),
                    airport=airport_code,
                ))
                leg_index += 1
                last_leg = leg
        return landings

    def _get_duration(self, flight: dict) -> int:
        flight_duration = flight.get('flightTime')
        time_match = self.TIME_PATTERN.match(flight_duration)
        return int(time_match.group(1)) * 3600 + int(time_match.group(2)) * 60

    def _calc_landing_time(self, time_start: str, time_end: str, format: str = '%H:%M %d.%m.%Y'):
        diff_delta = datetime.strptime(time_end, format) - datetime.strptime(time_start, format)
        return (datetime.min + diff_delta).strftime('%H:%M')
