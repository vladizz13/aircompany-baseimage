from uuid import UUID
from typing import Union

from base.use_case import BaseUseCaseRequest

from base.exception import ApplicationError


class ExchangeStartRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]
    success_url: str
    fail_url: str

    def __init__(
            self,
            exchange_uuid: Union[str, UUID],
            success_url: str,
            fail_url: str,
    ):
        super().__init__()
        self.exchange_uuid = exchange_uuid
        self.success_url = success_url
        self.fail_url = fail_url

    def is_valid(self, *args, **kwargs) -> 'ExchangeStartRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))

        if not (self.success_url and self.fail_url):
            self.add_error(ApplicationError(code=400, message="Success and Fail urls required"))

        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
            'success_url': self.success_url,
            'fail_url': self.fail_url,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
            success_url=data.get('success_url'),
            fail_url=data.get('fail_url'),
        )
