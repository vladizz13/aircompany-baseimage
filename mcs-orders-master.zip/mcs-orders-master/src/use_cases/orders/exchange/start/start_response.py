from domain.exchange import DomainExchange

from base.use_case import BaseUseCaseResponse


class ExchangeStartResponse(BaseUseCaseResponse):
    def __init__(self, exchange: DomainExchange):
        super().__init__(self.serialize(exchange))

    @classmethod
    def serialize(cls, exchange: DomainExchange) -> dict:
        return {
            'paymentUrl': exchange.payment.payment_url,
        }
