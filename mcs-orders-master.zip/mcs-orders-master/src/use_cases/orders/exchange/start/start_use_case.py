from typing import Optional

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter

from domain.types import ExchangeStatus
from libs.messages.telegram import TelegramMessenger

from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase

from use_cases.orders.exchange.start.start_request import ExchangeStartRequest
from use_cases.orders.exchange.start.start_response import ExchangeStartResponse
from use_cases.orders.exceptions.exchange import CannotBeProcessedError


class ExchangeStartUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    """
    Подтверждение обмена
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        exchange_repo: GenericMongoRepository,
        internal_order_adapter: InternalOrderAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
        internal_payments_adapter: PaymentsInternalAdapter,
        messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )

    def __execute__(self, request: ExchangeStartRequest, *args, **kwargs) -> ExchangeStartResponse:
        self.logger.info(f'Starting exchange flow for {request.exchange_uuid}')

        exchange = self._get_exchange(request.exchange_uuid)
        if exchange.flow == exchange.flow.MANUAL:
            raise CannotBeProcessedError()

        order = self._get_order(order_uuid=exchange.order_uuid, update_existing=False)

        try:
            self._create_payment(order, exchange, success_url=request.success_url, fail_url=request.fail_url)
        except Exception as ex:
            self.logger.exception(ex)
            self._set_status(exchange, ExchangeStatus.ERROR)
            exchange.set_error(ex)
            self._update_exchange(exchange)
            self._cancel_payment(exchange)
            raise

        self.logger.info(
            f'Started payment flow for {exchange.exchange_uuid}'
        )

        return ExchangeStartResponse(exchange=exchange)
