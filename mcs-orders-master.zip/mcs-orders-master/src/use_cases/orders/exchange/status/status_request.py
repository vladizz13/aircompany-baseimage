from uuid import UUID
from typing import Union

from base.use_case import BaseUseCaseRequest

from base.exception import ApplicationError


class ExchangeStatusRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]

    def __init__(self, exchange_uuid: Union[str, UUID]):
        super().__init__()
        self.exchange_uuid = exchange_uuid

    def is_valid(self, *args, **kwargs) -> 'ExchangeStatusRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))

        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
        )
