from typing import List, Dict, Optional

from domain.exchange import DomainExchange, DomainExchangeFlight, DomainExchangeRefundedServices

from base.use_case import BaseUseCaseResponse
from domain.order.data import DomainSegment
from use_cases.orders.exchange.shared.types import ExchangeableFlight, ExchangeablePassenger, CancelableService


class ExchangeStatusResponse(BaseUseCaseResponse):
    def __init__(
        self,
        exchange: DomainExchange,
        flights: List[ExchangeableFlight],
        passengers: List[ExchangeablePassenger],
        airports: Dict[str, str],
        cities: Dict[str, str],
        cancelable_services: List[CancelableService],
    ):
        super().__init__(self.serialize(
            exchange,
            flights,
            passengers,
            airports,
            cities,
            cancelable_services
        ))

    @classmethod
    def serialize(
        cls,
        exchange: DomainExchange,
        flights: List[ExchangeableFlight],
        passengers: List[ExchangeablePassenger],
        airports: Dict[str, str],
        cities: Dict[str, str],
        cancelable_services: List[CancelableService],
    ) -> dict:
        data = {
            'status': exchange.status.value,
            'order_uuid': exchange.order_uuid,
        }

        if exchange.order:
            data['order'] = {
                'locator': exchange.order.locator.split('/')[0],
                'refund_services': exchange.refunded_services.serialize() if exchange.refunded_services else None,
                'refund_services_status': exchange.refunded_services_status,
            }

        if exchange.status.with_exchangeable_services():
            data['services'] = [s.serialize() for s in cancelable_services]
        else:
            data['services'] = cls._serialize_services(exchange.refunded_services)

        data['flights'] = [cls.__serialize_flight(f, airports, cities) for f in flights]
        map_passengers = {p.passenger.passenger_id: p for p in passengers}
        data['exchange'] = {
            'passengers': cls.__serialize_passengers(exchange.passengers, map_passengers),
            'price': exchange.price.serialize(),
            'flights': [cls.__serialize_exchange_flight(f, airports, cities)
                        for f in exchange.flights],
        }

        return data

    @classmethod
    def __serialize_flight(
        cls, flight: ExchangeableFlight, airports: Dict[str, str], cities: Dict[str, str]
    ) -> dict:
        return {
            'flight_id': flight.flight_id,
            'segments': [{
                'segment_id': s.segment_id,
                'flight_number': f'{s.ak}{s.flight_number}',
                'departure': cls.__serialize_point(s, 'departure', airports, cities),
                'arrival': cls.__serialize_point(s, 'arrival', airports, cities),
                'duration': s.duration,
                'status': s.status_visual,
            } for s in flight.segments],
        }

    @classmethod
    def __serialize_exchange_flight(
        cls,
        flight: DomainExchangeFlight,
        airports: Dict[str, str],
        cities: Dict[str, str],
    ) -> dict:
        data = flight.serialize()
        segments = []
        for segment in flight.exchange:
            segments.append(dict(
                flight_number=f'{segment.airline}{segment.flight_number}',
                departure=dict(
                    airport_code=segment.departure_airport,
                    airport_name=airports.get(segment.departure_airport),
                    city_code=segment.departure_city,
                    city_name=cities.get(segment.departure_city),
                    local=segment.departure_local
                ),
                arrival=dict(
                    airport_code=segment.arrival_airport,
                    airport_name=airports.get(segment.arrival_airport),
                    city_code=segment.arrival_city,
                    city_name=cities.get(segment.arrival_city),
                    local=segment.arrival_local
                ),
                landings=[landing.serialize() for landing in segment.landings],
                duration=segment.duration
            ))
        data['exchange'] = segments

        return data

    @classmethod
    def __serialize_passengers(cls, ids: List[str], passengers: Dict[str, ExchangeablePassenger]) -> dict:
        return [cls.__serialize_passenger(passengers.get(pid)) for pid in ids if passengers.get(pid)]

    @classmethod
    def __serialize_passenger(cls, passenger: ExchangeablePassenger) -> dict:
        return {
            'passenger_id': passenger.passenger.passenger_id,
            'first_name': passenger.passenger.first_name,
            'last_name': passenger.passenger.last_name,
            'second_name': passenger.passenger.second_name,
            'dob': passenger.dob.isoformat(),
            'doc_number': passenger.document.docnumber,
            'doc_type': passenger.document.doctype,
            'category': passenger.category.value,
            'registered': passenger.registered,
        }

    @staticmethod
    def __serialize_point(
        segment: DomainSegment, code: str, airports: Dict[str, str], cities: Dict[str, str]
    ) -> dict:
        airport_code = getattr(segment, f'{code}_airport_code')
        city_code = getattr(segment, f'{code}_city_code')

        return {
            'airport_code': airport_code,
            'airport_name': airports.get(airport_code),
            'city_code': city_code,
            'city_name': cities.get(city_code),
            'local': getattr(segment, f'{code}_local_iso'),
        }

    @staticmethod
    def _serialize_services(refunded_services: Optional[DomainExchangeRefundedServices]):
        if not refunded_services:
            return []
        status = 'ERROR' if refunded_services.price is None else 'SUCCESS'
        return [{'status': status, **service.serialize()} for service in refunded_services.services]
