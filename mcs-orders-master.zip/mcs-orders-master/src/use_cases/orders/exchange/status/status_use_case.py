from typing import List, Optional

from sirena_xml_client.exceptions import BaseSirenaError, SirenaResponseError

from adapter.monoapp import MonoAppAdapter
from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from domain.exchange import DomainExchange, DomainExchangeSegment
from libs.messages.telegram import TelegramMessenger
from libs.utils.threads import bulk_requests

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter

from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase
from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exceptions.exchange import ExchangeNotFound, ExchangeRetryNeededError

from .status_request import ExchangeStatusRequest
from .status_response import ExchangeStatusResponse
from ..shared.enrich_exchange_segments import EnrichExchangeSegments
from ..shared.sirena_requests.pricing_route_request import PricingRouteBuilder
from ..shared.types import ExchangeablePassenger
from ..shared.variant_data_combiner import VariantDataCombiner


class ExchangeStatusUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):
    """
    Получение статуса обмена
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        exchange_repo: GenericMongoRepository,
        internal_order_adapter: InternalOrderAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
        internal_payments_adapter: PaymentsInternalAdapter,
        mono_app_adapter: MonoAppAdapter,
        messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.mono_app_adapter = mono_app_adapter

    def __execute__(self, request: ExchangeStatusRequest, *args, **kwargs) -> ExchangeStatusResponse:
        exchange = self._get_exchange(request.exchange_uuid)
        if exchange.status.is_canceled():
            raise ExchangeNotFound()

        self.logger.info(f'Retrieved {request.exchange_uuid} exchange status: {exchange.status.value}')

        order = self._get_order(exchange.order_uuid, update_existing=False)
        exchangeable_flights = self._get_exchangeable_flights(order)
        self.logger.info(f'Found {len(exchangeable_flights)} flights in {order.data.rloc}')

        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)
        self.logger.info(f'Found {len(exchangeable_passengers)} passengers in {order.data.rloc}')

        segments = [
            segment
            for flight in exchangeable_flights
            for segment in flight.segments
        ]
        airports, cities = self._get_points_reference(self.mono_app_adapter, segments)

        (cities_by_airports, cities_tz, exchange_airports, exchange_cities) = self._enrich_airports(
            self.mono_app_adapter, exchange.flights
        )
        airports.update(exchange_airports)
        cities.update(exchange_cities)

        cancelable_services = []

        if exchange.status.with_exchangeable_services():
            exchangeable_segment_ids = [
                segment_id
                for flight in exchange.flights
                for segment_id in flight.segments
            ]
            cancelable_services = self._get_cancelable_services(order, exchangeable_segment_ids, exchange.passengers)

        self._enrich_segments(
            exchange=exchange,
            exchangeable_passengers=exchangeable_passengers,
            cities_by_airports=cities_by_airports,
            cities_tz=cities_tz,
        )

        return ExchangeStatusResponse(
            exchange=exchange,
            flights=exchangeable_flights,
            passengers=exchangeable_passengers,
            airports=airports,
            cities=cities,
            cancelable_services=cancelable_services
        )

    def _enrich_segments(
            self,
            exchange: DomainExchange,
            exchangeable_passengers: List[ExchangeablePassenger],
            cities_by_airports,
            cities_tz,
    ):
        segments: List[DomainExchangeSegment] = [
            segment
            for flight in exchange.flights
            for segment in flight.exchange
        ]
        need_enrich = any(not s.duration for s in segments)
        if not need_enrich:
            return
        pricing_route_responses = self._pricing_route(segments, exchangeable_passengers)
        EnrichExchangeSegments(
            segments=segments,
            pricing_route_responses=pricing_route_responses,
            flights=exchange.flights,
            cities_by_airports=cities_by_airports,
            cities_tz=cities_tz,
            variant_data_combiner=VariantDataCombiner(mono_app_adapter=self.mono_app_adapter),
        ).run()
        self._update_exchange(exchange)

    def _pricing_route(
            self,
            segments: List[DomainExchangeSegment],
            exchangeable_passengers: List[ExchangeablePassenger],
    ) -> list:
        """
        Получение вариантов перелета из сирены
        """
        if not len(segments):
            return []

        requests = PricingRouteBuilder.get_requests(segments, exchangeable_passengers)

        try:
            return bulk_requests(self.internal_sirena_adapter.client.get_pricing_route, requests)
        except (BaseSirenaError, SirenaResponseError) as ex:
            self.logger.exception(ex)
            if ex.http_code == 500:
                raise ExchangeRetryNeededError()
        except Exception as ex:
            self.logger.exception(ex)
        return []
