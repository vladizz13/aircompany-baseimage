from typing import Union
from uuid import UUID
from ...base_order_use_case import BaseOrderRequest
from base.exception import ApplicationError


class ExchangeOrderV1Request(BaseOrderRequest):

    def __init__(
            self,
            order_uuid: Union[str, UUID] = None,
    ):
        super().__init__()
        self.order_uuid = order_uuid

    def is_valid(self, *args, **kwargs) -> 'ExchangeOrderV1Request':
        try:
            UUID(str(self.order_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid order uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None),
        )
