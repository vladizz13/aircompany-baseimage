from domain import DomainOrder
from use_cases.orders.base_order_use_case import BaseOrderResponse


class ExchangeOrderV1Response(BaseOrderResponse):
    def __init__(
        self,
        value: DomainOrder = None,
    ):
        redirect_url = self.create_redirect_link(value) if value else None
        super().__init__({'redirect_url': redirect_url})

    @staticmethod
    def create_redirect_link(order: DomainOrder) -> str:
        """
        Создание ссылки для редиректа в таис
        """
        template = "https://www.utair.ru/ticket/exchange/?id={}&order_key={}"
        return template.format(order.data.order_id, order.data.order_key)
