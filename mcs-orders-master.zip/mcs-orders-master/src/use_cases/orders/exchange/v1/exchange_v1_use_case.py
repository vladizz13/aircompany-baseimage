import time
import uuid
from typing import Type, Union, Dict, List
from domain import DomainOrder
from domain.types import TransactionSource, CompanyPPR
from adapter.tais_adapter import TaisInternalAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.save.deferred_save.deferred_save_queue import SaveOrdersQueue
from ...base_order_use_case import BaseOrderUseCase
from .exchange_v1_request import ExchangeOrderV1Request
from .exchange_v1_response import ExchangeOrderV1Response
from ...exceptions.user import OrderNotFoundError
from ...exceptions.exchange import (
    ExchangeIsNotAllowedError,
    ExchangeRetryNeededError
)


class ExchangeOrderV1UseCase(BaseOrderUseCase):
    """
    Юзкейс подготовки заказа заказа к обмену
    и перенаправления пользователя в таис
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        tais_adapter: TaisInternalAdapter,
        internal_order_adapter: Type[InternalOrderAdapter],
        orders_queue: SaveOrdersQueue,
    ):
        super().__init__()
        self.order_repo = order_repo
        self.tais_adapter = tais_adapter
        self.internal_order_adapter = internal_order_adapter
        self.orders_queue = orders_queue

    def __execute__(self, request: ExchangeOrderV1Request, *args, **kwargs) -> ExchangeOrderV1Response:

        order: DomainOrder = self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(str(request.order_uuid))
        )
        if not order:
            return ExchangeOrderV1Response.build_from_exception(OrderNotFoundError())

        if not order.data.available_actions.can_change:
            return ExchangeOrderV1Response.build_from_exception(ExchangeIsNotAllowedError())

        if self.is_ready_to_exchange(order):    # Можем выполнить обмен сразу
            return ExchangeOrderV1Response(value=order)
        if not self.is_update_needed(order):    # Если при этом не нужно обновить заказ - обмен выполнить невозможно
            return ExchangeOrderV1Response.build_from_exception(ExchangeIsNotAllowedError())

        if not self.is_queue_empty(order):
            return ExchangeOrderV1Response.build_from_exception(ExchangeRetryNeededError())

        tais_raw_orders: List[Dict] = self.search_orders(order)
        if not tais_raw_orders:
            return ExchangeOrderV1Response.build_from_exception(ExchangeRetryNeededError())
        if len(tais_raw_orders) > 1:
            return ExchangeOrderV1Response.build_from_exception(
                OrderNotFoundError(message="Unable to find suitable order")
            )
        raw_order = tais_raw_orders[0]
        order: DomainOrder = self.save_tais_order(raw_order)
        if not order:
            return ExchangeOrderV1Response.build_from_exception(ExchangeRetryNeededError())

        return ExchangeOrderV1Response(value=order)

    def is_queue_empty(self, order: DomainOrder) -> bool:
        """
        Проверка на наличие очереди сохранение для заказа
        """
        return not self.orders_queue.queue_is_active(order.data.rloc)

    @staticmethod
    def is_ready_to_exchange(order: DomainOrder) -> bool:
        return all((
            order.data.available_actions.can_change,
            order.data.order_id, order.data.order_key
         ))

    @staticmethod
    def is_update_needed(order: DomainOrder) -> bool:
        """Нужно обновить броню, если нет полей от таис и подходящий pos_id"""
        return all((
            order.data.order_id is None,
            order.data.order_key is None,
            order.data.pos_data.pos_id in (
                CompanyPPR.SIRENA_CLIENT444.value,
                CompanyPPR.VOICE_IVR.value,
                CompanyPPR.WEBSITE.value
            )
        ))

    def search_orders(self, order: DomainOrder) -> List[Dict]:
        """
        Поиск заказов в таисе
        """
        raw_orders: List[Dict] = self.tais_adapter.search_orders(
            rloc=order.data.rloc,
            last_name=order.data.passengers[0].last_name,
            sirena_sync=True,
            check_booking=True
        )
        return raw_orders

    def save_tais_order(self, raw_order: dict) -> Union[DomainOrder, None]:
        """
        Сохранение нового заказа
        """
        if not raw_order:
            return None
        response = self.internal_order_adapter().save(
            raw_order=raw_order,
            provider=TransactionSource.TAIS.value,
            received=time.time(),
            message_id=str(uuid.uuid4()),
            deferred_save=False,
            return_full_response=True
        )
        order: Union[DomainOrder, None] = response.saved_order
        return order
