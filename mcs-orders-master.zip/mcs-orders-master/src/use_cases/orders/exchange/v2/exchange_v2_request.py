from uuid import UUID
from typing import Union

from use_cases.orders.base_order_use_case import BaseOrderRequest

from base.exception import ApplicationError


class ExchangeOrderV2Request(BaseOrderRequest):

    def __init__(
            self,
            order_uuid: Union[str, UUID],
    ):
        super().__init__()
        self.order_uuid = order_uuid

    def is_valid(self, *args, **kwargs) -> 'ExchangeOrderV2Request':
        try:
            UUID(str(self.order_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid order uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid', None),
        )
