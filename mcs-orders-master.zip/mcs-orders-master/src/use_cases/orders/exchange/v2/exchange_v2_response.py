from typing import List, Dict

from base.use_case import BaseUseCaseResponse
from domain import DomainOrder
from domain.order.data import DomainSegment

from use_cases.orders.exchange.shared.types import ExchangeableFlight, ExchangeablePassenger


class ExchangeOrderV2Response(BaseUseCaseResponse):
    def __init__(
        self,
        order: DomainOrder,
        flights: List[ExchangeableFlight],
        passengers: List[ExchangeablePassenger],
        airports: Dict[str, str],
        cities: Dict[str, str],
    ):
        super().__init__(self.serialize(order, flights, passengers, airports, cities))

    @classmethod
    def serialize(
        cls,
        order: DomainOrder,
        flights: List[ExchangeableFlight],
        passengers: List[ExchangeablePassenger],
        airports: Dict[str, str],
        cities: Dict[str, str],
    ) -> dict:
        return {
            **cls.__serialize_locator(order),
            'flights': [cls.__serialize_flight(f, airports, cities) for f in flights],
            'passengers': [cls.__serialize_passenger(p) for p in passengers],
        }

    @staticmethod
    def __serialize_locator(order: DomainOrder) -> dict:
        locator, gds = order.data.rloc.split('/')

        return {
            'gds': gds,
            'locator': locator,
        }

    @classmethod
    def __serialize_passenger(cls, passenger: ExchangeablePassenger) -> dict:
        return {
            'passenger_id': passenger.passenger.passenger_id,
            'first_name': passenger.passenger.first_name,
            'last_name': passenger.passenger.last_name,
            'second_name': passenger.passenger.second_name,
            'dob': passenger.dob.isoformat(),
            'doc_number': passenger.document.docnumber,
            'doc_type': passenger.document.doctype,
            'category': passenger.category.value,
            'registered': passenger.registered,
        }

    @classmethod
    def __serialize_flight(
        cls, flight: ExchangeableFlight, airports: Dict[str, str], cities: Dict[str, str]
    ) -> dict:
        return {
            'flight_id': flight.flight_id,
            'segments': [{
                'segment_id': s.segment_id,
                'flight_number': f'{s.ak}{s.flight_number}',
                'departure': cls.__serialize_point(s, 'departure', airports, cities),
                'arrival': cls.__serialize_point(s, 'arrival', airports, cities),
                'duration': s.duration,
                'status': s.status_visual,
            } for s in flight.segments],
        }

    @staticmethod
    def __serialize_point(
        segment: DomainSegment, code: str, airports: Dict[str, str], cities: Dict[str, str]
    ) -> dict:
        airport_code = getattr(segment, f'{code}_airport_code')
        city_code = getattr(segment, f'{code}_city_code')

        return {
            'airport_code': airport_code,
            'airport_name': airports.get(airport_code),
            'city_code': city_code,
            'city_name': cities.get(city_code),
            'local': getattr(segment, f'{code}_local_iso'),
        }
