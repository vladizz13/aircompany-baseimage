from typing import List

from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from domain import DomainOrder
from domain.exchange import DomainExchange
from repositories.query_builders.exchange import ExchangeQueryBuilder
from rest.interfaces.external_exchange_order_adapter import ExternalExchangeOrderAdapter

from rest.interfaces.internal_order_adapter import InternalOrderAdapter

from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase

from .exchange_v2_request import ExchangeOrderV2Request
from .exchange_v2_response import ExchangeOrderV2Response
from use_cases.orders.exchange.shared.check_exists_exchanges import CheckExistsExchanges


class ExchangeOrderV2UseCase(BaseExchangeableOrderUseCase):
    """
    Получение данных заказа для обмена
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        exchange_repo: GenericMongoRepository,
        internal_order_adapter: InternalOrderAdapter,
        internal_sirena_adapter: SirenaInternalAdapter,
        mono_app_adapter: MonoAppAdapter,
    ):
        super().__init__(
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        self.mono_app_adapter = mono_app_adapter
        self.exchange_repo = exchange_repo

    def __execute__(self, request: ExchangeOrderV2Request, *args, **kwargs) -> ExchangeOrderV2Response:
        self.logger.info(f'Collecting exchange data for {request.order_uuid}')

        order = self._get_order(str(request.order_uuid), update_existing=True)
        self._check_exists_exchange(order=order)
        self._get_exchange_contacts(order)
        exchangeable_flights = self._get_exchangeable_flights(order)
        self.logger.info(f'Found {len(exchangeable_flights)} flights in {order.data.rloc}')

        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)
        self.logger.info(f'Found {len(exchangeable_passengers)} passengers in {order.data.rloc}')
        segments = [
            segment
            for flight in exchangeable_flights
            for segment in flight.segments
        ]
        airports, cities = self._get_points_reference(self.mono_app_adapter, segments)

        return ExchangeOrderV2Response(order, exchangeable_flights, exchangeable_passengers, airports, cities)

    def _check_exists_exchange(self, order: DomainOrder):
        existing_exchanges: List[DomainExchange] = self.exchange_repo.list(
            spec=ExchangeQueryBuilder.get_exchange_by_order_uuid(order.data.order_uuid),
            sort=[('_id', -1)]
        )
        if not existing_exchanges:
            return None
        return CheckExistsExchanges(
            existing_exchanges=existing_exchanges,
            cancel_exchange_callback=ExternalExchangeOrderAdapter().cancel_order_exchange,
        ).run()
