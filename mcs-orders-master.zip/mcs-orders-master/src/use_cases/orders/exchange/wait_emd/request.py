from typing import Union
from uuid import UUID

from base.exception import ApplicationError
from base.use_case import BaseUseCaseRequest


class WaitEMDRequest(BaseUseCaseRequest):
    exchange_uuid: Union[str, UUID]

    def __init__(
            self,
            exchange_uuid: Union[str, UUID],
            exchange_pricing_response: dict,
    ):
        super().__init__()
        self.exchange_uuid = exchange_uuid
        self.exchange_pricing_response = exchange_pricing_response

    def is_valid(self, *args, **kwargs) -> 'WaitEMDRequest':
        try:
            UUID(str(self.exchange_uuid))
        except ValueError:
            self.add_error(ApplicationError(code=400, message="Invalid exchange uuid"))
        return self

    def serialize(self) -> dict:
        return {
            'exchange_uuid': self.exchange_uuid,
            'exchange_pricing_response': self.exchange_pricing_response,
        }

    @classmethod
    def deserialize(cls, data: dict) -> 'WaitEMDRequest':
        return cls(
            exchange_uuid=data.get('exchange_uuid'),
            exchange_pricing_response=data.get('exchange_pricing_response'),
        )
