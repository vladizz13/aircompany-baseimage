import logging
from typing import List, Optional

from adapter.payments.payments_adapter import PaymentsInternalAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from base.use_case import BaseUseCaseResponse

from domain import DomainOrder
from domain.exchange import DomainExchange, DomainSSRRequest
from domain.receipts_data import DomainReceiptsData
from domain.types import ExchangeStatus
from libs.messages.telegram import TelegramMessenger
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.exceptions.exchange import NewTicketNotFound, NotValidConfirmPrice
from use_cases.orders.exchange.shared.cancel_exchange import CancelExchangeService
from use_cases.orders.exchange.shared.check_documents import CheckDocuments
from use_cases.orders.exchange.shared.exchange_use_case import BaseExchangeUseCase
from use_cases.orders.exchange.shared.order_use_case import BaseExchangeableOrderUseCase
from use_cases.orders.exchange.shared.replace_ssr import ReplaceSSR
from use_cases.orders.exchange.shared.sale_parts import PartGenerator, ProcessTicketResult
from use_cases.orders.exchange.shared.types import ExchangeablePassenger
from use_cases.orders.exchange.wait_emd.request import WaitEMDRequest
from mcs_payments_client.payment_types import State as PaymentState


class WaitEMDUseCase(BaseExchangeableOrderUseCase, BaseExchangeUseCase):

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            exchange_repo: GenericMongoRepository,
            internal_order_adapter: InternalOrderAdapter,
            internal_sirena_adapter: SirenaInternalAdapter,
            internal_payments_adapter: PaymentsInternalAdapter,
            messenger: Optional[TelegramMessenger] = None,
    ):
        BaseExchangeableOrderUseCase.__init__(
            self,
            order_repo=order_repo,
            internal_order_adapter=internal_order_adapter,
            internal_sirena_adapter=internal_sirena_adapter,
        )
        BaseExchangeUseCase.__init__(
            self,
            exchange_repo=exchange_repo,
            internal_payments_adapter=internal_payments_adapter,
            messenger=messenger,
        )
        self.logger = logging.getLogger('exchange_logger')

    def __execute__(self, request: WaitEMDRequest, *args, **kwargs) -> BaseUseCaseResponse:
        self.logger.info(f'WaitEMDUseCase for {request.exchange_uuid} exchange')
        exchange = self._get_exchange(request.exchange_uuid)
        if self._is_skip_flow(exchange=exchange):
            return BaseUseCaseResponse(value=dict(result=True))
        order = self._get_order(str(exchange.order_uuid), update_existing=True)
        exchangeable_flights = self._get_exchangeable_flights(order)
        exchangeable_passengers = self._get_exchangeable_passengers(order, exchangeable_flights)
        selected_passengers, left_passengers = self._get_selected_passengers(
            exchangeable_passengers, exchange.passengers
        )
        exchange_pricing_response = request.exchange_pricing_response
        try:
            self._save_sale_parts(
                order=order,
                exchange=exchange,
                exchange_pricing_response=exchange_pricing_response,
                selected_passengers=selected_passengers,
            )
        except (NewTicketNotFound, ConnectionError, NotValidConfirmPrice) as ex:
            self.logger.exception(str(ex))
            raise ex
        except Exception as ex:
            self.logger.exception(str(ex))
            try:
                CancelExchangeService(
                    exchange=exchange,
                    internal_sirena_adapter=self.internal_sirena_adapter,
                    internal_payments_adapter=self.internal_payments_adapter,
                    messenger=self.messenger,
                ).run()
            except Exception as sub_ex:
                self.logger.exception(str(sub_ex))
            self._set_status(exchange, ExchangeStatus.ERROR)
            exchange.set_error(ex)
            self._update_exchange(exchange)
        else:
            self._update_ssr(order=order, exchange=exchange)
            from rest.applications.celery_app.tasks.exchange import payments_confirm_fast_task
            payments_confirm_fast_task.delay(
                exchange_uuid=exchange.exchange_uuid,
                exchange_pricing_response=exchange_pricing_response
            )
        return BaseUseCaseResponse(value=dict(result=True))

    def _is_skip_flow(self, exchange: DomainExchange) -> bool:
        if exchange.status != exchange.status.WAIT_RECEIPT:
            return True
        if exchange.payment.state != PaymentState.HELD.value:
            return True
        return False

    def _receipts_data(
            self,
            order: DomainOrder,
            exchange: DomainExchange,
            passengers: List[ExchangeablePassenger],
    ) -> DomainReceiptsData:
        """
        Получение документов и проверяем, всё ли пришло
        """
        pax_by_ticket_mapper = order.get_pax_by_ticket_mapper()
        response = self.internal_sirena_adapter.get_receipts_data(
            rloc=order.data.rloc,
            last_name=passengers[0].passenger.last_name,
        )
        receipts_data: DomainReceiptsData = DomainReceiptsData.deserialize_by_raw(raw=response)
        receipts_data.mutate_by_old_data(exchange.old_receipts_data)
        # Проверяем появились ли новые тикеты. Если нет, то повторим чуть позже
        if not CheckDocuments(
            receipts_data=receipts_data,
            pax_by_ticket_mapper=pax_by_ticket_mapper,
            exchange_passenger_ids=[pax.passenger.passenger_id for pax in passengers],
        ).run():
            raise NewTicketNotFound()
        return receipts_data

    def _save_sale_parts(
            self,
            order: DomainOrder,
            exchange: DomainExchange,
            exchange_pricing_response: dict,
            selected_passengers: List[ExchangeablePassenger],
    ):
        self.logger.info(f'Receipt data {exchange.exchange_uuid}')
        receipts_data = self._receipts_data(
            order=order,
            exchange=exchange,
            passengers=selected_passengers,
        )
        self.logger.info(f'Generate sale parts {exchange.exchange_uuid}')
        ticket_results = ProcessTicketResult(
            exchange_pricing_response=exchange_pricing_response,
            receipts_data=receipts_data,
            pax_by_ticket_mapper=order.get_pax_by_ticket_mapper(),
            invoice_id=exchange.payment.invoice,
        ).run()
        part_generator = PartGenerator(results=ticket_results)
        exchange.payment.sale_parts = part_generator.generate_sale_parts()
        exchange.payment.exchange_income_parts = part_generator.generate_exchange_income_parts()
        exchange.payment.exchange_refund_parts = part_generator.generate_exchange_refund_parts()
        self._update_exchange(exchange)
        if not exchange.valid_confirm_price():
            raise NotValidConfirmPrice()

    def _update_ssr(self, order: DomainOrder, exchange: DomainExchange):
        # При сплите могли запомнить ssr_requests. Иначе ищем в текущем
        if exchange.ssr_requests:
            ssr_requests: Optional[List[DomainSSRRequest]] = exchange.ssr_requests
        else:
            ssr_requests: Optional[List[DomainSSRRequest]] = ReplaceSSR(
                order=order,
                exchange=exchange,
                ssr_type='FQTV',
                logger=self.logger,
                segment_status_visual='exchanged',
            ).run()
        if not ssr_requests:
            return
        from rest.applications.celery_app.tasks.add_ssrs import add_ssr
        add_ssr.delay(
            order_uuid=order.data.order_uuid,
            rloc=order.data.rloc,
            last_name=ssr_requests[0].units[0].surname,
            ssrs=[x.serialize() for x in ssr_requests]
        )
