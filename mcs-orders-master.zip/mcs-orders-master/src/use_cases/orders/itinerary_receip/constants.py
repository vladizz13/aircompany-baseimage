from enum import Enum


class GetItineraryReceiptFilters(Enum):
    """
    Допустимые значения в filters для юзкейса получения маршрутной квитанции
    (для поиска заказа в базе)
    """
    ORDER_UUID = 'order_uuid'
    LAST_NAME = 'last_name'
