from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.user import InvalidLastNameError, InvalidOrderUUIDError


class GetItineraryReceiptRequest(BaseOrderRequest):
    """
    Сериализатор, валидатор входных данных.
    """

    def __init__(self, order_uuid: str = None, last_name: str = None, tais_look_up: bool = True) -> None:
        super().__init__()
        self.order_uuid = str(order_uuid)
        self.last_name = last_name
        self.tais_look_up = tais_look_up

    def is_valid(self, *args, **kwargs) -> 'GetItineraryReceiptRequest':
        if not self.order_uuid:
            self.add_error(InvalidOrderUUIDError())

        if not self.last_name:
            self.add_error(InvalidLastNameError())

        return self

    def serialize(self) -> dict:
        return {'order_uuid': self.order_uuid, 'last_name': self.last_name}

    @classmethod
    def deserialize(cls, data: dict) -> 'GetItineraryReceiptRequest':
        return cls(order_uuid=data.get('order_uuid'), last_name=data.get('last_name'))
