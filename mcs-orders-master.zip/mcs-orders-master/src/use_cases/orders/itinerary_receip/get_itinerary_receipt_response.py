from use_cases.orders.base_order_use_case import BaseOrderResponse


class GetItineraryReceiptResponse(BaseOrderResponse):

    def __init__(self, download_link: str = None):
        super().__init__(self.serialize(download_link))

    @staticmethod
    def serialize(download_link: str = None):
        if not download_link:
            return {'download_link': None}
        return {'download_link': download_link}
