import time
import typing as T
from base64 import b64decode
from datetime import datetime
from io import BytesIO
from uuid import uuid4

from base.exception import ApplicationError
from domain.types import TransactionSource, CompanyPPR
from domain.pd_changes import DomainPDChanges
from tais_xml_client.exceptions import BaseTAISError
from adapter.file_storage_adapter import FileStorageAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from adapter.tais_adapter import TaisInternalAdapter
from sirena_xml_client.exceptions import (
    SirenaPnrAndSurnameDontMatch,
    SirenaUnableToFindReceiptForPnr,
    SirenaOrderNotFound,
    SirenaAccessToPnrDenied,
)
from domain import DomainOrder
from libs.query_builder import AndQueryUnit, QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders import OrdersQueryBuilder
from repositories.query_builders.pd_changes import PDChangesQueryBuilder
from use_cases.orders.exceptions.itinerary_receip import (
    FailedToRequestSirenaGRSError,
    TicketDecodeError,
    DownloadURLGenerationError,
    CanReturnAvailableActionError
)
from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.orders.itinerary_receip.constants import GetItineraryReceiptFilters
from use_cases.orders.itinerary_receip.get_itinerary_receipt_request import (
    GetItineraryReceiptRequest,
)
from use_cases.orders.itinerary_receip.get_itinerary_receipt_response import (
    GetItineraryReceiptResponse,
)
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase


class GetItineraryReceiptUseCase(BaseSearchOrderUseCase):
    """
    Юзкейс получения файла машрутной квитанции.
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        sirena_adapter: SirenaInternalAdapter,
        tais_adapter: TaisInternalAdapter,
        filestorage_adapter: FileStorageAdapter,
        save_order_func: T.Callable,
        change_pd_repo: GenericMongoRepository
    ) -> None:
        super().__init__(
            order_repo=order_repo,
            sirena_adapter=sirena_adapter,
        )
        self.tais_adapter = tais_adapter
        self.filestorage_adapter = filestorage_adapter
        self.save_order_func = save_order_func
        self.change_pd_repo = change_pd_repo

    def __execute__(
        self, request: GetItineraryReceiptRequest, *args, **kwargs
    ) -> GetItineraryReceiptResponse:
        """
        Основной сценарий выполнения бизнес-логики.
        :param request: объект входных данных
        :param args: остальные аргументы, переданные позиционно
        :param kwargs: остальные аргументы, переданные по ключу
        :return: объект выходных данных
        """
        order = self.get_order(request)

        if not order:
            return GetItineraryReceiptResponse.build_from_exception(OrderNotFoundError())

        if not order.data.available_actions.can_print_mk:
            return GetItineraryReceiptResponse.build_from_exception(CanReturnAvailableActionError())

        if not any((
            'Q' in [seg.rbd for seg in order.data.segments],
            order.data.pos_data.pos_id == CompanyPPR.SIRENA_CLIENT444.value
        )):
            try:
                self.update_order(order)
                download_link = self.get_itinerary_receipt_from_tais(order.data.order_id)
                return GetItineraryReceiptResponse(download_link)
            except Exception:
                pass

        try:
            if self.is_order_archived(order):
                # Пробуем разархивировать заказ
                self.sirena_adapter.un_archive_order(order.data.rloc)
            encoded_file = self.get_itinerary_receipt_from_sirena(order.data.rloc, request.last_name)
        except (
            SirenaPnrAndSurnameDontMatch,
            SirenaUnableToFindReceiptForPnr,
            SirenaOrderNotFound,
            SirenaAccessToPnrDenied
        ) as e:
            return GetItineraryReceiptResponse.build_from_exception(FailedToRequestSirenaGRSError(message=e.message))
        except Exception as e:
            self.logger.exception('Не удалось получить маршрутную квитанцию из Sirena: {}'.format(str(e)))
            return GetItineraryReceiptResponse.build_from_exception(FailedToRequestSirenaGRSError())

        try:
            binary_itinerary_receipt = self.decode_file(encoded_file)
        except Exception as e:
            self.logger.exception('Не удалось расшифровать маршрутную квитанцию из Sirena: {}'.format(str(e)))
            return GetItineraryReceiptResponse.build_from_exception(TicketDecodeError())

        try:
            download_link = self.save_itinerary_receipt(binary_itinerary_receipt, order)
        except Exception as e:
            self.logger.exception(f'Не удалось сгенерировать ссылку на скачивание маршрутной квитанции: {str(e)}')
            return GetItineraryReceiptResponse.build_from_exception(DownloadURLGenerationError())
        return GetItineraryReceiptResponse(download_link)

    def update_order(self, order: DomainOrder):
        """
        Отложенно обновляет заказ из таиса
        Синкает таис с сиреной, если для этого достаточно данных
        https://jira.utair.ru/browse/UTBCKN-2940
        """
        # Синкать только если была смена данных
        pd_changes: T.Optional[DomainPDChanges] = self.change_pd_repo.get_single(
            spec=PDChangesQueryBuilder.get_by_order_uuid(order.data.order_uuid)
        )
        if not pd_changes:
            return

        if all((order.data.order_id, order.data.rloc)):
            try:
                orders: T.List[T.Dict] = self.tais_adapter.search_orders(
                    rloc=order.data.rloc,
                    last_name=order.data.passengers[0].last_name,
                    sirena_sync=True,
                )
                for order in orders:
                    self.save_order_func(
                        raw_order=order,
                        provider=TransactionSource.TAIS.value,
                        message_id=str(uuid4()),
                        received=time.time(),
                        deferred_save=True
                    )
            except (ApplicationError, BaseTAISError):
                # https://jira.utair.ru/browse/UTBCKN-2940
                # не падаем, лучше отдать какую-то МК, чем никакой
                pass

    def get_order(self, request) -> DomainOrder:
        filters: T.Dict = {'order_uuid': request.order_uuid, 'last_name': request.last_name}
        query: AndQueryUnit = self.__build_search_query__(filters)
        order: DomainOrder = self.order_repo.get_single(query)
        return order

    def get_itinerary_receipt_from_tais(self, order_id) -> str:
        tiket = self.tais_adapter.get_ticket(order_id)
        download_link = tiket.get('pdf_link')
        return download_link

    def get_itinerary_receipt_from_sirena(self, rloc, last_name):
        return self.sirena_adapter.get_itinerary_receipt(rloc, last_name)

    @staticmethod
    def decode_file(encrypted_itinerary_receipt) -> bytes:
        binary_itinerary_receipt = b64decode(encrypted_itinerary_receipt, validate=True)
        if binary_itinerary_receipt[0:4] != b'%PDF':
            raise ValueError('Missing the PDF file signature')
        return binary_itinerary_receipt

    def save_itinerary_receipt(self, file_data, order) -> str:
        departure_date = datetime.fromtimestamp(order.data.departure_start_timestamp).date()
        file_name = f'{order.data.order_uuid}_{departure_date}_' \
                    f'{order.data.departure_point}-{order.data.arrival_point}.pdf'

        with BytesIO(file_data) as steam:
            self.filestorage_adapter.upload_binary_file(steam, file_name)

        download_link = self.filestorage_adapter.get_download_url(file_name)
        return download_link

    def __map_query_units__(self, param: str, value: T.Any) -> QueryUnit:
        """
        Мапим фильтры к подходящему поисковому запросу из OrdersQueryBuilder
        """
        mapping = {
            GetItineraryReceiptFilters.LAST_NAME.value: OrdersQueryBuilder.get_by_passenger_last_name,
            GetItineraryReceiptFilters.ORDER_UUID.value: OrdersQueryBuilder.get_by_order_uuid,
        }
        return mapping[param](value)
