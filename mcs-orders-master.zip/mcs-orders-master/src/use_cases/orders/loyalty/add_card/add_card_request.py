import re
from typing import List, Dict
from use_cases.orders.base_order_use_case import BaseOrderRequest
from ...exceptions.user import InvalidRlocError, InvalidInputFieldsError
from .passenger_dto import PassengerDTO
from .input_types import AddLoyaltyCardFilters


class AddLoyaltyCardRequest(BaseOrderRequest):

    rloc_pattern = re.compile('^[0-9A-Z-/]+$')

    def __init__(
            self,
            filters: dict = None,
            passengers_data: List[Dict] = None
    ):
        super().__init__()
        self.filters = filters
        passengers_data = passengers_data if passengers_data else []
        try:
            self.passenger_data: List[PassengerDTO] = [PassengerDTO.deserialize(p) for p in passengers_data]
        except TypeError as e:
            self.add_error(InvalidInputFieldsError(message=str(e)))

    def is_valid(self, *args, **kwargs) -> 'AddLoyaltyCardRequest':
        if not self.filters:
            self.filters = dict()

        if not self.filters.get(
                AddLoyaltyCardFilters.RLOC.value, None
        ) or not bool(self.rloc_pattern.match(self.filters.get(AddLoyaltyCardFilters.RLOC.value, None))):
            self.add_error(InvalidRlocError())

        return self

    def serialize(self) -> dict:
        return {
            'filters': self.filters,
            'passengers_data': [p.serialize() for p in self.passenger_data],
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            filters=data.get('filters', {}),
            passengers_data=data.get('passengers_data', [])
        )
