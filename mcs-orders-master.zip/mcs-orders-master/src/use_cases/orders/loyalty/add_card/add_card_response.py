from typing import List
from use_cases.orders.loyalty.add_card.passenger_dto import PassengerDTO
from use_cases.orders.base_order_use_case import BaseOrderResponse


class AddLoyaltyCardResponse(BaseOrderResponse):

    def __init__(self, value: List[PassengerDTO] = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: List[PassengerDTO] = None):
        if not value:
            return {'passengers': []}
        [p.set_status() for p in value]
        return {'passengers': [v.serialize_for_response() for v in value]}
