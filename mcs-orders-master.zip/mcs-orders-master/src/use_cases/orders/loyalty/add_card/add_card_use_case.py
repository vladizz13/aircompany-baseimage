import time
from typing import Any, Union, Type, List, Dict, Optional, Set
from base.exception import ApplicationError
from sirena_xml_client.types import SegmentForAddFFInfo, PassengerForAddFFInfo
from domain import DomainOrder
from domain.order.data.segment import DomainSegment
from domain.types import TransactionSource, SegmentStatus
from adapter.monoapp import MonoAppAdapter
from adapter.monoapp.exceptions import (
    CardDoesNotExist,
    BonusAccountNotFoundError,
    UserNotFoundError,
    CardBelongsToDifferentUserError,
    UserIsNotCompletelyRegisteredError
)
from libs.query_builder import QueryUnit, AndQueryUnit
from libs.rpc_client.exceptions import RPCServiceError
from repositories.query_builders.order import OrdersQueryBuilder
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from mcs_oauth_client.domain.user import DomainUser
from adapter.sirena_adapter import SirenaInternalAdapter, SirenaPnrAndSurnameDontMatch
from use_cases.shared.order_processor import OrderProcessorMixIn
from .add_card_request import AddLoyaltyCardRequest
from .add_card_response import AddLoyaltyCardResponse
from .input_types import AddLoyaltyCardFilters
from .passenger_dto import AddLoyaltyCardErrors
from ...exceptions.loyalty import OrderNotFoundError, AllSegmentAreFlownError, FailedToRequestSirenaGRSError


class AddLoyaltyCardUseCase(BaseSearchOrderUseCase, OrderProcessorMixIn):
    """
    Юзкейс добавления карты лояльности пользователю
    """
    # Если мы не нашли заказ в базе, мы идем в сирену и ищем его там
    # В случае если транзакция записана, нам не нужно еще раз ходить в сирену после проверки ssr
    # так как броня была только что обновлена
    # Так же эта транзакция будет использоваться для получения id пассажиров и сегментов от сирены
    sirena_origin_transaction: Optional[Dict] = None

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            sirena_adapter: SirenaInternalAdapter,
            mono_app_adapter: MonoAppAdapter,
            internal_order_adapter: Type[InternalOrderAdapter]
    ):
        super().__init__(
            order_repo=order_repo,
            mono_app_adapter=mono_app_adapter,
            sirena_adapter=sirena_adapter,
            internal_order_adapter=internal_order_adapter
        )
        # ID непролетанных сегментов из системы SirenaGRS
        self.unflown_segment_ids: Dict[str, str] = dict()

    def __execute__(self, request: AddLoyaltyCardRequest, *args, **kwargs) -> AddLoyaltyCardResponse:
        query: AndQueryUnit = self.__build_search_query__(request.filters)
        order: DomainOrder = self.order_repo.get_single(query)
        if not order:
            # Пробуем найти в сирене
            order: DomainOrder = self.__search_in_sirena(request, force_search=True)
            if not order:
                return AddLoyaltyCardResponse.build_from_exception(OrderNotFoundError())

        # Проверка на наличие пассажиров в броне, обогащение данными из брони
        self.prepare_passengers_data(order, request)
        # Запросы на валидацию карт в моноапп
        self.verify_passengers(request)
        # Получение loyalty_card из юзеров в моноапп по userId
        self.enrich_passengers_with_loyalty_card(request)
        # Проверяем полученные карты на наличие в заказе, если уже были добавлены
        self.check_loyalty_card_already_exists(order, request)

        # Если у всех пассажиров флаг невозможности продолжения - возвращаем как есть
        if all([not p.is_allowed_to_proceed() for p in request.passenger_data]):
            return AddLoyaltyCardResponse(request.passenger_data)

        # Если изначально заказ достали из базы, то в сирену нужно сходить
        if not self.sirena_origin_transaction:
            # Пересохраняем заказ из сирены
            order: DomainOrder = self.__search_in_sirena(request)
            if not order:
                return AddLoyaltyCardResponse.build_from_exception(OrderNotFoundError(
                    message="Order not found in sirena grs, unable to check if loyalty card already exists"
                ))
            # Еще раз проверяем ssrs
            self.check_loyalty_card_already_exists(order, request)

        try:
            # Проставляем айди пассажира из сирены во все PassengerDTO
            self.set_sirena_passenger_id(request)
            # Получаем айди непролетанных сегментов из SirenaGRS
            self.set_unflown_segment_ids(order)
        except ApplicationError as e:
            return AddLoyaltyCardResponse.build_from_exception(e)

        if not self.unflown_segment_ids:
            return AddLoyaltyCardResponse.build_from_exception(AllSegmentAreFlownError())

        try:
            response: AddLoyaltyCardResponse = self.make_sirena_grs_add_ff_request(request, order)
        except FailedToRequestSirenaGRSError:
            return AddLoyaltyCardResponse.build_from_exception(FailedToRequestSirenaGRSError())

        try:
            self.internal_order_adapter().update_from_sirena_grs(order.data.order_uuid)
        except ApplicationError as e:
            self.logger.info(f'Не удалось обновить заказ {order.data.rloc}-{order.data.order_uuid} {e.message}')

        return response

    def make_sirena_grs_add_ff_request(
        self,
        request: AddLoyaltyCardRequest,
        order: DomainOrder
    ) -> AddLoyaltyCardResponse:
        """
        Делаем запрос в Сирену и возвращаем AddLoyaltyCardResponse
        """
        rloc: str = request.filters.get(AddLoyaltyCardFilters.RLOC.value)
        # Фамилия любого пассажира, который прошел предыдущие проверки
        try:
            last_name: str = next(p for p in request.passenger_data if p.is_allowed_to_proceed()).last_name
        except StopIteration:
            return AddLoyaltyCardResponse(request.passenger_data)

        passenger_requests: List[PassengerForAddFFInfo] = list()
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed():
                continue
            segments_to_request: List[SegmentForAddFFInfo] = []
            for s in self.segments_to_add_loyalty_card_by_pax_id(order, passenger.internal_passenger_id):
                sirena_seg_id = self.unflown_segment_ids.get(s)
                segments_to_request.append(SegmentForAddFFInfo(segment_id=sirena_seg_id))

            passenger_requests.append(PassengerForAddFFInfo(
                passenger_id=passenger.sirena_passenger_id,
                loyalty_card=passenger.loyalty_card,
                segments=segments_to_request
            ))

        result: Union[dict, None] = self.sirena_adapter.add_ff_info(
            rloc=rloc,
            last_name=last_name,
            passengers=passenger_requests
        )
        try:
            error = result.get('answer', {}).get('add_ff_info', {}).get('error', {}).get('text', None)
            if error:
                for passenger in request.passenger_data:
                    if not passenger.is_allowed_to_proceed():
                        continue
                    passenger.add_exception(error)
            return AddLoyaltyCardResponse(request.passenger_data)
        except AttributeError:
            raise FailedToRequestSirenaGRSError()

    def set_unflown_segment_ids(self, order: DomainOrder):
        """
        Получаем id всех непролетанных сегментов от сирены
        """
        unflown_segments: List[DomainSegment] = self.get_unflown_segments_from_order(order)

        real_sirena_segment_ids_map: Dict[str, str] = self.get_segment_hash_to_sirena_real_id(
            raw_order=self.sirena_origin_transaction
        )
        for segment in unflown_segments:
            self.unflown_segment_ids.update({
              segment.segment_id: real_sirena_segment_ids_map[segment.get_hash()]
            })

    @staticmethod
    def get_unflown_segments_from_order(order: DomainOrder) -> List[DomainSegment]:
        unflown_segments: List[DomainSegment] = list()
        for segment in order.data.segments:
            if time.time() >= segment.departure_timestamp:
                continue
            if segment.status not in (SegmentStatus.HK.value, SegmentStatus.TK.value):
                continue
            unflown_segments.append(segment)
        return unflown_segments

    def set_sirena_passenger_id(self, request: AddLoyaltyCardRequest):
        """
        Проставляем пассажирам айдишники из системы сирены
        """
        sirena_passengers: List[Dict] = self.__get_sirena_pnr().get('passengers', {}).get('passenger', []) or []
        doc_number_to_sirena_id_map: Dict = {p.get('doc'): p.get('@id') for p in sirena_passengers}
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed():
                continue
            passenger.sirena_passenger_id = doc_number_to_sirena_id_map.get(passenger.doc_number)

    def __get_sirena_pnr(self) -> Dict:
        """
        Достать тело PNR и оригинальной транзакции сирены
        """
        return self.sirena_origin_transaction.get('order', {}).get('pnr', {})

    def check_loyalty_card_already_exists(self, order: DomainOrder, request: AddLoyaltyCardRequest):
        """
        Проверяем была ли уже добавлена карта в заказ
        """
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed():
                continue

            if not self.segments_to_add_loyalty_card_by_pax_id(order, passenger.internal_passenger_id):
                passenger.add_exception(AddLoyaltyCardErrors.ALREADY_EXISTS.value)

    def segments_to_add_loyalty_card_by_pax_id(
        self,
        order: DomainOrder,
        passenger_id: str
    ) -> Set[str]:
        """
        Проверить, есть ли карта лояльности у переданных пассажиров
        на КАЖДЫЙ сегмент.
        """
        unflown_segment_ids = {s.segment_id for s in self.get_unflown_segments_from_order(order)}
        ssrs_with_card = {s.segment_id for s in order.data.ssrs if s.passenger_id == passenger_id and s.ssr == "FQTV"}
        available_segments_id = unflown_segment_ids - ssrs_with_card

        return available_segments_id

    def enrich_passengers_with_loyalty_card(self, request: AddLoyaltyCardRequest):
        """
        Получаем карты лояльности из пользователей
        """
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed():
                continue
            try:
                user: DomainUser = self.mono_app_adapter.get_user_by_user_id(
                    passenger.verification_status.get('user_id')
                )
                passenger.loyalty_card = user.status.card_no
            except UserNotFoundError as e:
                passenger.add_exception(e.message)

    def verify_passengers(self, request: AddLoyaltyCardRequest):
        """
        Запрос валидации пассажиров
        """
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed():
                continue
            try:
                passenger.verification_status = self.mono_app_adapter.verify_level_status(
                    login=passenger.get_login(),
                    login_type=passenger.login_type,
                    first_name=passenger.first_name,
                    last_name=passenger.last_name,
                    birthday=passenger.birthday
                )
            except (
                    BonusAccountNotFoundError,
                    CardDoesNotExist,
                    CardBelongsToDifferentUserError,
                    UserIsNotCompletelyRegisteredError
            ) as e:
                passenger.add_exception(f'{AddLoyaltyCardErrors.UNABLE_TO_VALIDATE.value}: {e.message}')
            except RPCServiceError as e:
                self.logger.info(e)
                passenger.add_exception(f'{AddLoyaltyCardErrors.UNABLE_TO_VALIDATE.value}: {e.message}')

    @staticmethod
    def prepare_passengers_data(order: DomainOrder, request: AddLoyaltyCardRequest):
        """
        Проверка на наличие переданных пассажиров в броне
        Добавление внутреннего id пассажира
        Добавление даты рождения
        Заполнение полей ошибок
        """
        # В броне могут быть однофамильцы, поэтому нам нужны фамилии с дубликатами
        passenger_last_names: List[str] = [p.last_name.lower() for p in order.data.passengers]

        last_name_to_id_map: Dict[str, str] = {p.last_name.lower(): p.passenger_id for p in order.data.passengers}
        id_to_first_name_map: Dict[str, str] = {p.passenger_id: p.first_name for p in order.data.passengers}

        doc_number_to_id_map: Dict[str, str] = {d.docnumber: d.passenger_id for d in order.data.documents}
        id_to_doc_number_map: Dict[str, str] = {d.passenger_id: d.docnumber for d in order.data.documents}
        id_to_birthday_map: Dict[str, str] = {d.passenger_id: d.birthday for d in order.data.documents}

        for passenger in request.passenger_data:
            # Ищем по номеру документа, если есть
            if passenger.doc_number and passenger.doc_number in doc_number_to_id_map:
                passenger.is_present_in_order = True
                passenger.internal_passenger_id = doc_number_to_id_map.get(passenger.doc_number)
                passenger.birthday = id_to_birthday_map.get(passenger.internal_passenger_id)
                passenger.first_name = id_to_first_name_map.get(passenger.internal_passenger_id)
                continue
            # Ищем по фамилии
            if passenger.last_name.lower() in last_name_to_id_map:
                if passenger_last_names.count(passenger.last_name.lower()) > 1:
                    passenger.add_exception(AddLoyaltyCardErrors.UNABLE_TO_IDENTIFY_PASSENGER.value)
                    continue
                passenger.is_present_in_order = True
                passenger.internal_passenger_id = last_name_to_id_map.get(passenger.last_name.lower())
                passenger.birthday = id_to_birthday_map.get(passenger.internal_passenger_id)
                passenger.first_name = id_to_first_name_map.get(passenger.internal_passenger_id)
                # Добавляем doc_number чтобы далее вытащить по нему номер сиреновского пассажира
                passenger.doc_number = id_to_doc_number_map.get(passenger.internal_passenger_id)
                continue
            passenger.add_exception(AddLoyaltyCardErrors.PASSENGER_NOT_FOUND.value)

    def __map_query_units__(self, param: str, value: Any) -> QueryUnit:
        """
        Мапим фильтры к подходящему поисковому запросу из OrdersQueryBuilder
        """
        map = {
            AddLoyaltyCardFilters.RLOC.value: OrdersQueryBuilder.get_by_order_rloc_extended,
        }
        return map[param](value)

    def __search_in_sirena(
            self,
            request: AddLoyaltyCardRequest,
            force_search: bool = False
    ) -> Union[DomainOrder, None]:
        """
        Поиск заказа в сирене
        :param force_search: Искать не смотря на то, что флаг пассажира not is_allowed_to_process
        """
        for passenger in request.passenger_data:
            if not passenger.is_allowed_to_proceed() and not force_search:
                continue
            try:
                sirena_raw_order = self.sirena_adapter.search_order(
                    rloc=request.filters.get(AddLoyaltyCardFilters.RLOC.value),
                    last_name=passenger.last_name,
                )
            except SirenaPnrAndSurnameDontMatch:
                sirena_raw_order = None
            self.sirena_origin_transaction = sirena_raw_order
            if sirena_raw_order:
                return self.__save_new_order__(sirena_raw_order, TransactionSource.SIRENA_GRS.value)
