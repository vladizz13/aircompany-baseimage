from enum import Enum


class AddLoyaltyCardFilters(Enum):
    """
    Допустимые значения в filters для AddLoyaltyCard юзкейса
    (для поиска заказа в базе)
    """
    RLOC = 'rloc'
