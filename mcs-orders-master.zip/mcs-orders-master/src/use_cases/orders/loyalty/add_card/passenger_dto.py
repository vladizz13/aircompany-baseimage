from typing import List, Dict, Optional
from enum import Enum


class AddLoyaltyCardErrors(Enum):
    """
    Ошибки, которые могут возникнуть в течении всего флоу
    добавления карты лояльности
    """
    ALREADY_EXISTS = "Номер карты уже указан у данного пассажира"
    UNABLE_TO_VALIDATE = "Карта лояльности не прошла валидацию"
    UNABLE_TO_IDENTIFY_PASSENGER = "Не удалось идентифицировать пассажира по фамилии"
    PASSENGER_NOT_FOUND = "Пассажир в броне не найден"
    UNABLE_TO_DEFINE_LOGIN_TYPE = "Не удалось вычислить тип верификаци. Укажите телефон/почту/карту лояльности"


class LoginType(Enum):
    """
    Типы верификации
    """
    EMAIL = 'email'
    PHONE = 'phone'
    CARD_NUMBER = 'card_number'


class ResultStatus(Enum):
    """
    Статус результата добавления карты лояльности
    """
    OK = 'OK'
    ERROR = 'ERROR'


class PassengerDTO(object):
    """
    DTO Объект пассажира для добавления карты лояльности
    """

    status: str                        # Статус результата добавления карты лояльности

    is_present_in_order: bool                    # Присуствует ли пользователь в заказе
    sirena_passenger_id: Optional[str]           # ID пассажира в системе сирены
    internal_passenger_id: Optional[str]         # ID пассажира внутри DomainOrder.DomainPassenger

    login_type: Optional[str]               # Тип верификации карты

    first_name: Optional[str]     # Имя будет взято из заказа если пассажир в нем найдется
    last_name: str                # Обязательное поле

    # Любое поле из представленных ниже должно быть
    # заполненно в паре с фамилией
    doc_number: Optional[str]
    loyalty_card: Optional[str]
    phone_number: Optional[str]
    email: Optional[str]

    # Дата рождения будет взята из заказа, если пассажир в нем найдется
    birthday: Optional[str]

    # Ошибки добавления карты для конкретного пассажира
    exceptions: List[str]

    # Ответ от метода верификации карты статус
    verification_status: Optional[Dict]

    def __init__(
            self,
            last_name: str = None,
            doc_number: str = None,
            loyalty_card: str = None,
            phone_number: str = None,
            email: str = None
    ):
        self.is_present_in_order = False
        self.sirena_passenger_id = None
        self.internal_passenger_id = None

        self.first_name = None

        self.last_name = last_name
        self.doc_number = doc_number
        self.loyalty_card = loyalty_card
        self.phone_number = phone_number
        self.email = email

        self.birthday = None

        self.exceptions = list()
        self.verification_status = None
        self.login_type = None

        self.verify()
        self.__set_login_type()
        self.set_status()

    def is_allowed_to_proceed(self) -> bool:
        """
        Имеет смысл продолжать работу с пассажиром
        если status == OK
        и данные для запроса присутсвуют
        При каждом вызове будет проверятся self.exceptions на наличие ошибок
        """
        self.set_status()
        return all([
            self.status == ResultStatus.OK.value,
            self.is_present_in_order,
            self.internal_passenger_id
        ])

    def set_status(self):
        """
        Проставление статуса в зависимости от наличия ошибок
        Здесь можно игнорировать ошибки, которые не влияют на добавление карты либо тюнить их
        """
        self.status = ResultStatus.OK.value if not self.exceptions else ResultStatus.ERROR.value

    def add_exception(self, message: str):
        self.exceptions.append(message)

    def get_login(self) -> str:
        """
        Получаем логин для отправки карты на валидацию по его типу
        """
        login_map = {
            LoginType.PHONE.value: self.phone_number,
            LoginType.EMAIL.value: self.email,
            LoginType.CARD_NUMBER.value: self.loyalty_card
        }
        return login_map.get(self.login_type)

    def __set_login_type(self):
        """
        Проставление типа верификации карты статус
        Если переданны все данные, то выставляем оп приоритету
        Карта->телефон->почта
        """
        if self.loyalty_card:
            self.login_type = LoginType.CARD_NUMBER.value
        elif self.phone_number:
            self.login_type = LoginType.PHONE.value
        elif self.email:
            self.login_type = LoginType.EMAIL.value
        else:
            self.exceptions.append(AddLoyaltyCardErrors.UNABLE_TO_DEFINE_LOGIN_TYPE.value)

    def verify(self) -> bool:
        """
        Проверка на наличие комбинации нужных для запроса полей
        """
        if self.exceptions:
            return False
        if any([
            (self.last_name and self.doc_number),
            (self.last_name and self.loyalty_card),
            (self.last_name and self.phone_number),
            (self.last_name and self.email)
        ]):
            return True
        self.exceptions.append("Недостаточно данных пассажира для добавления карты лояльности")
        return False

    @classmethod
    def deserialize(cls, data: dict) -> 'PassengerDTO':
        return cls(**data)

    def serialize(self) -> dict:
        return {
            'status': self.status,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'doc_number': self.doc_number,
            'loyalty_card': self.loyalty_card,
            'phone_number': self.phone_number,
            'email': self.email,
            'birthday': self.birthday,
            'exceptions': self.exceptions
        }

    def serialize_for_response(self) -> dict:
        """
        Сериализация полей для ответа метода добавления карты лояльности
        """
        # Для фронта берем первую ошибку
        error = self.exceptions[0] if self.exceptions else None

        return {
            'first_name': self.first_name,
            'last_name': self.last_name,
            'elite_tier': self.verification_status.get('status') if self.verification_status else None,
            'status': self.status,
            'error': error
        }
