from use_cases.orders.base_order_use_case import BaseOrderRequest
from ...exceptions.loyalty import InvalidLoyaltyRequest


class GetOrderDetailPriceRequest(BaseOrderRequest):

    def __init__(
            self,
            ticket_number: str = None,
            lastname: str = None,
            rloc: str = None,
    ):
        super().__init__()
        self.rloc = rloc
        self.passenger_lastname = lastname
        self.passenger_ticket_number = ticket_number

    def is_valid(self, *args, **kwargs) -> 'GetOrderDetailPriceRequest':
        if not self.passenger_lastname:
            self.add_error(InvalidLoyaltyRequest(message="last_name is required field"))
        if not self.passenger_ticket_number:
            self.add_error(InvalidLoyaltyRequest(message="ticket_number is required field"))
        return self

    def serialize(self) -> dict:
        return {key: value for key, value in self.__dict__.items() if key != 'errors' and value is not None}

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            rloc=data.get('rloc', None),
            lastname=data.get('lastname', None),
            ticket_number=data.get('ticket_number', None)
        )
