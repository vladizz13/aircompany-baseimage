from typing import List
from domain.types import FopsCode
from domain.order.data.fop import DomainFop
from domain.order.data.document import DomainDocument
from use_cases.orders.base_order_use_case import BaseOrderResponse


class GetOrderDetailPriceResponse(BaseOrderResponse):

    def __init__(
            self,
            fops: List[DomainFop] = None,
            ticket_number: str = None,
            total_with_agency_tax: int = 0,
            total: int = 0,
            coupons_count: int = 0,
            document: DomainDocument = None,
    ):
        super().__init__(self.serialize(
            fops=list() if fops is None else fops,
            ticket_number=ticket_number,
            total=total,
            total_with_agency_tax=total_with_agency_tax,
            coupons_count=coupons_count,
            document=document,
        ))

    def serialize(
            self,
            fops: List[DomainFop],
            ticket_number: str,
            total: int = 0,
            total_with_agency_tax: int = 0,
            coupons_count: int = 0,
            document: DomainDocument = None,
    ):
        return {
            "tickets": {
                ticket_number: {
                    'total_with_agency_tax': total_with_agency_tax,
                    'total': total,
                    'coupons_count': coupons_count,
                    FopsCode.FF.value: self.get_fops_ff_amount(fops),
                    'document': document.serialize() if document else None,
                }
            }
        }

    @staticmethod
    def get_fops_ff_amount(fops: List[DomainFop]) -> int:
        ff_amount: int = 0
        for fop in fops:
            ff_amount += int(fop.amount) if fop.amount else 0
        return int(ff_amount)
