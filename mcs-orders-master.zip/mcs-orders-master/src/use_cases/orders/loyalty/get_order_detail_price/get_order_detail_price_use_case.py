import re
import time
import uuid
from typing import Type, List, Optional, Dict, Union, Any

from pymongo import DESCENDING
from sirena_xml_client.exceptions import SirenaPnrAndSurnameDontMatch, BaseSirenaError

from adapter.sirena_adapter import SirenaInternalAdapter
from base.exception import ApplicationError
from domain import DomainOrder
from domain.order.data.fop import DomainFop
from domain.order.data.remark import DomainRemark
from domain.order.data.ticket import DomainTicket, DomainTaxes
from domain.order.data.document import DomainDocument
from domain.types import FopsCode
from domain.types import TicketMonetaryCode
from domain.types import TransactionSource, GDS
from libs.query_builder import QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import AndQueryUnit
from repositories.query_builders.order import OrdersQueryBuilder
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.exceptions.loyalty import OrderNotFoundError
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from use_cases.orders.search.input_types.internal import InternalScopeFilters
from .get_order_detail_price_request import GetOrderDetailPriceRequest
from .get_order_detail_price_response import GetOrderDetailPriceResponse


class GetOrderDetailPriceUseCase(BaseSearchOrderUseCase):
    """
    Юзкейс расчета цен для лояльности по заказу
    Мили/Рубли/Emd
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository,
        transaction_repo: GenericMongoRepository,
        sirena_adapter: SirenaInternalAdapter,
        internal_order_adapter: Type[InternalOrderAdapter],
    ):
        super().__init__(
            order_repo=order_repo, sirena_adapter=sirena_adapter, internal_order_adapter=internal_order_adapter
        )
        self.transaction_repo: GenericMongoRepository = transaction_repo
        self.saved_from_sirena: bool = False
        self.fops_found_by_free_text: Optional[bool] = None

    def __execute__(self, request: GetOrderDetailPriceRequest, *args, **kwargs) -> GetOrderDetailPriceResponse:
        """
        Метод, содержащий основную логику функционала getOrderDetailPrice

        :param request: объект входных данных
        :param args: прочие позиционные аргументы
        :param kwargs: прочие именованные аргументы
        :return:
        """
        try:
            # Ищем в БД
            order = self.find_in_db(request)
            if not order:
                # Ищем в Сирене
                order = self.find_in_sirena(request)
        except (ApplicationError, OrderNotFoundError) as e:
            return GetOrderDetailPriceResponse.build_from_exception(e)

        # Не нашли - печалька. Но сделать тут ничего больше не можем.
        if not order:
            return GetOrderDetailPriceResponse.build_from_exception(OrderNotFoundError())

        fops: List[DomainFop] = self.get_fops(order, request)
        if self.is_update_needed(order, request):
            try:
                order = self.update_order(order)
            except ApplicationError as e:
                return GetOrderDetailPriceResponse.build_from_exception(
                    OrderNotFoundError(
                        code=e.code, message=f"Unable to update order from sirena, {str(e)}, {str(e.message)}"
                    )
                )
            fops: List[DomainFop] = self.get_fops(order, request)

        coupons_count: int = len([i for i in order.data.coupons if i.ticket == request.passenger_ticket_number])

        ticket_price, agent_tax = self.get_ticket_price(
            tickets=order.data.tickets, ticket_num=request.passenger_ticket_number
        )

        document = self.get_passenger_document(order, request.passenger_ticket_number)

        return GetOrderDetailPriceResponse(
            total=ticket_price - agent_tax,
            total_with_agency_tax=ticket_price,
            coupons_count=coupons_count,
            fops=fops,
            ticket_number=request.passenger_ticket_number,
            document=document,
        )

    def find_in_db(self, request: GetOrderDetailPriceRequest) -> Optional[DomainOrder]:
        """
        Изощрённый поиск заказа в БД

        :param request: параметры поиска
        :return:
        """
        # Поиск заказа в БД
        filters: Dict = request.serialize()
        order: Optional[DomainOrder] = self.get_order_from_db(filters)

        if not order:
            # Если во входных данных нет rloc-а, ищем rloc по номеру билета
            if not request.rloc:
                request.rloc = self.get_rloc_by_ticket_number(request.passenger_ticket_number)
                if not request.rloc:
                    raise OrderNotFoundError(
                            message="Order Not Found, Unable to get rloc from e_ticket_display by ticket_number"
                        )
                # Ищем заказ по rloc-у в БД
                order: Optional[DomainOrder] = self.get_order_from_db({InternalScopeFilters.RLOC.value: request.rloc})
                self.update_order(order) if order else None
            if not order:
                return None

        # Проверяем, производился ли, в заказе, сплит
        separated_orders_rlocs = self.check_split_remarks(order.data.remarks)
        if not separated_orders_rlocs:
            return order

        for rloc in separated_orders_rlocs:
            separated_order: Optional[DomainOrder] = self.get_order_from_db({InternalScopeFilters.RLOC.value: rloc})
            try:
                if separated_order:
                    self.update_order(separated_order)
                else:
                    self.get_order_from_sirena(rloc, request.passenger_lastname)
            except (ApplicationError, BaseSirenaError) as e:
                self.logger.info(f"Unable to update order in sirena grs, reason: {e.message} / {rloc}")
                pass

        filters = request.serialize()
        filters.pop(InternalScopeFilters.RLOC.value, None)
        order: Optional[DomainOrder] = self.get_order_from_db(filters)
        if order:
            return order
        return None

    def find_in_sirena(self, request: GetOrderDetailPriceRequest):
        """
        Ищет заказ в Сирене

        :param request:
        :return:
        """
        # Если во входных данных нет rloc-а, ищем rloc по номеру билета
        if not request.rloc:
            request.rloc = self.get_rloc_by_ticket_number(request.passenger_ticket_number)
        if not request.rloc:
            raise OrderNotFoundError(
                message="Order Not Found, Unable to get rloc from e_ticket_display by ticket_number"
            )

        try:
            fresh_order: Optional[DomainOrder] = self.get_order_from_sirena(request.rloc, request.passenger_lastname)
        except SirenaPnrAndSurnameDontMatch as e:
            raise OrderNotFoundError(message=f"Order Not Found: {str(e)}, {str(e.message)}")
        except BaseSirenaError as e:
            raise OrderNotFoundError(message=f"Sirena Error: {str(e)}, {str(e.message)}")

        if not fresh_order:
            return None

        self.saved_from_sirena = True

        separated_orders_rlocs = self.check_split_remarks(fresh_order.data.remarks)
        for rloc in separated_orders_rlocs:
            try:
                self.get_order_from_sirena(rloc, request.passenger_lastname)
            except BaseSirenaError:
                pass

        filters: Dict = request.serialize()
        filters.pop(InternalScopeFilters.RLOC.value)
        order: Optional[DomainOrder] = self.get_order_from_db(filters)
        if order:
            return order
        return None

    def get_order_from_db(self, filters: Dict) -> Optional[DomainOrder]:
        """
        Ищет заказ в БД

        :param filters:
        :return:
        """

        query: AndQueryUnit = self.__build_search_query__(filters)
        order: DomainOrder = self.order_repo.get_single(query, sort=[("_id", DESCENDING)])
        return order

    @staticmethod
    def check_split_remarks(remarks: List[DomainRemark]) -> List[str]:
        """
        Ищет ремарки, сообщающие о сплите заказа
        :param remarks:
        :return:
        """
        pattern = re.compile(r"(\w+)<-|->(\w+)")
        split_remarks = [pattern.search(r.text).group(2) for r in remarks if pattern.search(r.text)]
        return [i for i in split_remarks if i is not None]

    def is_update_needed(self, order: DomainOrder, request: GetOrderDetailPriceRequest) -> bool:
        """
        Правила обновления заказа в сирене:
        1. Если купонов по билету больше, чем фопсов и фопсы найдены не по полю free_text
        2. Не нашли фопсов по билету и не искали заказа в сирене до этого
        3. Если в ticket.monetary_info нет данных соответствующих условиям:
        присутствует tickets.monetary_info.amount_rub, coupon_id != null и code == T
        4. Если рлок брони заканчивается на '/1H/15'
        5. Если нет owner в data.tickets.taxes

        :param order:
        :param request:
        :return:
        """
        if not any((
            order.data.rloc.endswith(f"/{GDS.SIRENA.value}"),
            order.data.rloc.endswith(f"/{GDS.SIRENA_V2.value}")
        )):
            return False

        fops_count = len([f for f in order.data.fops if f.ticket == request.passenger_ticket_number])
        coupons_count = len([c for c in order.data.coupons if c.ticket == request.passenger_ticket_number])
        ticket: Optional[DomainTicket] = next(
            (x for x in order.data.tickets if x.ticket == request.passenger_ticket_number), None
        )
        prices_count = len([
            monetary_info for monetary_info in ticket.monetary_info
            if all((
                monetary_info.amount_rub,
                monetary_info.coupon_id,
                monetary_info.code == TicketMonetaryCode.TOTAL.value,
            ))
        ])

        # Нет подходящих данных о ценах
        if not prices_count:
            return True if not self.saved_from_sirena else False

        # Нет фопсов по билету
        if not fops_count:
            return True if not self.saved_from_sirena else False

        ff_fops: List[DomainFop] = [
            fop for fop in order.data.fops
            if all([fop.ticket == request.passenger_ticket_number, fop.code == FopsCode.FF.value])
        ]

        if all([
            # Фопсы были найдены не по free_text
            self.fops_found_by_free_text is not None,
            not self.fops_found_by_free_text,
            # Кол-во купонов больше, чем фопсов найденых по коду FF
            coupons_count > len(ff_fops),
        ]):
            return True if not self.saved_from_sirena else False

        # Нет owner в data.tickets.taxes
        taxes: List[DomainTaxes] = list()
        for ticket in order.data.tickets:
            taxes.extend(ticket.taxes)
        if not any([t.owner for t in taxes]):
            return True if not self.saved_from_sirena else False

        return False

    def update_order(self, order):
        """
        Обновить заказ

        :param order:
        :return:
        """
        self.internal_order_adapter().update_from_sirena_grs(order_uuid=order.data.order_uuid)
        # Обновленный заказ
        order: DomainOrder = self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(order_uuid=order.data.order_uuid)
        )
        return order

    def get_ticket_price(self, tickets: List[DomainTicket], ticket_num: str) -> (int, int):
        """
        Получить цену

        :param tickets:
        :param ticket_num:
        :return:
        """
        price: int = 0
        # Агентский сбор
        agent_tax: int = 0

        ticket: Optional[DomainTicket] = next((x for x in tickets if x.ticket == ticket_num), None)
        if not ticket:
            return price, agent_tax

        for tax in ticket.taxes:
            if tax.owner == 'agency' and any([tax.amount_rub, tax.amount]):
                agent_tax += tax.amount_rub or tax.amount

        for monetary_info in ticket.monetary_info:
            if all([
                monetary_info.amount_rub,
                monetary_info.coupon_id,
                monetary_info.code == TicketMonetaryCode.TOTAL.value,
            ]):
                price += monetary_info.amount_rub

        if not price:
            for monetary_info in ticket.monetary_info:
                if all([
                    not monetary_info.coupon_id,
                    monetary_info.amount_rub,
                    monetary_info.code == TicketMonetaryCode.TOTAL.value,
                ]):
                    return monetary_info.amount_rub, agent_tax

        return price, agent_tax

    def get_fops(self, order: DomainOrder, request: GetOrderDetailPriceRequest) -> List[DomainFop]:
        """
        Получить ФОПС-ы

        :param order:
        :param request:
        :return:
        """
        fops: List[DomainFop] = list()

        for fop in order.data.fops:
            if not all([
                fop.ticket == request.passenger_ticket_number,
                fop.free_text and fop.free_text.startswith(f"{FopsCode.FF.value}/"),
            ]):
                continue
            self.fops_found_by_free_text = True
            fops.append(fop)

        if fops:
            return fops

        # Если не нашли, пробуем найти по code FF, так как данные могут быть задвоены от разных хостов
        # Делаем это отдельно от первой итерации
        for fop in order.data.fops:
            if not all([fop.ticket == request.passenger_ticket_number, fop.code == FopsCode.FF.value]):
                continue
            self.fops_found_by_free_text = False
            fops.append(fop)

        return fops

    def get_order_from_sirena(self, rloc: str, last_name: str) -> Optional[DomainOrder]:
        """
        Поиск заказа в Сирене, с последующим сохранением данных в БД

        :param rloc:
        :param last_name:
        :return:
        """
        if not rloc:
            return None

        try:
            sirena_raw_order = self.sirena_adapter.search_order(rloc=rloc, last_name=last_name)
            if not sirena_raw_order:
                return None
        except SirenaPnrAndSurnameDontMatch:
            # Пробуем разархивировать заказ и снова поискать
            unarchived = self.sirena_adapter.un_archive_order(rloc)
            if unarchived:
                sirena_raw_order = self.sirena_adapter.search_order(rloc=rloc, last_name=last_name)
            else:
                raise SirenaPnrAndSurnameDontMatch()

        response = self.internal_order_adapter.save(
            raw_order=sirena_raw_order,
            provider=TransactionSource.SIRENA_GRS.value,
            message_id=str(uuid.uuid4()),
            received=time.time(),
            return_full_response=True,
            deferred_save=False,
        )
        order: Union[DomainOrder, None] = response.saved_order
        return order

    def get_rloc_by_ticket_number(self, ticket_number: str) -> Optional[str]:
        """
        Достаем рлок из get_eticket response, он будет нужен для поиска
        заказа в сирене, если в запросе не передали рлок

        :param ticket_number:
        :return:
        """
        response: Optional[Dict] = self.sirena_adapter.get_eticket(ticket_number=ticket_number)
        if not response:
            return None
        rloc: str = response.get("eticket_display", dict()).get("eticket", dict()).get("regnum")
        return rloc

    def get_passenger_document(self, order: DomainOrder, ticket_number: str) -> Optional[DomainDocument]:
        coupon = next(
            (c for c in order.data.coupons if c.ticket == ticket_number),
            None
        )

        if not coupon:
            return None

        return next(
            (d for d in order.data.documents if d.passenger_id == coupon.passenger_id),
            None
        )

    @staticmethod
    def __map_query_units__(param: str, value: Any) -> QueryUnit:
        """
        Мапим фильтры к подходящему поисковому запросу из OrdersQueryBuilder

        :param param:
        :param value:
        :return:
        """
        query_by_filter_mapping = {
            InternalScopeFilters.RLOC.value: OrdersQueryBuilder.get_by_order_rloc_or_rloc_host,
            InternalScopeFilters.PASSENGER_LASTNAME.value: OrdersQueryBuilder.get_by_passenger_last_name,
            InternalScopeFilters.PASSENGER_TICKET_NUMBER.value: OrdersQueryBuilder.get_by_ticket_number,
        }
        return query_by_filter_mapping[param](value)
