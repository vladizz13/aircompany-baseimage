from uuid import UUID

from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.user import InvalidOrderUUIDError


class RefundGetInitialDataRequest(BaseOrderRequest):
    """
    Сериализатор, валидатор входных данных.
    """

    def __init__(self, order_uuid: UUID = None) -> None:
        super().__init__()
        self.order_uuid = str(order_uuid)

    def is_valid(self, *args, **kwargs) -> 'RefundGetInitialDataRequest':
        if not self.order_uuid:
            self.add_error(InvalidOrderUUIDError())

        return self

    def serialize(self) -> dict:
        return {'order_uuid': self.order_uuid}

    @classmethod
    def deserialize(cls, data: dict) -> 'RefundGetInitialDataRequest':
        return cls(order_uuid=data.get('order_uuid'))
