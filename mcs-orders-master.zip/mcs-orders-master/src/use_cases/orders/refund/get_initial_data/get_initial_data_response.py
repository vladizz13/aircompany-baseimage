from typing import Dict

from use_cases.orders.base_order_use_case import BaseOrderResponse


class RefundGetInitialDataResponse(BaseOrderResponse):
    """
    Объект ответа
    """

    def __init__(self, value: Dict = None):
        super().__init__(self.serialize(value))

    @staticmethod
    def serialize(value: Dict = None):
        if not value:
            return value

        order = value.get('order')
        contacts = value.get('contacts')
        involuntary_marker = value.get('involuntary_marker')
        registered_passengers = value.get('registered_passengers')
        all_standby = value.get('is_stand_by', False)

        result_data = {
            'rloc': order.rloc,
            'order_uuid': order.order_uuid,
            'passengers': [
                {
                    'passenger_id': passenger.passenger_id,
                    'first_name': passenger.first_name,
                    'last_name': passenger.last_name,
                    'second_name': passenger.second_name,
                    'type': passenger.type,
                    'registered': True if passenger.passenger_id in registered_passengers else False
                }
                for passenger in order.passengers
            ],
            'contacts': contacts,
            'only_involuntary': involuntary_marker,
            'all_standby': all_standby
        }
        return result_data
