from copy import copy
from datetime import datetime, timedelta
from typing import List, Type, Set

from base.exception import ApplicationError
from domain import DomainOrder
from domain.order.data import DomainFop
from domain.order.meta.meta import DomainMeta
from domain.types import CouponStatus, TransactionSource, FopsCode
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from use_cases.orders.exceptions.base import NoContactsFoundError
from use_cases.orders.exceptions.refund import NoRefundsPossibleError, NoOpenCouponsError, OnlyVZFopsInOrderError
from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.orders.refund.get_initial_data.get_initial_data_request import RefundGetInitialDataRequest
from use_cases.orders.refund.get_initial_data.get_initial_data_response import RefundGetInitialDataResponse
from use_cases.shared.get_order_from_db import RetrieveOrderFromDBMixin
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from use_cases.shared.mask_phone_number import MaskPhoneNumberMixin
from ..shared.is_only_involuntary import IsOnlyInvoluntaryRefundMixIn
from ..shared.is_all_segments_standby import IsSegmentsStandbyRefundMixIn


class RefundGetInitialDataUseCase(
    BaseSearchOrderUseCase,
    RetrieveOrderFromDBMixin,
    MaskPhoneNumberMixin,
    IsOnlyInvoluntaryRefundMixIn,
    IsSegmentsStandbyRefundMixIn
):
    """
    Юзкейс получения данных необходимых, для начала процесса возврата.
    """

    def __init__(self, order_repo: GenericMongoRepository, internal_order_adapter: Type[InternalOrderAdapter]) -> None:
        super().__init__(order_repo=order_repo, internal_order_adapter=internal_order_adapter)

    def __execute__(self, request: RefundGetInitialDataRequest, *args, **kwargs) -> RefundGetInitialDataResponse:
        """
        Обработка выполнения бизнес-логики запроса данных, необходимых для начала процедуры возврата

        :param request: объект входных данных
        :param args: остальные аргументы, переданные позиционно
        :param kwargs: остальные аргументы, переданные по ключу
        :return: объект выходных данных
        """
        try:
            order: DomainOrder = self.get_order(self.order_repo, request.order_uuid)
        except OrderNotFoundError:
            return RefundGetInitialDataResponse.build_from_exception(OrderNotFoundError())

        # Если в заказе нет ни одного подходящего контакта, прервать дальнейшую работу и сообщить об этом в ответе
        for contact in order.data.contacts:
            if self.contact_is_valid_for_user_interactions(contact):
                break
        else:
            return RefundGetInitialDataResponse.build_from_exception(NoContactsFoundError())

        # Если броня была обновлена от sirena_grs более, чем 24 часа назад - обновляем броню из Сирены ГРС
        latest_transaction = self.get_latest_transaction_date(order.meta)
        if datetime.now().timestamp() - latest_transaction >= 86400:
            try:
                self.internal_order_adapter().update_from_sirena_grs(order.data.order_uuid)
                order = self.get_order(self.order_repo, request.order_uuid)
            except ApplicationError:
                pass

        # Проверяем, что для брони доступен возврат (order.data.available_actions.can_return : True)
        # Если недоступен, прервать дальнейшую работу и сообщить об этом в ответе
        if not order.data.available_actions.can_return:
            return RefundGetInitialDataResponse.build_from_exception(NoRefundsPossibleError())

        # Проверяем, что в броне есть, что возвращать
        # (в броне есть хотя бы 1 купон в не терминальном статусе (E, F, P, R, G, X, V, T, Z))
        registered_pax_coupons: Set[str] = set()
        none_terminal_coupons: Set[str] = set()
        for coupon in order.data.coupons:
            if coupon.status not in set(CouponStatus.TERMINAL_LIST.value + (CouponStatus.Z.value,)):
                none_terminal_coupons.add(coupon.ticket)
            if coupon.status == CouponStatus.C.value:
                registered_pax_coupons.add(coupon.passenger_id)

        if not none_terminal_coupons:
            return RefundGetInitialDataResponse.build_from_exception(NoOpenCouponsError())

        if all([
            order.data.fops,
            all((self._is_fop_restricted(fop) for fop in order.data.fops))
        ]):
            return RefundGetInitialDataResponse.build_from_exception(OnlyVZFopsInOrderError())

        masked_contacts: List[str] = self.get_disguised_phone_numbers(order.data.contacts)
        is_stand_by: bool = self.calculate_standby(segments=order.data.segments)
        involuntary_marker: bool = True if is_stand_by else self.calculate_only_involuntary(order.data)

        return RefundGetInitialDataResponse(
            {
                'order': order.data,
                'contacts': masked_contacts,
                'involuntary_marker': involuntary_marker,
                'registered_passengers': registered_pax_coupons,
                'is_stand_by': is_stand_by
            }
        )

    @staticmethod
    def _is_fop_restricted(fop: DomainFop) -> bool:
        """
        Если в заказе отсутствуют формы оплаты кроме VZ (т.е. полная оплата ваучером) fops.code
        и у таких форм оплаты account_num начинается с VAU
        Запрещаем денежный возврат для заказов, оплаченных 100% ваучером
        """
        return all((
            fop.code == FopsCode.VZ.value,
            fop.account_num is not None and fop.account_num.startswith("VAU")   # Ваучер
        ))

    @staticmethod
    def get_latest_transaction_date(order_meta: DomainMeta) -> float:
        """
        Извлечь последнюю транзакцию данных заказа от sirena_grs

        :param order_meta:
        :return:
        """
        transactions_list = copy(order_meta.updated)
        transactions_list.insert(0, order_meta.created)
        sirenagrs_transactions = [
            transaction
            for transaction in transactions_list
            if transaction.provider == TransactionSource.SIRENA_GRS.value
        ]
        if sirenagrs_transactions:
            return sirenagrs_transactions[-1].date
        return (datetime.now() - timedelta(days=2)).timestamp()
