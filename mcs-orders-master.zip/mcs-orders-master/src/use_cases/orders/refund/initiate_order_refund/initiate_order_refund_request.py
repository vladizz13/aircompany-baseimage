from typing import List, Dict
from uuid import UUID

from pydantic import ValidationError
from domain.types import CodeDispatchType
from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.refund import InputDataValidationError
from use_cases.orders.refund.initiate_order_refund.serializers import InitiateRefundData


class InitiateOrderRefundRequest(BaseOrderRequest):
    """
    Сериализатор, валидатор входных данных.
    """

    def __init__(self,
                 order_uuid: UUID = None,
                 passengers: List[Dict[str, str]] = None,
                 contact: str = None,
                 involuntary: bool = None,
                 type_of_dispatch: str = CodeDispatchType.CALL.value
                 ) -> None:
        super().__init__()
        self.order_uuid: str = str(order_uuid)
        self.passengers: List[Dict[str, str]] = passengers
        self.contact: str = contact
        self.involuntary: bool = involuntary
        self._type_of_dispatch: str = type_of_dispatch

    def is_valid(self, *args, **kwargs) -> 'InitiateOrderRefundRequest':
        try:
            CodeDispatchType(self._type_of_dispatch)
        except ValueError:
            self.add_error(InputDataValidationError(
                message=f"Invalid code dispatch type, must be one of {[c.value for c in CodeDispatchType]}")
            )
        try:
            InitiateRefundData(
                order_uuid=self.order_uuid,
                passengers=self.passengers,
                contact=self.contact,
                involuntary=self.involuntary,
            )
        except ValidationError as err:
            self.add_error(InputDataValidationError(message=err.__repr__()))
        return self

    @property
    def code_dispatch_type(self) -> CodeDispatchType:
        return CodeDispatchType(self._type_of_dispatch)

    def serialize(self) -> dict:
        data: Dict = {
            'order_uuid': self.order_uuid,
            'passengers': self.passengers,
            'contact': self.contact,
            'involuntary': self.involuntary,
        }
        return data

    @classmethod
    def deserialize(cls, data: dict) -> 'InitiateOrderRefundRequest':
        instance: InitiateOrderRefundRequest = cls(
            order_uuid=data.get('order_uuid'),
            passengers=data.get('passengers'),
            contact=data.get('contact'),
            involuntary=data.get('involuntary'),
        )
        return instance
