from use_cases.orders.base_order_use_case import BaseOrderResponse


class InitiateOrderRefundResponse(BaseOrderResponse):
    """
    Объект ответа
    """

    def __init__(self, attempt_id: str = None):
        super().__init__(self.serialize(attempt_id))

    @staticmethod
    def serialize(attempt_id: str):
        if not attempt_id:
            return {'attempt_id': None}
        return {'attempt_id': attempt_id}
