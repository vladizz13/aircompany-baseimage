import json
from collections import namedtuple
from uuid import uuid4
from typing import Dict
from redis import Redis

from adapter.monoapp import MonoAppAdapter
from adapter.service_desk import JiraServiceDeskAdapter
from base.exception import ApplicationError
from domain import DomainOrder
from domain.refunds import DomainRefund
from domain.types import PassengerCategory, CouponStatus
from libs.query_builder import QueryUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.refund import RefundsQueryBuilder
from use_cases.orders.exceptions.refund import (
    AlreadyCheckedInError,
    NoInvoluntaryRefundPossibleError,
    LonelyInfantError,
    NoRefundsPossibleError,
    RefundAlreadyRegisteredError,
    IncorrectPassengersDataError,
)
from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.orders.refund.initiate_order_refund.initiate_order_refund_request import InitiateOrderRefundRequest
from use_cases.orders.refund.initiate_order_refund.initiate_order_refund_response import InitiateOrderRefundResponse
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from use_cases.shared.get_order_from_db import RetrieveOrderFromDBMixin
from use_cases.shared.send_verification_code import SendVerificationCodeMixin
from use_cases.shared.unmask_phone_number import GetPhoneNumberMixin
from ..shared.is_only_involuntary import IsOnlyInvoluntaryRefundMixIn
from ..shared.is_all_segments_standby import IsSegmentsStandbyRefundMixIn


class InitiateOrderRefundUseCase(
    BaseSearchOrderUseCase,
    RetrieveOrderFromDBMixin,
    GetPhoneNumberMixin,
    SendVerificationCodeMixin,
    IsOnlyInvoluntaryRefundMixIn,
    IsSegmentsStandbyRefundMixIn
):
    """
    Юзкейс начала процесса возврата.
    """

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            mono_app_adapter: MonoAppAdapter,
            redis_adapter: Redis,
            refunds_repo: GenericMongoRepository,
            service_desk: JiraServiceDeskAdapter,
    ) -> None:
        super().__init__(
            order_repo=order_repo, mono_app_adapter=mono_app_adapter,
        )
        self.redis_adapter: Redis = redis_adapter
        self.refunds_repo: GenericMongoRepository = refunds_repo
        self.service_desk: JiraServiceDeskAdapter = service_desk

    def __execute__(self, request: InitiateOrderRefundRequest, *args, **kwargs) -> InitiateOrderRefundResponse:
        """
        Обработка запроса на возврат средств за бронь
        :param request: объект входных данных
        :param args: остальные аргументы, переданные позиционно
        :param kwargs: остальные аргументы, переданные по ключу
        :return: объект выходных данных
        """
        # Проверка, что такая заявка на возврат не была оформлена ранее
        for passenger in request.passengers:
            try:
                self.check_refund_request_already_registered(
                    request.order_uuid, passenger["first_name"], passenger["last_name"]
                )
            except RefundAlreadyRegisteredError:
                return InitiateOrderRefundResponse.build_from_exception(RefundAlreadyRegisteredError())
        try:
            order: DomainOrder = self.get_order(self.order_repo, request.order_uuid)
        except OrderNotFoundError:
            return InitiateOrderRefundResponse.build_from_exception(OrderNotFoundError())

        # Проверить, что, пришедшие данные о пассажирах, совпадают с реальными данными о пассажирах заказа
        try:
            self.validate_input_passenger_data(order.data.passengers, request.passengers)
        except IncorrectPassengersDataError:
            return InitiateOrderRefundResponse.build_from_exception(IncorrectPassengersDataError())

        # Проверяем, что для брони доступен возврат
        if not order.data.available_actions.can_return:
            return InitiateOrderRefundResponse.build_from_exception(NoRefundsPossibleError())

        # Проверяем, что выбранные пассажиры не зарегистрированы
        try:
            self.check_passengers_already_registered(order, request)
        except AlreadyCheckedInError:
            return InitiateOrderRefundResponse.build_from_exception(AlreadyCheckedInError())

        # Проверить, что для данной брони допустим добровольный возврат.
        is_stand_by: bool = self.calculate_standby(segments=order.data.segments)
        if not is_stand_by:
            only_involuntary = self.calculate_only_involuntary(order.data)
            if only_involuntary is True and request.involuntary is False:
                return InitiateOrderRefundResponse.build_from_exception(NoInvoluntaryRefundPossibleError())

        # Проверить, что в броне не оставили одного младенца или ребенка
        try:
            self.check_lonely_infant_or_child_exist(order, request)
        except LonelyInfantError:
            return InitiateOrderRefundResponse.build_from_exception(LonelyInfantError())

        # Генерируем attempt_id (идентификатор попытки возврата)
        attempt_id = str(uuid4())

        try:
            # По указанному номеру телефона направляем звонок через смс-центр
            phone_number = self.get_phone_number(request.contact, order.data.contacts)
            code = self.send_code(
                self.mono_app_adapter,
                phone_number,
                type_of_dispatch=request.code_dispatch_type,
                operation_type="order_refund",
                salt=order.data.rloc
            )
        except ApplicationError as e:
            return InitiateOrderRefundResponse.build_from_exception(e)

        refund_req_data = request.serialize()
        refund_req_data["code"] = code

        # Фиксируем, какие пассажиры были выбраны для возврата
        self.redis_adapter.set(
            f"order_refund:{attempt_id}", json.dumps(refund_req_data, indent=2, ensure_ascii=False), ex=3600
        )

        return InitiateOrderRefundResponse(attempt_id)

    @staticmethod
    def check_passengers_already_registered(order: DomainOrder, requested_passengers: InitiateOrderRefundRequest):
        """
        https://jira.utair.ru/browse/UTBCKN-3047
        Проверяем, что выбранные пассажиры не зарегистрированы
        Пассажир зарегистрирован, если есть хотя бы один купон в статусе C
        Если находим зарегистрированного - выдаем ошибку
        :param order: данные заказа
        :param requested_passengers: запрос пассажира
        :raises: AlreadyCheckedInError
        """
        coupons = order.data.coupons
        passenger_ids = {p["passenger_id"] for p in requested_passengers.passengers}
        if not coupons:
            raise AlreadyCheckedInError
        for c in coupons:
            if all((
                c.status == CouponStatus.C.value,
                c.passenger_id in passenger_ids
            )):
                raise AlreadyCheckedInError

    @staticmethod
    def check_lonely_infant_or_child_exist(order, request):
        """Проверить не осталось ли в заказе одного младенца или ребенка"""
        Passenger = namedtuple("Passenger", "last_name first_name type")
        order_passengers = {Passenger(p.last_name, p.first_name, p.type) for p in order.data.passengers}
        passengers_to_refund = {Passenger(p["last_name"], p["first_name"], p["type"]) for p in request.passengers}
        if remaining := order_passengers - passengers_to_refund:
            types_in_remaining = [x.type for x in remaining]
            if PassengerCategory.ADULT.value not in types_in_remaining:
                raise LonelyInfantError

    def check_refund_request_already_registered(self, order_uuid: str, first_name: str, last_name: str):
        query: QueryUnit = RefundsQueryBuilder.find_refund_request(order_uuid, first_name, last_name)
        refund_request: DomainRefund = self.refunds_repo.get_single(query)
        # Проверка, что такая заявка не была оформлена в Jira ранее
        res: Dict = self.service_desk.find_refund_by_uuid(order_uuid)
        if refund_request or res.get("total"):
            raise RefundAlreadyRegisteredError
        return refund_request

    @staticmethod
    def validate_input_passenger_data(original_passengers, incoming_passengers):
        for inc_p in incoming_passengers:
            for orig_p in original_passengers:
                if all((
                    inc_p.get("passenger_id") == orig_p.passenger_id,
                    inc_p.get("first_name") == orig_p.first_name,
                    inc_p.get("last_name") == orig_p.last_name,
                )):
                    break
            else:
                raise IncorrectPassengersDataError
