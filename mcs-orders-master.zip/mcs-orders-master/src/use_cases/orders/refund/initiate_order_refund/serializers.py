from typing import List, Optional

from pydantic import BaseModel, UUID4, model_validator


class ValidatorMixin(BaseModel):

    @model_validator(mode='before')
    def check_values_not_empty(cls, values):
        for k, v in values.items():
            if v == '':
                msg = f'Field "{k}": Empty strings are not allowed.'
                raise ValueError(msg)
        return values


class Passengers(ValidatorMixin):
    passenger_id: str
    first_name: str
    last_name: str
    second_name: Optional[str] = None
    type: str


class InitiateRefundData(ValidatorMixin):
    order_uuid: UUID4
    passengers: List[Passengers]
    contact: str
    involuntary: bool
