from use_cases.orders.base_order_use_case import BaseOrderRequest


class OrderRefundsSearchRequest(BaseOrderRequest):

    def __init__(
            self,
            order_uuid: str = None,
    ):
        super().__init__()
        self.order_uuid: str = order_uuid

    def is_valid(self, *args, **kwargs) -> 'OrderRefundsSearchRequest':
        return self

    def serialize(self) -> dict:
        return {
            'order_uuid': self.order_uuid,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order_uuid=data.get('order_uuid')
        )
