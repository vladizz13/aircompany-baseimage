from typing import Dict, List
from use_cases.orders.base_order_use_case import BaseOrderResponse

from .response_dto import OrderRefundsSearchResponseDTO


class OrderRefundsSearchResponse(BaseOrderResponse):

    def __init__(
            self,
            values: List[OrderRefundsSearchResponseDTO] = None,
    ):
        values: List[Dict] = self.serialize_refunds(values)
        super().__init__(self.serialize(values))

    @staticmethod
    def serialize(values: List[Dict] = None):
        return {'total': len(values), 'objects': values}

    @staticmethod
    def serialize_refunds(refunds: List[OrderRefundsSearchResponseDTO]) -> List[Dict]:
        if not refunds:
            return []
        return [o.serialize() for o in refunds]
