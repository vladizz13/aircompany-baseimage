from pymongo import DESCENDING
from pymongo.errors import OperationFailure
from typing import List, Optional
from libs.query_builder import AndQueryUnit

from domain import DomainOrder
from domain.refunds import DomainRefund

from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from repositories.query_builders.refund import RefundsQueryBuilder

from ...base_order_use_case import BaseOrderUseCase
from ...exceptions.search import OrderRefundsSearchError, UnableToBuildQueryError
from .order_refunds_search_request import OrderRefundsSearchRequest
from .order_refunds_search_response import OrderRefundsSearchResponse
from .response_dto import OrderRefundsSearchResponseDTO


class OrderRefundsSearchUseCase(BaseOrderUseCase):
    """
    Поиск заявок на возврат для заказа
    """

    def __init__(
        self,
        order_repo: GenericMongoRepository = None,
        refund_repo: GenericMongoRepository = None
    ):
        super().__init__()
        self.order_repo = order_repo
        self.refund_repo = refund_repo

    def __execute__(self, request: OrderRefundsSearchRequest, *args, **kwargs) -> OrderRefundsSearchResponse:
        order: Optional[DomainOrder] = self.get_order_by_uud(request)
        if not order:
            return OrderRefundsSearchResponse.build_from_exception(
                OrderRefundsSearchError(
                    message="Order not found"
                )
            )
        refunds: List[DomainRefund] = self.get_order_refunds(order)
        converted: List[OrderRefundsSearchResponseDTO] = self.convert_refunds(refunds)

        return OrderRefundsSearchResponse(values=converted)

    def convert_refunds(
        self,
        refunds: List[DomainRefund]
    ) -> List[OrderRefundsSearchResponseDTO]:
        objects: List[dict] = []

        for refund in refunds:
            passengers: List[dict] = []
            for p in refund.passengers:
                names: List[str] = []
                if p.last_name:
                    names.append(p.last_name)
                if p.first_name:
                    names.append(p.first_name)
                if p.second_name:
                    names.append(p.second_name)
                if len(names):
                    passengers.append({'name': ' '.join(names)})

            objects.append({
                'order_uuid': refund.order_uuid,
                'contact': refund.contact,
                'involuntary': refund.involuntary,
                'datetime_utc': refund.datetime_utc,
                'order_refund_id': refund.order_refund_id,
                'passengers': passengers,
            })

        return [OrderRefundsSearchResponseDTO(**obj) for obj in objects]

    def get_order_refunds(
        self,
        order: DomainOrder
    ) -> List[DomainRefund]:
        """
        Получаем список заявок на возврат
        """
        query = AndQueryUnit()
        query.add(RefundsQueryBuilder.get_by_order_uuid(order.data.order_uuid))
        sorters = [('_id', DESCENDING)]

        try:
            refunds = self.refund_repo.list(spec=query, sort=sorters)
        except OperationFailure as e:
            self.logger.exception('Не удалось составить поисковый запрос: {}'.format(str(e)))
            return OrderRefundsSearchResponse.build_from_exception(UnableToBuildQueryError())

        return refunds

    def get_order_by_uud(
            self,
            request: OrderRefundsSearchRequest
    ) -> Optional[DomainOrder]:
        """
        Получаем заказ по идентификатору
        """
        order: DomainOrder = self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_uuid(request.order_uuid)
        )
        return order
