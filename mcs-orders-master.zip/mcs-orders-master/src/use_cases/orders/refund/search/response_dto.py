from typing import List

from dataclasses import dataclass, field

from libs.utils.data_classes import nested_dataclass
from use_cases.orders.search.external.common.common import Serializable


@dataclass
class Passenger:
    name: str = None

    @staticmethod
    def fields_to_ignore() -> List:
        return []


@nested_dataclass
class OrderRefundsSearchResponseDTO(Serializable):
    """
    Объект для с сегментами, на которые открыта регистрация по контексту пользователя
    """
    order_uuid: str = None
    contact: str = None
    involuntary: bool = False
    datetime_utc: str = None
    order_refund_id: str = None

    passengers: List[Passenger] = field(default_factory=list)
