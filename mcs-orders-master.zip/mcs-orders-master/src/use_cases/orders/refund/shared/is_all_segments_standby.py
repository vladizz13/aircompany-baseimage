from typing import List
from domain.order.data.segment import DomainSegment


class IsSegmentsStandbyRefundMixIn:

    @staticmethod
    def calculate_standby(segments: List[DomainSegment]) -> bool:
        """
        Если все сегменты заказа являются подсадкой, тогда True
        :param segments:
        :return:
        """
        for s in segments:
            if not s.standby:
                return False
        return True
