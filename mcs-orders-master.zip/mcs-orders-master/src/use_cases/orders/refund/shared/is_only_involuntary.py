from domain import DomainTransaction
from domain.types import FareCode, ServiceRFISCs, ServiceStatus


class IsOnlyInvoluntaryRefundMixIn:

    @staticmethod
    def calculate_only_involuntary(order: DomainTransaction) -> bool:
        """
        По умолчанию true (доступен только вынужденный)
        Добровольный (false) доступен, если:
        Хотя бы 1 у сегмента брони код тарифа orders.data.offers.fare_code FL или STR (проверяем подстроку со второго
        символа. Первый символ fare_code - код подкласса. Символы дальше - примечания к тарифу)
        Или дата бронирования orders.data.booking_timestamp больше 01.04.2020 и меньше 07.07.2020 (период, когда
        добровольный возврат был доступен для всех броней вне зависимости от тарифа)
        :param order:
        :return:
        """
        # https://jira.utair.ru/browse/UTBCKN-3094
        if any(((
            s.rfisc == ServiceRFISCs.REFUND.value and s.status == ServiceStatus.HI.value
        ) for s in order.services)):
            return False
        # Если дата бронирования orders.data.analytics_data.first_segment_booking_time больше 01.04.2020 и меньше
        # 07.07.2020 (период, когда добровольный возврат был доступен для всех броней вне зависимости от тарифа)
        if 1585699200 <= order.analytics_data.first_segment_booking_time < 1594080000:
            return False
        # Хотя бы у 1 сегмента брони код тарифа (orders.data.offers.fare_code) FL/STR/PP (проверка подстроки со второго
        # символа. Первый символ fare_code - код подкласса. Символы дальше - примечания к тарифу)
        for offer in order.offers:
            if offer.fare_code.startswith((
                    FareCode.SUBSIDIZED.value,
                    FareCode.PREMIUM.value,
                    FareCode.OPTIMUM_PLUS.value,
                    FareCode.PREMIUM_PLUS.value,
                    FareCode.BUSINESS.value,
                    FareCode.REG.value,
            ), 1):
                return False
        return True
