from use_cases.orders.base_order_use_case import BaseOrderRequest
from use_cases.orders.exceptions.refund import (
    MissingAttemptIdError,
    MissingVerificationCodeError
)


class SubmitOrderRefundRequestReqObj(BaseOrderRequest):
    """
    Сериализатор, валидатор входных данных.
    """

    def __init__(self, attempt_id: str = None, code: str = None):
        super().__init__()
        self.attempt_id: str = attempt_id
        self.code: str = code

    def is_valid(self, *args, **kwargs) -> 'SubmitOrderRefundRequestReqObj':
        if not self.attempt_id:
            self.add_error(MissingAttemptIdError())
        if not self.code:
            self.add_error(MissingVerificationCodeError())
        return self

    def serialize(self) -> dict:
        return {'attempt_id': self.attempt_id, 'code': self.code}

    @classmethod
    def deserialize(cls, data: dict) -> 'SubmitOrderRefundRequestReqObj':
        return cls(attempt_id=data.get('attempt_id'), code=data.get('code'))
