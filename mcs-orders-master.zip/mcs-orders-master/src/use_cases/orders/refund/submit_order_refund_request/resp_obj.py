from use_cases.orders.base_order_use_case import BaseOrderResponse


class SubmitOrderRefundRequestRespObj(BaseOrderResponse):
    """
    Объект ответа
    """

    def __init__(self, rloc: str = None, order_uuid: str = None, order_refund_id: str = None, email: str = None):
        super().__init__(self.serialize(rloc, order_uuid, order_refund_id, email))

    @staticmethod
    def serialize(rloc: str, order_uuid: str, order_refund_id: str, email: str):
        return {
            'rloc': rloc,
            'order_uuid': order_uuid,
            'order_refund_id': order_refund_id,
            'email': email,
        }
