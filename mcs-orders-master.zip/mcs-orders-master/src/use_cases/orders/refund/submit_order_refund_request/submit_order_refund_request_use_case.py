import copy
import json
from datetime import datetime
from typing import List, Dict, Set, Type, Optional
from time import time, sleep
from uuid import uuid4

from redis import Redis
from event_engine import Event
from events.events.refunds import RefundOrderEvent

from adapter.service_desk import JiraServiceDeskAdapter
from adapter.service_desk.exceptions import JiraSDBaseError
from adapter.sirena_adapter import SirenaInternalAdapter, BaseSirenaError
from base.exception import ApplicationError
from domain import DomainOrder
from domain.order.data import DomainContact
from domain.order.data import DomainSegment
from domain.refunds import DomainRefund
from domain.types import (
    ContactType, MatchTypes, TransactionSource, SegmentStatus, SegmentStatusVisual
)
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from rest.interfaces.internal_order_adapter import InternalOrderAdapter
from rest.applications.celery_app.tasks.add_ssrs import add_ssr_vzr
from rest.applications.celery_app.tasks.update_from_sirena import update_from_sirena_grs
from use_cases.orders.exceptions.refund import (
    WrongVerificationCodeError,
    MissingOrderRefundDataError,
    FailedRegisterRefundInServiceDeskError,
    FailedToReleaseSeatsError,
    FailedToDivideOrderError
)
from use_cases.orders.exceptions.user import OrderNotFoundError
from use_cases.shared.unmask_phone_number import GetPhoneNumberMixin
from use_cases.shared.get_order_from_db import RetrieveOrderFromDBMixin
from use_cases.orders.refund.submit_order_refund_request.req_obj import SubmitOrderRefundRequestReqObj
from use_cases.orders.refund.submit_order_refund_request.resp_obj import SubmitOrderRefundRequestRespObj
from use_cases.orders.search.base_search_usecase import BaseSearchOrderUseCase
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from sirena_xml_client.types import PassengersForReleaseSeats, SegmentsForReleaseSeats


class SubmitOrderRefundRequestUseCase(
    BaseSearchOrderUseCase, RetrieveOrderFromDBMixin, GetPhoneNumberMixin, BaseOrderUseCase
):
    """
    Юзкейс начала процесса возврата.
    """

    def __init__(
            self,
            order_repo: GenericMongoRepository,
            internal_order_adapter: Type[InternalOrderAdapter],
            refunds_repo: GenericMongoRepository,
            redis_adapter: Redis,
            service_desk: JiraServiceDeskAdapter,
            sirena_adapter: SirenaInternalAdapter
    ) -> None:
        super().__init__(order_repo=order_repo, internal_order_adapter=internal_order_adapter)
        self.refunds_repo: GenericMongoRepository = refunds_repo
        self.redis_adapter: Redis = redis_adapter
        self.service_desk: JiraServiceDeskAdapter = service_desk
        self.sirena_adapter: SirenaInternalAdapter = sirena_adapter
        self.events: List[Type[Event]] = [RefundOrderEvent]

    def __execute__(self, request: SubmitOrderRefundRequestReqObj, *args, **kwargs) -> SubmitOrderRefundRequestRespObj:
        """
        Обработка запроса на оформления заявки на возврат

        :param request: объект входных данных
        :param args: остальные аргументы, переданные позиционно
        :param kwargs: остальные аргументы, переданные по ключу
        :return: объект выходных данных
        """

        # Проверить, совпадает ли присланный код валидации
        order_refund_data = self.redis_adapter.get(f'order_refund:{request.attempt_id}')
        if not order_refund_data:
            return SubmitOrderRefundRequestRespObj.build_from_exception(MissingOrderRefundDataError())
        refund_request_data = json.loads(order_refund_data)
        if request.code != refund_request_data['code']:
            return SubmitOrderRefundRequestRespObj.build_from_exception(WrongVerificationCodeError())

        # Ищем заказ в БД
        order_uuid = refund_request_data['order_uuid']
        try:
            order: DomainOrder = self.get_order(self.order_repo, order_uuid)
        except OrderNotFoundError:
            return SubmitOrderRefundRequestRespObj.build_from_exception(OrderNotFoundError())

        # Проставить ssr vzr при необходимости
        add_ssr_vzr.apply_async(
            (order.data.order_uuid, refund_request_data['passengers'])
        )

        # Если в возврате билета участвуют не все пассажиры брони
        rloc = order.data.rloc
        last_name = order.data.passengers[0].last_name
        is_splitted = False
        splitted_rloc = None
        splitted_order_uuid = None
        if len(order.data.passengers) != len(refund_request_data['passengers']):
            try:
                # Сплит пассажиров в Sirena
                response = self.sirena_adapter.divide_order(
                    rloc=rloc,
                    surname=order.data.passengers[0].last_name,
                    passengers=self.create_release_seats_passengers(
                        passengers=refund_request_data['passengers']
                    )
                )
                rloc = response.get('regnum').get("text")
                last_name = refund_request_data['passengers'][0]["last_name"]

                order_uuid = self.save_from_sirena(rloc, last_name)
                splitted_order_uuid = order_uuid
                is_splitted = True
                splitted_rloc = rloc
            except (ApplicationError, BaseSirenaError) as e:
                self.logger.exception(f"Unable to split order {rloc=} {order_uuid=} due to error: {str(e)}")
                return SubmitOrderRefundRequestRespObj.build_from_exception(
                    FailedToDivideOrderError(inner_exception=e)
                )

        segments_for_release: List[DomainSegment] = [
            s for s in order.data.segments
            if all((
                s.status not in [SegmentStatus.XX.value, SegmentStatus.UN.value],
                s.status_visual != SegmentStatusVisual.FLOWN.value
            ))
        ]

        # Аннулирование мест в Sirena через метод release_seats
        if segments_for_release:
            try:
                release_seats_passengers = self.create_release_seats_passengers(
                    passengers=refund_request_data['passengers']
                )
                release_seats_segments = self.create_release_seats_segments(segments_for_release)
                self._release_seats(
                    rloc=rloc,
                    last_name=last_name,
                    release_seats_passengers=release_seats_passengers,
                    release_seats_segments=release_seats_segments
                )
            except BaseSirenaError as e:
                return SubmitOrderRefundRequestRespObj.build_from_exception(
                    FailedToReleaseSeatsError(inner_exception=e)
                )

        # Отправить заявку в ServiceDesk
        try:
            order_refund_id = self.send_message_to_service_desk(
                order_uuid=order_uuid, refund_request_data=refund_request_data
            )
        except FailedRegisterRefundInServiceDeskError as e:
            return SubmitOrderRefundRequestRespObj.build_from_exception(exception=e)

        event_payload = copy.deepcopy(refund_request_data)

        # Сохранить заявку на возврат в БД
        self.store_refund_in_db(order_refund_id, refund_request_data, order, order_uuid)

        # Удалить промежуточные данные из редиса
        self.redis_adapter.delete(f'order_refund:{request.attempt_id}')

        # Инициировать обновление данных заказа
        update_from_sirena_grs.apply_async((order.data.order_uuid,))

        # Отправить ивент
        event_payload.pop('code')
        event_payload.pop('contact')

        payload = {
            "refund_request": event_payload,
            "splitted_order": {
                "is_splitted": is_splitted,
                "rloc": splitted_rloc,
                "order_uuid": splitted_order_uuid
            },
            "order": order.data.serialize()
        }

        self.__raise_event__(event=RefundOrderEvent, payload=payload)

        return SubmitOrderRefundRequestRespObj(
            rloc=order.data.rloc,
            order_uuid=order_uuid,
            order_refund_id=order_refund_id,
            email=self.get_email(order.data.contacts)
        )

    @staticmethod
    def get_tickets_by_passengers(passengers: Dict, order: DomainOrder) -> Set[str]:
        tickets: Set[str] = set()
        passenger_ids = {p["passenger_id"] for p in passengers}
        for ticket in order.data.tickets:
            if ticket.passenger_id in passenger_ids:
                tickets.add(ticket.ticket)
        return tickets

    @staticmethod
    def get_email(contacts: List[DomainContact]) -> str:
        """ Найти подходящий email-адрес"""
        for contact in contacts:
            if contact.type == ContactType.MAIL.value and contact.match_type == MatchTypes.AUTO.value:
                return contact.contact

    def store_refund_in_db(self, order_refund_id: str, refund_request_data: Dict, order: DomainOrder, order_uuid: str):
        """ Сохранить успешную заявку на возврат заказа в бд"""
        refund_request_data.pop('code')
        refund_request_data['order_refund_id'] = order_refund_id
        refund_request_data['order_uuid'] = order_uuid
        refund_request_data['datetime_utc'] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        refund_request_data['contact'] = self.get_phone_number(refund_request_data['contact'], order.data.contacts)

        order_refund = DomainRefund.deserialize(refund_request_data)
        self.refunds_repo.create(order_refund)

    @staticmethod
    def compose_first_name(passenger: Dict) -> str:
        """
        Составление имени для сирены
        :param passenger:
        {
            "first_name": "kool",
            "second_name": "kid",
            ....
        }
        :return:
        """
        first_name = passenger["first_name"]
        if first_name == "Cbbg":
            return first_name
        if second_name := passenger["second_name"]:
            first_name = f"{first_name.capitalize()} {second_name.capitalize()}"
        return first_name

    def create_release_seats_passengers(self, passengers: List[Dict]) -> List[PassengersForReleaseSeats]:
        _passengers: List[PassengersForReleaseSeats] = list()
        for p in passengers:
            _passengers.append(
                PassengersForReleaseSeats(
                    first_name=self.compose_first_name(p),
                    last_name=p["last_name"]
                )
            )
        return _passengers

    @staticmethod
    def create_release_seats_segments(segments: List[DomainSegment]) -> List[Dict]:
        _segments = list()
        for s in segments:
            _segments.append(
                dict(
                    company=s.ak,
                    flight=s.flight_number,
                    departure=s.departure_airport_code,
                    arrival=s.arrival_airport_code,
                    departure_date=datetime.fromisoformat(s.departure_local_iso).strftime('%d.%m.%Y'),
                )
            )
        return _segments

    def save_from_sirena(self, rloc: str, last_name: str) -> Optional[str]:
        sirena_raw_order = self.sirena_adapter.search_order(rloc=rloc, last_name=last_name)
        if not sirena_raw_order:
            return SubmitOrderRefundRequestRespObj.build_from_exception(OrderNotFoundError())

        response = self.internal_order_adapter().save(
            raw_order=sirena_raw_order,
            provider=TransactionSource.SIRENA_GRS.value,
            received=time(),
            message_id=str(uuid4()),
            deferred_save=False,
            return_full_response=True
        )
        if not response:
            raise response.errors[0]
        return response.saved_order.data.order_uuid

    def send_message_to_service_desk(
        self,
        order_uuid: str,
        refund_request_data: Dict,
    ) -> str:
        try:
            order_refund_id = self.service_desk.apply_for_refund(
                order_uuid=order_uuid,
                is_involuntary=refund_request_data['involuntary']
            )["key"]
        except JiraSDBaseError as e:
            raise FailedRegisterRefundInServiceDeskError(message=e.message)
        return order_refund_id

    def _release_seats(
        self,
        rloc: str,
        last_name: str,
        release_seats_passengers: List[PassengersForReleaseSeats],
        release_seats_segments: List[Dict]
    ) -> Dict:
        # FIXME
        #  в текущей реализации блокируем основной поток на 3 секунды. В худшем случае 9 сек.
        #  celery retry требует backend для хранения результатов повтора. Так же он будет хранить результаты
        #  ВСЕХ задач. Поэтому в текущей реализации нативный celery retry не используется.
        segments_request = [SegmentsForReleaseSeats(**s) for s in release_seats_segments]

        retry_count = 4
        for i in range(retry_count):
            # Превысили максимальное кол-во повторов.
            if i + 1 == retry_count:
                raise BaseSirenaError()

            try:
                res = self.sirena_adapter.release_seats(
                    rloc=rloc,
                    surname=last_name,
                    passengers=release_seats_passengers,
                    segments=segments_request
                )
                if not res:
                    self.logger.exception(f"Unable to release seats for {rloc=} retry count: {i} due to error: {str(res)}") # noqa
                    sleep(3)
                    continue
                return res
            except BaseSirenaError as e:
                self.logger.exception(f"Unable to release seats for {rloc=} retry count: {i} due to error: {str(e)}")
                sleep(3)
                continue
