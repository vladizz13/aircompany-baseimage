from datetime import datetime
from dateutil import parser
from use_cases.orders.base_order_use_case import BaseOrderRequest
from ...exceptions.base import BaseValidationError


class LoadModifiedOrdersRequest(BaseOrderRequest):

    def __init__(self, offset: datetime = None):
        super().__init__()
        self.offset: datetime = offset

    def is_valid(self, *args, **kwargs) -> 'LoadModifiedOrdersRequest':
        if not self.offset:
            self.add_error(BaseValidationError(message="Invalid offset timestamp"))
            return self
        if self.offset > datetime.now():
            self.add_error(BaseValidationError(message="Offset date is in future"))
        if (datetime.now() - self.offset).days > 2:
            self.add_error(BaseValidationError(message="Maximum offset exceed. Max is 2 days."))
        return self

    def serialize(self) -> dict:
        return {'offset': str(self.offset)}

    @classmethod
    def deserialize(cls, data: dict):
        return cls(offset=parser.parse(data.get('offset', None)))
