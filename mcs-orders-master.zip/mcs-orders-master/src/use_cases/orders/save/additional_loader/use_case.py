from typing import List, Dict, Set, Optional, Callable
from domain import DomainOrder
from time import time
from uuid import uuid4
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from adapter.sirena_adapter import SirenaInternalAdapter, BaseSirenaError
from ...base_order_use_case import BaseOrderUseCase
from .request import LoadModifiedOrdersRequest
from base.use_case import BaseUseCaseResponse
from domain.types import TicketIdentifier, TransactionSource
from use_cases.orders.search.libs.rloc_transliteration import RlocTransliteration
from repositories.query_builders.order import OrdersQueryBuilder, AndQueryUnit
from dataclasses import dataclass
from redis import Redis


@dataclass
class ModifiedOrder:
    rloc: str
    tickets: Set
    max_tries: int
    current_try: int = 0
    exists_in_db: bool = False
    last_name: Optional[str] = None
    raw_order: Optional[Dict] = None

    def __post_init__(self):
        self.current_try = int(self.current_try)

    @property
    def is_able_to_save(self):
        """
        Можем сохранить броню если есть
        Фамилия
        Билет
        НЕ СОХРАНЕНА у нас
        Нашли ее в сирене
        """
        return all([
            not self.tries_exceeded_maximum,
            self.tickets,
            self.last_name,
            not self.exists_in_db,
            self.raw_order
        ])

    @property
    def is_able_to_check_in_db(self):
        """
        Можем проверить на сущ в базе если есть билет + рлок
        """
        return all([
            not self.tries_exceeded_maximum,
            self.tickets,
            self.rloc
        ])

    @property
    def tries_exceeded_maximum(self) -> bool:
        if self.current_try > self.max_tries:
            return True
        return False

    @property
    def first_ticket(self) -> Optional[str]:
        """
        Первый попавшийся билет
        """
        return next(iter(self.tickets), None)

    def add_last_name(self, last_name: str):
        """
        Сирена возвращает фамилию капсом,
        но не хочет принимать эту же фамилию для поиска брони
        """
        self.last_name = last_name.capitalize()

    def __repr__(self):
        return f"{self.rloc}-{self.first_ticket}"


class LoadModifiedOrdersUseCase(BaseOrderUseCase):
    """
    Проверка измененных заказов в сирене и сохранение их в базу если в базе их нет
    """
    MAX_SAVE_TRIES = 2
    CACHE_EX = 60 * 60 * 24 * 2

    def __init__(
        self,
        sirena_adapter: SirenaInternalAdapter,
        order_repo: GenericMongoRepository,
        save_order_func: Callable,
        redis: Redis
    ):
        super().__init__()
        self.sirena_adapter = sirena_adapter
        self.order_repo = order_repo
        self.save_order_func = save_order_func
        self.redis = redis

        # Статистика
        self.total_received = 0
        self.total_succeed = 0

    def __execute__(self, request: LoadModifiedOrdersRequest, *args, **kwargs) -> BaseUseCaseResponse:
        modified_orders: List[Dict] = self.sirena_adapter.get_modified_orders(request.offset)
        self.total_received = len(modified_orders)
        suitable_orders: List[ModifiedOrder] = self.get_suitable_orders(modified_orders)
        self.mark_existing_orders(suitable_orders)
        self.update_cache(suitable_orders)
        self.enrich_orders_with_last_name(suitable_orders)
        self.enrich_orders_with_raw_pnr(suitable_orders)
        self.save_orders(suitable_orders)
        self.logger.info(f"Total received: {self.total_received}, total saved: {self.total_succeed}")
        return BaseUseCaseResponse(
            value=dict(
                total_orders_modified=len(modified_orders),
                total_orders_suitable=len(suitable_orders),
                total_orders_saved=self.total_succeed
            )
        )

    def update_cache(self, orders: List[ModifiedOrder]) -> List[ModifiedOrder]:
        """
        Получаем попытку сохранения зазака
        """
        for order in orders:
            order.current_try = self.increment_try(order)
        return orders

    def enrich_orders_with_raw_pnr(self, orders: List[ModifiedOrder]):
        """
        Ищем броню в сирене и добавляем ее в ДТО для сохранения
        """
        for order in orders:
            if order.exists_in_db:
                continue
            if order.tries_exceeded_maximum:
                continue
            if not order.last_name:
                continue
            try:
                sirena_raw_order: Optional[Dict] = self.sirena_adapter.search_order(
                    rloc=order.rloc,
                    last_name=order.last_name
                )
            except BaseSirenaError as e:
                self.logger.info(f"Unable to find order in sirena: {e.message}")
                continue
            if not sirena_raw_order:
                continue
            order.raw_order = sirena_raw_order
        return orders

    def save_orders(self, orders: List[ModifiedOrder]):
        """
        Сохраняем отсутствующие в базе заказы
        """
        for order in orders:
            if not order.is_able_to_save:
                continue
            try:
                self.save_order_func(
                    raw_order=order.raw_order,
                    provider=TransactionSource.SIRENA_GRS.value,
                    received=time(),
                    message_id=str(uuid4()),
                    deferred_save=True,
                    return_full_response=False,
                    save_origin_transaction=True
                )
                self.total_succeed += 1
            except Exception as e:
                self.logger.info(f"Unable to save order from sirena, reason: {str(e)}")

    def enrich_orders_with_last_name(self, orders: List[ModifiedOrder]) -> List[ModifiedOrder]:
        """
        Добавляем в DTO фамилию, чтобы можно было запросить заказ в сирене
        Добавляем только для заказов, которые отсуствуют в базе
        """
        for order in orders:
            if order.exists_in_db:
                continue
            if order.tries_exceeded_maximum:
                continue
            ticket: Optional[str] = order.first_ticket
            if not ticket:
                continue
            try:
                res: Dict = self.sirena_adapter.get_eticket(ticket_number=ticket, show_passenger=True, lang='ru')
            except BaseSirenaError as e:
                self.logger.info(f"Failed to get eticket from sirena for {ticket}, reason: {e}")
                continue
            if not res:
                continue
            try:
                last_name: Optional[str] = res.get(
                    'eticket_display', dict()
                ).get('eticket').get('passenger', dict()).get('surname', None)
            except AttributeError:
                continue
            if not last_name:
                continue
            order.add_last_name(last_name)
        return orders

    def mark_existing_orders(self, orders: List[ModifiedOrder]) -> List[ModifiedOrder]:
        """
        Отмечаем существующие заказы в базе
        """
        for order in orders:
            if self.is_order_exists(order):
                order.exists_in_db = True
        return orders

    def is_order_exists(self, order: ModifiedOrder) -> bool:
        """
        Проверяем есть ли заказ в базе
        """
        if not order.is_able_to_check_in_db:
            return True

        query = AndQueryUnit()
        query.add(OrdersQueryBuilder.get_by_ticket_number(order.first_ticket))
        query.add(OrdersQueryBuilder.get_by_order_rloc_or_rloc_host(order.rloc))

        order: Optional[DomainOrder] = self.order_repo.get_single(query)
        return bool(order)

    def get_suitable_orders(self, get_modified_response: List[Dict]) -> List[ModifiedOrder]:
        """
        Нас интересуют заказы где есть рлок, информация о билетах и все билеты UTair
        """
        suitable_orders: List[ModifiedOrder] = list()
        for order in get_modified_response:
            rloc: str = order.get('regnum', {}).get('text')
            tickets: List = order.get('tickinfo', list())

            if not all([rloc, tickets]):
                continue

            if isinstance(tickets, dict):
                tickets = [tickets]
            # все билеты должны быть наши:
            tickets: Set = {ticket.get('@ticknum') for ticket in tickets}
            if not all((
                ticket.startswith(TicketIdentifier.UTAIR.value) for ticket in tickets
            )):
                continue

            suitable_orders.append(
                ModifiedOrder(
                    rloc=self.transliterate_rloc(rloc),
                    tickets=tickets,
                    max_tries=self.MAX_SAVE_TRIES
                ))
        return suitable_orders

    @staticmethod
    def transliterate_rloc(rloc: str) -> str:
        return RlocTransliteration().translate_rloc(rloc)

    def increment_try(self, order: ModifiedOrder) -> int:
        key = f"{order.rloc}-{order.first_ticket}"
        res: int = self.redis.get(key)
        if not res:
            res = 0
        next_try = int(res) + 1
        self.redis.set(key, value=next_try, ex=self.CACHE_EX)
        return next_try
