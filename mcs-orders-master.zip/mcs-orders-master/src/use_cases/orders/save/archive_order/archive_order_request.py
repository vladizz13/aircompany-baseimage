from ...base_order_use_case import BaseOrderRequest

from ...exceptions.save import InvalidTimestampError


class ArchiveOrdersRequest(BaseOrderRequest):

    def __init__(
            self,
            timestamp: int = NotImplementedError
    ):
        super().__init__()
        # Настоящее время, от которого надо будет отсчитать 65 дней и архивировать / перевести заказ в соотв. статус
        self.timestamp = timestamp

    def is_valid(self, *args, **kwargs) -> 'ArchiveOrdersRequest':
        invalid_request = ArchiveOrdersRequest()

        if not self.timestamp:
            invalid_request.add_error(InvalidTimestampError())

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize(self) -> dict:
        return {
            'timestamp': self.timestamp,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            timestamp=data.get('timestamp', None)
        )
