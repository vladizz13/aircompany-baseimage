from typing import List
import time
from domain import DomainOrder
from domain.order.data.status_updated import DomainOrderStatusUpdated
from domain.order.meta.transaction_source import DomainTransactionSource
from domain.types import OrderStatus, TransactionSource
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder, QueryUnit
from use_cases.orders.save.save_order.save_order_response import SaveOrderResponse
from ..archive_order.archive_order_request import ArchiveOrdersRequest
from use_cases.orders.base_order_use_case import BaseOrderUseCase


class ArchiveOrderUseCase(BaseOrderUseCase):
    """
    Юзкейс архивирования заказов
    """
    def __init__(
            self,
            order_repo: GenericMongoRepository,
    ):
        super().__init__()
        self.order_repo = order_repo

    def __execute__(self, request: ArchiveOrdersRequest, *args, **kwargs) -> SaveOrderResponse:
        archive_date: int = self.get_archive_date(request)
        spec: QueryUnit = OrdersQueryBuilder.get_by_status_and_timelimit(
            status=OrderStatus.B.value,
            time_limit=archive_date
        )
        orders: List[DomainOrder] = self.order_repo.list(spec)

        for order in orders:
            # Если присуствуют либо билеты/купоны/оплата - не архивируем такой заказ
            if any([
                order.data.tickets,
                order.data.coupons,
                order.data.fops
            ]):
                continue

            order.data.status_updated.append(
                DomainOrderStatusUpdated(
                    status=order.data.status,
                    date=time.time()
                )
            )
            order.data.status = OrderStatus.X.value
            order.meta.updated.append(
                DomainTransactionSource(
                    date=time.time(),
                    provider=TransactionSource.ARCHIVED.value,
                    message_id=None
                )
            )

            self.order_repo.update(
                item=order,
                spec=OrdersQueryBuilder.get_by_order_uuid(
                    order_uuid=order.data.order_uuid
                )
            )

        return SaveOrderResponse(value=orders)

    @staticmethod
    def get_archive_date(request: ArchiveOrdersRequest) -> int:
        """
        Получить дату архивации
        """
        delta: int = 0  # 60 * 60 * 24 * 65  # 65 дней
        archive_date: int = request.timestamp - delta
        return archive_date
