from typing import Union, Optional
from domain.types import TransactionSource
from use_cases.orders.save.save_order.save_order_request import SaveOrderRequest


class DeferredSaveOrderRequest(SaveOrderRequest):

    def __init__(
            self,
            order: dict,
            provider: str,
            received: Union[int, float],
            message_id: str,
            sirena_version: Optional[str] = None
    ):
        super().__init__(
            order=order,
            provider=provider,
            received=received,
            message_id=message_id,
        )
        self.sirena_version = sirena_version

    @property
    def is_sirena_versioned(self) -> bool:
        return all((
            self.provider == TransactionSource.SIRENA.value,
            self.sirena_version
        ))

    def serialize(self) -> dict:
        return {
            'order': self.order,
            'provider': self.provider,
            'received': self.received,
            'message_id': self.message_id,
            'sirena_version': self.sirena_version
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order=data.get('order', None),
            provider=data.get('provider', None),
            received=data.get('received', None),
            message_id=data.get('message_id', None),
            sirena_version=data.get('sirena_version', None)
        )
