from domain import DomainOrder
from redis import Redis
from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from repositories.mongo.mongo_generic_repository import GenericMongoRepository

from use_cases.orders.save.save_order.save_order_use_case import SaveOrderUseCase
from use_cases.orders.save.save_order.save_order_response import SaveOrderResponse
from .deferred_save_order_request import DeferredSaveOrderRequest
from ..utils.currency_rates import CurrencyRates
from ...search.libs.rloc_transliteration import RlocTransliteration
from adapter.service_agent.service_agent_adapter import ServiceAgentAdapter


class DeferredSaveOrderUseCase(SaveOrderUseCase):
    """
    Юзкейс отложенного сохранения заказа
    Сохраняет смапленный и нормализованный заказ
    """
    def __init__(
            self,
            order_repo: GenericMongoRepository,
            prorate_repo: GenericMongoRepository,
            origin_transactions_repo: GenericMongoRepository,

            currency_adapter: CurrencyRates,
            mono_app_adapter: MonoAppAdapter,
            sirena_adapter: SirenaInternalAdapter,
            rloc_transliteration: RlocTransliteration,
            change_pd_repo: GenericMongoRepository,
            redis: Redis,
    ):
        super().__init__(
            order_repo=order_repo,
            prorate_repo=prorate_repo,
            origin_transactions_repo=origin_transactions_repo,
            currency_adapter=currency_adapter,
            mono_app_adapter=mono_app_adapter,
            save_orders_queue=None,
            sirena_adapter=sirena_adapter,
            service_agent_adapter=ServiceAgentAdapter(),
            rloc_transliteration=rloc_transliteration,
            change_pd_repo=change_pd_repo,
            redis=redis
        )

    def __execute__(self, request: DeferredSaveOrderRequest, *args, **kwargs) -> SaveOrderResponse:
        mapped_order = request.order
        new_order: DomainOrder = DomainOrder.deserialize(mapped_order)
        return self.save_order(new_order, request)
