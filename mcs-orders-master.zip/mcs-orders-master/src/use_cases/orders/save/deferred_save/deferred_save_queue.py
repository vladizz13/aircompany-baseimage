from typing import List
from uuid import uuid4
import json
from redis import Redis
import time
from libs.redis_queues.list_queue import ListRedisQueue
from use_cases.orders.save.deferred_save.deferred_save_order_request import DeferredSaveOrderRequest


class SaveOrdersQueue(ListRedisQueue):
    """
    Адаптер для работы с отложенным сохранением заказа
    """

    save_delta = 10

    def __init__(self, gateway: Redis):
        super(SaveOrdersQueue, self).__init__(gateway=gateway)

    def _get_time_delta_(self) -> int:
        """
        Дельта времени, старше которого мы осталвяем заказы в очереди
        и ожидаем поступления новых для сортировки в будущем
        """
        return int(time.time()) - self.save_delta

    def get_save_queue(self, key: uuid4, dequeue_orders: bool = True) -> List[DeferredSaveOrderRequest]:
        """
        Возвращаем отсортированные по дате сохранения SaveOrderRequest для последовательного сохранения
        :param key: ключ очереди
        :param dequeue_orders: Убрать из очереди полученные заказы
        :return:
        """
        queued_orders = self.get_queue_values_by_key(key)

        queued_requests: List[DeferredSaveOrderRequest] = []
        for request in queued_orders:
            queued_requests.append(DeferredSaveOrderRequest.deserialize(json.loads(request)))

        filtered_orders: List[DeferredSaveOrderRequest] = list(
            filter(lambda r: r.received < self._get_time_delta_(), queued_requests)
        )

        if dequeue_orders:
            for order_to_deque in filtered_orders:
                self.dequeue(key, order_to_deque)

        # сортируем по времени получения
        sorted_orders: List[DeferredSaveOrderRequest] = list(sorted(filtered_orders, key=lambda k: k.received))
        # в отсортированном массиве, сортируем по версии брони от сирены на месте
        sorted_orders: List[DeferredSaveOrderRequest] = self.sort_sirena_requests(sorted_orders)

        return sorted_orders

    def get_active_orders(self, max_queues_to_return: int = 250) -> List[str]:
        """
        Получить все ключи очередей заказов
        """
        return self.get_available_queue_keys(max_items=max_queues_to_return)[0:max_queues_to_return]

    @staticmethod
    def sort_sirena_requests(sorted_orders: List[DeferredSaveOrderRequest]) -> List[DeferredSaveOrderRequest]:
        """
        Сортировка транзакций из потока сирены по версии
        """
        sirena_indexes: List[int] = list()
        sirena_requests: List[DeferredSaveOrderRequest] = list()

        # Собираем сиреновские запросы, которые можно отсортировать по версии
        # запоминаем их адрес
        for idx, save_request in enumerate(sorted_orders):
            if save_request.is_sirena_versioned:
                sirena_indexes.append(idx)
                sirena_requests.append(save_request)

        # Сортируем по версии
        sirena_requests: List[DeferredSaveOrderRequest] = list(sorted(
            sirena_requests, key=lambda k: k.sirena_version
        ))

        # Заменяем запросы по порядку
        for idx, sirena_request in enumerate(sirena_requests):
            sorted_orders[sirena_indexes[idx]] = sirena_request
        return sorted_orders
