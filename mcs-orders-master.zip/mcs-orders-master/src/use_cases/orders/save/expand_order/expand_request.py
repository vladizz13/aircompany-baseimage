from typing import Optional
from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain.types import TransactionSource
from domain import DomainOrder

from use_cases.orders.exceptions.save import InvalidProviderSourceError

from use_cases.orders.exceptions.save import InvalidInputTransactionError


class ExpandOrderRequest(BaseOrderRequest):

    def __init__(
            self,
            new_order: DomainOrder = None,
            provider: str = None,
            existing_order: Optional[DomainOrder] = None
    ):
        super().__init__()
        self.new_order: DomainOrder = new_order
        self.existing_order: DomainOrder = existing_order
        self.provider: str = provider

    def is_valid(self, *args, **kwargs) -> 'ExpandOrderRequest':
        invalid_request = ExpandOrderRequest()

        if not self.new_order or not isinstance(self.new_order, DomainOrder):
            invalid_request.add_error(InvalidInputTransactionError())

        if self.provider not in TransactionSource._value2member_map_:
            invalid_request.add_error(InvalidProviderSourceError())

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize(self) -> dict:
        return {
            'new_order': self.new_order.serialize(),
            'existing_order': self.existing_order.serialize() if self.existing_order else None
        }

    @classmethod
    def deserialize(cls, data: dict):
        existing_order = data.get('existing_order', dict())
        return cls(
            new_order=DomainOrder.deserialize(data.get('new_order', dict())),
            existing_order=DomainOrder.deserialize(existing_order) if existing_order else None,
        )
