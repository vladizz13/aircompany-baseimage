from domain import DomainOrder
from use_cases.orders.base_order_use_case import BaseOrderResponse


class ExpandOrderResponse(BaseOrderResponse):

    def __init__(self, value: DomainOrder = None):
        super().__init__(value=value)
