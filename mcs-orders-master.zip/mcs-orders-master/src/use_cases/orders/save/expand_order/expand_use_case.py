import logging

from adapter.service_agent import ServiceAgentAdapter
from domain import DomainOrder
from libs.chain_of_responsibility.chain import InitChainUnit
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from use_cases.orders.save.expand_order.expanders.available_actions import SetAvailableActionsExpander
from use_cases.orders.save.expand_order.expanders.convert_currency import ConvertTicketMoneyIntoRubCurrencyExpander
from use_cases.orders.save.expand_order.expanders.departure_timestamps import DepartureTimestampsExpander
from use_cases.orders.save.expand_order.expanders.layover_time import LayOverTimeExpander
from use_cases.orders.save.expand_order.expanders.marketing_tags import MarketingTagsExpander
from use_cases.orders.save.expand_order.expanders.offers_expander import OffersExpander
from use_cases.orders.save.expand_order.expanders.order_gds import OrderGDSExpander
from use_cases.orders.save.expand_order.expanders.order_status import OrderStatusArchiveExpander
from use_cases.orders.save.expand_order.expanders.price import OrderPriceExpander
from use_cases.orders.save.expand_order.expanders.segment_cost import CalculateSegmentCostByProrateExpander
from use_cases.orders.save.expand_order.expanders.segment_duration import CalculateSegmentDurationExpander
from use_cases.orders.save.expand_order.expanders.segment_direction import OrderDirectionExpander
from use_cases.orders.save.expand_order.expanders.segment_status_visual import CalculateSegmentStatusVisualExpander
from use_cases.orders.save.expand_order.expanders.service_expander import ServiceExpander
from use_cases.orders.save.utils.currency_rates import CurrencyRates
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from .expand_request import ExpandOrderRequest
from .expand_response import ExpandOrderResponse
from use_cases.orders.exceptions.save import UnableToExpandOrderError


logger = logging.getLogger()


class ExpandOrderUseCase(BaseOrderUseCase):

    def __init__(
            self,
            prorate_repo: GenericMongoRepository,
            currency_adapter: CurrencyRates,
            service_agent_adapter: ServiceAgentAdapter,
            change_pd_repo: GenericMongoRepository,
    ):
        super().__init__()
        self.prorate_repo: GenericMongoRepository = prorate_repo
        self.currency_adapter: CurrencyRates = currency_adapter
        self.service_agent_adapter: ServiceAgentAdapter = service_agent_adapter
        self.change_pd_repo: GenericMongoRepository = change_pd_repo

    def __execute__(self, request: ExpandOrderRequest, *args, **kwargs) -> ExpandOrderResponse:
        try:
            expanded_order: DomainOrder = self.expand_order(
                order=request.new_order,
                existing_order=request.existing_order,
                provider=request.provider
            )
        except Exception as e:
            logger.exception(e)
            return ExpandOrderResponse.build_from_exception(UnableToExpandOrderError(message=str(e), inner_exception=e))

        return ExpandOrderResponse(value=expanded_order)

    def expand_order(
            self,
            order: DomainOrder,
            provider: str,
            existing_order: DomainOrder = None
    ) -> DomainOrder:
        """
        Расширяем заказ дополнительными полями
        """
        chain = InitChainUnit()

        (
            chain
            .set_next(MarketingTagsExpander())
            .set_next(OrderGDSExpander())
            .set_next(OrderDirectionExpander(existing_order=existing_order))
            .set_next(LayOverTimeExpander())
            .set_next(ConvertTicketMoneyIntoRubCurrencyExpander(currency_adapter=self.currency_adapter))
            .set_next(CalculateSegmentCostByProrateExpander(prorate_repo=self.prorate_repo))
            .set_next(OrderPriceExpander())
            .set_next(CalculateSegmentStatusVisualExpander())
            .set_next(OffersExpander())
            .set_next(CalculateSegmentDurationExpander())
            .set_next(ServiceExpander(service_agent_adapter=self.service_agent_adapter))
            .set_next(OrderStatusArchiveExpander(existing_order=existing_order))
            .set_next(DepartureTimestampsExpander(existing_order=existing_order))
            # NB: расширитель основывается на StatusVisual сегментов и на архивный статус заказа
            .set_next(SetAvailableActionsExpander(change_pd_repo=self.change_pd_repo))
        )

        chain.handle(order, request=provider)
        return order
