import logging
from typing import Any, Union, List, Optional, Set, Dict
from time import time

from domain.pd_changes import DomainPDChanges
from domain import DomainOrder
from domain.order.data import (
    DomainSegment, DomainCoupon, DomainFop, DomainTicket
)
from domain.types import TicketIdentifier
from domain.types import OrderStatus
from domain.types import SegmentStatusVisual
from domain.types import CouponStatus
from domain.types import CompanyPPR
from domain.types import FopsCode
from domain.types import GDS
from domain.types import Agencies
from domain.types import OAK
from domain.types import UTairChangePDReqStatuses
from domain.types import SegmentStatus
from domain.types import FareCode
from domain.types import ServiceStatus
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.pd_changes import PDChangesQueryBuilder
from .base_expander import BaseOrderExpander

logger = logging.getLogger('SetAvailableActionsExpander')


class SetAvailableActionsExpander(BaseOrderExpander):
    """
    Устанавливает флаги возможных действий с бронью
        обмен
        возврат
        покупка доп услуг
        доступность ваучера
        распечатка МК
        оплата заказа
        регистрация на рейс
        снятие мест
        смена персональных данных
    """

    def __init__(
            self,
            change_pd_repo: GenericMongoRepository
    ):
        self.order: Optional[DomainOrder] = None
        self.change_pd_repo: GenericMongoRepository = change_pd_repo

        self.segment_id_to_coupon_map: Dict[str, List[DomainCoupon]] = dict()

    def __init(self, order: DomainOrder):
        self.order = order
        self.segment_id_to_coupon_map = {
            seg.segment_id: [
                coup for coup in self.order.data.coupons if coup.segment_id == seg.segment_id
            ]
            for seg in self.gds_active_segments()
        }

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        self.__init(order)

        if self.is_all_actions_unavailable():
            return order

        field_to_func_map: Dict[str, callable] = dict(
            can_return_deposit=self.can_return_deposit,
            can_print_mk=self.can_print_mk,
            can_pay_order=self.can_pay_order,
            can_change_personal_data=self.can_change_personal_data,
            can_check_in=self.can_check_in,
            can_release=self.can_release,
            can_change=self.can_change,
            can_return=self.can_return,
            can_purchase_services=self.can_purchase_services,
        )

        for name, func in field_to_func_map.items():
            try:
                result = func()
            except Exception as e:
                logger.exception(
                    f"Unable to calculate order available action: {name}, reason: {e}", extra={
                        "order_uuid": order.data.order_uuid,
                    }
                )
                result = False
            order.data.available_actions.__setattr__(name, result)

        return order

    def is_all_actions_unavailable(self) -> bool:
        """
        Если есть сегмент на контроле и gds_active -> True
        """
        return self._is_segment_status_visual_exists([SegmentStatusVisual.CONTROL])

    def can_change(self) -> bool:
        """
        Возможность изменить даты полёта
        Если:
            статус заказа T, А (то есть в заказе есть билеты/купоны/данные о формах оплаты)
            нашелся хотя бы один сегмент с купоном, и
                визуальный статус сегмента (Активен, Зарегистрирован, Аннулировано место, неактивен)
                (status_visual=active/disabled/released/transfer)
            нет сегментов со статусом:
                рейс отменен, пересадка
            билет выписан менее 1 года назад для хотя бы одного купона в не терминальном статусе
                (от даты data.tickets.issue_datetime, если не заполнено, то data.segments.booking_timestamp,
                если не заполнено, то analytics_data.first_segment_booking_timestamp, если пусто, то не проверяем срок)
            "agency" : "02TUM" или "02ТЮМ"
            Pos_id = 29834733 (голосовая оплата),
                29828326 (СайтТаис 441), 29843203 (сайт, переход с авиасейлз),
                29843553 (сайт, переход со skyscanner),
                29837533 (Краснодарский ППР Sirena#444),
                29845631 (эксперименты с тарификацией),
                92308716 (Сайт + КоллЦентр в сеансе ТКП)
            нет сегментов с подсадкой
        """
        return all((
            self.order.data.status in (OrderStatus.T.value, OrderStatus.A.value),
            self._is_segment_status_visual_exists([
                SegmentStatusVisual.ACTIVE, SegmentStatusVisual.DISABLED,
                SegmentStatusVisual.RELEASED, SegmentStatusVisual.REGISTERED
            ], has_coupon=True),
            not self._is_segment_status_visual_exists([
                SegmentStatusVisual.CANCELED, SegmentStatusVisual.TRANSFER
            ]),
            self.order.data.pos_data.agency in Agencies.UT_SITE.value,
            self._is_valid_booking_time_constraint(
                coupons_to_check=self._get_coupons_by_status(
                    status=CouponStatus.non_terminal_values()
                )
            ),
            self.order.data.pos_data.pos_id in (
                CompanyPPR.VOICE_IVR.value,
                CompanyPPR.WEBSITE.value,
                CompanyPPR.SIRENA_CLIENT444.value,
                CompanyPPR.TARIFICATION_EXPERIMENTS.value,
                CompanyPPR.WEBSITE_AND_CALLCENTER.value,
                CompanyPPR.WEBSITE_AVIASALES.value,
                CompanyPPR.WEBSITE_SKYSCANNER.value,
            ),
            not self.any_standby_segment_exists()
        ))

    def can_purchase_services(self) -> bool:
        """
        Возможность покупки услуг
            статус заказа T
            хотя бы один сегмент в будущем и у него status_visual= active или registered
            у такого сегмента есть купон
            нет сегментов с подсадкой
        """
        future_segments: List[DomainSegment] = [
            s for s in self.gds_active_segments() if s.departure_timestamp > time()
        ]
        future_segment_ids: Set[str] = {s.segment_id for s in future_segments}
        return all((
            self.order.data.status == OrderStatus.T.value,
            self._is_segment_status_visual_exists([
                SegmentStatusVisual.ACTIVE, SegmentStatusVisual.REGISTERED
            ], future_segments),
            self.order.data.coupons,
            any((c.segment_id in future_segment_ids for c in self.order.data.coupons)),
            not self.any_standby_segment_exists()
        ))

    def can_return(self) -> bool:
        """
        Возможность оформить возврат
            статус заказа Т
            не попадает под постановление
                (купоны в O, U, A, C, их сегменты еще в будущем (после 18.03.2020).
                и Покупка брони до 30.04.2020)
            билет продан нами
        """
        if any((item.fare_code.startswith("YSHOW") for item in self.order.data.coupons if item.fare_code)):
            return True

        return all((
            self.order.data.status == OrderStatus.T.value,
            not self.is_under_decree(),
            self.order.data.pos_data.pos_id in (
                CompanyPPR.VOICE_IVR.value,
                CompanyPPR.WEBSITE.value,
                CompanyPPR.WEBSITE_AND_CALLCENTER.value,
                CompanyPPR.WEBSITE_AVIASALES.value,
                CompanyPPR.WEBSITE_SKYSCANNER.value,
                CompanyPPR.SIRENA_CLIENT444.value,

                CompanyPPR.TARIFICATION_EXPERIMENTS.value
            ),
            self._is_valid_booking_time_constraint(
                coupons_to_check=self._get_coupons_by_status(
                    status=CouponStatus.non_terminal_values()
                )
            ),
        ))

    def can_return_deposit(self) -> bool:
        """
        Возможность оформить возврат ваучером
            1. Ни один из купонов не находится в статусах: Z, Е
            2. Тариф не коммерческий и не транзитный (Ни один из Fare_code не заканчивается на "/ZZM", "/TR")
            3. GDS 1H/15
            4. Для всех форм оплаты fop_code из списка ("CC", "CA", "FF", "PK", "IN", "VZ") или fop_free_text
                начинается элементом из списка ("FF", "PK", "IN", "VZ/VAU")
            5. Если fop_code ==  "VZ",
                то account_num должен начинаться с "VAU" - проверка, что оплата была ваучером,
                остальные VZ не разрешены
            6. Хотя бы 1 билет должен начинаться с "298"

            7. Выполнено одно из условий:
                Заказ подходит под поставновление:
                    есть сегменты с вылетом после 18.03.2020,
                    с которым связаны купоны в статусе O,U, A или С,
                    Бронь оформлена до 30.04.2020 (проверить в полях data.tickets.issue_datetime,
                    если не заполнено, то data.segments.booking_timestamp, если не заполнено,
                    то analytics_data.first_segment_booking_timestamp).
                Заказу менее года
                    Хотя бы 1 из купонов в статусе A, O или U,
                    и его билет выписан менее года назад (от даты data.tickets.issue_datetime, если не заполнено,
                    то data.segments.booking_timestamp, если не заполнено,
                    то analytics_data.first_segment_booking_timestamp,
                    если пусто, то не проверяем срок)
            8. Нет сегментов с подсадкой
        """
        return all((
            # Ни один из купонов не находится в статусах: Z, Е
            not any((c.status in (
                CouponStatus.Z.value,
                CouponStatus.E.value
            ) for c in self.order.data.coupons)),
            # Ни один из Fare_code не заканчивается на ZZM, TRR
            not any((f for f in self.order.data.offers if f.fare_code and f.fare_code.endswith((
                FareCode.TRANSFER.value, FareCode.CORPORATE.value
            )))),
            # GDS должен быть "наш"
            self.is_utair_gds(),
            # п4 п5
            all((self.is_fops_valid_for_deposit_return(fop) for fop in self.order.data.fops)),
            # Хотя бы 1 билет должен начинаться с "298"
            any((t.ticket.startswith(TicketIdentifier.UTAIR.value) for t in self.order.data.tickets)),

            any((self.is_under_decree(), self._is_valid_booking_time_constraint(
                coupons_to_check=self._get_coupons_by_status(
                    status=[CouponStatus.A, CouponStatus.O, CouponStatus.U]
                )
            ))),
            not self.any_standby_segment_exists()
        ))

    def can_print_mk(self) -> bool:
        """
        Возможность распечатать МК
            если статус заказа T или А,
            все билеты начинаются с "298"
            не стоит метка группы
            Нет сегмента с status_visual=пересадка(transfer)
            нет сегментов в статусе status_visual="Выполнен возврат"
        """
        return all((
            self.order.data.status in (OrderStatus.A.value, OrderStatus.T.value),
            all((
                t.ticket.startswith(TicketIdentifier.UTAIR.value) for t in self.order.data.tickets
            )),
            self.order.data.group is not True,
            not self._is_segment_status_visual_exists([
                SegmentStatusVisual.RETURNED,
                SegmentStatusVisual.TRANSFER
            ]),
        ))

    def can_pay_order(self) -> bool:
        """
        Возможность оплатить заказ
            1. Статус заказа в B. X
            2. у всех сегментов status_visual=Не оплачен (not_payed) и дата его вылета в будущем.
            3. "agency" : "02TUM" или "02ТЮМ"
            ИЛИ
            1. Заказ в статусе Т
            2. Хотя бы одна услуга в статусе HD
        """
        if all((s.departure_timestamp < time() for s in self.gds_active_segments())):
            return False

        def _is_segment_not_payed_and_in_future(segment: DomainSegment) -> bool:
            return all((
                segment.status_visual == SegmentStatusVisual.NOT_PAYED.value,
                segment.departure_timestamp > time()
            ))

        return all((
            self.order.data.status in (OrderStatus.B.value, OrderStatus.X.value),
            self.order.data.pos_data.agency in Agencies.UT_SITE.value,
            self.gds_active_segments(),
            all((_is_segment_not_payed_and_in_future(s) for s in self.gds_active_segments())),
        )) or all((
            self.order.data.status == OrderStatus.T.value,
            any((s.status == ServiceStatus.HD.value for s in self.order.data.services))
        ))

    def can_check_in(self) -> bool:
        """
        Возможность зарегистрироваться
            Бронь в статусе T
            Есть хотя бы один сегмент c status_visual= "активен" или "зарегистрирован",
                у которого до планового времени вылета осталось меньше 36 часов.
            Нет сегментов с подсадкой
        """
        def _is_able_to_check_in(departure_timestamp: int) -> bool:
            if departure_timestamp <= time():
                return False    # Вылетел
            delta: int = int(departure_timestamp - time())
            return delta < time_until_departure

        time_until_departure: int = 60 * 60 * 36  # 36 часов
        active_segments = [
            s for s in self.gds_active_segments() if s.status_visual in [
                SegmentStatusVisual.ACTIVE.value, SegmentStatusVisual.REGISTERED.value
            ] and _is_able_to_check_in(s.departure_timestamp)
        ]
        return all((
            self.order.data.status == OrderStatus.T.value,
            active_segments,
            not self.any_standby_segment_exists()
        ))

    def can_release(self) -> bool:
        """
        Возможность аннулирования мест
            Бронь в статусе T
            АК=UT
            Есть хотя бы 1 сегмент в статусе HK/TK с хотя бы одним купоном
                не в терминальном статусе (не E, F, P, R, G, X, V, T, Z)
            Нет сегментов с подсадкой
        """
        hk_tk_segments: List[DomainSegment] = self._get_segments_by_status([
            SegmentStatus.HK, SegmentStatus.TK
        ])
        is_utair: bool = False
        non_terminal_segment_exists: bool = False
        for segment in hk_tk_segments:
            non_terminal_coupons: List[DomainCoupon] = self._get_coupons_by_status(
                status=CouponStatus.non_terminal_values(),
                coupons=self.segment_id_to_coupon_map.get(segment.segment_id, [])
            )
            ak = segment.ak or segment.oak
            if non_terminal_coupons and ak == OAK.UT.value:
                is_utair = True
                non_terminal_segment_exists = True
                break

        return all((
            self.order.data.status == OrderStatus.T.value,
            non_terminal_segment_exists,
            is_utair,
            not self.any_standby_segment_exists()
        ))

    def can_change_personal_data(self) -> bool:
        """
        Возможность изменить персональные данные
            1.В броне есть хотя бы один пассажир, у которого не меняли данные.
            2.Pos_id = 29834733(VOICE_IVR), 29828326 (WEBSITE), 29843203 (сайт, переход с авиасейлз),
                29843553 (сайт, переход со skyscanner), 29837533 (Краснодарский ППР Sirena#444),
                29845631 (TARIFICATION_EXPERIMENTS), 92308716 (Сайт + КоллЦентр в сеансе ТКП)
            3.Маркетиновая АК у всех сегментов - UT
            4.Билет должен начинаться с "298"
            5.Нет сегментов в визуальных статусах canceled, released, disabled
            6.Все сегменты, связанные с купонами O и F данного пассажира, в статусах HK/TK
            7.Нет сегментов с подсадкой
        """
        # 1.
        unchanged_pd_passenger_ids: Set[str] = self._get_unchanged_passengers_ids()
        if not unchanged_pd_passenger_ids:
            return False

        return all((
            # 2.
            self.order.data.pos_data.pos_id in (
                CompanyPPR.VOICE_IVR.value,
                CompanyPPR.WEBSITE.value,
                CompanyPPR.WEBSITE_AVIASALES.value,
                CompanyPPR.WEBSITE_SKYSCANNER.value,
                CompanyPPR.SIRENA_CLIENT444.value,
                CompanyPPR.TARIFICATION_EXPERIMENTS.value,
                CompanyPPR.WEBSITE_AND_CALLCENTER.value
            ),
            any((pid for pid in unchanged_pd_passenger_ids if self._is_passenger_can_change_personal_data(pid))),
            # Все сегменты UT
            all((s.ak == OAK.UT.value or s.oak == OAK.UT.value for s in self.gds_active_segments())),
            # Все билеты UT
            all((t.ticket.startswith(TicketIdentifier.UTAIR.value) for t in self.order.data.tickets)),
            not self.any_standby_segment_exists()
        ))

    def is_under_decree(self):
        """
        Попадает ли заказ под постановление от минтранса
            - купоны в O.U.A C, их сегменты еще в будущем (после 18.03.2020)
            - и Покупка брони до 30.04.2020
        """
        order_created = self.order.data.analytics_data.first_segment_booking_time

        decree_date = 1588291200                # GMT: Friday, 1 May 2020 y., 0:00:00
        transfer_decree_date = 1584489600       # GMT: Wednesday, 18 March 2020 y., 0:00:00

        unused_segments = tuple(
            segment for segment in self.gds_active_segments()
            if segment.segment_id in {
                coupon.segment_id for coupon in self.order.data.coupons
                if coupon.status
                in (
                       CouponStatus.O.value,
                       CouponStatus.A.value,
                       CouponStatus.U.value,
                       CouponStatus.C.value
                   )
            }
        )
        return all((
            any((s.departure_timestamp > transfer_decree_date for s in unused_segments)),
            order_created is None or order_created <= decree_date
        ))

    def _is_segment_status_visual_exists(
            self,
            segment_status: Union[SegmentStatusVisual, List[SegmentStatusVisual]],
            segments: Optional[List[DomainSegment]] = None,
            has_coupon: bool = False
    ) -> bool:
        """
        Проверка на наличие сегмента в переданном статусе
        :param has_coupon: Нужно ли проверить наличие купона у подходящего сегмента
        """
        def _segment_has_coupon(_segment: DomainSegment) -> bool:
            return any((c.segment_id == _segment.segment_id for c in self.order.data.coupons))

        segments_to_check = segments if segments is not None else self.gds_active_segments()
        for segment in segments_to_check:
            if segment.status_visual in [s.value for s in self.to_list(segment_status)]:
                return True if not has_coupon else _segment_has_coupon(segment)
        return False

    def any_standby_segment_exists(self) -> bool:
        """
        Существует хотя бы один сегмент с подсадкой
        """
        return any((
            s.standby for s in self.gds_active_segments()
        ))

    def _get_segments_by_status(
            self,
            status: Union[SegmentStatus, List[SegmentStatus]],
            segments: Optional[List[DomainSegment]] = None
    ) -> List[DomainSegment]:
        """
        Получение сегментов по статусу
        """
        segments = segments or self.gds_active_segments()
        return [s for s in segments if s.status in [s.value for s in self.to_list(status)]]

    def _get_coupons_by_status(
            self,
            status: Union[CouponStatus, List[CouponStatus]],
            coupons: Optional[List[DomainCoupon]] = None
    ):
        """
        Получение купонов по статусу
        """
        coupons = coupons or self.order.data.coupons
        return [s for s in coupons if s.status in [s.value for s in self.to_list(status)]]

    @staticmethod
    def is_fops_valid_for_deposit_return(fops: DomainFop) -> bool:
        """
        Проверка на валидность фопса для возврата ваучером
        Форма оплаты fop_code из списка ("CC", "CA", "FF", "PK", "IN", "VZ")
        ИЛИ
        fop_free_text начинается элементом из списка ("FF", "PK", "IN", "VZ/VAU")
        Если fop_code ==  "VZ", то account_num должен начинаться с "VAU" - проверка,
            что оплата была ваучером, остальные VZ не разрешены
        """
        if fops.code and fops.code.startswith((
            FopsCode.CC.value,
            FopsCode.CA.value,
            FopsCode.FF.value,
            FopsCode.PK.value,
            FopsCode.IN.value,
        )):
            return True
        if fops.code and fops.code.startswith(FopsCode.VZ.value):
            return fops.account_num.startswith("VAU")
        if fops.free_text and fops.free_text.startswith((
            FopsCode.FF.value,
            FopsCode.PK.value,
            FopsCode.IN.value,
            FopsCode.VZ.value
        )):
            return True
        return False

    @staticmethod
    def to_list(data: Union[Any, List[Any]]) -> List[Any]:
        if not isinstance(data, list):
            data = [data]
        return data

    def _get_unchanged_passengers_ids(self) -> Set[str]:
        """
        Получение идентификаторов пассажиров, которые не меняли персональные данные
        """
        pd_changes: List[DomainPDChanges] = self.change_pd_repo.list(
            spec=PDChangesQueryBuilder.get_by_order_uuid(self.order.data.order_uuid)
        )
        changed_pd_passengers_ids: Set[str] = {
            p.passenger_id for p in pd_changes if p.status == UTairChangePDReqStatuses.DONE.value
        }
        unchanged_pd_passenger_ids: Set[str] = {
            p.passenger_id for p in self.order.data.passengers
        } - changed_pd_passengers_ids
        return unchanged_pd_passenger_ids

    def _is_passenger_can_change_personal_data(self, passenger_id: str) -> bool:
        """
        Проверка возможности изменить персональные данные
        для пассажира по его идентификатору
        """
        coupons: List[DomainCoupon] = [
            c for c in self.order.data.coupons if c.passenger_id == passenger_id
        ]

        # Купоны в статусе O, F
        of_coupons: List[DomainCoupon] = [c for c in coupons if c.status in (
            CouponStatus.O.value, CouponStatus.F.value
        )]

        return all((
            # есть сегменты, связанные с купонами O и F данного пассажира, в статусах HK/TK
            any((c for c in of_coupons if self._is_coupon_corresponds_to_segment_in_status(c, [
                SegmentStatus.HK, SegmentStatus.TK
            ]))),
            not self._is_segment_status_visual_exists([
                SegmentStatusVisual.CANCELED, SegmentStatusVisual.RELEASED, SegmentStatusVisual.DISABLED
            ])
        ))

    def _is_coupon_corresponds_to_segment_in_status(
            self,
            coupon: DomainCoupon,
            status: Union[SegmentStatus, List[SegmentStatus]]
    ) -> bool:
        """
        Связан ли купон с сегментов в целевом статусе
        """
        segments: List[DomainSegment] = self._get_segments_by_status(status)
        return any((s for s in segments if coupon.segment_id == s.segment_id))

    def _is_valid_booking_time_constraint(
            self,
            coupons_to_check: List[DomainCoupon]
    ) -> bool:
        """
        Некоторые действия можно совершать только если с момента
        бука/оплаты прошло не больше года (общее ограничение)
        Проверяем прошел ли год
        """
        if not coupons_to_check:
            return False
        ticket_numbers: Dict[str, str] = {c.ticket: c.segment_id for c in coupons_to_check}
        if not ticket_numbers:
            return False

        tickets: List[DomainTicket] = [
            t for t in self.order.data.tickets if t.ticket in ticket_numbers
        ]
        segments: List[DomainSegment] = [
            s for s in self.gds_active_segments() if s.segment_id in set(ticket_numbers.values())
        ]

        try:
            _tickets_source = tickets[0].issue_datetime
        except IndexError:
            _tickets_source = None

        try:
            _segment_source = segments[0].booking_timestamp
        except IndexError:
            _segment_source = None

        _root_source = self.order.data.analytics_data.first_segment_booking_time

        if not any((_tickets_source, _segment_source, _root_source)):
            # Если нигде данных нет, то опускаем эту проверку
            return True

        year: int = 60 * 60 * 24 * 365  # 1 year
        book_time: int = _tickets_source or _segment_source or _root_source
        return (time() - book_time) < year

    def is_utair_gds(self) -> bool:
        gds_field = self.order.data.pos_data.gds.value in (GDS.SIRENA.value, GDS.SIRENA_V2.value)
        rloc_suffix = self.order.data.rloc.split('/')[1] in (GDS.SIRENA.value, GDS.SIRENA_V2.value)
        return gds_field or rloc_suffix

    def gds_active_segments(self) -> List[DomainSegment]:
        """
        Возвращает массив активных сегментов.
        При расчетах доступных действий с заказом необходимо опираться только
        на активные сегменты (gds_active: True).
        У сегментов gds_active: False купонов нет.
        """
        return [s for s in self.order.data.segments if s.gds_active]
