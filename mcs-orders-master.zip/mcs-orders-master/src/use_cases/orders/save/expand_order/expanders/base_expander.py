from abc import abstractmethod
from typing import Any
from domain import DomainOrder
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseOrderExpander(AbstractChainHandler):
    """
    Базовый расширитель заказа
    Для добавления нового расширителя унаследоваться и реализовать
    логику в методе expand

    Указать transaction_source если расширитель принадлежит конкретному провайдеру
    >>> from domain.types import TransactionSource
    >>> transaction_source = TransactionSource.SIRENA.value
    """
    transaction_source: str = None

    def handle(self, order: DomainOrder, request: Any = None):
        if not self.skip(request):
            order = self.expand(order, request)
        return super().handle(order, request)

    def skip(self, request: Any) -> bool:
        # Общие расширители для любого провайдера
        if self.transaction_source is None:
            return False
        # Расширители для конкретного провайдера
        if request is not None and self.transaction_source != request:
            return True
        return False

    @abstractmethod
    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        raise NotImplementedError()
