from typing import Any, Union, List
from domain import DomainOrder
from domain.order.data.ticket import DomainTicket, DomainMonetaryInfo, DomainTaxes
from domain.order.data.service_money import DomainServiceMoney
from domain.types import Currency
from domain.types import TicketMonetaryCode
from domain.currency_rates import DomainCurrencyRates
from .base_expander import BaseOrderExpander
from use_cases.orders.save.utils.currency_rates import CurrencyRates


class ConvertTicketMoneyIntoRubCurrencyExpander(BaseOrderExpander):
    """
    Конвертирует значения из data.tickets [monetary_info / taxes]
    в рубли, если они были в валюте
    """
    def __init__(
            self,
            currency_adapter: CurrencyRates
    ):
        self.currency_adapter = currency_adapter

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        if not any([order.data.tickets, order.data.service_money]):
            return order

        currency_rates: DomainCurrencyRates = self.currency_adapter.get_actual_currency_rates()
        if order.data.tickets:
            self.calculate_ticket_prices(order.data.tickets, currency_rates)
        if order.data.service_money:
            self.calculate_service_money_prices(order.data.service_money, currency_rates)

        return order

    @staticmethod
    def __get_new_amount__(amount: float, from_rate: float, to_rate: float) -> Union[float]:
        """
        Возвращает конвертированную валюту, если сумма не пустая, иначе возвращаем 0
        """
        default_amount_value = 0
        result = CurrencyRates.get_converted_currency(amount, from_rate, to_rate) if amount else default_amount_value
        return result

    def calculate_service_money_prices(
            self,
            service_money: List[DomainServiceMoney],
            currency_rates: DomainCurrencyRates
    ):
        """
        Рассчет стоимости сервисов
        """
        for sm in service_money:
            if all([sm.currency, sm.amount, sm.currency != Currency.RUB.value]):
                ruble_rate = currency_rates.rates.get(Currency.RUB.value)
                foreign_rate = currency_rates.rates.get(sm.currency)
                sm.amount_rub = self.__get_new_amount__(sm.amount, foreign_rate, ruble_rate)
            else:
                sm.amount_rub = sm.amount

    def calculate_ticket_prices(self, tickets: List[DomainTicket], currency_rates: DomainCurrencyRates):
        """
        Рассчет стоимости билетов
        """
        for ticket in tickets:
            if ticket.monetary_info:
                taxes: List[DomainTaxes] = ticket.taxes
                monetaries: List[DomainMonetaryInfo] = ticket.monetary_info

                for monetary in monetaries:
                    rates = currency_rates.rates
                    monetary_amount = monetary.amount
                    monetary_currency = monetary.currency

                    if all([monetary_currency, monetary_currency != Currency.RUB.value]):
                        rubles_rate = rates.get(Currency.RUB.value)
                        foreign_rate = rates.get(monetary_currency)

                        if monetary.code in [TicketMonetaryCode.TOTAL.value]:
                            for tax in taxes:
                                tax.amount_rub = self.__get_new_amount__(tax.amount, foreign_rate, rubles_rate)
                        monetary.amount_rub = self.__get_new_amount__(monetary_amount, foreign_rate, rubles_rate)
                    else:
                        # Всеравно заполняем/дублируем данные в amount_rub (используется для поиска)
                        monetary.amount_rub = monetary.amount
                        if monetary.code in [TicketMonetaryCode.TOTAL.value]:
                            for tax in taxes:
                                tax.amount_rub = tax.amount
            else:
                # Фолбек, если нет каких то данных, заполняем amount_rub
                for monetary in ticket.monetary_info:
                    if monetary.currency == Currency.RUB.value and monetary.amount:
                        monetary.amount_rub = monetary.amount
                for tax in ticket.taxes:
                    if tax.amount:
                        tax.amount = tax.amount_rub
