import logging
from typing import Any
from domain import DomainOrder
from .base_expander import BaseOrderExpander
from domain.types import SegmentStatus

logger = logging.getLogger('departure_timestamps_expander')


class DepartureTimestampsExpander(BaseOrderExpander):
    """
    Корректно мержит timestamp-ы первого и последнего вылетов
    """

    def __init__(self, existing_order: DomainOrder):
        self.existing_order = existing_order

    unwanted_segment_status_list = [SegmentStatus.XX.value, SegmentStatus.UN.value]

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        """
        Получение корректных значений времён первого и последнего вылетов из сегментов заказа
        и присваивание этих значений departure_start_timestamp и departure_end_timestamp
        """
        active_segments = [
            segment
            for segment in order.data.segments
            if segment.status not in self.unwanted_segment_status_list
        ]
        if not active_segments:
            try:
                order.data.departure_start_timestamp = order.data.segments[0].departure_timestamp
                order.data.departure_end_timestamp = order.data.segments[-1].departure_timestamp
            except IndexError:
                order.data.departure_start_timestamp = self.existing_order.data.departure_start_timestamp
                order.data.departure_end_timestamp = self.existing_order.data.departure_end_timestamp
            return order
        if len(active_segments) > 1:
            active_segments.sort(key=lambda segment: segment.departure_timestamp)
        order.data.departure_start_timestamp = active_segments[0].departure_timestamp
        order.data.departure_end_timestamp = active_segments[-1].departure_timestamp
        return order
