import logging
from typing import Any, Dict
from domain import DomainOrder
from domain.order.data import DomainSegment
from .base_expander import BaseOrderExpander
from domain.types import SegmentStatus

logger = logging.getLogger('layovertime_expander')


class LayOverTimeExpander(BaseOrderExpander):
    """
    Высчитывает layover_time для каждого сегмента заказа
    """
    unwanted_segment_status_list = [SegmentStatus.XX.value, SegmentStatus.UN.value]

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        order_segments: Dict[str, DomainSegment] = {s.segment_id: s for s in order.data.segments}
        # получаем список сегментов (сортировка от последнего к первому)
        try:
            segments = sorted(
                filter(
                    lambda segment: segment.status not in self.unwanted_segment_status_list, order.data.segments
                ),
                key=(lambda x: (x.arrival_timestamp, x.segment_id)),
                reverse=True
            )
        except TypeError as e:
            # Отсуствует arrival_timestamp у одного из сегментов
            logger.warning("Не удалось вычислить layover_time. rlock:{} Ошибка:{}".format(
                str(order.data.rloc),
                str(e)
            ))
            return order

        segment_index = 0
        if len(segments) == 1:
            # Если у заказа только 1 сегмент - layover_time = 0. Это условие нужно для тех случаев, если, например, в
            # изначальном заказе было два сегмента, а потом осталься только 1
            order.data.segments[segment_index].layover_time = 0
        else:
            while segment_index < len(segments) - 1:
                layover_time = 0
                try:
                    # если сегменты принадлежат одному направлению
                    if all([
                        segments[segment_index].direction == segments[segment_index + 1].direction,
                        segments[segment_index].direction
                    ]):
                        departure_timestamp = segments[segment_index].departure_timestamp or 0
                        arrival_timestamp = segments[segment_index + 1].arrival_timestamp or 0
                        layover_time = int(float(departure_timestamp) - float(arrival_timestamp))
                        if layover_time < 0:
                            raise ValueError('"layover_time" < 0')
                    map_segment = order_segments.get(segments[segment_index + 1].segment_id)
                    map_segment.layover_time = layover_time
                except (KeyError, IndexError, ValueError) as e:
                    logger.warning("Не удалось вычислить layover_time. rlock:{} Ошибка:{}".format(
                        str(order.data.rloc),
                        str(e)
                    ))
                finally:
                    segment_index += 1
        return order
