import logging
import datetime
from typing import Any

from dateutil.relativedelta import relativedelta
from domain.types import TimesOfDay
from domain.types import Gender
from domain import DomainOrder
from domain.order.data import DomainMarketingTags
from .base_expander import BaseOrderExpander


logger = logging.getLogger('marketing_tags_expander')


class MarketingTagsExpander(BaseOrderExpander):
    """
    Добавляет в заказ маркетинговые характеристики.

    Рассчитываем маркетинговые характеристики для заказа, такие как:
    Первый набор характеристик:
        ночной рейс: локальное время вылета с 21:00 до 05:00
        утренний рейс: локальное время вылета с 05:00 до 11:00
        дневной рейс: локальное время вылета с 11:00 до 18:00
        вечерний рейс: локальное время вылета с 18:00 до 21:00

    Второй набор характеристик:
        пара: два человека в броне, оба взрослые, разных полов
        семья с младенцем: в броне есть хотя бы один РМ
        компания: от 3х взрослых в броне
    """

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        """
        Рассчитываем маркетинговые характеристики по заказу для каждого сегмента
        """
        now = datetime.datetime.utcnow().date()

        passengers = order.data.passengers
        documents = order.data.documents
        babies, adults = self.split_by_ages(passengers, documents, now)[:2]

        have_baby = len(babies) > 0
        pair = len(passengers) == len(adults) == 2 and set((x.gender for x in adults)) == (
            Gender.FEMALE.value, Gender.MALE.value
        )
        party = len(adults) > 2

        mt = {
            'baby': have_baby,
            'pair': pair,
            'party': party,
        }
        gmt = lambda t: {'times_of_day': t, **mt}  # noqa

        segments = []
        for s, t in self.times_of_flights(order.data.segments):
            s.marketing_tags = DomainMarketingTags.deserialize(gmt(t))
            segments.append(s)

        order.data.segments = segments
        return order

    def times_of_flights(self, segments: list):
        """
        Рассчитываем время суток вылета, для каждого сегмента.
        @return: генератор: (сегмент, время суток) для каждого сегмента
        """
        x = ((s, self.time(s.departure_timestamp)) for s in segments)
        y = ((s, self.times_of_day(t) if t else None) for s, t in x)
        return y

    def split_by_ages(self, passengers, documents, now) -> (list, list, list):
        """
        Сортируем пассажиров по возрастам.
        @return: lists: младенцы, взрослые, все остальные
        """

        def get_passenger_by_id(pass_id: str):
            for _p in passengers:
                if _p.passenger_id == pass_id:
                    return _p

        birthdays = ((p, self.date(p.birthday)) if p.birthday else (p, None) for p in documents)
        ages = ((p, self.age(b, now)) for p, b in birthdays if b)

        babies, adults, others = [], [], []
        for p, a in ages:
            _passenger = get_passenger_by_id(p.passenger_id)
            if self.baby(a):
                babies.append(_passenger)
            elif self.adult(a):
                adults.append(_passenger)
            else:
                others.append(_passenger)
        return babies, adults, others

    @staticmethod
    def time(t: int):
        try:
            return datetime.datetime.fromtimestamp(t).time()
        except TypeError as e:
            logger.warning('marketing_tags ({}): {}'.format('fromtimestamp error', e))
            return None

    @staticmethod
    def date(d: str):
        try:
            return datetime.datetime.strptime(d, '%d.%m.%Y').date()
        except TypeError as e:
            logger.warning('marketing_tags ({}): {}'.format('strptime error', e))
            return None

    @staticmethod
    def age(birthday, now):
        """
        Чистая функция расчета возраста, от birthday до now
        """
        return relativedelta(now, birthday).years

    @staticmethod
    def baby(age):
        """
        Это не обычные пассажирские критерии, это специальные маркетинговые критерии
        """
        return age < 2

    @staticmethod
    def adult(age):
        """
        Это не обычные пассажирские критерии, это специальные маркетинговые критерии
        """
        return age > 17

    @staticmethod
    def times_of_day(t) -> str:
        """
        Возвращаем время суток (Утро/День/Вечер/Ночь) по времени (часы/минуты)
        """
        _morning = datetime.time(5)
        _afternoon = datetime.time(11)
        _evening = datetime.time(18)
        _night = datetime.time(21)

        if t < _morning:
            return TimesOfDay.NIGHT.value

        if t < _afternoon:
            return TimesOfDay.MORNING.value

        if t < _evening:
            return TimesOfDay.AFTERNOON.value

        if t < _night:
            return TimesOfDay.EVENING.value

        return TimesOfDay.NIGHT.value
