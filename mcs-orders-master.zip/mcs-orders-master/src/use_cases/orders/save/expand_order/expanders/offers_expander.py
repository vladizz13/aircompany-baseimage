from typing import Any, List, Optional, Union

from domain import DomainOrder
from domain.order.data import DomainCoupon
from domain.order.data import DomainOffer
from domain.types import BrandName, FareCode, BrandCode
from domain.types import TransactionSource
from .base_expander import BaseOrderExpander


class OffersExpander(BaseOrderExpander):
    """
    Создаем offers и проставляем им brand_name и fare_code
    """
    BOOKING_CODE_COMFORT = ['M']
    BOOKING_CODE_PREMIUM = ['Q']
    BOOKING_CODE_BUSINESS = ['A', 'D', 'C', 'J', 'I']
    BOOKING_CODE_STANDARD = ['K', 'L', 'H', 'V', 'O', 'P', 'U', 'X', 'B',
                             'N', 'G', 'S', 'T', 'R', 'Y', 'W', 'E', 'Z', 'F']

    # Постфикс корпоративных тарифиов, которые нужно обрабатывать отдельно
    CORPORATE_POSTFIX = FareCode.CORPORATE.value

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        if request == TransactionSource.TAIS.value:
            # У таиса свои офферы, рассчитываем по ним
            unique_items: List[DomainOffer] = order.data.offers
        else:
            # У потока Sirena и SirenaGRS - купоны
            unique_items: List[DomainCoupon] = self.__get_unique_segment_coupons(order)
        if not unique_items:
            self.__mark_offers_as_unknown__(order)
            return order
        offers: List[DomainOffer] = self.define_brands(unique_items)
        order.data.offers = offers
        return order

    @staticmethod
    def __mark_offers_as_unknown__(order: DomainOrder) -> DomainOrder:
        for offer in order.data.offers:
            if not all([
                offer.brand_code,
                offer.brand_name
            ]):
                offer.brand_code = BrandCode.UNKNOWN.value
                offer.brand_name = BrandName.UNKNOWN.value
        return order

    @staticmethod
    def __get_unique_segment_coupons(order: DomainOrder) -> List[DomainCoupon]:
        """
        Достаем уникальные по сегменту купоны
        """
        coupons: List[DomainCoupon] = order.data.coupons
        segments_seen: List[str] = list()
        unique_coupons: List[DomainCoupon] = list()
        for coupon in coupons:
            if not coupon.segment_id:
                continue
            if coupon.segment_id not in segments_seen:
                unique_coupons.append(coupon)
                segments_seen.append(coupon.segment_id)
        return unique_coupons

    @classmethod
    def define_brands(cls, items: List[Union[DomainCoupon, DomainOffer]]) -> List[DomainOffer]:
        """
        Создаем offers для каждого уникального сегмента, у которого есть купон
        """
        defined_offers: List[DomainOffer] = list()

        for item in items:
            fare_code: Optional[str] = item.fare_code
            if fare_code is None:
                continue

            offer: DomainOffer = DomainOffer(
                segment_id=item.segment_id,
                fare_code=item.fare_code
            )

            fare_code: str = fare_code.upper()
            booking_code: str = fare_code[0]
            if FareCode.CHARTER.value in fare_code:
                offer.brand_code = BrandCode.MINIMUM_NEW.value
                offer.brand_name = BrandName.MINIMUM_NEW.value
            elif FareCode.KINTER.value in fare_code:
                offer.brand_code = BrandCode.OPTIMUM_NEW.value
                offer.brand_name = BrandName.OPTIMUM_NEW.value
            elif FareCode.STANDBY.value in fare_code:
                offer.brand_code = BrandCode.STANDBY.value
                offer.brand_name = BrandName.STANDBY.value
            elif FareCode.SUBSIDIZED.value in fare_code:
                offer.brand_code = BrandCode.MINIMUM_PLUS.value
                offer.brand_name = BrandName.MINIMUM_PLUS.value
            elif FareCode.OPTIMUM_PLUS.value in fare_code:
                offer.brand_code = BrandCode.OPTIMUM_PLUS.value
                offer.brand_name = BrandName.OPTIMUM_PLUS.value
            if all([offer.brand_code, offer.brand_name]):
                defined_offers.append(offer)
                continue

            # флаг корпоративного тарифа
            is_corp: bool = fare_code.endswith(cls.CORPORATE_POSTFIX)
            # Берем только 2 и 3 символ из строки для проверки на последующее
            # наличие FareCode(Enum) в fare_code
            fare_code: str = fare_code[1:3]

            if booking_code in cls.BOOKING_CODE_PREMIUM:
                offer.brand_code = BrandCode.PREMIUM_NEW.value if not is_corp else BrandCode.PREMIUM_CORP.value
                offer.brand_name = BrandName.PREMIUM_NEW.value if not is_corp else BrandName.PREMIUM_CORP.value

            elif booking_code in cls.BOOKING_CODE_STANDARD and FareCode.MINIMUM.value in fare_code:
                offer.brand_code = BrandCode.MINIMUM_NEW.value if not is_corp else BrandCode.MINIMUM_CORP.value
                offer.brand_name = BrandName.MINIMUM_NEW.value if not is_corp else BrandName.MINIMUM_CORP.value
            elif booking_code in cls.BOOKING_CODE_STANDARD and any(
                    c.startswith(fare_code) for c in (FareCode.OPTIMUM.value, FareCode.OPTIMUM_PLUS.value)):
                offer.brand_code = BrandCode.OPTIMUM_NEW.value if not is_corp else BrandCode.OPTIMUM_CORP.value
                offer.brand_name = BrandName.OPTIMUM_NEW.value if not is_corp else BrandName.OPTIMUM_CORP.value

            elif booking_code in cls.BOOKING_CODE_STANDARD and FareCode.PREMIUM.value in fare_code:
                offer.brand_code = BrandCode.PREMIUM_NEW.value if not is_corp else BrandCode.PREMIUM_CORP.value
                offer.brand_name = BrandName.PREMIUM_NEW.value if not is_corp else BrandName.PREMIUM_CORP.value

            elif booking_code in cls.BOOKING_CODE_BUSINESS and FareCode.BUSINESS.value in fare_code:
                offer.brand_code = BrandCode.BUSINESS_NEW.value
                offer.brand_name = BrandName.BUSINESS_NEW.value

            elif booking_code in cls.BOOKING_CODE_BUSINESS and FareCode.PREMIUM.value in fare_code:
                offer.brand_code = BrandCode.BUSINESS_NEW.value if not is_corp else BrandCode.BUSINESS_CORP.value
                offer.brand_name = BrandName.BUSINESS_NEW.value if not is_corp else BrandName.BUSINESS_CORP.value

            elif booking_code in cls.BOOKING_CODE_STANDARD and FareCode.PREMIUM_PLUS.value in fare_code:
                offer.brand_code = BrandCode.PREMIUM_PLUS.value
                offer.brand_name = BrandName.PREMIUM_PLUS.value

            elif booking_code in cls.BOOKING_CODE_COMFORT and FareCode.PREMIUM.value in fare_code:
                offer.brand_code = BrandCode.COMFORT.value
                offer.brand_name = BrandName.COMFORT.value

            # Если ничего не проставилось - дефолт UNKNOWN
            if not offer.brand_code:
                offer.brand_code = BrandCode.UNKNOWN.value
                offer.brand_name = BrandName.UNKNOWN.value

            defined_offers.append(offer)

        return defined_offers

    @classmethod
    def create_brand_offer_by_coupon(cls, coupon: DomainCoupon) -> Optional[DomainOffer]:
        offers = cls.define_brands([coupon])
        if not offers:  # fare_code is None
            return None
        return offers[0]
