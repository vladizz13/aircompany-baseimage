import datetime
from typing import Any
from domain import DomainOrder
from domain.order.data import DomainGDS
from .base_expander import BaseOrderExpander


class OrderGDSExpander(BaseOrderExpander):
    """
    Вытаскивает GDS из rloc и добавляет в data.pos_data.gds {value, created }
    если gds еще не добавлена
    """

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        rloc: str = order.data.rloc or ''
        order_gds: str = rloc.split('/')[1]

        if order_gds:

            if order.data.pos_data.gds.value == order_gds:
                return order

            order.data.pos_data.gds = DomainGDS(
                created=int(float(datetime.datetime.utcnow().timestamp())),
                value=order_gds
            )

        return order
