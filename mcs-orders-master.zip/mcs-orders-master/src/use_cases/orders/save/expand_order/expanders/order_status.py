import time
from typing import Any, Set
from domain import DomainOrder
from domain.order.data.status_updated import DomainOrderStatusUpdated
from domain.types import CouponStatus, OrderStatus
from .base_expander import BaseOrderExpander


class OrderStatusArchiveExpander(BaseOrderExpander):
    """
    Проставление заказу статуса A, если подходит по правилам
    """
    def __init__(
            self,
            existing_order: DomainOrder
    ):
        self.existing_order = existing_order

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        initial_status: str = order.data.status
        order: DomainOrder = self.set_archive_status(order)

        if self.existing_order and self.existing_order.data.status != order.data.status:
            order.data.status_updated.append(
                DomainOrderStatusUpdated(
                    status=self.existing_order.data.status
                )
            )
        elif initial_status != order.data.status:
            order.data.status_updated.append(
                DomainOrderStatusUpdated(
                    status=initial_status
                )
            )

        return order

    @staticmethod
    def set_archive_status(order: DomainOrder) -> DomainOrder:
        """
        Проставляем заказу статус A (archived), если заказ подходит под правила:

        Заказ получает статус А, если
            В нем все купоны в статусах E, F, P, R, G, X, V, T
            В нем статус T , нет купонов, дата вылета всех сегментов меньше текущей даты.
        Статус A может измениться только на статус T, статус T может измениться только на статус A
        Статус Т - все остальные кейсы, когда в броне есть купон, билет, фопс
        """

        available_coupon_statuses: Set[str] = {c.status for c in order.data.coupons if c.status is not None}

        if all([
            bool(available_coupon_statuses),
            available_coupon_statuses.issubset(set(CouponStatus.TERMINAL_LIST.value)),
        ]):
            order.data.status = OrderStatus.A.value
            return order

        if all([
            order.data.status == OrderStatus.T.value,
            not order.data.coupons,
            all([
                s.departure_timestamp < time.time() for s in order.data.segments
            ])
        ]):
            order.data.status = OrderStatus.A.value
            return order

        return order
