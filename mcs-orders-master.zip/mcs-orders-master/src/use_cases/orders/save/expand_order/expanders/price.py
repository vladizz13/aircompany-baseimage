from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainTicket
from domain.order.data import DomainServiceMoney
from .base_expander import BaseOrderExpander
from domain.types import TicketMonetaryCode
from domain.types import Currency
from domain.types import ServiceStatus


class OrderPriceExpander(BaseOrderExpander):
    """
    Рассчитывает цену в словарь price
    """

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:

        # Список emd активных услуг
        active_services_emd: List[str] = [
            i.emd for i in order.data.services if i.status != ServiceStatus.XX.value
        ]

        # стоимость билетов
        tickets_price = self.__get_tickets_price__(order.data.tickets)
        # сумма стоимости билетов и услуг
        tickets_and_services_price = self.__get_service_price__(
            order.data.service_money, active_services_emd
        ) + tickets_price

        order.data.price.full_price = tickets_and_services_price
        order.data.price.tickets_price = tickets_price
        order.data.price.currency = Currency.RUB.value

        return order

    @staticmethod
    def __get_tickets_price__(tickets: List[DomainTicket]) -> int:
        """
        Расчет стоимости билетов
        """
        tickets_price: int = 0
        tickets_price_alternative: int = 0
        for ticket in tickets:
            for mi in ticket.monetary_info:
                if mi.code == TicketMonetaryCode.TOTAL.value and mi.coupon_id is None:
                    tickets_price += mi.amount_rub if mi.amount_rub is not None else 0
                if mi.code == TicketMonetaryCode.TOTAL.value and mi.coupon_id:
                    tickets_price_alternative += mi.amount_rub if mi.amount_rub is not None else 0
        return int(tickets_price) or int(tickets_price_alternative)

    @staticmethod
    def __get_service_price__(service_money: List[DomainServiceMoney], active_service_emd: List[str]) -> int:
        """
        Рассчет стоимости услуг
        """
        total_service_price: int = 0
        if not active_service_emd:
            return total_service_price
        for sm in service_money:
            if sm.emd in active_service_emd:
                total_service_price += sm.amount if sm.amount is not None else 0
        return total_service_price
