import logging
from typing import Any, List
from domain.types import TicketMonetaryCode
from domain.prorate import DomainProrate
from domain import DomainOrder
from domain.order.data import DomainTicket
from domain.order.data import DomainSegment
from domain.order.data import DomainCoupon, DomainCouponMoney
from .base_expander import BaseOrderExpander
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.prorate import ProrateQueryBuilder

logger = logging.getLogger("prorates_expander")


class CalculateSegmentCostByProrateExpander(BaseOrderExpander):
    """
    Расчет стоимости сегмента по прорейту.
    https://jira.utair.ru/browse/UTBCKN-258
    """
    def __init__(
            self,
            prorate_repo: GenericMongoRepository
    ):
        self.prorate_repo = prorate_repo

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        coupons = order.data.coupons
        tickets = order.data.tickets
        segments = order.data.segments

        if not all([coupons, tickets]):
            return order

        try:
            # TODO Get additional_data[discounts] from mapping
            discount = None
            # discount = self.__get_discount__(order.get("data", {}).get("additional_data", {}))

            full_price_order = self.__get_full_price__(tickets)
            segments_prorate = self.__get_segments_prorate__(segments)

            if not segments_prorate or segments_prorate.get("sum") == 0:
                return order

            for ticket in tickets:
                coupons_for_ticket = self.__get_coupons_by_num__(coupons, ticket.ticket)

                # Если нет купонов, скипаем
                if not coupons_for_ticket:
                    continue

                tax_zz, tax_any = self.__sum_taxes__(ticket or [])
                # Расчитываем тариф
                base_tariff = self.__get_base_tariff__(ticket)

                for coupon in coupons_for_ticket:

                    coeff = segments_prorate.get(str(coupon.segment_id), 0) / segments_prorate.get("sum")

                    if not base_tariff or not base_tariff.amount_rub:
                        return order
                    fare = float(coeff * base_tariff.amount_rub)

                    # Расчитываем сборы
                    coupon_tax_any = float(coeff * tax_any)
                    coupon_tax = float(tax_zz / int(order.data.segment_count) + coupon_tax_any)

                    # Расчитываем скидку
                    coupon_discount: int = 0
                    if discount:
                        coupon_discount = float((coupon_tax + fare) / full_price_order * discount)

                    self.__set_coupon_money_in_coupon__(
                        coupons=coupons,
                        coupon=coupon,
                        fare=int(fare),
                        tax=int(coupon_tax),
                        discount=int(coupon_discount)
                    )

        except Exception as e:
            logger.exception(e)
        return order

    def __get_segments_prorate__(self, segments: List[DomainSegment]) -> [dict, None]:
        """
        Возвращает прорэйты сегментов
        :param segments:
        :return:
        """
        segments_prorate = dict()
        sum_prorate = int()

        for segment in segments:
            spec = ProrateQueryBuilder.get_by_deaprture_and_arrival(
                departure=segment.departure_city_code,
                arrival=segment.arrival_city_code
            )
            prorate: DomainProrate = self.prorate_repo.get_single(spec)

            if not prorate:
                return None

            segments_prorate.update({segment.segment_id: prorate.factor})
            sum_prorate += prorate.factor

        segments_prorate["sum"] = sum_prorate
        return segments_prorate

    @staticmethod
    def __get_base_tariff__(ticket: DomainTicket):
        """
        Возвращает базовый тариф для билета
        :param ticket_money_rub:
        :return:
        """
        base_tariff_code = TicketMonetaryCode.BASE.value
        for _tariff in ticket.monetary_info or []:
            if _tariff.code == base_tariff_code:
                return _tariff

    @staticmethod
    def __get_coupons_by_num__(coupons: List[DomainCoupon], num: str) -> List[DomainCoupon]:
        """
        Возвращает купоны по их number
        :param coupons:
        :param num:
        :return:
        """
        _coupons = list()
        for coupon in coupons:
            if coupon.ticket == num:
                _coupons.append(coupon)
        return _coupons

    @staticmethod
    def __sum_taxes__(ticket: DomainTicket) -> (int, int):
        """
        Складываем все сборы кроме сбора ZZ
        Складываем сумму сборов ZZ
        :param taxes:
        :return:
        """
        tax_zz: int = 0
        tax_any: int = 0
        for tax in ticket.taxes:
            if tax.code == "ZZ":
                tax_zz += tax.amount_rub or 0
            else:
                tax_any += tax.amount_rub or 0
        return tax_zz, tax_any

    @staticmethod
    def __get_full_price__(tickets: List[DomainTicket]) -> int:
        """
        Возвращает полную стоимость заказа
        :param tickets:
        :return:
        """
        full_price: int = 0
        total_code = TicketMonetaryCode.TOTAL.value
        for ticket in tickets:
            for money in ticket.monetary_info:
                if money.code == total_code:
                    full_price += money.amount_rub or 0
        return full_price

    @staticmethod
    def __get_discount__(additional_data: dict) -> int:
        # TODO Передалать
        """
        Возвращает сумму скидки
        :param additional_data:
        :return:
        """
        full_discount: int = 0
        for discount in additional_data.get("discounts", []):
            full_discount += int(discount.get("amount", 0))
        return full_discount

    @staticmethod
    def __set_coupon_money_in_coupon__(
            coupons: List[DomainCoupon],
            coupon: DomainCoupon,
            fare: int,
            tax: int,
            discount: int
    ):
        """
        Сохраняет coupon_money в купон
        :return:
        """
        local_coupon_id: str = "{}{}".format(coupon.passenger_id, coupon.segment_id)
        for _coupon in coupons:
            _coupon_id: str = "{}{}".format(_coupon.passenger_id, _coupon.segment_id)
            if local_coupon_id == _coupon_id:
                _coupon.coupon_money = DomainCouponMoney(
                    fare=fare,
                    tax=tax,
                    discount=discount
                )
