from typing import Any, Dict, List, Optional, Set
import copy
from operator import attrgetter
from domain import DomainOrder
from domain.order.data import DomainSegment
from .base_expander import BaseOrderExpander
from domain.types import SegmentStatus, OWRT, TransactionSource


class OrderDirectionExpander(BaseOrderExpander):
    """
    Расчет направлений
    """
    def __init__(
        self,
        existing_order: DomainOrder
    ):
        self.existing_order = existing_order

    SEGMENT_UNWANTED_STATUS_LIST = [SegmentStatus.XX.value, SegmentStatus.UN.value]

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        """
        Таис направления присылает. Sirena рассчитывается в маппиинге правильно.
        Sirena_grs сортирует сегменты по @id.
        Проверить, есть ли дубликаты сегментов не используя rbd.

        Если есть дубликаты, то:
            заново рассчитываем направления сегментов
            owrt рассчитываем без учета дубликатов и неактивных сегментов, сортируем по времени вылета!

        """
        # owrt/directions рассчитывает таис
        if request in [TransactionSource.TAIS.value, TransactionSource.SIRENA.value]:
            return order

        if not self.existing_order:
            return order

        try:
            new_segments: List[DomainSegment] = copy.deepcopy(order.data.segments)
            existing_segments = copy.deepcopy(self.existing_order.data.segments)
        except AttributeError:
            return order

        new_segments_hash = [{s.get_hash(use_rbd=False): s} for s in new_segments]
        existing_segments_hash_map: Dict[str, DomainSegment] = {s.get_hash(use_rbd=False): s for s in existing_segments}

        duplicated_segment_ids: Set[str] = self.find_duplicates(new_segments_hash)
        if not duplicated_segment_ids:
            return order

        mapped_segments = self.map_directions(new_segments_hash, existing_segments_hash_map)

        segments_to_calc: List[DomainSegment] = self.exclude_duplicate_segments_by_segment_ids(
            segments=new_segments,
            segment_ids=duplicated_segment_ids
        )
        owrt = self.owrt_direction(segments_to_calc)

        order.data.segments = mapped_segments
        order.data.owrt = owrt

        return order

    def owrt_direction(self, segments: List[DomainSegment]) -> Optional[str]:
        if len(segments) == 1:
            return OWRT.OW.value

        if not self.is_ignore_segment_status(segments):
            segments = list(filter(lambda s: s.status not in self.SEGMENT_UNWANTED_STATUS_LIST, segments))

        segments = sorted(segments, key=attrgetter('departure_timestamp'), reverse=False)

        owrt_direction = None
        try:
            departure_point: str = segments[0].departure_city_code
            arrival_point: str = segments[-1:][0].arrival_city_code
            if departure_point == arrival_point:
                owrt_direction = OWRT.RT.value
            else:
                owrt_direction = OWRT.OW.value
        except (AttributeError, TypeError):
            owrt_direction = None

        return owrt_direction

    @classmethod
    def is_ignore_segment_status(cls, segments: List[DomainSegment]) -> bool:
        """
        Проверяет что все сегменты в статусе XX или UN
        """
        for segment in segments:
            if segment.status not in cls.SEGMENT_UNWANTED_STATUS_LIST:
                return False
        return True

    @staticmethod
    def exclude_duplicate_segments_by_segment_ids(
        segments: List[DomainSegment],
        segment_ids: Set[str]
    ) -> List[DomainSegment]:
        segments: List[DomainSegment] = [s for s in segments if s.segment_id not in segment_ids]
        return segments

    @classmethod
    def find_duplicates(cls, segments_hash: List[Dict[str, DomainSegment]]) -> Set[str]:
        """
        Ищем дублирование сегментов.
        Дублирующийся сегмент тот, у которого hash сегмента уже есть в БД.
        Если у дубликата статус XX/UN, то это дубликат.
        Если у родительского сегмента статус XX/UN, то это дубликат.
        Возвращаем сет segment_id у которых статус XX/UN.
        Если статус любой другой, тогда можно вернуть любой segment_id
        """
        hash_keys = dict()
        duplicate_segment_ids = set()
        for index, item in enumerate(segments_hash):
            hash_key = list(item.keys())[0]
            hash_value = list(item.values())[0]

            if index == 0:
                hash_keys.update(item)
                continue

            if appended_segment := hash_keys.get(hash_key):
                if appended_segment.status in cls.SEGMENT_UNWANTED_STATUS_LIST:
                    duplicate_segment_ids.update(appended_segment.segment_id)
                else:
                    duplicate_segment_ids.update(hash_value.segment_id)
                continue

            hash_keys.update(item)

        return duplicate_segment_ids

    @staticmethod
    def map_directions(
        new_segments_hash: List[Dict[str, DomainSegment]],
        existing_segments_hash_map: Dict[str, DomainSegment]
    ) -> List[DomainSegment]:
        """
        Сохраняем направление задублированного сегмента как было у родительского сегмента.
        """
        mapped_segments: List[DomainSegment] = []
        for segment in new_segments_hash:
            new_segment_hash = list(segment.keys())[0]
            new_segment = list(segment.values())[0]
            new_segment.direction = existing_segments_hash_map.get(new_segment_hash).direction
            mapped_segments.append(new_segment)

        return mapped_segments
