from typing import Any
from domain import DomainOrder
from .base_expander import BaseOrderExpander


class CalculateSegmentDurationExpander(BaseOrderExpander):
    """
    Рассчет времени перелета в секундах
    """

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        return self.calculate_duration(order)

    @staticmethod
    def calculate_duration(order: DomainOrder) -> DomainOrder:
        for segment in order.data.segments:
            if not segment.arrival_timestamp and not segment.departure_timestamp:
                continue
            if not isinstance(segment.arrival_timestamp, int) and not isinstance(segment.departure_timestamp, int):
                continue
            try:
                segment.duration: int = segment.arrival_timestamp - segment.departure_timestamp
            except TypeError:
                segment.duration = None
        return order
