from typing import Any, List, Dict, Optional, Callable, Union
from domain import DomainOrder
from domain.types import TransactionSource
from domain.types import SegmentStatusVisual
from domain.types import SegmentStatus
from domain.types import CouponStatus
from domain.types import OrderStatus
from domain.types import Agencies
from domain.order.data import DomainCoupon
from domain.order.data import DomainSegment
from .base_expander import BaseOrderExpander


class CalculateSegmentStatusVisualExpander(BaseOrderExpander):
    """
    Рассчет поля status_visual для сегментов, для отображения пользователю понятного
    состояния сегмента

    # https://confluence.utair.ru/pages/viewpage.action?pageId=171836187
    # https://jira.utair.ru/browse/UTBCKN-2976
    """
    DEFAULT_STATUS = SegmentStatusVisual.UNDEFINED

    def __init__(self):
        self.order: Optional[DomainOrder] = None
        self.request: TransactionSource.value = None
        self.segment_id_to_coupon_map: Dict[str, List[DomainCoupon]] = dict()

        self._is_all_segments_processing_cache: Optional[bool] = None

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        if not order.data.segments:
            return order
        self.request: TransactionSource = request
        self.order: DomainOrder = order

        # Инициализация карты айдишников сегмента к принадлежащим ему купонам
        self.segment_id_to_coupon_map = {
            seg.segment_id: [
                coup for coup in self.order.data.coupons if coup.segment_id == seg.segment_id
            ]
            for seg in self.order.data.segments
        }

        for segment in order.data.segments:
            calculated_status: SegmentStatusVisual = self.calculate_status(segment)
            segment.status_visual = calculated_status.value
        return order

    def calculate_status(self, segment: DomainSegment) -> SegmentStatusVisual:
        """
        Рассчет статуса для переданного сегмента
        """
        check_to_status_map: Dict[Callable[[DomainSegment], bool], SegmentStatusVisual] = {
            self.is_processing: SegmentStatusVisual.PROCESSING,     # 1
            # Расставлены по приоритету присвоения
            # Не менять порядок без явной необходимости
            self.is_no_data: SegmentStatusVisual.NO_DATA,           # 2
            self.is_active: SegmentStatusVisual.ACTIVE,             # 3
            self.is_flown: SegmentStatusVisual.FLOWN,               # 4
            self.is_registered: SegmentStatusVisual.REGISTERED,     # 5
            self.is_transfer: SegmentStatusVisual.TRANSFER,         # 6
            self.is_not_payed: SegmentStatusVisual.NOT_PAYED,       # 7
            self.is_control: SegmentStatusVisual.CONTROL,           # 8
            self.is_disabled: SegmentStatusVisual.DISABLED,         # 9
            self.is_returned: SegmentStatusVisual.RETURNED,         # 10
            self.is_canceled: SegmentStatusVisual.CANCELED,         # 11
            self.is_released: SegmentStatusVisual.RELEASED,         # 12
            self.is_void: SegmentStatusVisual.VOID,                 # 13
            self.is_exchanged: SegmentStatusVisual.EXCHANGED,       # 14
            self.is_unavailable: SegmentStatusVisual.UNAVAILABLE,   # 15
        }

        for check, status in check_to_status_map.items():
            if check(segment):  # Возвращаем статус соотв. первой подходящей проверке
                return status
        return self.DEFAULT_STATUS

    def is_processing(self, segment: DomainSegment) -> bool:
        """
        От таиса не приходят статусы сегментов и купоны
        Если транзакция от таиса и у сегмента нет статуса
        проставляем сегменту промежуточный статус - processing
        """
        return all((
            self.request == TransactionSource.TAIS.value,
            segment.status is None
        ))

    def is_no_data(self, segment: DomainSegment) -> bool:
        """
        Нет купонов
        Агентство не 02ТЮМ/02TUM
        """
        return all((
            self.order.data.pos_data.agency not in Agencies.UT_SITE.value,
            not self.have_coupons(segment)
        ))

    def is_not_payed(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе XX, HK, TK, SA
        - статус заказа B
        - нет других сегментов с купонами
        - сегмент без купона
        """
        if not self.is_segment_corresponds_to_status(segment, [
            SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.XX, SegmentStatus.SA
        ]):
            return False
        return all((
            not self.have_coupons(segment),
            not self.is_any_other_segments_with_coupons(segment),
            self.order.data.status in (OrderStatus.B.value, OrderStatus.X.value)
        ))

    def is_active(self, segment: DomainSegment) -> bool:
        """
        - статус сегмента TK, HK, SA
        - статус хотя бы одного купона O, A
        - нет купонов и в заказе нет других сегментов с купонами, заказ не в статусе B
        """
        if not self.is_segment_corresponds_to_status(
                segment,
                [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.SA]
        ):
            return False
        if self.any_coupon_for_segment_corresponds_to_status(
            segment,
            [CouponStatus.O, CouponStatus.A]
        ):
            return True
        return all((
            not self.have_coupons(segment),
            not self.is_any_other_segments_with_coupons(segment),
            self.order.data.status in (OrderStatus.A.value, OrderStatus.T.value),
        ))

    def is_flown(self, segment: DomainSegment) -> bool:
        """
        - статус сегмента HK, TK, XX, SA
        - хотя бы один купон в статусе F
        """
        if not self.is_segment_corresponds_to_status(
                segment,
                [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.XX, SegmentStatus.SA]
        ):
            return False
        return self.any_coupon_for_segment_corresponds_to_status(segment, CouponStatus.F)

    def is_returned(self, segment: DomainSegment) -> bool:
        """
        - сегмент в любом статусе
        - хотя бы один купон в статусе R
        """
        return self.any_coupon_for_segment_corresponds_to_status(segment, CouponStatus.R)

    def is_canceled(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе UN
        - сегмент без купона ИЛИ купон в статусах O, A, I, N, S, Z
        """
        if not self.is_segment_corresponds_to_status(segment, SegmentStatus.UN):
            return False
        return any((
            self.any_coupon_for_segment_corresponds_to_status(
                segment,
                [CouponStatus.O, CouponStatus.A,
                 CouponStatus.I, CouponStatus.N,
                 CouponStatus.S, CouponStatus.Z]
            ),
            not self.have_coupons(segment)
        ))

    def is_registered(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе TK, HK, SA
        - хотя бы один купон в статусе C, L
        """
        if not self.is_segment_corresponds_to_status(
            segment,
            [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.SA]
        ):
            return False
        return self.any_coupon_for_segment_corresponds_to_status(
            segment,
            [CouponStatus.C, CouponStatus.L]
        )

    def is_transfer(self, segment: DomainSegment) -> bool:
        """
        - сегмент HK, TK или XX, SA
        - хотя бы один купон в статусе G
        """
        if not self.is_segment_corresponds_to_status(
            segment,
            [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.XX, SegmentStatus.SA]
        ):
            return False
        return self.any_coupon_for_segment_corresponds_to_status(
            segment,
            CouponStatus.G
        )

    def is_disabled(self, segment: DomainSegment) -> bool:
        """
        - сегмент HK, TK, SA
        - хотя бы один купон в статусе U
        """
        if not self.is_segment_corresponds_to_status(
            segment,
            [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.SA]
        ):
            return False
        return self.any_coupon_for_segment_corresponds_to_status(
            segment,
            CouponStatus.U
        )

    def is_control(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе HK, TK, SA
        - без купона, но в заказе есть другие сегменты с купонами
        - хотя бы один купон статусах I, N, S, Z
        """
        if not self.is_segment_corresponds_to_status(
            segment,
            [SegmentStatus.HK, SegmentStatus.TK, SegmentStatus.SA]
        ):
            return False
        if self.any_coupon_for_segment_corresponds_to_status(
            segment,
            [CouponStatus.I, CouponStatus.N,
             CouponStatus.S, CouponStatus.Z]
        ):
            return True
        return not self.have_coupons(segment) and self.is_any_other_segments_with_coupons(segment)

    def is_released(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе XX
        - хотя бы один купон в статусах O, A, U, I, N, S, Z
        - без купона, нет других сегментов с купонами и статус заказа T или A
        """
        if not self.is_segment_corresponds_to_status(segment, SegmentStatus.XX):
            return False
        if self.any_coupon_for_segment_corresponds_to_status(
            segment,
            [CouponStatus.O, CouponStatus.A,
             CouponStatus.U, CouponStatus.I,
             CouponStatus.N, CouponStatus.S,
             CouponStatus.Z]
        ):
            return True
        return all((
            not self.have_coupons(segment),
            not self.is_any_other_segments_with_coupons(segment),
            self.order.data.status in (OrderStatus.T.value, OrderStatus.A.value)
        ))

    def is_exchanged(self, segment: DomainSegment) -> bool:
        """
        - сегмент в любом статусе
        - купоны в статусе E
        """
        return self.any_coupon_for_segment_corresponds_to_status(segment, CouponStatus.E)

    def is_void(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе XX
        - купоны в статусе V
        """
        if not self.is_segment_corresponds_to_status(segment, SegmentStatus.XX):
            return False
        return self.any_coupon_for_segment_corresponds_to_status(segment, CouponStatus.V)

    def is_unavailable(self, segment: DomainSegment) -> bool:
        """
        - сегмент в статусе XX
        - без купона и есть другие сегменты с купонами
        """
        if not self.is_segment_corresponds_to_status(segment, SegmentStatus.XX):
            return False
        return not self.have_coupons(segment) and self.is_any_other_segments_with_coupons(segment)

    def any_coupon_for_segment_corresponds_to_status(
            self, segment: DomainSegment, status: Union[CouponStatus, List[CouponStatus]]
    ):
        """
        Хотя бы один купон сегмента соответсвует переданному статусу
        """
        coupons = self.segment_id_to_coupon_map[segment.segment_id]
        if not coupons:
            return False
        status = [s.value for s in self.to_list(status)]
        return any((c.status in status for c in coupons))

    def all_coupons_for_segment_corresponds_to_status(
            self, segment: DomainSegment, status: Union[CouponStatus, List[CouponStatus]]
    ) -> bool:
        """
        Все купоны сегмента соответсвует переданному статусу
        """
        coupons = self.segment_id_to_coupon_map.get(segment.segment_id)
        if not coupons:
            return False
        status = [s.value for s in self.to_list(status)]
        return all((c.status in status for c in coupons))

    def have_coupons(self, segment: DomainSegment) -> bool:
        """
        Проверка на наличие купонов у сегмента
        """
        return bool(self.segment_id_to_coupon_map.get(segment.segment_id))

    def is_any_other_segments_with_coupons(self, segment: DomainSegment) -> bool:
        """
        Проверка на наличие других сегментов (помимо переданного)
        в заказе, у которых есть привязанные купоны
        """
        for s_id, coupons in self.segment_id_to_coupon_map.items():
            if segment.segment_id == s_id:
                continue
            if coupons:
                return True
        return False

    @classmethod
    def is_segment_corresponds_to_status(
            cls,
            segment: DomainSegment,
            status: Union[SegmentStatus, List[SegmentStatus]]
    ) -> bool:
        """
        Проверка на соответсвие сегмента статусам
        """
        return segment.status in [s.value for s in cls.to_list(status)]

    @staticmethod
    def to_list(data: Union[Any, List[Any]]) -> List[Any]:
        if not isinstance(data, list):
            data = [data]
        return data
