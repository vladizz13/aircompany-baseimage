
from typing import Any
from domain import DomainOrder
from .base_expander import BaseOrderExpander
from domain.service_agent import DomainAdditionalService
from adapter.service_agent.service_agent_adapter import ServiceAgentAdapter


class ServiceExpander(BaseOrderExpander):
    """
    Расширяет заказ данными из микросервиса service_agent
    """
    def __init__(
            self,
            service_agent_adapter: ServiceAgentAdapter
    ):
        self.service_agent_adapter = service_agent_adapter

    def expand(self, order: DomainOrder, request: Any) -> DomainOrder:
        for service in order.data.services:
            additional_service: DomainAdditionalService = self.service_agent_adapter.get_service_by_rfisc(service.rfisc)
            if not additional_service:
                continue
            service.guid = additional_service.guid
        return order
