from typing import Optional
from use_cases.orders.exceptions.base import BaseValidationError
from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain import DomainOrder


class HandleSplitRequest(BaseOrderRequest):

    def __init__(self, provider: str, new_order: DomainOrder, existing_order: Optional[DomainOrder] = None):
        super().__init__()
        self.new_order = new_order
        self.existing_order = existing_order
        self.provider = provider

    def is_valid(self, *args, **kwargs) -> 'HandleSplitRequest':
        if not self.provider:
            self.add_error(BaseValidationError(
                message="Invalid provider"
            ))
        if not self.new_order.is_valid:
            self.add_error(
                BaseValidationError(
                    message="new order data is not valid"
                )
            )
        if self.existing_order and not self.existing_order.is_valid:
            self.add_error(
                BaseValidationError(
                    message="existing order data is not valid"
                )
            )
        return self

    def serialize(self) -> dict:
        return {
            'new_order': self.new_order.serialize(),
            'existing_order': self.existing_order.serialize() if self.existing_order else None,
            'provider': self.provider,
        }

    @classmethod
    def deserialize(cls, data: dict):
        existing_order = data.get("existing_order", None)
        if existing_order:
            existing_order = DomainOrder.deserialize(existing_order)
        return cls(
            new_order=DomainOrder.deserialize(data.get('new_order', dict())),
            existing_order=existing_order,
            provider=data.get('provider', None),
        )
