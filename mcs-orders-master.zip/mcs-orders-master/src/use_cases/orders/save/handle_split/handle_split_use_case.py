from pymongo import DESCENDING
from typing import List, Tuple, Optional, Type
from event_engine import Event
from events.events import SplitOrderEvent
from base.exception import ApplicationError
from domain import DomainOrder
from domain.order.data.remark import DomainRemark
from domain.types import TransactionSource, GDS
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from repositories.query_builders.order import OrdersQueryBuilder
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from .handle_split_request import HandleSplitRequest
from .handle_split_response import HandleSplitResponse


class HandleSplitUseCase(BaseOrderUseCase):

    def __init__(self, order_repo: GenericMongoRepository):
        self.order_repo = order_repo
        super().__init__()

        # Доступные для юзкейса события
        self.events: List[Type[Event]] = [SplitOrderEvent]

    def __execute__(self, request: HandleSplitRequest, *args, **kwargs) -> HandleSplitResponse:
        for split in self.get_splits(request):
            try:
                self.handle_split(request, split)
            except Exception as e:
                self.logger.exception(f"Unable to process split: {split}, reason: {str(e)}")

        return HandleSplitResponse(value=None)

    def handle_split(self, request: HandleSplitRequest, split: Tuple[str, str]):
        if not any(split):
            return
        master, slave = split

        #  Если заказ в микросервисе имеет order_id и в очередном обновлении от Сирены появляется
        #  ремарка вида "G94MNG->G94R92" которой в предыдущей версии не было, где G94MNG -
        #  rloc самого заказа, значит по нему произошел сплит и надо актуализировать заказ.
        if all((
            request.new_order.data.order_id,
            master == request.new_order.data.rloc.split('/')[0],
        )):
            self.__raise_event__(event=SplitOrderEvent, payload={
                'rloc': request.new_order.data.rloc,
                'last_name': request.new_order.data.passengers[0].last_name
            })
            self.logger.info(
                f"Split handled: {master, slave},"
                f"{request.new_order.data.rloc} master order will be updated"
            )
            return

        # Если заказ в микросервисе не имеет order_id и в очередном обновлении от Сирены присутствует
        # ремарка вида "G94R92<-G94MNG", где G94R92 - rloc самого заказа, а G94MNG - rloc родительского заказа,
        # то проверить есть ли у родительского заказа order_id.
        if slave != request.new_order.data.rloc.split('/')[0]:
            return

        master_order: DomainOrder = self.order_repo.get_single(
            spec=OrdersQueryBuilder.get_by_order_rloc(f"{master}/{GDS.SIRENA.value}"),
            sort=[('_id', DESCENDING)]
        )
        if not master_order:
            return
        # Всегда обновляем родительский заказ из сирены Change pd anti fraud
        self.update_from_sirena_grs(str(master_order.data.order_uuid))

        if request.new_order.data.order_id:
            return
        # Если есть, то выполнить вызов GetOrderList к api ТАИС,
        # передав в качестве параметров rloc и фамилию пассажира.
        if master_order.data.order_id:
            self.__raise_event__(event=SplitOrderEvent, payload={
                'rloc': request.new_order.data.rloc,
                'last_name': request.new_order.data.passengers[0].last_name
            })
            self.logger.info(
                f"Split handled: {master, slave},"
                f"{request.new_order.data.rloc} slave order will be updated"
            )

    @staticmethod
    def update_from_sirena_grs(order_uuid: str):
        from rest.applications.celery_app.tasks.update_from_sirena import update_from_sirena_grs
        update_from_sirena_grs.delay(order_uuid)

    def get_splits(self, request: HandleSplitRequest) -> List[Tuple[Optional[str], Optional[str]]]:
        """
        Проверяем был ли сплит у заказа
        """
        splits = list()
        if request.provider != TransactionSource.SIRENA_GRS.value:
            return splits
        # Проверяем изменились/добавились сплит ремарки
        if request.existing_order:
            existing_order_splits = self.get_split_remarks(request.existing_order)
        else:
            existing_order_splits = []
        new_order_splits = self.get_split_remarks(request.new_order)
        new_split_count = len(new_order_splits) - len(existing_order_splits)
        if new_split_count > 0:
            for new_split in new_order_splits[-new_split_count:]:
                splits.append(self.get_master_slave_rlocs(new_split.text))
        return splits

    @staticmethod
    def get_split_remarks(order: DomainOrder) -> List[DomainRemark]:
        return [s for s in order.data.remarks if s.is_split]

    @staticmethod
    def get_master_slave_rlocs(remark_text: str) -> Tuple[str, str]:
        """
        Получаем сплит рлоки
        в очерёдности родительская бронь, дочерняя бронь
        """
        slave_master_pointer = '<-'
        master_slave_pointer = '->'
        if slave_master_pointer in remark_text:
            slave, master = remark_text.split(slave_master_pointer)
        elif master_slave_pointer in remark_text:
            master, slave = remark_text.split(master_slave_pointer)
        else:
            raise ApplicationError(message="Unable to get splits")
        return master, slave
