from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain.types import TransactionSource

from use_cases.orders.exceptions.save import (
    InvalidProviderSourceError,
    InvalidInputTransactionError,
)


class MapOrderRequest(BaseOrderRequest):

    def __init__(self, order: dict = None, provider: str = None):
        super().__init__()
        self.order = order
        self.provider = provider

    def is_valid(self, *args, **kwargs) -> 'MapOrderRequest':
        invalid_request = MapOrderRequest()

        if not self.order or not isinstance(self.order, dict):
            invalid_request.add_error(InvalidInputTransactionError())

        if self.provider not in TransactionSource._value2member_map_:
            invalid_request.add_error(InvalidProviderSourceError())

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize(self) -> dict:
        return {
            'order': self.order,
            'provider': self.provider,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order=data.get('order', None),
            provider=data.get('provider', None),
        )
