from domain import DomainOrder
from domain.types import TransactionSource
from libs.chain_of_responsibility.chain import InitChainUnit
from libs.mapper.mapper import Mapper
from use_cases.orders.save.map_order.providers.sirena.mapping.sirena_mapping import SirenaMapping
from use_cases.orders.save.map_order.providers.sirena.premappers.sirena_filter_arnk import SirenaFilterSegmentsPreMap
from use_cases.orders.save.map_order.providers.sirena.premappers.substitute_gds import SirenaSubstituteGDSPreMap
from use_cases.orders.save.map_order.providers.sirena_grs.mapping.sirena_grs_mapping import SirenaGRSMapping
from use_cases.orders.save.map_order.providers.sirena_grs.premappers.filter_dummy_tickets import (
    SirenaGRSFilterDummyTicketsPreMap
)
from use_cases.orders.save.map_order.providers.tais.mapping.tais_mapping import TaisMapping
from use_cases.orders.save.map_order.providers.tais.premappers.additional_data import TaisAdditionalDataPreMap
from use_cases.orders.save.map_order.providers.tais.premappers.insurance import TaisInsurancePreMap
from use_cases.orders.save.map_order.providers.tais.premappers.services import TaisBaggagePreMap
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.exceptions.save import (
    UnableToMapOrderError,
    UnableToDeserializeOrderModelError
)
from .map_request import MapOrderRequest
from .map_response import MapOrderResponse


class MapOrderUseCase(BaseOrderUseCase):

    def __init__(self):
        super().__init__()

    def __execute__(self, request: MapOrderRequest, *args, **kwargs) -> MapOrderResponse:
        try:
            # Выполняем действия с транзакцией перед началом мапинга
            ready_to_map_order: dict = self.__prepare_raw_transaction__(request, request.order)
            # Мапим заказ соответственно провайдеру
            mapped_order: dict = self.__map_order__(request, ready_to_map_order)
        except Exception as e:
            return MapOrderResponse.build_from_exception(UnableToMapOrderError(
                message="Unable to map raw transaction: {}".format(str(e)), inner_exception=e
            ))

        # Создаем заказ из смапленной транзакции
        try:
            new_order: DomainOrder = DomainOrder.deserialize(dict(data=mapped_order))
        except (TypeError, AttributeError):
            return MapOrderResponse.build_from_exception(UnableToDeserializeOrderModelError())

        return MapOrderResponse(value=new_order)

    @staticmethod
    def __prepare_raw_transaction__(request: MapOrderRequest, raw_order: dict) -> dict:
        """
        Подготавливаем сырую транзакцию к маппингу
        Если транзакция должна быть отфильтрована/видоизменена и т.д.
        Реализовывать логику здесь
        """
        chain = InitChainUnit()
        (
            chain
            .set_next(SirenaSubstituteGDSPreMap())
            .set_next(SirenaFilterSegmentsPreMap())
            .set_next(SirenaGRSFilterDummyTicketsPreMap())

            .set_next(TaisAdditionalDataPreMap())
            .set_next(TaisInsurancePreMap())
            .set_next(TaisBaggagePreMap())
        )
        chain.handle(raw_order, request=request.provider)
        return raw_order

    @staticmethod
    def __map_order__(request: MapOrderRequest, ready_to_map_order: dict) -> dict:
        mappers = {
            TransactionSource.SIRENA.value: SirenaMapping,
            TransactionSource.TAIS.value: TaisMapping,
            TransactionSource.SIRENA_GRS.value: SirenaGRSMapping
        }
        mapped_order: dict = Mapper.map(ready_to_map_order, mapping=mappers[request.provider]())
        return mapped_order
