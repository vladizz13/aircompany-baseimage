from abc import abstractmethod
from typing import Any
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseTransactionPreMap(AbstractChainHandler):
    """
    Базовый классс для работ с сырым заказом перед маппингом
    Для добавления новой рутины унаследоваться и реализовать
    логику в методе premap

    Указать transaction_source
    >>> from domain.types import TransactionSource
    >>> transaction_source = TransactionSource.SIRENA.value
    """
    transaction_source: str = None

    def handle(self, transaction: dict, request: Any = None):
        if not self.skip(request):
            transaction = self.premap(transaction, request)
        return super().handle(transaction, request)

    def skip(self, request: Any) -> bool:
        # Общая предмаппинговая рутина для любого провайдера
        if self.transaction_source is None:
            return False
        # Предмаппинговая рутина для конкретного провайдера
        if request is not None and self.transaction_source != request:
            return True
        return False

    @abstractmethod
    def premap(self, transaction: dict, request: Any) -> dict:
        raise NotImplementedError()
