from libs.mapper.base_mapping import BaseMapping
from use_cases.orders.save.map_order.providers.sirena.mapping import sirena_mapping_helpers as helpers
from domain.types import SegmentStatus


class SegmentMapping(BaseMapping):
    nested_data_key = "Segments"

    mapping = {
        'segment_id': helpers.normalize_segment_id,
        'tais_segment_id': None,
        'ak': lambda segment, *gs: segment['Flight'].split('-')[helpers.AIRPORT_PREFIX_PART],
        'ak_full_name': lambda segment, *gs: 'ЮТЭИР'
        if segment['Flight'].split('-')[helpers.AIRPORT_PREFIX_PART] == 'UT' else None,
        'oak': helpers.get_oak,
        'oak_full_name': None,
        'departure_city_code': lambda segment, *gs: segment['DepPoint'],
        'departure_airport_code': 'DepPoint',
        'arrival_city_code': lambda segment, *gs: segment['ArrPoint'],
        'arrival_airport_code': 'ArrPoint',
        'class': 'Cabin',
        'rbd': 'Rbd',
        'standby': lambda segment, *gs: True
        if segment.get('Status') == SegmentStatus.SA.value else False,
        'direction': helpers.calc_direction,
        'duration': None,
        'flight_number': lambda segment, *gs: segment['Flight'].split('-')[helpers.FLIGHT_NUMBER_PART],
        'layover_time': None,
        'plane_type': None,
        'plane_type_name': None,
        'status': 'Status',
        'status_visual': None,
        'seg_type': 'SegType',
        'ns': 'Ns',
        # NB! Для нормализации этих дат есть
        # normalize_order.providers.sirena.normalizers.dates import DatesSirenaNormalizer
        'arrival_local_iso': 'ArrTime',
        'departure_local_iso': 'DepTime',
        'arrival_timestamp': 'ArrTime',
        'departure_timestamp': 'DepTime',

        'booking_timestamp': helpers.segment_book_time,
        'gds_active': True
    }
