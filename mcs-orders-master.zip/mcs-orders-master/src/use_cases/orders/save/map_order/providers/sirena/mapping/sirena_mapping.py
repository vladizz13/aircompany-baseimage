import use_cases.orders.save.map_order.providers.sirena.mapping.sirena_mapping_helpers as helpers
from libs.mapper.base_mapping import BaseMapping
from .segment_mapping import SegmentMapping


class SirenaMapping(BaseMapping):
    mapping = {
        'rloc': helpers.get_rloc,
        'order_id': None,
        'order_key': None,
        'order_uuid': None,
        'sirena_id': lambda order, *gs: str(order.get('Id')),
        'rloc_host': helpers.compose_host_rloc,
        'rloc_parent_gds': 'Reclocs.GdsParent',
        'status': None,
        'waiting_for_refund': None,
        'owrt': helpers.calc_owrt,
        'departure_point': helpers.calc_departure_point,
        'arrival_point': helpers.calc_arrival_point,
        # NB: Рассчитаем в нормализации
        'departure_start_timestamp': None,
        'departure_end_timestamp': None,


        # Nested Fields
        'contacts': helpers.compose_contacts,
        'passengers': helpers.compose_passengers,
        'tickets': helpers.compose_tickets,
        'offers': helpers.compose_offers,
        'coupons': helpers.compose_coupons,
        'services': helpers.compose_services,
        'service_money': helpers.compose_service_money,
        'fops': helpers.compose_fops,
        'segments': SegmentMapping(),
        'ssrs': helpers.compose_ssrs,
        'documents': helpers.compose_documents,
        'pos_data': helpers.compose_pos_data,
        'analytics_data': helpers.compose_analytics_data,
        'price': helpers.compose_price,
    }
