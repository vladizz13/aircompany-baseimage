"""
Хелперы для маппинга заказов Сирены.
Первый аргумент хэлпера - конкретный источник данных для маппинга.
Последующие позиционнаые аргументы - более общие источники данных маппинга.
В данном случае это только root источник
"""
import collections
import datetime
import logging
import re
import typing
from typing import Optional
from itertools import chain
from operator import itemgetter
import time

from libs.case_converter.case_converter import CaseConverter
from libs.const.countries import COUNTRY_CODES
from libs.utils.memoized import memoized
from libs.utils.tools.date import convert_datetime_string_to_timestamp
from domain.types import OWRT
from domain.types import PassengerCategory
from domain.types import SegmentStatus
from domain.types import TicketMonetaryCode
from domain.types import ContactType
from domain.types import Direction
from domain.types import Currency # noqa


AIRPORT_PREFIX_PART = 0
FLIGHT_NUMBER_PART = 1

UTAIR_DATE_FORMAT = '%d.%m.%Y'
UTAIR_TIME_FORMAT = '%H:%M:%S'
UTAIR_DATETIME_FORMAT = '{} {}'.format(UTAIR_DATE_FORMAT, UTAIR_TIME_FORMAT)

SIRENA_DATE_FORMAT = '%Y-%m-%d'
SIRENA_TIME_FORMAT = UTAIR_TIME_FORMAT
SIRENA_DATETIME_FORMAT = '{} {}'.format(SIRENA_DATE_FORMAT, SIRENA_TIME_FORMAT)

SEGMENT_UNWANTED_STATUS_LIST = [SegmentStatus.XX.value, SegmentStatus.UN.value]


phone_regex = re.compile(r'([0-9-\)\(\.\s]{1,3}){9,15}')


document_types = {
    'BP': 'БП',
    'CN': 'КН',
    'PS': 'ПС',
    'PSP': 'ПСП',
    'SPU': 'СПУ',
    'SR': 'СР',
    'UD': 'УД',
    'UDL': 'УДЛ',
    'VB': 'ВБ',
    'VV': 'ВЖ',
    'ZA': 'ЗА',
    'NP': 'НП'
}

logger = logging.getLogger('sirena_mapping_helpers')


def calc_departure_point(order, *gs) -> str:
    """
    Вычисление кода города вылета по коду аэропорта вылета.
    Вычисляет код города вылета по IATA у аннулированого, возврщенного и действующего заказа.
    """
    segments = order['Segments']
    # Если это живой заказ (то отфильтровать отмененные/анулированые сегменты)
    # у мертвого будут все сегменты в этих статусах
    if not is_ignore_segment_status(order):
        segments = list(filter(lambda s: s.get('Status', '') not in SEGMENT_UNWANTED_STATUS_LIST, segments))
    segments = sorted(segments, key=itemgetter('DepTime'), reverse=False)
    return segments[0]['DepPoint']


def calc_arrival_point(order, *gs) -> str:
    """
    Вычисление кода города прилета по коду аэропорта прилета.
    Вычисляет кода города прилета по IATA у аннулированого, возврщенного и действующего заказа.
    """
    segments = order['Segments']

    # Если это живой заказ (то отфильтровать отмененные/анулированые сегменты)
    # у мертвого будут все сегменты в этих статусах
    if not is_ignore_segment_status(order):
        segments = list(filter(lambda s: s.get('Status', '') not in SEGMENT_UNWANTED_STATUS_LIST, segments))
    segments = sorted(segments, key=itemgetter('ArrTime'), reverse=False)

    # Получить потенциальный код iata аэропорта
    arr_point = segments[-1:][0]['ArrPoint']

    # или первычислить его если это owrt
    if calc_owrt(order) == OWRT.RT.value:
        dep_points = []
        for segment in segments:
            dep_points.append(segment['DepPoint'])
            if segment['ArrPoint'] in dep_points:
                arr_point = segment['DepPoint']
                break

    return arr_point


def compose_service_money(order, *gs):
    """
    Из словаря monetary_info брать поля amount, currency где code = T.
    Остальные поля не нужны т.к. у услуг нет сбора
    """
    service_money = [CaseConverter().convert_keys_to_underscore(x) for x in order.get('ServiceMoney', [])]
    composed_service_money = []
    for sm in service_money:
        monetary_info_to_add = {}
        for monetary_info in sm.get('monetary_info', []):
            if monetary_info.get('code', None) == TicketMonetaryCode.TOTAL.value:
                monetary_info_to_add = {
                    'amount': monetary_info.get('amount', None),
                    'currency': monetary_info.get('currency', None)
                }
        composed_sm = {
            'emd': sm.get('number', None)
        }
        composed_sm.update(monetary_info_to_add)
        composed_service_money.append(composed_sm)
    return composed_service_money


def compose_services(order, *gs):
    services = order.get('Services', []) or []
    service_money = order.get('ServiceMoney', []) or []
    local_services = []

    for service in services or []:
        segment_id = service.get('SegNum', None)
        if isinstance(segment_id, int):
            segment_id -= 1
        rfisc = service.get('Rfisc', None)
        emd_num = service.get("Num", None)
        if isinstance(emd_num, int):
            emd_num = str(emd_num)

        local_service = {
            'emd': emd_num,
            'count': service.get('Qtty', None),
            'description': service.get('Nos', None),
            'tais_id': None,
            'link': None,
            'pdf_link': None,
            'passenger_id': service.get('PassNum', None),
            'segment_id': segment_id,
            'status': service.get('Status', None),
            'type': None,  # Динамично проставляется в нормализации по рфиску
            'add_method': service.get('Type', None),
            'rfisc': rfisc,
            'provider': None,
            'price': None,
        }

        local_services.append(local_service)

    for sm in service_money:
        if sm.get('MonetaryInfo', None) is None:
            sm['MonetaryInfo'] = []

    local_services_with_price = calc_price_services(service_money, local_services)
    return local_services_with_price


def calc_price_services(services_money: dict, services: list) -> list:
    """
    Вычисление стоимости услуги
    :param services_money: словарь со стоимостью услуг
    :param services: услуги
    :return: список услуг со стоимостью
    """

    sorted_services_by_emd = collections.defaultdict(list)
    for service in services:
        sorted_services_by_emd[service['emd']].append(service)

    for key, sorted_services in sorted_services_by_emd.items():
        service_money = next((x for x in services_money if x.get('Number') == key), {})
        amount_info = next((x for x in service_money.get('MonetaryInfo', []) or []
                            if x.get('Code') == TicketMonetaryCode.TOTAL.value), {})
        currency = amount_info.get('Currency', None)
        amount = amount_info.get('Amount', None)

        if all([service_money, amount_info, currency, amount]):

            price = round(amount / sum([x['count'] for x in sorted_services]), 2)

            for service in sorted_services:
                service['price'] = price * service.get('count')

    result = list(chain.from_iterable(sorted_services_by_emd.values()))
    return result


def get_rloc(order, *gs):
    rloc = None
    if order.get('Reclocs') and order.get('Reclocs', {}).get('Gds') and order['Pos']['Gds']:
        rloc = '{}/{}'.format(order['Reclocs']['Gds'], order['Pos']['Gds'])
    return rloc


def get_coupon_by_id(order, seg_num):
    """
    Ищет купон по номеру сегмента
    """
    coupons = (order.get('Coupons', []) or [])
    for coupon in coupons:
        if coupon.get('N') == seg_num:
            return coupon
    return []


def get_coupon_by_num(order, ticket):
    """
    Ищет купон по его номеру
    """
    num = ticket.get("Coupon")
    ticket_num = ticket.get("Ticket")
    coupons = (order.get('Coupons', []) or [])
    for coupon in coupons:
        if coupon.get('N') == num and coupon.get("Num") == ticket_num:
            return coupon
    return {}


def get_tickets_by_segment_id(order: dict, seg_num):
    """
    Ищет все билеты по номеру сегмента
    """
    tickets = []
    for ticket in order.get("Tickets", []):
        if ticket.get("SegNum") == seg_num:
            tickets.append(ticket)
    return tickets


def compose_offers(order, *gs) -> list:
    offers_list = []
    services = order.get('Services') if order.get('Services', None) else order.get('Sevices', [])
    for segment in order.get('Segments', []):
        segment_coupons = get_coupons_of_segment(segment, order)

        segment_id = segment.get('SegNum', None)

        if isinstance(segment_id, int):
            segment_id -= 1

        offers_list.append({
            'segment_id': "{}".format(segment_id),
            'fare_code': segment_coupons[0].get('FareCode', None) if len(segment_coupons) else None,
            'marketing_fare_id': None,
            'marketing_fare_code': None,
            'marketing_fare_code2': None,
            'fare_services': {
                'FareService': get_fare_services(services, order.get('Coupons', []))
            },
            'sa': False
        })

    return offers_list


def get_coupons_of_segment(segment, order):
    segment_tickets = [
        (ticket['Coupon'], ticket['Ticket'])
        for ticket in order.get('Tickets', []) if ticket['SegNum'] == segment['SegNum']
    ]
    coupons = order.get('Coupons', [])
    segment_coupons = []
    for c in coupons:
        if (c.get('N', None), c.get('Num', None)) in segment_tickets:
            segment_coupons.append(c)

    return segment_coupons


def get_fare_services(services, coupons):
    return []


def get_segment_by_id(order, segment_id):
    for segment in order.get("Segments", []):
        if segment.get("SegNum", None) == segment_id:
            return segment
    return None


def compose_coupons(order, *gs):
    coupons = order.get('Coupons', [])
    local_coupons = []
    for c in coupons:
        ticket = get_ticket_by_coupon(c, order)
        segment = get_segment_by_id(order, ticket.get('SegNum', None))
        # Делаем нумерацию с 0
        seg_num = ticket.get('SegNum', None)

        if isinstance(seg_num, int):
            seg_num -= 1

        local_coupons.append({
            'number': int(c.get('N')) if c.get('N') is not None else None,
            'ticket': c.get('Num', None),
            'passenger_id': ticket.get('PassNum', None),
            'status': c.get('Status', None),
            'sac': c.get('SAC', None),
            'fare_code': c.get('FareCode', None),
            'op_comment': c.get('OpComment', None),
            'flights': [{
                'marketing': c.get('Itinenary', {}).get('Marketing', None),
                'operating': c.get('Itinenary', {}).get('Operating', None),
                'departure_local_iso': c.get('Itinenary', {}).get('DepDate', None),
                'departure_airport_code': c.get('Itinenary', {}).get('DepPoint', None),
                'arrival_airport_code': c.get('Itinenary', {}).get('ArrPoint', None),
                'booking_timestamp': segment_book_time(segment) if segment else None,
                'rbd': c.get('Itinenary', {}).get('Rbd', None),
            }],
            'segment_id': seg_num,
        })

    return local_coupons


def get_ticket_by_number(number, order):
    tickets = order.get('Tickets', [])
    ticket = next((t for t in tickets if number == t['Ticket']), {})
    return ticket


def get_ticket_by_coupon(coupon, order):
    tickets = order.get('Tickets', [])
    ticket = next((t for t in tickets if (coupon['Num'] == t['Ticket']) and coupon['N'] == t['Coupon']), {})
    return ticket


def get_ticket_money_by_ticket_number(number, order):
    tickets_money = order.get('TicketMoney', [])
    ticket_money = next((t for t in tickets_money if number == t.get('Number', None)), {})
    return ticket_money


def compose_tickets(order, *gs):
    composed_tickets = []
    tickets = order.get('Tickets', [])

    def ticket_composed(number: str) -> bool:
        for composed_ticket in composed_tickets:
            if number == composed_ticket.get('ticket'):
                return True
        return False

    for _ticket in tickets:
        ticket_number = _ticket.get('Ticket', None)

        if ticket_composed(ticket_number):
            continue

        t = {
            'passenger_id': str(_ticket.get('PassNum', None)),
        }
        ticket_money = get_ticket_money_by_ticket_number(ticket_number, order)
        ticket_money = CaseConverter().convert_keys_to_underscore(ticket_money)
        t['ticket'] = ticket_money.pop('number')
        t.update(ticket_money)
        composed_tickets.append(t)

    return composed_tickets


def map_pass_type(category: str) -> Optional[str]:
    """
    Мапим тип пассажира по данным сирены

    AAA - Adult
    IFT - Infant
    Остальное - Child
    """
    pass_type_map = {
        "AAA": PassengerCategory.ADULT.value,
        "CHD": PassengerCategory.CHILD.value,
        "IFT": PassengerCategory.INFANT.value
    }
    return pass_type_map.get(category, PassengerCategory.CHILD.value)


def compose_documents(order):
    documents = []
    origin_passengers = order.get('Passengers', [])
    for idx, p in enumerate(origin_passengers, start=1):
        doc = get_document_by_passenger_number(p['PassNum'], order['Documents'])
        document = convert_documents(p, doc)
        document['passenger_id'] = f"{document.get('passenger_id', idx)}"
        documents.append(document)
    return documents


def convert_documents(passenger, document):
    doccountry, docnumber = split_docnumber(document)
    document = {
        'passenger_id': passenger.get('PassNum', None),
        'birthday': (datetime.datetime.strptime(passenger['BirthDate'], SIRENA_DATETIME_FORMAT)
                     .strftime(UTAIR_DATE_FORMAT)) if passenger.get('BirthDate', None) else None,
        'doctype': document_types.get(document['DocType'], None) if document else None,
        'doccountry': doccountry,
        'docnumber': docnumber,
        'docexpiration': None,
    }
    return document


def compose_host_rloc(order):
    host_rloc = [{
        "value": order.get('Reclocs', {}).get('Host', None),
        "created": int(time.time())

    }]
    return host_rloc


def compose_passengers(order):

    def compare_passenger_with_infant(_passenger: dict, _infant: dict):
        _first_name, _second_name, _last_name, _title = get_passenger_names(_infant)
        return all([
            _passenger.get('last_name') == _last_name,
            _passenger.get('first_name') == _first_name,
            _passenger.get('second_name') == _second_name
        ])

    passengers = []
    origin_passengers = order.get('Passengers', [])
    infants = order.get("Infants", [])
    for idx, p in enumerate(origin_passengers, start=1):
        first_name, second_name, last_name, title = get_passenger_names(p)
        local_passenger = {
            'passenger_id': p.get('PassNum', None),
            'gender': p['Sex'],
            'last_name': last_name,
            'first_name': first_name,
            'second_name': second_name,
            'type': map_pass_type(p.get('PassType', None)),
            'parent_id': None,
            'title': title
        }
        if local_passenger.get('passenger_id'):
            local_passenger['passenger_id'] = str(local_passenger['passenger_id'])

        if local_passenger.get('type') == PassengerCategory.INFANT.value:
            # проставить parent_id из infants
            try:
                infant = next(i for i in infants if compare_passenger_with_infant(local_passenger, i))
                local_passenger['parent_id'] = str(infant.get('PassNum'))
            except StopIteration:
                local_passenger['parent_id'] = None

        passengers.append(local_passenger)

    return passengers


def split_docnumber(doc: dict = None) -> tuple:
    """
    Функция получения страны и номера документа из словаря документа.
    Если первые 2 буквы код страны, вырезаем их из номера документа:
    (код, номер документа),
    иначе возвращаем в исходном виде: (None, номер документа)

    :param doc: Словарь документа
    :return: tuple(код страны, номер документа)
    """

    docnumber = doc['DocNumber'] if doc else None
    doc_country = docnumber[:2].upper() if doc and docnumber else None
    country_in_docnumber = (is_doc_country(doc_country) if doc and docnumber else False)
    if country_in_docnumber:
        return doc_country, docnumber[2:]
    return None, docnumber


def get_passenger_names(passenger):
    """Извлечь ФИО пассажира"""
    first_name, second_name, last_name, title = None, None, None, None

    last_name = passenger.get('LastName')

    first_name_field_value = passenger.get('FirstName')
    first_second_names = []
    for n in first_name_field_value.split():
        if n.upper() not in ('MR', 'MS', 'MRS', 'MSS', 'DR'):
            first_second_names.append(n)
        else:
            title = n

    if len(first_second_names) == 2:
        first_name, second_name = first_second_names
    # elif len(first_second_names) == 1:
    #     first_name, second_name, _ = split_first_second_names(first_name_field_value)
    #     second_name = second_name or None
    else:
        first_name = ' '.join([i for i in first_second_names])

    return first_name, second_name, last_name, title


def convert_sirena_datetime(date_string) -> typing.Union[str, None]:
    if not date_string:
        return None
    parsed_time = parse_sirena_datetime(date_string)
    return parsed_time.strftime(UTAIR_DATETIME_FORMAT)


def parse_sirena_datetime(date_string) -> datetime:
    try:
        parsed_datetime = datetime.datetime.strptime(date_string, SIRENA_DATETIME_FORMAT)
    except ValueError:
        parsed_datetime = datetime.datetime.strptime(date_string, '%m/%d/%Y %I:%M:%S %p')
    return parsed_datetime


@memoized
def calc_owrt(order, *gs) -> str:
    """
    Вычисление OWRT
    """
    segments = order.get('Segments', [])
    if not is_ignore_segment_status(order):
        segments = list(filter(lambda s: s.get('Status', '') not in SEGMENT_UNWANTED_STATUS_LIST, segments))
    segments = sorted(segments, key=itemgetter('DepTime'), reverse=False)
    return OWRT.RT.value if segments[0]['DepPoint'] == segments[-1:][0]['ArrPoint'] else OWRT.OW.value


def segment_book_time(segment, *gs) -> typing.Union[int, None]:
    if not segment['BookTime']:
        return None
    return convert_datetime_string_to_timestamp(
        segment['BookTime'],
        SIRENA_DATETIME_FORMAT,
        datetime.timezone.utc,
    )


def first_segment_book_time(order, *gs):
    if len(order.get('Segments', [])):
        return convert_datetime_string_to_timestamp(
            order['Segments'][0]['BookTime'],
            SIRENA_DATETIME_FORMAT,
            datetime.timezone.utc,
        )
    return None


def calc_full_price(order, *gs):
    full_price = 0

    if not order.get('TicketMoney', None):
        return full_price

    monetary_items = []
    for money_item in order['TicketMoney']:
        if money_item.get('MonetaryInfo', None):
            monetary_items.extend(money_item['MonetaryInfo'])

    full_price = sum(
        (item['Amount'] if item.get('Amount', None) and item.get('Code', None) == TicketMonetaryCode.TOTAL.value else 0)
        for item in monetary_items
    )

    return full_price


def calc_direction(segment, *gs):
    order = gs[0]
    owrt = calc_owrt(order)
    if owrt == OWRT.RT.value:
        segments = order.get('Segments', [])
        segments.sort(key=lambda seg: seg.get('SegNum', 0))
        for seg in segments:
            if seg['SegNum'] == segment['SegNum']:
                return Direction.TO.value
            else:
                if segment['ArrPoint'] == seg['DepPoint']:
                    return Direction.BACK.value
    return Direction.TO.value


def compose_contacts(order, *gs):
    contacts = list()

    contacts_to_map = order.get('Contacts', [])

    for contact in contacts_to_map:
        text_contact = contact.get("Text", None)
        contact_type = contact.get("Type", None)

        if not text_contact:
            continue
        if phone_regex.match(text_contact):
            contacts.append({"contact": text_contact, "type": ContactType.PHONE.value, "sirena_type": contact_type})
        elif '@' in text_contact:
            contacts.append({"contact": text_contact, "type": ContactType.MAIL.value, "sirena_type": contact_type})
        elif text_contact:
            contacts.append({"contact": text_contact, "type": ContactType.OTHER.value, "sirena_type": contact_type})

    return contacts


def get_document_by_passenger_number(passenger_number, documents):
    return next((doc for doc in documents if doc['PassNum'] == passenger_number), None)


def is_doc_country(code: str = None) -> bool:
    """
    Проверка, является ли переданные символы кодом страны

    :param code: Код страны
    :return: bool
    """
    if not (code and code.isalpha()):
        return False
    return code in COUNTRY_CODES


def get_sirena_contacts_blacklist():
    """Возвращает список заблокированных контактов сирены
    :param contact: Тип контакта (email, phone)
    :Exemple::
        blacklist = get_sirena_contacts_blacklist()
    :return: ```{
                    "email": ["agent@mail.ru"],
                    "phone": ["+74959610013"]
                }```
    """
    blacklist = {}
    # Получаем список заблокированных контактов
    # qs = get_utair_db().settings.find_one({"name": "sirenaContactsBlacklist"})
    # if qs:
    #     blacklist = qs.get('value', {})
    return blacklist


def compose_price(order, *gs) -> dict:
    price = {
        'full_price': calc_full_price(order, *gs),
        'ticket_price': None,
        'currency': None,
        'discount': {}
    }
    return price


def compose_analytics_data(order, *gs) -> dict:
    analytics_data = {
        'payment_id': None,
        'partner_id': None,
        'partner_data': None,
        'partner_data_ex': None,
        'partner_discount': None,
        'partner_discount_active': None,
        'pay_method_id': None,
        'pay_method_code': None,
        'first_segment_booking_time': first_segment_book_time(order, *gs),
        'device_token': None,
    }
    return analytics_data


def compose_pos_data(order, *gs) -> dict:
    """
    Составляем справочник pos_data
    """
    pos_data = order.get('Pos', {})
    normalized_pos_data = CaseConverter().convert_keys_to_underscore(pos_data)
    normalized_pos_data['timelimit'] = convert_sirena_datetime(order.get('TimeLimit', None))
    normalized_pos_data['gds'] = {}

    if normalized_pos_data['term_id'] is not None:
        normalized_pos_data['term_id'] = [
            {'value': normalized_pos_data['term_id'], 'created': int(time.time())}
        ]
    else:
        normalized_pos_data['term_id'] = []

    return normalized_pos_data


def compose_fops(order, *gs) -> list:
    """
    Составляем справочник fops
    """
    converted_fops = [
        CaseConverter().convert_keys_to_underscore(x) for x in order.get('Fops', []) or []
    ]
    for cf in converted_fops:
        cf['fops_id'] = cf.pop('number')

        free_text = cf.get('free_text')

        if free_text is not None and '/' in free_text:

            fop_text = free_text.split('/')
            if len(fop_text) == 2:
                code, account_num = fop_text
            else:
                code = fop_text[0]
                account_num = '/'.join(fop_text[1::])

            cf['account_num'] = account_num
            cf['code'] = code

    return converted_fops


def compose_ssrs(order, *gs) -> list:
    """
    Составляем справочник ssrs
    """
    ssrs = order.get('Ssrs', [])
    normalized_ssrs = []
    for ssr in ssrs:
        seg_num = ssr.get('SegNum', None)
        if isinstance(seg_num, int):
            seg_num -= 1
        ssr['segment_id'] = seg_num
        ssr['passenger_id'] = ssr.get('PassNum', None)
        ssr['count'] = ssr.get('Qtty', None)
        normalized_ssrs.append(CaseConverter().convert_keys_to_underscore(ssr))

    return normalized_ssrs


def normalize_segment_id(segment, *gs):
    """Нормализация segment_id"""
    segment_id = segment.get('SegNum', None)
    if isinstance(segment_id, int):
        segment_id -= 1
    return str(segment_id)


def get_oak(segment, order):
    """Возвращает код операционной авиа компании для сегмента"""
    tickets = get_tickets_by_segment_id(order, segment.get('SegNum'))
    coupon = {}
    for ticket in tickets:
        coupon = get_coupon_by_num(order, ticket)
        if coupon:
            break
    operating = coupon.get("Itinenary", {}).get("Operating", "")
    if len(operating) >= 2:
        return operating[:2]
    return None


def is_ignore_segment_status(order: dict) -> bool:
    """
    Проверяет, все ли сегменты заказа имеют статус XX или UN.
    """
    segments = order.get('Segments', [])
    for segment in segments:
        if segment.get('Status') not in SEGMENT_UNWANTED_STATUS_LIST:
            return False
    return True
