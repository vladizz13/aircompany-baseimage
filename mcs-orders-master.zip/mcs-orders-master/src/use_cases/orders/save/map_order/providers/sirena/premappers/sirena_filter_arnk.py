from typing import Any
from domain.types import TransactionSource
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class SirenaFilterSegmentsPreMap(BaseTransactionPreMap):
    """
    Удаление сегментов с SegType: arnk из изначальной транзакции
    """
    transaction_source = TransactionSource.SIRENA.value

    def premap(self, transaction: dict, request: Any) -> dict:
        segments = transaction.get('Segments', [])
        for segment in segments:
            # удаляем стыковачный сегмент (технические данные сирены)
            if segment.get('SegType', '') == 'arnk':
                transaction['Segments'].remove(segment)
        return transaction
