from typing import Any
from domain.types import TransactionSource, GDS
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class SirenaSubstituteGDSPreMap(BaseTransactionPreMap):
    """
    Подмена хоста /15 на /1H
    """
    transaction_source = TransactionSource.SIRENA.value

    def premap(self, transaction: dict, request: Any) -> dict:
        if transaction.get("Pos", dict()).get("Gds") == GDS.SIRENA_V2.value:
            transaction["Pos"]["Gds"] = GDS.SIRENA.value
        return transaction
