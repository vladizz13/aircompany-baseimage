from typing import Dict
import pytz

from .common import get_order
from datetime import datetime

SIRENA_DATE_FORMAT = '%d.%m.%Y'
SIRENA_TIME_FORMAT = '%H:%M'
SIRENA_DATETIME_FORMAT = '{} {}'.format(SIRENA_TIME_FORMAT, SIRENA_DATE_FORMAT)


def compose_analytics_data(order, *gs) -> dict:
    order_body: Dict = get_order(order)

    first_segment_booking_time = None
    sirena_date = order_body.get('pnr', {}).get("@bdate", None)
    if sirena_date:
        naive_date = datetime.strptime(sirena_date, SIRENA_DATETIME_FORMAT)
        # Сирена присылает время по Москве
        tz_moscow = pytz.timezone("Europe/Moscow")
        moscow_date = tz_moscow.localize(naive_date)
        first_segment_booking_time = int(moscow_date.timestamp())

    analytics_data = {
        # 'payment_id': None,
        # 'partner_id': None,
        # 'partner_data': None,
        # 'partner_data_ex': None,
        # 'partner_discount': None,
        # 'partner_discount_active': None,
        # 'pay_method_id': None,
        # 'pay_method_code': None,
        'first_segment_booking_time': first_segment_booking_time,
        # 'device_token': None,
    }
    return analytics_data
