from operator import itemgetter
from typing import List, Dict, Union

from domain.types import OWRT
from domain.types import SegmentStatus
from libs.utils.memoized import memoized


SEGMENT_UNWANTED_STATUS_LIST = [SegmentStatus.XX.value, SegmentStatus.UN.value]


def filter_duplicates_by_value(input_list: List[Dict], key: str) -> List[Dict]:
    """
    Фультруем дубликаты словарей в массиве по ключ+значению
    """
    filtered_list = list()
    values_seen = list()
    for item in input_list:
        value = item.get(key)
        if value in values_seen:
            continue
        filtered_list.append(item)
        values_seen.append(value)
    return filtered_list


@memoized
def sirena_id_to_real_id(_id: str, input_list: list, start: int = 1) -> str:
    """
    Конвертация @Id сирены в порядковый id
    """
    passengers = sorted(input_list, key=lambda x: int(x.get("@id")), reverse=False)
    for idx, passenger in enumerate(passengers, start):
        if passenger.get('@id') == _id:
            return str(idx)


def extended_find_airport_by_iata(airport_iata: str) -> dict:
    # TODO Move to normalization
    from adapter.monoapp import MonoAppAdapter
    mad = MonoAppAdapter()
    result = mad.extended_find_airport_by_iata(airport_iata)['time_zone']
    return result


def is_ignore_segment_status(order: Dict) -> bool:
    """
    Проверяет что все сегменты в статусе XX или UN
    """
    segments: list = get_pnr(order).get('segments', {}).get('segment')
    for segment in segments:
        if segment.get('status', {}).get("@text", '') not in SEGMENT_UNWANTED_STATUS_LIST:
            return False
    return True


@memoized
def calc_owrt(order: Dict) -> Union[str, None]:
    """
    Вычисление OWRT
    """
    try:
        segments: list = get_pnr(order).get('segments', {}).get('segment')
        if not is_ignore_segment_status(order):
            segments = list(filter(
                lambda s: s.get('status', {}).get('@text', '') not in SEGMENT_UNWANTED_STATUS_LIST, segments)
            )
        segments = sorted(segments, key=itemgetter('@id'), reverse=False)

        departure_point: str = segments[0].get('departure', {}).get('city', None)
        arrival_point: str = segments[-1:][0].get('arrival', {}).get('city', None)

        return OWRT.RT.value if departure_point == arrival_point else OWRT.OW.value
    except (AttributeError, TypeError):
        return None


@memoized
def match_ticket_info(ticket_num: str, pass_id: str, ticket_info_list: Union[List, Dict]) -> List:
    if isinstance(ticket_info_list, dict):
        ticket_info_list = [ticket_info_list]
    matched_info_list = list()
    for ticket_info in ticket_info_list:
        if all([
            ticket_info.get('@ticknum', None) == ticket_num,
            ticket_info.get('@pass_id', None) == pass_id,
            ticket_info.get('@seg_id') != '-1'
        ]):
            matched_info_list.append(ticket_info)
    return matched_info_list


@memoized
def match_ticket_price(ticket_num: str, pass_id: str, ticket_price_list: List) -> List:
    matched_info_list = list()
    for ticket_price in ticket_price_list:
        if ticket_price.get('@ticket', None) == ticket_num and ticket_price.get('@passenger-id', None) == pass_id:
            matched_info_list.append(ticket_price)
    return matched_info_list


def get_ticket_num(ticket: Dict) -> str:
    """
    Получаем номер билета
    """
    return ticket.get('@accode') + ticket.get('@ticket')


def get_tickets(order: Dict) -> List[Dict]:
    """
    Извлекаем билеты из order.pnr.prices.price, где @doc_type == 'ticket' или из order.tickinfo, где @tick_ser == 'ETM'

    :param order: заказ
    :return: билеты
    """
    pnr: Dict = get_pnr(order)
    tickets_from_pnr: List[Dict] = pnr.get('prices', {}).get('price', [])
    if tickets_from_pnr:
        tickets = [
            ticket for ticket in tickets_from_pnr
            if ticket.get('@doc_type', None) == 'ticket'
        ]
    else:
        tickets = [
            {
                '@ticket': ticket.get('@ticknum')[len(ticket.get('@accode'))::],
                '@accode': ticket.get('@accode'),
                '@passenger-id': ticket.get('@pass_id', None),
            }
            for ticket in order.get('order', {}).get('tickinfo', dict())
            if ticket.get('@tick_ser', None) == 'ETM'
        ]
    return tickets


def get_order(order: Dict) -> Dict:
    """
    Получение тела заказа
    """
    return order.get('order', {})


def get_pnr(order) -> dict:
    """
    Получение тела заказа (pnr)
    """
    return get_order(order).get('pnr', {})
