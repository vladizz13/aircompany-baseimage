import re
from typing import Dict, List

from domain.types import ContactType
from .common import get_pnr


phone_regex = re.compile(r'([0-9-\)\(\.\s]{1,3}){9,15}')


def compose_contacts(order: Dict) -> List:
    """
    Составляем контакты
    """
    contacts = []

    _contacts = order.get('order').get('contacts', {})
    # Контакты могут быть в пассажирах
    _passengers = get_pnr(order).get('passengers', {}).get('passenger', [])

    all_contacts = list()
    all_contacts.extend(_contacts.get('contact', []))
    all_contacts.extend(_contacts.get('email', []))
    [all_contacts.extend(p.get('contacts', {}).get('contact', [])) for p in _passengers]

    for c in all_contacts:
        text_contact = c.get('text', None)
        contact_type = c.get('@type', None)

        if not text_contact:
            continue

        if phone_regex.match(text_contact):
            contacts.append({"contact": text_contact, "type": ContactType.PHONE.value, "sirena_type": contact_type})
        elif '@' in text_contact:
            contacts.append({"contact": text_contact, "type": ContactType.MAIL.value, "sirena_type": contact_type})
        elif text_contact:
            contacts.append({"contact": text_contact, "type": ContactType.OTHER.value, "sirena_type": contact_type})

    return contacts
