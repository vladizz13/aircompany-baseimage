import time
from typing import List, Dict, Optional, Union
from functools import reduce

from libs.utils.memoized import memoized

from .common import get_pnr
from .common import get_order
from .common import get_tickets
from .common import match_ticket_info
from .common import match_ticket_price
from .common import get_ticket_num
from .common import filter_duplicates_by_value
from .common import sirena_id_to_real_id


@memoized
def match_price_to_coupon(segment_id: str, pass_id: str, coupon_num: str, ticket_price_list: List) -> Dict:
    for price in ticket_price_list:
        if all([
            price.get('@segment-id') == segment_id,
            price.get('@passenger-id') == pass_id,
            price.get('@ticket_cpn') == coupon_num
        ]):
            return price


def compose_flight(segment: Optional[Dict]) -> List[Dict]:
    """
    Составления привязанного к купону рейса
    """
    if not segment:
        return list()
    marketing: str = f'{segment.get("company")}-{segment.get("flight")}'
    operating: str = f'{segment.get("operating_company", "")}-{segment.get("operating_flight", "")}'
    if operating == '-':
        operating = marketing

    arrival_city = segment.get("arrival", {}).get("city", None)
    departure_city = segment.get("departure", {}).get("city", None)
    departure_airport = segment.get("departure", {}).get("airport", None) or departure_city
    arrival_airport = segment.get("arrival", {}).get("airport", None) or arrival_city

    return [{
        'marketing': marketing,
        'operating': operating,
        'departure_local_iso': f'{segment.get("departure", {}).get("time")} {segment.get("departure", {}).get("date")}',
        'departure_airport_code': departure_airport,
        'arrival_airport_code': arrival_airport,
        'rbd': segment.get('subclass'),
        'booking_timestamp': None,  # отсутсвует, не используется при проверке
        'created': int(time.time()),
    }]


def compose_coupons(order: Dict) -> List[Dict]:
    """
    Составляем купоны
    """
    try:
        tickets: List[Dict] = get_tickets(order)
        unique_tickets: List[Dict] = filter_duplicates_by_value(tickets, "@ticket")
        ticket_info_list: List[Dict] = get_order(order).get('tickinfo', [])

        mapped_coupons: List[Dict] = list()

        passengers: List[Dict] = get_pnr(order).get('passengers', {}).get('passenger', [])
        segments: List[Dict] = get_pnr(order).get('segments', {}).get('segment', [])
    except AttributeError:
        return list()

    segment_id_to_segment_map: Dict = {s.get('@id'): s for s in segments}

    for ticket in unique_tickets:
        ticket_num: str = get_ticket_num(ticket)
        sirena_pass_id: str = ticket.get('@passenger-id', None)

        corresponding_ticket_info: List[Dict] = match_ticket_info(
            ticket_num,
            sirena_pass_id,
            ticket_info_list
        )

        corresponding_ticket_price: List[Dict] = match_ticket_price(
            ticket.get('@ticket'),
            sirena_pass_id,
            tickets
        )

        for info in corresponding_ticket_info:
            segment_id: str = info.get('@seg_id')
            coupon_num: str = info.get("@ticket_cpn")

            coupon_price: Dict = match_price_to_coupon(
                segment_id,
                sirena_pass_id,
                coupon_num,
                corresponding_ticket_price
            )

            try:
                coupon_taxes: Union[Dict, List] = coupon_price.get('taxes', {}).get('tax', [])
                if isinstance(coupon_taxes, dict):
                    coupon_taxes = [coupon_taxes]
                fare: Optional[str] = coupon_price.get('fare', {}).get('value', {}).get('text')
                fare_code: Optional[str] = coupon_price.get('fare', {}).get('code', {}).get('text')
            except AttributeError:
                fare = None
                fare_code = None
                coupon_taxes = list()

            taxes: List[float] = [
                float(t.get("value", {}).get('text', 0)) for t in coupon_taxes
            ]
            taxes_sum: float = reduce(lambda x, y: x+y, taxes) if taxes else .0

            mapped_coupons.append({
                'number': coupon_num,
                'ticket': info.get('@ticknum'),
                'passenger_id': sirena_id_to_real_id(sirena_pass_id, passengers),
                'segment_id': sirena_id_to_real_id(segment_id, segments, start=0),
                'status': None,  # Проставляется в расширителях сохранения заказа вызывая eticket_display
                'sac': None,
                'fare_code': fare_code,
                'updated': [],
                'flights': compose_flight(segment_id_to_segment_map.get(segment_id)),
                'coupon_money': {
                    "fare": fare,
                    "tax": taxes_sum,
                    "discount": 0
                },
                'op_comment': None,
            })

    return mapped_coupons
