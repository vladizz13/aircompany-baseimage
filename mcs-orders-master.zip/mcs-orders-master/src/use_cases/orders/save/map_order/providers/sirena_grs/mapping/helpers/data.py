import time
from operator import itemgetter
from typing import Union, Dict, List
from domain.types import GDS, OWRT
from .common import SEGMENT_UNWANTED_STATUS_LIST
from .common import calc_owrt
from .common import get_pnr
from .common import is_ignore_segment_status


def get_rloc(order: Dict) -> str:
    rloc = get_pnr(order).get('regnum', None)
    return f'{rloc}/{GDS.SIRENA.value}' if rloc else None


def get_rloc_host(order: Dict) -> List[Dict]:
    """
    Находится в каждом сегменте, всегда одинаковые во всех, берем из первого смегмента
    """
    try:
        first_segment: dict = get_pnr(order).get('segments', {}).get('segment')[0]
        rloc_host = [
            {
                'created': int(time.time()),
                'value': first_segment.get('remote_recloc', None),
            }
        ]
        return rloc_host
    except (AttributeError, TypeError):
        return list()


def get_group(order: Dict) -> bool:
    """
    Устанавливаем true если получили true от Сирены или в броне более 9 пассажиров
    """
    group: bool = get_pnr(order).get('group', False)
    if group:
        return True
    elif not group and len(get_pnr(order).get('passengers', {}).get('passenger', [])) > 9:
        return True
    return False


def get_departure_point(order: Dict) -> Union[str, None]:
    """
    Вычисление кода города вылета по коду аэропорта вылета.
    Вычисляет кода города вылета по IATA у аннулированого, возврщенного и действующего заказа.
    """
    segments: list = get_pnr(order).get('segments', {}).get('segment', [])
    if not segments:
        return None
    if not is_ignore_segment_status(order):
        segments = list(
            filter(
                lambda s: s.get('status', {}).get('@text', '')
                not in SEGMENT_UNWANTED_STATUS_LIST,
                segments,
            )
        )
    segments: list = sorted(segments, key=itemgetter('@id'), reverse=False)
    first_segment: dict = segments[0]
    departure_point: str = first_segment.get('departure', {}).get('city', None)
    return departure_point


def get_arrival_point(order: Dict) -> Union[str, None]:
    """
    Вычисление кода города прилета по коду аэропорта прилета.
    Вычисляет кода города прилета по IATA у аннулированого, возврщенного и действующего заказа.
    """
    segments: List = get_pnr(order).get('segments', {}).get('segment')
    if not segments:
        return None
    if not is_ignore_segment_status(order):
        segments = list(
            filter(
                lambda s: s.get('status', {}).get('@text', '')
                not in SEGMENT_UNWANTED_STATUS_LIST,
                segments,
            )
        )
    segments = sorted(segments, key=itemgetter('@id'), reverse=False)
    last_segment: Dict = segments[-1:][0]
    arrival_point: str = last_segment.get('arrival', {}).get('city', None)

    if calc_owrt(order) == OWRT.RT.value:
        dep_points = []
        for segment in segments:
            dep_points.append(segment.get('departure', {}).get('city', None))
            if segment.get('arrival', {}).get('city', None) in dep_points:
                arrival_point = segment.get('departure', {}).get('city', None)
                break

    return arrival_point
