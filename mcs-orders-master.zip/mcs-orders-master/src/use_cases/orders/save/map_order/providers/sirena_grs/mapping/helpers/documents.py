from .common import get_pnr
from .common import sirena_id_to_real_id


def compose_documents(order) -> list:
    """
    Составляем документы пассажиров
    """
    order_body = get_pnr(order)

    mapped_documents = list()
    passengers = order_body.get('passengers', {}).get('passenger', [])

    for passenger in passengers:
        mapped_documents.append({
            'passenger_id': sirena_id_to_real_id(passenger.get('@id'), passengers),
            'birthday': passenger.get('birthdate', None),
            'doccountry': passenger.get('doc_country', None),
            'docexpiration': passenger.get('pspexpire', None),
            'docnumber': passenger.get('doc', None),
            'doctype': passenger.get('doccode', None)
        })

    return mapped_documents
