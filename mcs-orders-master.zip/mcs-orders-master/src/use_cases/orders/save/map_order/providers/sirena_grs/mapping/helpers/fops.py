from typing import Dict, List
from .common import get_pnr
from .common import get_ticket_num


def compose_fops(order: Dict) -> List[Dict]:
    """
    Составление fops
    """
    prices: List[Dict] = get_pnr(order).get('prices', {}).get('price', [])

    mapped_fops: List[Dict] = list()

    for price in prices:
        ticket_num: str = get_ticket_num(price)
        payments: List[Dict] = price.get('payment_info', {}).get('payment', [])

        for payment in payments:

            fop = {
                'coupon_id': price.get('@ticket_cpn', None),
                'amount': payment.get('text', "0"),
                'code': payment.get('@fop', None),
                'account_num': payment.get('@num', None),
                'app_code': payment.get('@auth_code', None),
                'auth_center': payment.get('@auth_center', None)
            }
            if price.get('@doc_type', None) == 'ticket':
                fop.update({"ticket": ticket_num})
            elif price.get('@doc_type', None) == 'emd':
                fop.update({"emd": ticket_num})

            mapped_fops.append(fop)

    return mapped_fops
