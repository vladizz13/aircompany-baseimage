from typing import List, Dict, Optional

from domain.types import PassengerCategory, Gender
from .common import get_pnr
from .common import sirena_id_to_real_id


def get_passenger_names(passenger) -> (str, str, str, str):
    """ Извлечь ФИО пассажира"""
    first_name, second_name, last_name = None, None, None

    last_name = passenger.get('surname')

    first_name_field_value = passenger.get('name')
    title = None
    first_second_names = []
    for n in first_name_field_value.split():
        if n.upper() not in ('MR', 'MS', 'MRS', 'MSS', 'DR'):
            first_second_names.append(n)
        else:
            title = n

    if len(first_second_names) == 2:
        first_name, second_name = first_second_names
    else:
        first_name = ' '.join([i for i in first_second_names])

    return first_name, second_name, last_name, title


def map_pass_type(category: str) -> Optional[str]:
    """
    Мапим тип пассажира по данным сирены
    """
    try:
        category = int(category)
    except TypeError:
        return None
    pass_type_map = {
        0: PassengerCategory.ADULT.value,
        1: PassengerCategory.CHILD.value,
        2: PassengerCategory.INFANT.value,
    }
    return pass_type_map.get(category, None)


def compose_passengers(order) -> List[Dict]:
    """
    Составление пассажиров
    """
    order_body: dict = get_pnr(order)

    mapped_passengers = list()
    passengers: List[Dict] = order_body.get('passengers', {}).get('passenger', [])

    for passenger in passengers:
        first_name, second_name, last_name, title = get_passenger_names(passenger)
        passenger_category: str = passenger.get('category', {}).get('@rbm')
        _passenger = {
            'passenger_id': sirena_id_to_real_id(passenger.get('@id'), passengers),
            'parent_id': sirena_id_to_real_id(passenger.get('@parent_id'), passengers),
            'first_name': first_name,
            'second_name': second_name,
            'last_name': last_name,
            'category': passenger.get('category', {}).get('text'),
            'type': map_pass_type(passenger_category),
            'gender': Gender.FEMALE.value
            if passenger.get('sex', None) == 'female'
            else Gender.MALE.value,
            'title': title
        }

        mapped_passengers.append(_passenger)

    return mapped_passengers
