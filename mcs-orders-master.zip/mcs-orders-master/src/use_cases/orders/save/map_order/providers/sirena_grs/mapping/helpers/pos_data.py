from typing import Dict, Union, List

from .common import get_order


def get_tick_ppr(order_body: Dict) -> str:
    """
    Получаем tick_ppr первого купона
    """
    tick_info: Union[Dict, List] = order_body.get('tickinfo', [])
    if isinstance(tick_info, dict):
        tick_info: List = [tick_info]

    require_etick = len(tick_info) > 1

    for info in tick_info:
        if info.get('@ticket_cpn', None) == "1":
            if require_etick and info.get('@is_etick') != 'true':
                continue
            return info.get("@tkt_ppr")


def compose_pos_data(order: Dict) -> Dict:
    """
    Составляем pos_data
    """
    order_body: Dict = get_order(order)

    pos_data: Dict = {
        "pos_id": get_tick_ppr(order_body),
        "agency": order_body.get('@agency', {}),
        "timelimit": order_body.get('pnr', {}).get('timelimit', None),
        "create_time": order_body.get('pnr', {}).get("@bdate", None)

    }

    return pos_data
