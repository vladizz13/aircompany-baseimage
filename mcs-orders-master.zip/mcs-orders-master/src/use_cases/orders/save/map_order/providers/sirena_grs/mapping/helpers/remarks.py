from typing import Dict, List, Union

from .common import get_order


def compose_remarks(order: Dict) -> List:
    """
    Составление ремарок к заказу
    """
    remarks: Union[List[Dict], Dict] = get_order(order).get('remarks', {}).get('remark', [])
    if not isinstance(remarks, list):
        remarks = [remarks]
    mapped_remarks: List[Dict] = list()
    for remark in remarks:
        mapped_remarks.append({
            'remark_id': remark.get('@rem_id'),
            'carrier': remark.get('@carrier'),
            'text': remark.get('text')
        })
    return mapped_remarks
