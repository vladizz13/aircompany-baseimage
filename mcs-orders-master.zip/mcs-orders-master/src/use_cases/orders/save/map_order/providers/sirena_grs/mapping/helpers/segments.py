from typing import List, Dict

from domain.types import OWRT, Direction, SegmentStatus

from .common import get_pnr
from .common import sirena_id_to_real_id
from .common import calc_owrt


def calc_direction(order: Dict, segment: Dict, segments: List[Dict]) -> str:
    """
    Рассчет направления
    """
    owrt: str = calc_owrt(order)
    if owrt == OWRT.RT.value:
        segments.sort(key=lambda seg: seg.get('@id', 0), reverse=False)
        for seg in segments:
            if seg['@id'] == segment['@id']:
                return Direction.TO.value
            else:
                arrival = segment.get('arrival', {})
                arrival_airport = arrival.get('city', None)

                departure = seg.get('departure', {})
                departure_airport = departure.get('city', None)

                if arrival_airport == departure_airport:
                    return Direction.BACK.value
    return Direction.TO.value


def calc_flight_time(flight_time: str) -> int:
    """
    Рассчет времени полета
    """
    total_seconds = 0
    flight_time = flight_time.split(":")
    hours, minutes = int(flight_time[0]), int(flight_time[1])
    total_seconds += hours * 60 * 60
    total_seconds += minutes * 60
    return total_seconds


def compose_segments(order) -> List[Dict]:
    """
    Составление сегментов
    """
    try:
        order_body: Dict = get_pnr(order)
        segments: List[Dict] = order_body.get('segments', {}).get('segment', [])
    except AttributeError:
        return list()

    mapped_segments: List[Dict] = list()
    segments: List[Dict] = sorted(segments, key=lambda i: i['@id'])
    for segment in segments:
        arrival_city = segment.get("arrival", {}).get("city", None)
        departure_city = segment.get("departure", {}).get("city", None)
        departure_airport = segment.get("departure", {}).get("airport", None) or departure_city
        arrival_airport = segment.get("arrival", {}).get("airport", None) or arrival_city

        arrival_date_time, departure_date_time = get_time(segment)

        mapped_segments.append({
            "segment_id": sirena_id_to_real_id(segment.get('@id'), segments, start=0),
            "ak": segment.get("company"),
            "ak_full_name": "ЮТЭИР" if segment.get("company", "UT") == 'UT' else None,
            "oak": segment.get("operating_company"),
            "oak_full_name": None,  # TODO
            "arrival_city_code": arrival_city,
            "arrival_airport_code": arrival_airport,
            "departure_city_code": departure_city,
            "departure_airport_code": departure_airport,
            "class": segment.get("cabin"),
            "rbd": segment.get("subclass"),
            "standby": True if segment.get("status", {}).get("@text") == SegmentStatus.SA.value else False,
            "direction": calc_direction(order, segment, segments),
            "duration": calc_flight_time(segment.get('flightTime')),
            "flight_number": segment.get("flight"),
            "plane_type": segment.get("airplane"),
            "status": segment.get("status", {}).get("@text"),
            "ns": int(segment.get("seatcount")) if segment.get("seatcount") else None,
            'arrival_local_iso': arrival_date_time,
            'arrival_timestamp': arrival_date_time,
            'departure_local_iso': departure_date_time,
            'departure_timestamp': departure_date_time,
            "marketing_tags": dict(),
            'gds_active': True
            # "booking_timestamp": отсуствует
            # "status_visual" рассчитывает на лету
            # "seg_type" отсутсвует
            # "layover time" вычисляется на лету в сохранении
            # "plane_type_name" отсуствует
        })

    return mapped_segments


def get_time(segment: Dict):
    arrival_time_str = segment.get("arrival", {}).get("time") or '00:00'
    arrival_date_str = segment.get("arrival", {}).get("date")

    departure_time_str = segment.get("departure", {}).get("time") or '00:00'
    departure_date_str = segment.get("departure", {}).get("date")

    arrival_date_time = f'{arrival_time_str} {arrival_date_str}'
    departure_date_time = f'{departure_time_str} {departure_date_str}'

    return arrival_date_time, departure_date_time
