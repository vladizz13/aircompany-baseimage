from typing import Dict, List, Union

from .common import get_ticket_num
from .common import get_pnr
from .common import get_order


def get_service_money(service_price: List[Dict]) -> List[Dict]:
    service_price_list: List[Dict] = list()
    for sp in service_price:
        if sp.get('@doc_type', None) == 'emd':
            service_price_list.append(sp)
    return service_price_list


def get_insurance_money(order: Dict) -> List[Dict]:
    """
    Составление стоимости страховок
    """

    insurances: Union[List[Dict], Dict] = get_order(order).get("insurances", {}).get('ticket', [])
    if isinstance(insurances, dict):
        insurances = [insurances]

    mapped_insurance_money: List[Dict] = list()

    for insurance in insurances:
        mapped_insurance_money.append({
            "emd": insurance.get("@pseudo_num", None),
            "amount": insurance.get("@premium", None),
            "currency": insurance.get("@curr")
        })

    return mapped_insurance_money


def compose_service_money(order: Dict) -> List[Dict]:
    """
    Составление service money
    """
    mapped_service_money: List[Dict] = list()

    service_price_list = get_service_money(get_pnr(order).get('prices', {}).get('price', []))

    for sp in service_price_list:
        mapped_service_money.append({
            "emd": get_ticket_num(sp),
            "amount": sp.get("fare", {}).get('value', {}).get('text', None),
            "currency": sp.get("fare", {}).get('value', {}).get('@currency', None)
        })

    mapped_service_money.extend(get_insurance_money(order))

    return mapped_service_money
