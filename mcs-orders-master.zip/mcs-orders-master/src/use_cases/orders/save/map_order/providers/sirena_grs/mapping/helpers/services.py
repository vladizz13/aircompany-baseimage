from typing import Dict, List, Union

from .common import get_pnr
from .common import get_order
from .common import sirena_id_to_real_id
from domain.types import ServiceStatus


def compose_insurance(order: Dict) -> List[Dict]:
    """
    Составление сервисов (страховки)
    """
    order_full_body: Dict = get_order(order)
    order_body: Dict = get_pnr(order)

    mapped_insurances: List[Dict] = list()

    segments: List[Dict] = order_body.get('segments', {}).get('segment', [])
    passengers: List[Dict] = order_body.get('passengers', {}).get('passenger', [])
    insurances: Union[List[Dict], Dict] = order_full_body.get('insurances', {}).get('ticket', [])

    if isinstance(insurances, dict):
        insurances = [insurances]

    for insurance in insurances:
        segment_id = insurance.get('@segment-id', None)
        passenger_id = insurance.get('@passenger-id', None)

        mapped_insurances.append({
            'emd': insurance.get('@pseudo_num', None),
            'segment_id': sirena_id_to_real_id(segment_id, segments, start=0),
            'passenger_id': sirena_id_to_real_id(passenger_id, passengers),
            'add_method': insurance.get('@ins', '') + '/' + insurance.get('@tins', ''),
            'type': "insurance",
            'count': 1,
            'rfisc': "0BG",
            'provider': insurance.get('@ser', None),
            'ins_num': insurance.get('@num', None),
            'ins_id': insurance.get('@ins_id', None),
            'exchangeable': insurance.get('@exchangeable', '') == 'true',
            'price': insurance.get('@premium', 0),
            "status": get_status(insurance),
            "description": "Страхование пассажиров"
        })

    return mapped_insurances


def compose_services(order: Dict) -> List[Dict]:
    """
    Составление сервисов
    """

    order_body: Dict = get_pnr(order)

    try:
        segments: List[Dict] = order_body.get('segments', {}).get('segment', [])
        passengers: List[Dict] = order_body.get('passengers', {}).get('passenger', [])
    except AttributeError:
        return list()

    mapped_services: List[Dict] = list()

    for service in order_body.get('svcs', {}).get('svc', []):

        segment_id = service.get('@seg_id', None)
        passenger_id = service.get('@pass_id', None)

        if not all([segment_id, passenger_id]):
            continue

        mapped_services.append({
            "emd": service.get('@emd', None),
            "emd_type": service.get('@emdt', None),
            "rfisc": service.get('@rfisc', None),
            "description": service.get("@name", None),
            "count": service.get('@qtty', None),
            "status": service.get('@status', None),
            "segment_id": sirena_id_to_real_id(segment_id, segments, start=0),
            "passenger_id": sirena_id_to_real_id(passenger_id, passengers),
        })

    mapped_services.extend(compose_insurance(order))

    return mapped_services


def get_status(service):
    """
    Проставляем дефолтные статусы страховкам в зависимости от emd.
    """
    if service.get('emd', {}).get('@num', None):
        return ServiceStatus.HI.value
    else:
        return ServiceStatus.HD.value
