from typing import Dict, List

from domain.types import OAK

from .common import get_pnr, get_order
from .common import sirena_id_to_real_id


def compose_ssrs(order: Dict) -> List[Dict]:
    """
    Составление ssrs
    """
    order_body: Dict = get_pnr(order)

    try:
        special_services: List[Dict] = get_order(order).get('special_services', {}).get('ssr', [])
        passengers: List[Dict] = order_body.get('passengers', {}).get('passenger', [])
        segments: List[Dict] = order_body.get('segments', {}).get('segment', [])
    except AttributeError:
        return list()

    mapped_ssrs: List[Dict] = list()

    for ssr in special_services:
        segment_id = ssr.get('@seg_id')
        pass_id = ssr.get('@pass_id')

        if segment_id:
            segment_id = sirena_id_to_real_id(segment_id, segments, start=0)
        if pass_id:
            pass_id = sirena_id_to_real_id(pass_id, passengers)

        mapped_ssrs.append({
            "count": 1,
            "text": ssr.get('@text', None),
            "status": ssr.get('@status', None),
            "segment_id": segment_id,
            "passenger_id": pass_id,
            "airline": OAK.UT.value,
            "ssr": ssr.get('@type', None)
        })

    return mapped_ssrs
