from typing import List, Dict, Tuple

from domain.types import TicketMonetaryCode

from .common import get_pnr
from .common import get_tickets
from .common import sirena_id_to_real_id
from .common import filter_duplicates_by_value
from .common import match_ticket_info
from .common import match_ticket_price
from .common import get_ticket_num


def compose_base_monetary_info(ticket_info: List[Dict]) -> List[Dict]:
    """
    Составление monetary_info с кодом B (BASE)
    """
    monetary_info: List[Dict] = list()
    for item in ticket_info:
        fare = item.get('fare', {})
        if not fare:
            continue
        monetary_info.append({
            'coupon_id': item.get('@ticket_cpn'),
            'code': TicketMonetaryCode.BASE.value,
            'amount': fare.get('value', {}).get('text'),
            'amount_rub': None,
            'currency': fare.get('value', {}).get('@currency')
        })

    return monetary_info


def compose_total_monetary_info(price: List[Dict], currency: str) -> List[Dict]:
    """
    Составление monetary_info с кодом T (TOTAL)
    """
    monetary_info: List[Dict] = list()
    for p in price:
        monetary_info.append({
            'coupon_id': p.get('@ticket_cpn'),
            'code': TicketMonetaryCode.TOTAL.value,
            'amount': p.get('total', 0),
            'amount_rub': None,
            'currency': currency
        })
    return monetary_info


def compose_taxes(ticket_info: List[Dict]) -> List[Dict]:
    taxes: List[Dict] = list()
    for item in ticket_info:
        _taxes = item.get("taxes", {}).get('tax', [])
        if isinstance(_taxes, dict):
            _taxes = [_taxes]
        if not _taxes:
            continue
        for tax in _taxes:

            _code = tax.get('code', {})
            if isinstance(_code, dict):
                code = _code.get("text", None)
            elif isinstance(_code, str):
                code = _code
            else:
                code = None

            taxes.append({
                'coupon_id': item.get('@ticket_cpn'),
                'code': code,
                'amount': tax.get('value', {}).get('text', None),
                'amount_rub': None,
                'category': None,
                'owner': tax.get('@owner', None)
            })
    return taxes


def compose_tickets(order: Dict) -> List[Dict]:
    """
    Составляем билеты
    """
    mapped_tickets = list()
    order_body = get_pnr(order)

    passengers: List[Dict] = order_body.get('passengers', {}).get('passenger', [])
    ticket_info_list: List[Dict] = order.get('order', {}).get('tickinfo', [])

    tickets_to_map: List[Dict] = get_tickets(order)

    total_prices_list: List[Dict] = order_body.get('prices', {}).get('price', []) or list()

    # Key: (ticket-num, pass_id) Value: [price]
    total_prices_mapped: Dict[Tuple, List] = dict()
    for p in total_prices_list:
        key: Tuple = (p.get('@ticket'), p.get('@passenger-id'))
        total_prices_mapped.setdefault(key, []).append(p)
    currency: str = order_body.get('prices', {}).get('variant_total', {}).get('@currency')

    unique_tickets_to_map: List[Dict] = filter_duplicates_by_value(tickets_to_map, "@ticket")
    for ticket in unique_tickets_to_map:
        sirena_ticket_num: str = ticket.get('@ticket')
        ticket_num: str = get_ticket_num(ticket)
        sirena_pass_id: str = ticket.get('@passenger-id', None)

        corresponding_ticket_info: List[Dict] = match_ticket_info(
            ticket_num,
            sirena_pass_id,
            ticket_info_list
        )
        corresponding_ticket_price: List[Dict] = match_ticket_price(
            sirena_ticket_num,
            sirena_pass_id,
            tickets_to_map
        )

        monetary_info: List[Dict] = list()
        base_monetary_info: List[Dict] = compose_base_monetary_info(corresponding_ticket_price)
        total_monetary_info: List[Dict] = compose_total_monetary_info(
            price=total_prices_mapped.get((sirena_ticket_num, sirena_pass_id), []),
            currency=currency
        )
        monetary_info.extend(base_monetary_info)
        monetary_info.extend(total_monetary_info)

        try:
            issue_datetime = corresponding_ticket_info[0].get('@print_time', None)
        except IndexError:
            issue_datetime = None

        mapped_tickets.append({
            'ticket': ticket_num,
            'passenger_id': sirena_id_to_real_id(sirena_pass_id, passengers),
            'issue_datetime': issue_datetime,
            'taxes': compose_taxes(corresponding_ticket_price),
            'monetary_info': monetary_info
        })
    return mapped_tickets
