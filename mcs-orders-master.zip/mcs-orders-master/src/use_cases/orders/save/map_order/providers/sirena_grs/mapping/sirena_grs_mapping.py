from libs.mapper.base_mapping import BaseMapping

from .helpers.common import calc_owrt
from .helpers import data
from .helpers.tickets import compose_tickets
from .helpers.contacts import compose_contacts
from .helpers.coupons import compose_coupons
from .helpers.passengers import compose_passengers
from .helpers.documents import compose_documents
from .helpers.remarks import compose_remarks
from .helpers.segments import compose_segments
from .helpers.services import compose_services
from .helpers.service_money import compose_service_money
from .helpers.fops import compose_fops
from .helpers.ssrs import compose_ssrs
from .helpers.pos_data import compose_pos_data
from .helpers.analytics_data import compose_analytics_data


class SirenaGRSMapping(BaseMapping):

    mapping = {
        'rloc': data.get_rloc,
        'order_id': None,
        'order_key': None,
        'order_uuid': None,
        'sirena_id': None,
        'rloc_host': data.get_rloc_host,
        'rloc_parent_gds': None,
        'status': None,  # Будет рассчитан в нормализации в юзкейсе сохранения
        'waiting_for_refund': None,
        'group': data.get_group,
        'owrt': calc_owrt,
        'departure_point': data.get_departure_point,
        'arrival_point': data.get_arrival_point,
        # NB: Проставляется в нормализации
        'departure_start_timestamp': None,  # data.get_departure_start_timestamp,
        'departure_end_timestamp': None,    # data.get_departure_end_timestamp,

        # Nested Fields
        'remarks': compose_remarks,
        'contacts': compose_contacts,
        'passengers': compose_passengers,
        'tickets': compose_tickets,
        'coupons': compose_coupons,
        'segments': compose_segments,
        'documents': compose_documents,
        'offers': [],  # Динамично составляем в юзкейсе сохранения
        'services': compose_services,
        'service_money': compose_service_money,
        'fops': compose_fops,
        'ssrs': compose_ssrs,
        'pos_data': compose_pos_data,
        'analytics_data': compose_analytics_data,
        'price': {}  # Отсуствует
    }
