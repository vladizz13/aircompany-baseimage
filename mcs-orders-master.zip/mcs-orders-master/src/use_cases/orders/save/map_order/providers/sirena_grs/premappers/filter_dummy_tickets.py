from typing import Any
import copy
from domain.types import TransactionSource
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class SirenaGRSFilterDummyTicketsPreMap(BaseTransactionPreMap):
    """
    Удаление билетов с нулевым номером
    """
    transaction_source = TransactionSource.SIRENA_GRS.value

    def premap(self, transaction: dict, request: Any) -> dict:
        tickets = copy.copy(transaction.get('order', {}).get('pnr', {}).get('prices', {}).get('price', [])) or []
        for ticket in tickets:
            ticket_num = ticket.get('@ticket')
            if not ticket_num:
                continue
            if ticket_num[0:3] == '000':
                transaction['order']['pnr']['prices']['price'].remove(ticket)
        return transaction
