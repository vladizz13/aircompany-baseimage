import use_cases.orders.save.map_order.providers.tais.mapping.tais_mapping_helpers as helpers
from libs.mapper.base_mapping import BaseMapping


class TaisMapping(BaseMapping):

    mapping = {
        'rloc': 'rloc',
        'order_id': 'order_id',
        'order_key': 'order_key',
        'sirena_id': None,
        'rloc_host': [],
        'rloc_parent_gds': None,
        'status': 'status',
        'waiting_for_refund': 'waiting_for_refund',
        'owrt': 'owrt',
        'departure_point': 'departure_point',
        'arrival_point': 'arrival_point',
        'departure_start_timestamp': 'transfer_start_time',
        'departure_end_timestamp': 'transfer_end_time',

        # Nested Fields
        'contacts': helpers.compose_contacts,
        'passengers': helpers.compose_passengers,
        'tickets': helpers.compose_tickets,
        'offers': helpers.compose_offers,
        'coupons': [],
        'services': helpers.compose_services,
        'service_money': [],
        'fops': [],
        'segments': helpers.compose_segments,
        'ssrs': [],
        'documents': helpers.compose_documents,
        'pos_data': helpers.compose_pos_data,
        'price': helpers.compose_price,
        'analytics_data': helpers.compose_analytics_data,
        'available_actions': {}
    }
