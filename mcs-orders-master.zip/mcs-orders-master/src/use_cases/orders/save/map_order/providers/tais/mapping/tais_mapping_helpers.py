"""
Хелперы для маппинга заказов Таиса.
Первый аргумент хэлпера - конкретный источник данных для маппинга.
Последующие позиционнаые аргументы - более общие источники данных маппинга.
В данном случае это только root источник
"""
import datetime
import pytz
import json

from domain.types import ContactType

TAIS_DATE_FORMAT = '%d.%m.%Y'
TAIS_TIME_FORMAT = '%H:%M:%S'
TAIS_DATETIME_FORMAT = '{} {}'.format(TAIS_DATE_FORMAT, TAIS_TIME_FORMAT)


def compose_price(order, *gs) -> dict:
    """
    Собираем словарь цен
    """
    mapped_discounts = []
    additional_data = order.get('additional_data', {}) or dict()
    discounts = additional_data.get('discounts', [])
    voucher = additional_data.get('voucher', {})

    for discount in discounts:
        _discount = {
            'amount': int(discount.get('amount', None)) if discount.get('amount', None) else None,
            'card_number': discount.get('card_number', None) or discount.get('card_no', None),
            'type': discount.get('type', None) or discount.get('component_type', None),
            'code': discount.get('code', None) or discount.get('promo_code', None)
        }
        if _discount["type"] == "promo" and _discount["code"]:
            _discount["code"] = _discount["code"].upper()

        mapped_discounts.append(_discount)

    price = {
        'full_price': order.get('full_price', None),
        'tickets_price': order.get('tickets_price', None),
        'currency': None,
        'discount': mapped_discounts,
        'voucher': voucher
    }
    return price


def compose_analytics_data(order, *gs) -> dict:
    """
    Собираем словарь analytics_data
    """
    first_segment_booking_time = None
    if order.get('booking_timestamp', None):

        first_segment_booking_time = int(datetime.datetime.strptime(
            order.get('booking_timestamp', None),
            TAIS_DATETIME_FORMAT
        ).timestamp())

    analytics_data = {
        'payment_id': order.get('payment_id', None),
        'partner_id': order.get('partner_id', None),
        'partner_data': order.get('partner_data', None),
        'partner_data_ex': order.get('partner_data_ex', None),
        'partner_discount': order.get('partner_discount', None),
        'partner_discount_active': order.get('partner_discount_active', None),
        'pay_method_id': order.get('pay_method_id', None),
        'pay_method_code': order.get('pay_method_code', None),
        'ticketing_timestamp': order.get('ticketing_timestamp', None),
        'first_segment_booking_time': first_segment_booking_time,
        'device_token': order.get('device_token', None),
        'platform': order.get('platform', None),
        'utm': order.get('utm', dict()),
        'created': order.get('created', None),
        'meta_search': order.get('meta_search', None)
    }
    return analytics_data


def compose_contacts(order, *gs) -> list:
    """
    Собираем контакты
    """
    mail = order.get('ctc_mail', None)
    phone = order.get('ctc_phone', None)
    other = order.get('ctc_phone_2', None)

    contacts = list()

    if mail:
        contacts.append({"contact": mail, "type": ContactType.MAIL.value})
    if phone:
        contacts.append({"contact": phone, "type": ContactType.PHONE.value})
    if other:
        contacts.append({"contact": other, "type": ContactType.OTHER.value})

    return contacts


def compose_passengers(order, *gs) -> list:
    """
    Собираем массив пассажиров
    """
    passengers = order.get('passengers', {}).get('passenger', [])
    composed_passengers = []
    passengers = sorted(passengers, key=lambda i: i.get('id'))
    for idx, p in enumerate(passengers):
        psng = {
            'passenger_id': idx + 1,
            'tais_passenger_id': p.get('id', None),
            'first_name': p.get('first_name', None),
            'last_name': p.get('last_name', None),
            'second_name': p.get('second_name', None),
            'loyalty_cardnumber': p.get('ff_cardnumber', None),
            'type': p.get('passenger_id', None),  # Нормализируем из passenger_id в нормалайзерах
            'gender': p.get('gender', None),
            'title': None
        }
        composed_passengers.append(psng)
    return composed_passengers


def compose_documents(order, *gs) -> list:
    """
    Собираем массив документов
    """
    passengers = order.get('passengers', {}).get('passenger', [])
    composed_documents = []
    passengers = sorted(passengers, key=lambda i: i.get('id'))
    for idx, p in enumerate(passengers):
        psng = {
            'passenger_id': idx + 1,
            'birthday': p.get('birthday', None),
            'doccountry': p.get('doccountry', None),
            'docexpiration': p.get('docexpiration', None),
            'docnumber': p.get('docnumber', None),
            'doctype': p.get('doctype', None)
        }
        composed_documents.append(psng)
    return composed_documents


def compose_tickets(order, *gs) -> list:
    """
    Собираем массив билетов
    """

    def get_passenger_id_by_tais_pass_id(pass_id: str):
        """
        Получаем passenger_id по таисовскому идентификатору пассажира - id
        """
        passengers = order.get('passengers', {}).get('passenger', [])
        passenger = next((p for p in passengers if pass_id == p['id']), {})
        return passenger.get('passenger_id', None)

    tickets_active = order.get('tickets_active') or {}
    tickets_active = tickets_active.get('GetListOrderTicket', [])

    tickets_returned = order.get('tickets_returned') or {}
    tickets_returned = tickets_returned.get('GetListOrderTicket', [])

    tickets = tickets_active + tickets_returned

    for t in tickets:
        t['monetary_info'] = [{
            'code': None,
            'amount': t.get('price_active', None),
            'amount_rub': None,
            'category': None
        }]
        t['taxes'] = [{
            'code': None,
            'amount': t.get('taxes', None),
            'amount_rub': None,
            'currency': None
        }]
        t['ticket'] = t.pop('docno')
        t['passenger_id'] = get_passenger_id_by_tais_pass_id(t.pop('psgid'))
    return tickets


def compose_segments(order, *gs) -> list:
    """
    Собираем массив сегментов
    """
    try:
        segments = order.get('segments', {}).get('AirSegment', [])
    except AttributeError:
        segments = list()
    for s in segments:
        s['tais_segment_id'] = s.pop('id')
        departure_utc = s.pop('departure_utc')
        arrival_utc = s.pop('arrival_utc')

        s['arrival_timestamp'] = get_unixtime(arrival_utc)
        s['departure_timestamp'] = get_unixtime(departure_utc)
        s['departure_local_iso'] = datetime.datetime.strptime(departure_utc, TAIS_DATETIME_FORMAT).isoformat()
        s['arrival_local_iso'] = datetime.datetime.strptime(arrival_utc, TAIS_DATETIME_FORMAT).isoformat()
        s['gds_active'] = True
    return segments


def compose_offers(order, *gs) -> list:
    """
    Собираем массив офферов
    """
    offers = order.get('offers') or {}
    offers = offers.get('GetOrderListFare', [])
    composed_offers = []
    for o in offers:
        off = {
            'segment_id': o.get('segment_id', None),
            'brand_code': o.get('marketing_fare_code', None),
            'brand_name': o.get('marketing_fare_code2', None),
            'fare_code': o.get('fare_code', None)
        }
        composed_offers.append(off)
    return composed_offers


def compose_services(order, *gs) -> list:
    """
    Собираем массив сервисов
    """
    services = order.get('services') or {}
    services = services.get('service', [])
    for s in services:
        service_type = s.pop('type2')
        add_method = s.pop('type')
        s['emd'] = s.pop('ext_id')
        s['tais_id'] = s.pop('id')
        s['type'] = service_type
        s['add_method'] = add_method
    return services


def compose_pos_data(order, *gs) -> dict:
    """
    Собираем словарь pos_data
    """
    additional_data = {}
    try:
        data = json.loads(order.get('additional_data', {}))
    except TypeError:
        data = order.get('additional_data', {}) or dict()

    additional_data.update({
        'pay_token': data.get('pay_token', None),
        'profile_card_number': data.get('profile_card_number', None),
        'discounts': data.get('discounts', []),
    })

    pos_data = {
        'additional_data': additional_data,
        'timelimit': order.get('timelimit', None)
    }
    return pos_data


def get_unixtime(str_time: str) -> int:
    """
    Получаем utc по iata коду аэропорта и таймстампу
    """
    utc = datetime.datetime.strptime(str_time, TAIS_DATETIME_FORMAT)
    result = pytz.timezone('UTC').localize(utc).astimezone(pytz.utc)
    return int(result.timestamp())
