import json
from typing import Any

from domain.types import TransactionSource
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class TaisAdditionalDataPreMap(BaseTransactionPreMap):
    """
    Десериализация поля additional_data из 'сырой' транзакции
    """
    transaction_source = TransactionSource.TAIS.value

    def premap(self, transaction: dict, request: Any) -> dict:
        additional_data = transaction.get('additional_data', dict()) or dict()
        if isinstance(additional_data, str):
            transaction['additional_data'] = json.loads(additional_data.lower())
        return transaction
