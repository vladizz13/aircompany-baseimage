from typing import Any, List, Dict

from domain.types import TransactionSource
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class TaisInsurancePreMap(BaseTransactionPreMap):
    """
    Разбивка страховки на сегменты, пересчёт цен
    """
    transaction_source = TransactionSource.TAIS.value

    def premap(self, transaction: dict, request: Any) -> dict:
        insurances: List[Dict] = self.get_insurances(transaction)
        if not insurances:
            return transaction

        total_segments: int = int(transaction.get('segment_count', 1))
        split_insurances: List[Dict] = list()

        for insurance in insurances:
            split_insurances.extend(self.split_insurance(insurance, total_segments))

        return self.substitute_insurance(transaction, split_insurances)

    @staticmethod
    def split_insurance(insurance: Dict, total_segments: int) -> List[Dict]:
        split: List[Dict] = list()
        price_per_segment = float(insurance.get('price', 0)) / total_segments
        for i in range(total_segments):
            s_insurance = insurance.copy()
            s_insurance['segment_id'] = str(i)
            s_insurance['price'] = round(price_per_segment, 2)
            split.append(s_insurance)
        return split

    def get_insurances(self, transaction: Dict) -> List[Dict]:
        services = self.get_services(transaction)
        insurances: List[Dict] = list()
        for service in services:
            if service.get('type2') == 'insurance':
                service["ext_id"] = None
                insurances.append(service)
        return insurances

    @staticmethod
    def get_services(transaction: Dict) -> List[Dict]:
        services = transaction.get('services') or {}
        services = services.get('service', [])
        return services

    def substitute_insurance(self, transaction: Dict, insurance: List[Dict]) -> Dict:
        """
        Подменяем пришедшие страховки на новые с разбивкой по сегментам
        """
        services = self.get_services(transaction)
        # Убираем все страховки
        services = list(filter(lambda service: service.get('type2') != 'insurance', services))
        # Добавляем страховки после разбиения
        services.extend(insurance)
        # Заменяем существующие услуги на новые
        transaction['services']['service'] = services
        return transaction
