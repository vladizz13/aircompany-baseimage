from typing import Any, List, Dict, Tuple
from itertools import islice

from domain.types import TransactionSource, ServiceStatus
from use_cases.orders.save.map_order.premap.base_premap import BaseTransactionPreMap


class TaisBaggagePreMap(BaseTransactionPreMap):
    """
    Разбивка багажных услуг на сегменты
    """
    transaction_source = TransactionSource.TAIS.value

    def premap(self, transaction: dict, request: Any) -> dict:
        baggage_services: List[Dict] = self.get_baggage(transaction)
        if not baggage_services:
            return transaction

        baggage_to: List[Dict] = list(filter(lambda x: x["segment_id"] == 'TO', baggage_services))
        baggage_back: List[Dict] = list(filter(lambda x: x["segment_id"] == 'BACK', baggage_services))

        direction_map: Dict[str, int] = self.direction_to_count_map(transaction)

        baggage_to: List[Dict] = self.set_segment_ids(baggage_to, direction_map, 'TO')
        baggage_back: List[Dict] = self.set_segment_ids(baggage_back, direction_map, 'BACK')
        baggage_services = baggage_to + baggage_back

        return self.substitute_baggage(transaction, baggage_services)

    @staticmethod
    def direction_to_count_map(transaction: Dict) -> Dict[str, int]:
        segments = transaction.get('segments', dict()).get('AirSegment', list())
        d_map: Dict[str, int] = dict(
            TO=0,
            BACK=0,
            total_segments=int(transaction.get('segment_count', 1))
        )
        for segment in segments:
            d_map[segment['direction']] = d_map[segment['direction']] + 1
        return d_map

    def set_segment_ids(
            self,
            baggage: List[Dict],
            direction_to_count_map: Dict,
            direction: str
    ) -> List[Dict]:
        def _start_counter() -> int:
            if direction == 'TO':
                return 0
            re = direction_to_count_map['total_segments'] - direction_to_count_map['TO']
            return re

        settled_baggage: List[Dict] = list()
        total_to_segments = direction_to_count_map[direction]

        baggage.sort(key=lambda x: x['passenger_id'])
        chunked = self.group_baggage(baggage, total_to_segments)

        for chunk in chunked:

            idx = _start_counter()
            for _baggage in chunk:
                _baggage['segment_id'] = idx
                settled_baggage.append(_baggage)
                idx += 1

        return baggage

    @staticmethod
    def group_baggage(baggage: List[Dict], chunk_size) -> List[Tuple[Dict]]:
        baggage = iter(baggage)
        return list(iter(lambda: tuple(islice(baggage, chunk_size)), ()))

    def get_baggage(self, transaction: Dict) -> List[Dict]:
        services = self.get_services(transaction)
        baggage: List[Dict] = list()
        for service in services:
            if service.get('type2') == 'baggage':
                baggage.append(service)
        return baggage

    @staticmethod
    def get_services(transaction: Dict) -> List[Dict]:
        services = transaction.get('services') or {}
        services = services.get('service', [])
        return services

    def substitute_baggage(self, transaction: Dict, baggage: List[Dict]) -> Dict:
        """
        Подменяем пришедшие услуги багажа на новые с разбивкой по сегментам
        """
        services = self.get_services(transaction)
        # Убираем все багажи
        services = list(filter(lambda service: service.get('type2') != 'baggage', services))
        # Проставляем багажам статус HI
        for service in baggage:
            service['status'] = ServiceStatus.HI.value
        # Добавляем багаж после разбиения
        services.extend(baggage)
        # Заменяем существующие услуги на новые
        transaction['services']['service'] = services
        return transaction
