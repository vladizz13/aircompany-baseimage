from abc import abstractmethod
from typing import Any
from domain import DomainOrder
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseOrderMerger(AbstractChainHandler):
    """
    Базовый матчер заказа
    Для добавления нового звена мерджа унаследоваться и реализовать
    локигу в методе merge
    """
    def __init__(
            self,
            existing_order: DomainOrder
    ):
        self.existing_order = existing_order

    def handle(self, order: DomainOrder, request: Any = None):
        order = self.merge(order, request)
        return super().handle(order, request)

    @abstractmethod
    def merge(self, order: DomainOrder, request: Any) -> DomainOrder:
        raise NotImplementedError()
