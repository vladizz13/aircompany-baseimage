from typing import Any, List
from domain import DomainOrder
from domain.order.data.contacts import DomainContact

from .base_merger import BaseOrderMerger


class MergeContacts(BaseOrderMerger):
    """
    Склеиваем контакты
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        existing_contacts: List[DomainContact] = self.existing_order.data.contacts
        new_contacts: List[DomainContact] = new_order.data.contacts

        merged_contacts: List[DomainContact] = list()
        union_contacts: List[DomainContact] = list()
        union_contacts.extend(existing_contacts)
        union_contacts.extend(new_contacts)
        union_contacts: List[DomainContact] = sorted(
            union_contacts,
            key=(lambda x: x.created is x.created is not None),
            reverse=False
        )

        for merge_contact in union_contacts:
            new_contact = next((x for x in new_contacts if x == merge_contact), None)

            if new_contact:
                if new_contact.sirena_type and not merge_contact.sirena_type:
                    merge_contact.sirena_type = new_contact.sirena_type
                elif merge_contact.sirena_type and not new_contact.sirena_type:
                    new_contact.sirena_type = merge_contact.sirena_type

            if merge_contact in merged_contacts:
                continue

            merged_contacts.append(merge_contact)

        new_order.data.contacts = merged_contacts
        return new_order
