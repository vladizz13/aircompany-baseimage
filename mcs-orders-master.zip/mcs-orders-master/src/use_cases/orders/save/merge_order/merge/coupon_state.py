from typing import Any, List, Set, Dict, Union
from domain import DomainOrder
from domain.order.data import DomainCoupon
from domain.types import CouponStatus
from domain.types import SegmentStatus
from domain.types import TransactionSource
from domain.order.data.coupon import DomainCouponUpdated
from adapter.sirena_adapter import SirenaInternalAdapter
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.coupon_status_normalizer import (
    CouponStatusSirenaGRSNormalizer
)

from .base_merger import BaseOrderMerger


class SetCouponState(BaseOrderMerger):
    """
    Слияние купонов по правилу: не удалять купоны, которые не пришли.
    Сравниваем по полю "number" и "ticket".
    У старых купонов изменяем segment_id на полученный из маппера.
    Удаляем дубликаты после обновления.
    :return:
    """
    def __init__(
            self,
            existing_order: DomainOrder,
            new_order_reference: DomainOrder,
            sirena_adapter: SirenaInternalAdapter,
    ):
        super().__init__(existing_order=existing_order)
        # Референс нового заказа, его неизмененное состояние
        self.new_order_reference = new_order_reference
        self.sirena_adapter = sirena_adapter

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        if request.provider == TransactionSource.SIRENA_GRS.value:
            new_order: DomainOrder = self.set_sirena_grs_removed_coupons_status(
                new_order=new_order,
                received=request.received
            )

        updated_coupons: List[DomainCoupon] = self.set_coupon_state(
            new_order=new_order,
            request=request
        )
        new_order.data.coupons = updated_coupons
        return new_order

    def set_sirena_grs_removed_coupons_status(
            self,
            new_order: DomainOrder,
            received: Union[float, int]
    ) -> DomainOrder:
        """
        Если в полученной версии заказа от Сирены_грс  исчез купон/билет:
        Получаем данные из eticket_display по данному номеру билета.
        Если исчезнувших билетов ( не купонов) - больше 1,
        запрашиваем eticket_display по каждому удалившемуся номеру билета. Для каждого сохраняем данные.
        https://jira.utair.ru/browse/UTBCKN-1882
        :param new_order: Новый заказ, который уже был обработан в цепочке и будет передан дальше
        :param received: Время получения транзакции для проставления в coupon.status_updated
        :return:
        """
        new_tickets: Set[str] = {t.ticket for t in self.new_order_reference.data.tickets if t.ticket is not None}
        existing_tickets: Set[str] = {t.ticket for t in self.existing_order.data.tickets if t.ticket is not None}
        tickets_removed: Set[str] = existing_tickets - new_tickets

        if not tickets_removed:
            return new_order
        new_order: DomainOrder = CouponStatusSirenaGRSNormalizer(
            sirena_adapter=self.sirena_adapter,
            created=received,
        ).normalize(order=new_order, request=None, unique_ticket_numbers=tickets_removed)

        return new_order

    @staticmethod
    def get_new_action_status_coupons(tickets: List[Dict], ticket_number: str):
        for ticket in tickets:
            if ticket.get('action_status', None) == 'new' and ticket.get('number', None) == ticket_number:
                return ticket
        return tickets

    def set_coupon_state(
            self,
            new_order: DomainOrder,
            request: Any
    ) -> List[DomainCoupon]:
        """
        Установка статуса купона в 'R', если соответствует правилам:

        Если в броне есть купон в статусах не R, E, F, P, X, V, T, Z, G  ,
        а в новой версии брони купона нет, то нужно проверить: если в пришедшей
        версии брони отсуствует оплата ( не заполнен словарь fops), а в сохраненной брони
        присутствует fops (словарь заполнен) , купон, который
        отсутствует в броне ссылается на сегмент, который в новой версии брони в
        статусе XX - установить купону статус R.

        :param new_order: Смердженная транзакция
        :param request: SaveOrderRequest на сохранение заказа
        :return:
        """
        processed_coupons: List[DomainCoupon] = []
        current_coupons = new_order.data.coupons
        for coup in current_coupons:
            if not (coup.status in CouponStatus.TERMINAL_LIST.value or self.is_coupon_in(
                    coup, self.new_order_reference.data.coupons
            )):
                if not self.new_order_reference.data.fops and not new_order.data.fops:
                    continue
                for segment in self.new_order_reference.data.segments:
                    if segment.segment_id != coup.segment_id:
                        continue
                    if segment.status == SegmentStatus.XX.value:
                        status_update = DomainCouponUpdated(
                            status=coup.status,
                            date=request.received
                        )
                        if status_update not in coup.updated:
                            coup.updated.append(status_update)
                        coup.status = CouponStatus.R.value
            processed_coupons.append(coup)
        return processed_coupons

    @staticmethod
    def is_coupon_in(coupon: DomainCoupon, coupons: List[DomainCoupon]) -> bool:
        """
        Содержится ли купон в списке купонов.
        Ищет соответствие по номеру билета и либо по n, либо по seg_num и pass_num

        :param coupon: Искомый купон
        :param coupons: Список купонов для поиска
        :return:
        """
        find_ticket = coupon.ticket
        find_n = coupon.number
        find_seg_num = coupon.segment_id
        find_pass_num = coupon.passenger_id
        for coup in coupons:
            cur_ticket = coup.ticket
            curr_n = coup.number if coup.number is not None else None
            cur_seg_num = coup.segment_id
            cur_pass_num = coup.passenger_id
            if find_ticket == cur_ticket and (
                        (find_n is not None and find_n == curr_n)
                    or
                        (find_seg_num == cur_seg_num and find_pass_num == cur_pass_num)
            ):
                # нашли купон
                return True
        return False
