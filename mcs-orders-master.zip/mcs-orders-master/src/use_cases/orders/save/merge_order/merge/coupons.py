from time import time
from typing import Any, List
from copy import copy
from domain import DomainOrder
from domain.order.data import DomainSegment
from domain.order.data import DomainCoupon
from domain.order.data.coupon import DomainCouponUpdated
from domain.types import TransactionSource

from .base_merger import BaseOrderMerger
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO


class MergeCoupons(BaseOrderMerger):
    """
    Слияние купонов по правилу: не удалять купоны, которые не пришли.
    Сравниваем по полю "number" и "ticket".
    У старых купонов изменяем segment_id на полученный из маппера.
    Удаляем дубликаты после обновления.
    :return:
    """
    def __init__(
            self,
            existing_order: DomainOrder,
            new_order_reference: DomainOrder,
            normalizer_dto: NormalizerDTO = None
    ):
        super().__init__(existing_order=existing_order)
        self.new_order_reference = new_order_reference
        self.normalizer_dto = normalizer_dto

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        segment_mapping: dict = self.__get_segment_mapping__(
            new_segments=new_order.data.segments,
            existing_segments=self.existing_order.data.segments
        )

        current_coupons = self.existing_order.data.coupons
        new_coupons = new_order.data.coupons

        result = copy(current_coupons)
        # маппим в новые segment_id
        self.remap_list(result, 'segment_id', segment_mapping, str)

        for coupon in new_coupons:
            find_ticket = coupon.ticket
            find_n = coupon.number
            found = False
            for idx, coup in enumerate(result):
                cur_ticket = coup.ticket
                curr_n = coup.number if coup.number is not None else None
                # в старых версиях купона может не быть поля "number", такие просто добавляем, потом фильтруем
                if find_ticket == cur_ticket and (find_n is not None and find_n == curr_n):
                    # нашли купон, обновляем
                    found = True

                    if coupon.status != coup.status:
                        upd = DomainCouponUpdated(
                            status=coup.status,
                            date=request.received
                        )
                        coupon.updated.append(upd)

                    result[idx] = coupon
            # не нашли, добавляем
            if not found:
                result.append(coupon)

        if not next((x for x in result if x.number is not None), None):
            # если купонов с "number" != None нет, дальше не идем(новые купоны приходят всегда с "number")
            new_order.data.coupons = result
            return new_order

        # удаляем купоны с "number" == None
        result = [x for x in result if x.number is not None]

        # TODO: 09.2018 избавляемся от дубликатов после ошибок в мерже, со временем это можно удалить
        set_result = set()
        for item in result[:]:
            if (item.number, item.ticket) not in set_result:
                set_result.add((item.number, item.ticket))
                continue
            result.remove(item)

        new_order.data.coupons = result
        self.__assign_sirena_grs_coupon_statuses__(new_order)
        return new_order

    def __assign_sirena_grs_coupon_statuses__(self, new_order: DomainOrder):
        """
        Проставляем статусы купонам данными из нормализации заказа для провайдера SirenaGRS
        Так как кол-во пришедших купонов в транзакции может отличатся от количества купонов, находящихся в базе
        """
        if not self.normalizer_dto:
            return
        if self.normalizer_dto.provider != TransactionSource.SIRENA_GRS.value:
            return
        if not self.normalizer_dto.sirena_grs_tickets_to_coupon_map:
            return
        for coupon in new_order.data.coupons:
            ticket_num: str = str(coupon.ticket)
            coupon_num: int = int(coupon.number)

            _coup_id = f"{ticket_num}-{coupon_num}"

            new_status = self.normalizer_dto.sirena_grs_tickets_to_coupon_map.get(_coup_id)
            if not new_status:
                continue
            if coupon.status == new_status:
                continue
            coupon.updated.append(
                DomainCouponUpdated(
                    status=coupon.status,
                    date=time()
                )
            )
            coupon.status = new_status

    @staticmethod
    def __get_segment_mapping__(
            new_segments: List[DomainSegment],
            existing_segments: List[DomainSegment]
    ) -> dict:
        """
        Получение соответствия идентификаторов сегментов "старый"->"новый". Если в новой версии сегмент удален,
        то "старый" -> None.
        :return:
        """
        mapping = {}
        for item in existing_segments:
            # находим первый элемент в новом списке, который соответствует условиям
            new_map = next((x for x in new_segments if x.get_hash() == item.get_hash()), None)
            segment_id = new_map.segment_id if new_map else None
            mapping[item.segment_id] = segment_id
        return mapping

    @staticmethod
    def remap_list(items: List[DomainCoupon], field: str, mapping: dict, mod_func: callable = None):
        """
        Функция замены поля field в списке items, согласно маппингу mapping

        :param items: Список словарей одной сущности
        :param field: Название поля для замены
        :param mapping: Словарь маппинга значений "старое" -> "новое"
        :param mod_func: Функция модификации конечного значения, если значение != None
        """

        for item in items:
            map_value = mapping.get(str(item.__getattribute__(field)))
            if mod_func and map_value is not None:
                map_value = mod_func(map_value)
            item.__setattr__(field, map_value)
