from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainSegment

from .base_merger import BaseOrderMerger


class FilterOffers(BaseOrderMerger):
    """
    Фильтруем офферы
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        """
        Удалить элементы из поля offers, которые не привязаны к сегментам
        """
        segments: List[DomainSegment] = [x.segment_id for x in new_order.data.segments]
        for item in new_order.data.offers[:]:
            if item.segment_id not in segments:
                new_order.data.offers.remove(item)
        return new_order
