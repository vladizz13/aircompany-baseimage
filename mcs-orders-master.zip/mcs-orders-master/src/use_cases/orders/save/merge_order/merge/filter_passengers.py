from typing import Any, List, Union
from domain import DomainOrder
from domain.order.data import DomainPassenger
from domain.types import PassengerCategory
from .base_merger import BaseOrderMerger


class FilterPassengers(BaseOrderMerger):
    """
    Удаление данных о купонах, билетах и оплате, которые не привязаны к пассажиру
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:

        missing_passengers: List[DomainPassenger] = self.find_missing_passengers(new_order)
        if not missing_passengers:
            return new_order

        tickets_to_remove: List[str] = self.get_passengers_tickets(missing_passengers)
        if not tickets_to_remove:
            return new_order

        new_order.data.fops = list(
            filter(lambda x: x.ticket not in tickets_to_remove, new_order.data.fops)
        )
        new_order.data.coupons = list(
            filter(lambda x: x.ticket not in tickets_to_remove, new_order.data.coupons)
        )
        new_order.data.tickets = list(
            filter(lambda x: x.ticket not in tickets_to_remove, new_order.data.tickets)
        )
        new_order.data.service_money = list(
            filter(lambda x: x.emd not in tickets_to_remove, new_order.data.service_money)
        )
        new_order.data.services = list(
            filter(lambda x: x.emd not in tickets_to_remove, new_order.data.services)
        )

        return new_order

    def find_missing_passengers(self, new_order: DomainOrder) -> Union[None, List[DomainPassenger]]:
        """
        Вычисляем ушедших пассажиров
        """
        current_passengers: List[DomainPassenger] = self.existing_order.data.passengers
        new_passengers: List[DomainPassenger] = new_order.data.passengers

        if not len(new_passengers) < len(current_passengers):
            return None

        missing_passengers: List[DomainPassenger] = [
            cp for cp in current_passengers
            if cp not in new_passengers and cp.type is not PassengerCategory.INFANT.value
        ]
        return missing_passengers

    def get_passengers_tickets(self, passengers: List[DomainPassenger]) -> List[str]:
        """
        Вычисляем номера билета по пассажирам
        """
        result: List[str] = []
        for p in passengers:
            for ticket in self.existing_order.data.tickets:
                if ticket.passenger_id == p.passenger_id:
                    result.append(ticket.ticket)
        return result
