from typing import Any, Union, List, Optional
from domain.types import TransactionSource
from domain import DomainOrder
from domain.order.data.pos_data import DomainGDS, DomainAdditionalData
from domain.order.data import DomainPassenger
from domain.order.data import DomainSegment
from domain.order.data.ticket import DomainTicket, DomainTaxes, DomainMonetaryInfo
from domain.order.data.coupon import DomainCoupon
from domain.order.meta.transaction_source import DomainTransactionSource
from domain.order.data.analytics_data import DomainUTM
from .base_merger import BaseOrderMerger


class Finalize(BaseOrderMerger):
    """
    Финальная стадия слияния - действия, которые нужно выполнить с броней после мерджа
    """
    def __init__(self, existing_order: DomainOrder, unpaid_order: bool = False):
        self.unpaid_order = unpaid_order
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        self.restore_remarks(new_order)
        self.restore_inherited_fields(new_order, request)
        self.restore_root_fields(new_order)
        self.restore_pos_data_fields(new_order)
        self.restore_analytics_data_fields(new_order, request)
        self.restore_passenger_data_fields(new_order)
        self.restore_tickets_fields(new_order)
        self.restore_segments_fields(new_order)
        self.restore_rloc_host(new_order)
        self.restore_status_updated(new_order)
        self.restore_coupons(new_order)

        self.preserve_data(new_order, request)

        new_order.data.count_nested_fields()

        if self.unpaid_order:
            return self.finalize_unpaid_order(self.existing_order, new_order)

        return new_order

    @classmethod
    def finalize_unpaid_order(cls, existing_order: DomainOrder, new_order: DomainOrder) -> DomainOrder:
        """
        Финализация неоплаченного заказа
        Оставляем в существующем заказе только требуемые поля:
        https://jira.utair.ru/browse/UTBCKN-1846
        https://jira.utair.ru/browse/UTBCKN-1967
        В итоге отправляем на сохранение existing_order (!!!!!)
        """
        instance = cls(existing_order)
        new_order: DomainOrder = instance.restore_rloc_host(new_order)
        instance.existing_order = new_order
        existing_order: DomainOrder = instance.restore_root_fields(existing_order)

        existing_order.meta.updated = new_order.meta.updated
        existing_order.data.rloc_host = new_order.data.rloc_host
        existing_order.data.pos_data = new_order.data.pos_data
        existing_order.data.analytics_data = new_order.data.analytics_data

        new_booking_timestamp: Optional[int] = new_order.data.analytics_data.first_segment_booking_time
        if all([
            # Сохраняем один раз, если в новом есть, а в старом нет
            not existing_order.data.analytics_data.first_segment_booking_time,
            new_booking_timestamp
        ]):
            existing_order.data.analytics_data.first_segment_booking_time = new_booking_timestamp

        for segment in existing_order.data.segments:
            try:
                new_segment: DomainSegment = next(
                    s for s in new_order.data.segments if s.segment_id == segment.segment_id
                )
                segment.status = new_segment.status
            except StopIteration:
                # Оставляем старый статус
                pass

        return existing_order

    def restore_remarks(self, order: DomainOrder):
        """
        Восстанавливаем remarks
        """
        if self.existing_order.data.remarks and not order.data.remarks:
            order.data.remarks = self.existing_order.data.remarks

    def restore_coupons(self, order: DomainOrder):
        """
        Восстанавливаем поля, которые пропали в новых купонах
        Проверяем изменилась ли привязка купона к сегмунту (поле flights)
        Если изменилась, добавляем это изменение
        """

        def __find_corresponding_coupon__(
                coupon: DomainCoupon,
                coupons: List[DomainCoupon]
        ) -> Union[DomainCoupon, None]:
            for _coupon in coupons:
                if all([
                    _coupon.passenger_id == coupon.passenger_id,
                    _coupon.ticket == coupon.ticket,
                    _coupon.number == coupon.number
                ]):
                    return _coupon
            return None

        existing_coupons: List[DomainCoupon] = self.existing_order.data.coupons
        new_coupons: List[DomainCoupon] = order.data.coupons

        for c in new_coupons:
            corresponding_coupon: Union[None, DomainCoupon] = __find_corresponding_coupon__(c, existing_coupons)
            if not corresponding_coupon:
                continue

            c.flights.extend(x for x in corresponding_coupon.flights if x not in c.flights)
            c.updated.extend(x for x in corresponding_coupon.updated if x not in c.updated)

            for k, v in c:
                if corresponding_coupon.__getattribute__(k) and not v:
                    c.__setattr__(
                        k, corresponding_coupon.__getattribute__(k)
                    )

    def restore_rloc_host(self, order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем поля rloc_host
        """
        order.data.rloc_host.extend(
            x for x in self.existing_order.data.rloc_host if x not in order.data.rloc_host
        )
        return order

    def restore_status_updated(self, order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем поля status_updated
        :param order:
        :return:
        """
        order.data.status_updated.extend(
            x for x in self.existing_order.data.status_updated if x not in order.data.status_updated
        )
        return order

    def restore_inherited_fields(self, order: DomainOrder, request: Any) -> DomainOrder:
        """
        Обновляем поля, которые должны быть унаследованы от существующего заказа
        """
        order.data.order_uuid = self.existing_order.data.order_uuid
        order.meta.created = self.existing_order.meta.created
        order.meta.sub_owners = self.existing_order.meta.sub_owners
        order.meta.is_hidden_for = self.existing_order.meta.is_hidden_for
        order.meta.updated = self.existing_order.meta.updated

        order.meta.updated.append(
            DomainTransactionSource(
                provider=request.provider,
                date=request.received,
                message_id=request.message_id
            )
        )
        return order

    def restore_root_fields(self, order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем корневые поля транзакции (order.data)
        """
        root_field_types = (int, float, str, bool, type(None))
        for k, v in order.data:
            if not isinstance(v, root_field_types):
                continue
            if self.existing_order.data.__getattribute__(k) and not v:
                order.data.__setattr__(
                    k, self.existing_order.data.__getattribute__(k)
                )
        return order

    def restore_pos_data_fields(self, order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем поля pos_data
        """
        # Восстанавливаем поля pos_data
        for k, v in order.data.pos_data:
            # Должен мапится всегда
            if isinstance(v, DomainGDS):
                continue
            if isinstance(v, DomainAdditionalData):
                for _k, _v in v:
                    if self.existing_order.data.pos_data.additional_data.__getattribute__(_k) and not _v:
                        order.data.pos_data.additional_data.__setattr__(
                            _k, self.existing_order.data.pos_data.additional_data.__getattribute__(_k)
                        )
            if self.existing_order.data.pos_data.__getattribute__(k) and not v:
                order.data.pos_data.__setattr__(
                    k, self.existing_order.data.pos_data.__getattribute__(k)
                )
        return order

    def restore_analytics_data_fields(self, order: DomainOrder, request: Any):
        """
        Восстанавливаем поля analytics_data
        """
        for k, v in order.data.analytics_data:
            # Перезаписываем/обновляем first_segment_booking_time если там уже что-то есть
            # только если источник изменения Сирена ГРС
            if all([
                k == 'first_segment_booking_time',
                self.existing_order.data.analytics_data.__getattribute__(k),
                request.provider == TransactionSource.SIRENA_GRS.value
            ]):
                order.data.analytics_data.__setattr__(k, v)
                continue

            if isinstance(v, DomainUTM):
                current_utm = self.existing_order.data.analytics_data.utm
                new_utm = order.data.analytics_data.utm
                for _k, _current_utm_v in current_utm:
                    if new_utm.__getattribute__(_k):
                        # всегда оставляем новый utm, если есть
                        continue
                    if new_utm.__getattribute__(_k) is None and _current_utm_v:
                        # если нового utm нет, а старый есть - оставляем старый
                        new_utm.__setattr__(_k, _current_utm_v)
                continue

            if self.existing_order.data.analytics_data.__getattribute__(k) and not v:
                order.data.analytics_data.__setattr__(
                    k, self.existing_order.data.analytics_data.__getattribute__(k)
                )

            if all([
                k in ["partner_id", "partner_data"],
                self.existing_order.data.analytics_data.__getattribute__(k),
                request.provider == TransactionSource.TAIS.value,
            ]):
                if self.existing_order.data.analytics_data.__getattribute__(k) not in ("-", None):
                    order.data.analytics_data.__setattr__(
                        k, self.existing_order.data.analytics_data.__getattribute__(k)
                    )

    def restore_passenger_data_fields(self, order: DomainOrder):
        """
        Восстанавливаем поля passengers
        """
        def find_corresponding_passenger_in_save_order(_passenger: DomainPassenger) -> Union[None, DomainPassenger]:
            for _p in self.existing_order.data.passengers:
                if _passenger == _p:
                    return _p
            return None

        for passenger in order.data.passengers:
            existing_passenger: DomainPassenger = find_corresponding_passenger_in_save_order(passenger)
            if not existing_passenger:
                continue
            for k, v in passenger:
                if existing_passenger.__getattribute__(k) and not v:
                    passenger.__setattr__(
                        k, existing_passenger.__getattribute__(k)
                    )

    def restore_tickets_fields(self, order: DomainOrder):
        """
        Восстанавливаем поля в tickets
        """
        def find_corresponding_ticket_in_existing_order(_ticket: DomainTicket) -> Union[None, DomainTicket]:
            for _t in self.existing_order.data.tickets:
                if _t.ticket == _ticket.ticket and _t.passenger_id == _ticket.passenger_id:
                    return _t
            return None

        for ticket in order.data.tickets:
            existing_ticket: DomainTicket = find_corresponding_ticket_in_existing_order(ticket)
            if not existing_ticket:
                continue
            for k, v in ticket:
                if not isinstance(v, (DomainTaxes, DomainMonetaryInfo)):
                    if existing_ticket.__getattribute__(k) and not v:
                        ticket.__setattr__(
                            k, existing_ticket.__getattribute__(k)
                        )

    def restore_segments_fields(self, order: DomainOrder):
        """
        Восстанавливаем поля в сегментах
        """
        def find_corresponding_segment_in_existing_order(_hash: str) -> Union[None, DomainSegment]:
            for _s in self.existing_order.data.segments:
                if _s.get_hash() == _hash:
                    return _s
            return None

        for segment in order.data.segments:
            existing_segment: DomainSegment = find_corresponding_segment_in_existing_order(segment.get_hash())
            if not existing_segment:
                continue
            for k, v in segment:
                if existing_segment.__getattribute__(k) and not v:
                    segment.__setattr__(
                        k, existing_segment.__getattribute__(k)
                    )

    def preserve_data(self, order: DomainOrder, request: Any):
        """
        Сохранение данных, которые не нужно перетирать
        """
        if request.provider == TransactionSource.SIRENA_GRS.value:
            return
        existing_booking_time: Optional[int] = self.existing_order.data.analytics_data.first_segment_booking_time
        if self.existing_order.data.analytics_data.first_segment_booking_time:
            order.data.analytics_data.first_segment_booking_time = existing_booking_time
