from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainFop

from .base_merger import BaseOrderMerger


class MergeFops(BaseOrderMerger):
    """
    Слиянии двух списков Fops
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:

        self.__prepare_fops(new_order)
        self.__prepare_fops(self.existing_order)

        self.__filter_duplicate_fops(new_order)
        self.__filter_duplicate_fops(self.existing_order)

        if not self.existing_order.data.fops and new_order.data.fops:
            self.__sort_fops_in_order__(new_order)
            return new_order

        elif not new_order.data.fops and self.existing_order.data.fops:
            new_order.data.fops = self.existing_order.data.fops

        elif new_order.data.fops and self.existing_order.data.fops:
            for existing_fop in self.existing_order.data.fops:
                if existing_fop not in new_order.data.fops:
                    new_order.data.fops.append(existing_fop)
                else:
                    # Если существует в заказе, то сравниваем все данные, которые могли добавится/исчезнуть
                    new_fop: DomainFop = new_order.data.fops[new_order.data.fops.index(existing_fop)]
                    new_order.data.fops[new_order.data.fops.index(existing_fop)] = self.__restore_fops_data__(
                        new_fop=new_fop, existing_fop=existing_fop
                    )

        self.__sort_fops_in_order__(new_order)
        return new_order

    @staticmethod
    def __restore_fops_data__(new_fop: DomainFop, existing_fop: DomainFop) -> DomainFop:
        for k, v in new_fop:
            if getattr(existing_fop, k) and not v:
                setattr(new_fop, k, getattr(existing_fop, k))
        return new_fop

    @staticmethod
    def __sort_fops_in_order__(order: DomainOrder) -> DomainOrder:
        order.data.fops = sorted(
            order.data.fops, key=lambda x: (x.fops_id is not None, x.fops_id)
        )
        return order

    @staticmethod
    def __prepare_fops(order: DomainOrder) -> DomainOrder:
        for fop in order.data.fops:
            if fop.free_text and '/' in fop.free_text:
                fop_text = fop.free_text.split('/')
                if len(fop_text) == 2:
                    code, account_num = fop_text
                else:
                    code = fop_text[0]
                    account_num = '/'.join(fop_text[1::])
                fop.code = code
                fop.account_num = account_num
        return order

    @staticmethod
    def __filter_duplicate_fops(order: DomainOrder) -> DomainOrder:
        unique_fops: List[DomainFop] = list()
        for fop in order.data.fops:
            if fop in unique_fops:
                continue
            unique_fops.append(fop)
        order.data.fops: List[DomainFop] = unique_fops
        return order
