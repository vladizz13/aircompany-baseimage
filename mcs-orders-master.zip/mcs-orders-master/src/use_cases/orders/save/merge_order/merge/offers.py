from typing import Any
from domain import DomainOrder

from .base_merger import BaseOrderMerger


class MergeOffers(BaseOrderMerger):
    """
    Склеиваем офферы
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        return new_order
