from dataclasses import dataclass
from typing import Any, List, Optional, Dict
from domain import DomainOrder
from domain.order.data import DomainPassenger
from domain.order.data import DomainDocument
from copy import deepcopy
from .base_merger import BaseOrderMerger
from domain.types import SsrsSsr, OAK, UTairChangePDReqStatuses
from repositories.mongo.mongo_generic_repository import GenericMongoRepository
from domain.pd_changes import DomainPDChanges
from repositories.query_builders.pd_changes import PDChangesQueryBuilder


@dataclass
class Passenger:
    """
    Представление пассажира
    """
    human: DomainPassenger
    document: DomainDocument

    def __eq__(self, other: "Passenger") -> bool:
        """
            Сравниваем по приориту:
            1. День рождения + Документ
            2. День рождения + Имя + Фамилия
            3. Документ + Фамилия
            4. Имя + Фамилия + Отчество
        Если по одному из правил пассажиры сходятся - считаем их за одного человека
        """
        is_equal_conditions = False
        if all((
            # День рождения + Документ
            self.is_doc_exists, other.is_doc_exists,
            self.is_birthday_exists, other.is_birthday_exists
        )):
            is_equal_conditions = all((
                self.document.docnumber == other.document.docnumber,
                self.document.birthday == other.document.birthday
            ))
        if all((
            # День рождения + Имя + Фамилия
            not is_equal_conditions,
            self.is_birthday_exists, other.is_birthday_exists,
            self.is_first_name_exists, other.is_first_name_exists,
            self.is_last_name_exists, other.is_last_name_exists
        )):
            is_equal_conditions = all((
                self.document.birthday == other.document.birthday,
                self.human.first_name.upper() == other.human.first_name.upper(),
                self.human.last_name.upper() == other.human.last_name.upper(),
            ))
        if all((
            # Документ + Фамилия
            not is_equal_conditions,
            self.is_doc_exists, other.is_doc_exists,
            self.is_last_name_exists, other.is_last_name_exists
        )):
            is_equal_conditions = all((
                self.document.docnumber == other.document.docnumber,
                self.human.last_name.upper() == other.human.last_name.upper(),
            ))
        if all((
            # Имя + Фамилия + Отчество
            not is_equal_conditions,
            self.is_first_name_exists, other.is_first_name_exists,
            self.is_second_name_exists, other.is_second_name_exists,
            self.is_last_name_exists, other.is_last_name_exists
        )):
            is_equal_conditions = all((
                self.human.first_name.upper() == other.human.first_name.upper(),
                self.human.second_name.upper() == other.human.second_name.upper(),
                self.human.last_name.upper() == other.human.last_name.upper(),
            ))
        return is_equal_conditions

    def merge(self, passenger: "Passenger") -> "Passenger":
        # # проходим по объединению ключей
        for key, _ in {*self.human.__iter__(), *passenger.human.__iter__()}:
            # в любом случае оставляем только не пустые данные или старое
            new_value = self.human.__getattribute__(key) if self.human.__getattribute__(key) is not None \
                else passenger.human.__getattribute__(key)
            self.human.__setattr__(
                key, new_value
            )

        for key, _ in {*self.document.__iter__(), *passenger.document.__iter__()}:
            # в любом случае оставляем только не пустые данные или старое
            new_value = self.document.__getattribute__(key) if self.document.__getattribute__(key) is not None \
                else passenger.document.__getattribute__(key)
            self.document.__setattr__(
                key, new_value
            )

        return self

    @property
    def is_doc_exists(self) -> bool:
        return self.document.docnumber is not None

    @property
    def is_birthday_exists(self) -> bool:
        return self.document.birthday is not None

    @property
    def is_first_name_exists(self):
        return self.human.first_name is not None

    @property
    def is_second_name_exists(self):
        return self.human.second_name is not None

    @property
    def is_last_name_exists(self):
        return self.human.last_name is not None


class MergePassengers(BaseOrderMerger):
    """
    Слияние пассажиров. Необходимо оставлять поля, которые пытаются обновиться на None
    """
    def __init__(self, existing_order: DomainOrder, pd_changes_repo: GenericMongoRepository):
        super().__init__(existing_order=existing_order)
        self.pd_changes_repo = pd_changes_repo

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        existing_passengers: List[Passenger] = self.create_passengers(self.existing_order)
        new_passengers: List[Passenger] = self.create_passengers(new_order)

        change_pd_pax: List[DomainPDChanges] = self.get_change_pd_by_order_uuid(self.existing_order.data.order_uuid)
        changed_pd_passengers: List[Passenger] = self.get_paid_clean_second_name_change_pd_passengers(change_pd_pax)

        merged_passengers: List[Passenger] = deepcopy(new_passengers)

        for index, new_passenger in enumerate(new_passengers):
            for existing_passenger in existing_passengers:

                if new_passenger != existing_passenger:
                    # Если новый пассажир не соотв. никакому из старых - удаляем его
                    continue

                if existing_passenger in changed_pd_passengers:
                    existing_passenger.human.second_name = None
                # Сравниваем все поля
                #   - если какой-то изменился - приоритет новому
                #   - если в новом поля нет, а в старом есть - восстанавливаем
                new_passenger = new_passenger.merge(existing_passenger)
                merged_passengers[index] = new_passenger

        passengers: List[DomainPassenger] = [p.human for p in merged_passengers]
        documents: List[DomainDocument] = [p.document for p in merged_passengers]

        passengers.sort(key=lambda x: x.passenger_id)
        documents.sort(key=lambda x: x.passenger_id)

        new_order.data.passengers = passengers
        new_order.data.documents = documents

        return new_order

    @classmethod
    def create_passengers(cls, order: DomainOrder) -> List[Passenger]:
        documents = {d.passenger_id: d for d in order.data.documents}
        passengers: List[Passenger] = list()
        loyalty_cards = {s.passenger_id: s.text for s in order.data.ssrs if s.ssr == SsrsSsr.FQTV.value}
        _sorted_passengers: List[DomainPassenger] = sorted(deepcopy(order.data.passengers), key=lambda x: (
            x.first_name, x.last_name, x.second_name is None, x.second_name
        ))

        for passenger in _sorted_passengers:
            if card_number := loyalty_cards.get(passenger.passenger_id, None):
                passenger.loyalty_cardnumber = cls.get_loyalty_cardnumber(card_number)
            passengers.append(Passenger(
                human=passenger,
                document=documents.get(passenger.passenger_id)
            ))
        return passengers

    @staticmethod
    def get_loyalty_cardnumber(card_number: str) -> Optional[str]:
        card = card_number.split('.')[0]
        if not card.startswith(OAK.UT.value):
            return None
        return card.split(OAK.UT.value)[1]

    def get_change_pd_by_order_uuid(self, order_uuid: str) -> List[DomainPDChanges]:
        """
        Поиск изменение ПД по order_uuid
        """
        pd_changes: List[DomainPDChanges] = self.pd_changes_repo.list(
            spec=PDChangesQueryBuilder.get_by_order_uuid(order_uuid)
        )
        return pd_changes

    def get_paid_clean_second_name_change_pd_passengers(
        self,
        passengers: List[DomainPDChanges]
    ) -> List[Passenger]:
        """
        Проверяет оплаченный статус смены ПД пассажиров,
        у которых есть флаг удаления отчества passenger.new_pd.clean_second_name
        Возвращает массив Passenger
        """
        paid_passengers: List[DomainPDChanges] = list()
        for passenger in passengers:
            if all((
                passenger.status == UTairChangePDReqStatuses.DONE.value,
                passenger.new_pd.clean_second_name
            )):
                paid_passengers.append(passenger)
        if not paid_passengers:
            return list()

        return self.create_change_pd_passengers(paid_passengers)

    @staticmethod
    def create_change_pd_passengers(passengers: List[DomainPDChanges]) -> List[Passenger]:
        """
        Составляет модель Passenger по модели DomainPDChanges
        """
        domain_documents: Dict[str, DomainDocument] = dict()
        for document in passengers:
            domain_documents.update({document.passenger_id: DomainDocument(
                passenger_id=document.passenger_id,
                birthday=document.previous_pd.birthday,
                doccountry=document.previous_pd.document.doccountry,
                docexpiration=document.previous_pd.document.docexpiration,
                docnumber=document.previous_pd.document.docnumber,
                doctype=document.previous_pd.document.doctype
            )})

        _passengers: List[Passenger] = list()
        for passenger in passengers:
            _passengers.append(
                Passenger(
                    human=DomainPassenger(
                        passenger_id=passenger.passenger_id,
                        first_name=passenger.previous_pd.first_name,
                        last_name=passenger.previous_pd.last_name,
                        second_name=passenger.previous_pd.second_name,
                        gender=passenger.previous_pd.gender,
                        type=passenger.previous_pd.type,
                    ),
                    document=domain_documents.get(passenger.passenger_id)
                )
            )

        return _passengers
