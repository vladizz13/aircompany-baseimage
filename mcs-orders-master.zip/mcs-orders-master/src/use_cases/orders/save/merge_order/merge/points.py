from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainSegment
from domain.types import SegmentStatus

from .base_merger import BaseOrderMerger


class MergePoints(BaseOrderMerger):
    """
    Склеиваем departure_point и arrival_point
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        current_dep_point = self.existing_order.data.departure_point
        current_arr_point = self.existing_order.data.arrival_point
        new_dep_point = new_order.data.departure_point
        new_arr_point = new_order.data.arrival_point
        current_segments: List[DomainSegment] = self.existing_order.data.segments
        new_segments: List[DomainSegment] = new_order.data.segments

        new_order.data.departure_point = self.merge_point(
            current_dep_point, new_dep_point, current_segments, new_segments
        )
        new_order.data.arrival_point = self.merge_point(
            current_arr_point, new_arr_point, current_segments, new_segments
        )

        return new_order

    def merge_point(
            self,
            curr_point: str,
            new_point: str,
            curr_segments: List[DomainSegment],
            new_segments: List[DomainSegment]
    ) -> str:
        """
        Слияние города отправления-прибытия
        https://jira.utair.ru/browse/UTBCKN-852
        :return:
        """
        result = any([
            self.is_returned_segments(new_segments),
            self.is_rescheduled_flight(curr_segments, new_segments)
        ])
        return curr_point if result else new_point

    @staticmethod
    def is_returned_segments(segments: List[DomainSegment]) -> bool:
        """ Возвращает True, если есть сегменты в статусе XX или UN"""
        return bool(next((x for x in segments if x.status in [
            SegmentStatus.XX.value, SegmentStatus.UN.value
        ]), False))

    @staticmethod
    def is_rescheduled_flight(
            curr_segments: List[DomainSegment],
            new_segments: List[DomainSegment]
    ) -> bool:
        """ Вычисляет были ли переносы рейсов по дате вылета """
        try:
            sorted_current = sorted(curr_segments, key=lambda k: k.departure_timestamp)
            sorted_new = sorted(new_segments, key=lambda k: k.departure_timestamp)
        except TypeError:
            return False

        if len(sorted_current) != len(sorted_new):
            return True

        for i, current in enumerate(sorted_current):
            if current.departure_timestamp != sorted_new[i].departure_timestamp:
                return True

        return False
