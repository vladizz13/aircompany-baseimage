from typing import Any, List
from domain import DomainOrder
from domain.types import TransactionSource, CompanyPPR
from .base_merger import BaseOrderMerger


class MergePosData(BaseOrderMerger):
    """
    Слияние pos_data
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        new_order: DomainOrder = self.update_term_id(new_order)
        new_order: DomainOrder = self.update_pos_id(new_order)
        new_order: DomainOrder = self.restore_time_limit(new_order)
        return new_order

    def update_pos_id(self, new_order: DomainOrder) -> DomainOrder:
        if all((
            # https://jira.utair.ru/browse/UTBCKN-2999
            # Если не было сохранено транзакций от sirena_grs
            not any((u.provider == TransactionSource.SIRENA_GRS.value for u in new_order.meta.all_order_updates)),
            # в данный момент у брони pos_id контакт центра
            self.existing_order.data.pos_data.pos_id == CompanyPPR.CONTACT_CENTER.value,
            # у новой транзакции есть pos_id
            new_order.data.pos_data.pos_id,
        )):
            # Сохраняем новый pos_id
            return new_order

        # Если в существующей броне уже есть pos_data, оставляем то что есть
        if self.existing_order.data.pos_data.pos_id:
            new_order.data.pos_data.pos_id = self.existing_order.data.pos_data.pos_id

        # Если поле не имеет значения (null) - обновляем поле вне зависимости от источника данных.
        return new_order

    def restore_time_limit(self, new_order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем time_limit
        """
        if not new_order.data.pos_data.timelimit and self.existing_order.data.pos_data.timelimit:
            new_order.data.pos_data.timelimit = self.existing_order.data.pos_data.timelimit
        return new_order

    def update_term_id(self, new_order: DomainOrder):
        """
        Если полученного term_id в словаре нет - записываем его, если уже есть - пропускаем.
        """
        existing_term_id_values: List[str] = []
        for ti in self.existing_order.data.pos_data.term_id:
            existing_term_id_values.append(ti.value)

        if new_order.data.pos_data.term_id:
            if new_order.data.pos_data.term_id[0].value not in existing_term_id_values:
                new_order.data.pos_data.term_id.extend(self.existing_order.data.pos_data.term_id)
        return new_order
