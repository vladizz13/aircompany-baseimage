from typing import Any
from domain import DomainOrder
from domain.order.data.price import DomainVoucher

from .base_merger import BaseOrderMerger


class MergePrice(BaseOrderMerger):
    """
    Слияние цен
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        new_order: DomainOrder = self.merge_discounts(new_order)
        new_order: DomainOrder = self.merge_voucher(new_order)
        return new_order

    def merge_voucher(self, new_order: DomainOrder):
        existing_voucher: DomainVoucher = self.existing_order.data.price.voucher
        new_voucher: DomainVoucher = new_order.data.price.voucher

        if all([
            existing_voucher.amount, existing_voucher.id
        ]) and all([
            not new_voucher.amount, not new_voucher.id
        ]):
            new_order.data.price.voucher.amount = existing_voucher.amount
            new_order.data.price.voucher.id = existing_voucher.id

        return new_order

    def merge_discounts(self, new_order: DomainOrder):
        if not self.existing_order.data.price.discount and new_order.data.price.discount:
            return new_order

        if self.existing_order.data.price.discount and not new_order.data.price.discount:
            new_order.data.price.discount = self.existing_order.data.price.discount
            return new_order

        if self.existing_order.data.price.discount and new_order.data.price.discount:
            for discount in self.existing_order.data.price.discount:
                if discount not in new_order.data.price.discount:
                    new_order.data.price.discount.append(discount)
        return new_order
