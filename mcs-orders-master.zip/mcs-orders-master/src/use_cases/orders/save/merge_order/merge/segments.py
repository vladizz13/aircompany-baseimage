from typing import Any, List, Dict, Optional
from domain import DomainOrder
from domain.order.data import DomainSegment
from domain.order.data import DomainCoupon
from domain.types import TransactionSource
from .base_merger import BaseOrderMerger


class MergeSegments(BaseOrderMerger):
    """
    Склеиваем сегменты
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        new_segments: List[DomainSegment] = new_order.data.segments
        existing_segments: List[DomainSegment] = self.existing_order.data.segments

        # Карта соответсвия всех изменений айдишников сегментов
        # Было -> Стало
        segment_id_changes_map: Dict[str, str] = dict()

        # Карта купонов сегмент_ид к купону
        # Для изменения сегментов новых купонов, если сегменты существуют в базе
        new_coupons_hash_map: Dict[str, DomainCoupon] = {
            self.get_coupon_hash_by_coupon(c): c for c in new_order.data.coupons
        }

        # Карты соответсвия хэша к его сегменту
        new_segments_hash_map: Dict[str, DomainSegment] = {s.get_hash(): s for s in new_segments}
        existing_segments_hash_map: Dict[str, DomainSegment] = {s.get_hash(): s for s in existing_segments}

        merged_segments: List[DomainSegment] = list()

        # Смотрим пришли ли обновления сегментов
        for k, existing_segment in existing_segments_hash_map.items():
            # Сегмент не изменился
            if k not in new_segments_hash_map:
                if request.provider == TransactionSource.SIRENA_GRS.value:
                    existing_segment.gds_active = False
                merged_segments.append(existing_segment)
                continue
            # Сегмент изменился
            new_segment: DomainSegment = new_segments_hash_map[k]

            # Если есть купон, привязанный к такому сегменту в новом заказе - проставляем ему старый segment_id
            new_coupons: List[DomainCoupon] = [
                v for k, v in new_coupons_hash_map.items() if k.startswith(f"{new_segment.segment_id}-")
            ]
            for new_coupon in new_coupons:
                new_coupons_hash_map[
                    self.get_coupon_hash_by_coupon(new_coupon)
                ].segment_id = existing_segment.segment_id

            # Было -> стало
            segment_id_changes_map.update({new_segment.segment_id: str(existing_segment.segment_id)})

            new_segment.segment_id = existing_segment.segment_id
            if not existing_segment.gds_active and request.provider != TransactionSource.SIRENA_GRS.value:
                new_segment.gds_active = False
            merged_segments.append(new_segment)
            # удаляем этот сегмент из карты
            del new_segments_hash_map[k]

        # Последний айдишник смердженных сегментов
        try:
            last_segment_id: Optional[int] = int(merged_segments[-1].segment_id)
        except IndexError:
            last_segment_id = None
        # Если в карте новых сегментов остались значения - пришел новый сегмент
        # Записываем такие сегменты в конец, присваивая им следующий segment_id
        if new_segments_hash_map and last_segment_id is not None:
            new_segment_id: int = last_segment_id + 1
            for _, new_segment in new_segments_hash_map.items():

                new_coupons: List[DomainCoupon] = [
                    v for k, v in new_coupons_hash_map.items() if k.startswith(f"{new_segment.segment_id}-")
                ]
                for new_coupon in new_coupons:
                    new_coupons_hash_map[
                        self.get_coupon_hash_by_coupon(new_coupon)
                    ].segment_id = str(new_segment_id)

                # Было -> Стало
                segment_id_changes_map.update({new_segment.segment_id: str(new_segment_id)})
                new_segment.segment_id = str(new_segment_id)
                merged_segments.append(new_segment)
                new_segment_id += 1

        # Сохраняем смердженные сегменты
        new_order.data.segments: List[DomainSegment] = merged_segments
        # Сохраняем купоны, так как у них могли поменятся segment_id
        new_order.data.coupons: List[DomainCoupon] = [c for c in new_coupons_hash_map.values()]

        new_order: DomainOrder = self.assign_new_segment_ids(new_order, segment_id_changes_map)

        return new_order

    @staticmethod
    def get_coupon_hash_by_coupon(coupon: DomainCoupon) -> str:
        return f"{coupon.segment_id}-{coupon.ticket}-{coupon.number}"

    @staticmethod
    def assign_new_segment_ids(
            new_order: DomainOrder,
            segment_id_change_map: Dict[str, str]
    ) -> DomainOrder:
        for ssr in new_order.data.ssrs:
            if ssr.segment_id in segment_id_change_map:
                ssr.segment_id = segment_id_change_map[ssr.segment_id]
        for service in new_order.data.services:
            if service.segment_id in segment_id_change_map:
                service.segment_id = segment_id_change_map[service.segment_id]
        return new_order
