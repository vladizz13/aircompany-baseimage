from copy import deepcopy
from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainServiceMoney

from .base_merger import BaseOrderMerger


class MergeServiceMoney(BaseOrderMerger):
    """
    Слияние стоимости услуг.
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:

        existing_service_money_list: List[DomainServiceMoney] = deepcopy(self.existing_order.data.service_money)
        new_service_money_list: List[DomainServiceMoney] = deepcopy(new_order.data.service_money)

        if not existing_service_money_list:
            return new_order

        if not new_service_money_list:
            new_order.data.service_money = existing_service_money_list
            return new_order

        existing_service_money_list_emd = {m.emd: m for m in existing_service_money_list}
        new_service_money_list_emd = {m.emd: m for m in new_service_money_list}

        extend_service_money_list: List[DomainServiceMoney] = []
        for m in existing_service_money_list_emd:
            if not new_service_money_list_emd.get(m):
                extend_service_money_list.append(existing_service_money_list_emd.get(m))

        new_service_money_list.extend(extend_service_money_list)

        new_order.data.service_money = new_service_money_list

        return new_order
