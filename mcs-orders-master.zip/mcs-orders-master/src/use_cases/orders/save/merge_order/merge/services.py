import logging
from copy import deepcopy
from typing import Any, List, Dict, Literal, Type
from domain import DomainOrder
from domain.types import TransactionSource, ServiceStatus
from domain.order.data import DomainService
from .base_merger import BaseOrderMerger
from use_cases.orders.save.merge_order.merge.services_helper.service_strategies import (
    HdServiceStrategy,
    HiServiceStrategy,
    HkServiceStrategy,
    HnServiceStrategy,
    XxServiceStrategy,
    BaseStrategy
)
from use_cases.orders.exceptions.save import UnableToMergeOrderError

logger = logging.getLogger("SaveOrderUseCase")


class MergeServices(BaseOrderMerger):
    """
    Слияние услуг.
    Создаем копию новых услуг и текущих (new_services_list/existing_services_list).
    Итерируем новые услуги, выполняем БП, если услуга была найдена, то удаляем ее
    из new_services_list/existing_services_list.

    После итераций:
    если в existing_services_list что-то осталось, тогда это услуги, которые нам не прислали, проверяем на страховки;
    если в new_services_list что-то осталось, то эти услуги нужно добавить к нам (они новые).
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:

        existing_services_list: List[DomainService] = deepcopy(self.existing_order.data.services)
        new_services: List[DomainService] = deepcopy(new_order.data.services)
        new_services_list: List[DomainService] = self.sort_new_services(new_services)

        merged_services: List[DomainService] = []
        for new_service in new_services_list:
            try:
                strategy = self.merge_strategy(new_service)
            except UnableToMergeOrderError:
                msg: str = f"""Не удалось сделать merge услуг заказа
                         {self.existing_order.data.rloc} {self.existing_order.data.order_uuid} \n
                         Не удалось выбрать стратегию для услуги {new_service}
                         Текущие услуги {existing_services_list} \n
                         Новые услуги {new_services_list}"""
                logger.exception(msg)
                raise UnableToMergeOrderError(message=msg)

            try:
                found_existing_service, new_merged_service = strategy.merge(
                    new_service=new_service, existing_services=existing_services_list
                )
            except UnableToMergeOrderError as e:
                raise UnableToMergeOrderError(message=e.message)

            if not new_merged_service and strategy in [XxServiceStrategy, HnServiceStrategy]:
                # Если такие услуги не были найдены, тогда их не нужно сохранять к нам, как новые
                del new_services[new_services.index(new_service)]
                continue

            if not new_merged_service:
                # Если данная услуга не была найдена у нас, то переходим к следующей. Позже мы добавим ее как новую
                continue

            merged_services.append(new_merged_service)

            # Удаляем найденную услугу из новых и из существующих.
            del existing_services_list[existing_services_list.index(found_existing_service)]
            del new_services[new_services.index(new_service)]

        # Если у нас остались какие-то услуги после удалений, значит нам их не отправил поставщик.
        # Отменяем такие услуги.
        for existing_service in existing_services_list:
            merged_services.append(
                self.set_status_xx_except_insurance(service=existing_service, provider=request.provider)
            )

        # Если остались какие-то новые услуги после удалений, значит у нас их не было. Добавляем как новые.
        merged_services.extend(new_services)

        new_order.data.services = merged_services

        return new_order

    @staticmethod
    def set_status_xx_except_insurance(
        service: DomainService,
        provider: str
    ) -> DomainService:
        """
            Переводим статус в ХХ (кроме страховки от сирены)
        """
        if provider == TransactionSource.SIRENA.value:
            if service.type != "insurance":
                service.status = ServiceStatus.XX.value

        elif provider == TransactionSource.SIRENA_GRS.value:
            service.status = ServiceStatus.XX.value

        return service

    @staticmethod
    def sort_new_services(new_services_list: List[DomainService]) -> List[DomainService]:
        """
        начинать с HK, HI, HD, XX, остальные в конец списка
        """
        __service_status = {
            ServiceStatus.HK.value: 1,
            ServiceStatus.HI.value: 2,
            ServiceStatus.HD.value: 3,
            ServiceStatus.XX.value: 4,
        }

        def service_index(service: DomainService):
            try:
                return __service_status[service.status]
            except KeyError:
                return 100

        sorted_services: List[DomainService] = sorted([s for s in new_services_list], key=service_index)
        return sorted_services

    @classmethod
    def merge_strategy(cls, service: DomainService) -> BaseStrategy:
        _map: Dict[Literal, Type[BaseStrategy]] = {
            ServiceStatus.HD.value: HdServiceStrategy,
            ServiceStatus.HI.value: HiServiceStrategy,
            ServiceStatus.HN.value: HnServiceStrategy,
            ServiceStatus.HK.value: HkServiceStrategy,
            ServiceStatus.XX.value: XxServiceStrategy,
        }
        has_emd = bool(service.emd)
        try:
            status = service.status
            return _map[status](has_emd=has_emd)
        except KeyError:
            # Базовое поведение слияния услуг
            return HiServiceStrategy(has_emd=has_emd)
        except UnableToMergeOrderError as e:
            raise e
