from abc import ABC, abstractmethod
from enum import Enum
from typing import List, Optional, Tuple, Union
from domain.order.data import DomainService
from domain.types import ServiceStatus
from use_cases.orders.exceptions.save import UnableToMergeOrderError


class FindServiceType(Enum):
    """
    Тип поиска услуг
    """
    match_service_without_emd = 'Поиск услуг где service.emd: None'
    match_service_with_emd = 'Поиск услуг где есть service.emd'
    match_service = 'Поиск услуг только по дефолтным критериям'


class BaseStrategy(ABC):
    def __init__(self, has_emd):
        self.has_emd = has_emd

    def __eq__(self, other):
        return isinstance(self, other)

    @abstractmethod
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Union[Tuple[None, None], Tuple[DomainService, DomainService]]:
        """
        Ищем услугу в существующих.
        Объединяем значения новой услуги с существующей.
        Возвращаем найденную услугу и слитую.
        :new_service: новая услуга от поставщика.
        :existing_services: список услуг заказа в БД
        :return: найденная услуга у нас в БД, смердженная услуга
        """
        raise NotImplementedError()

    @staticmethod
    def combine_data(existing_service: DomainService, new_service: DomainService) -> DomainService:
        for key, value in existing_service:
            if not value:
                existing_service.__dict__[key] = new_service.__getattribute__(key)
            elif not new_service.__getattribute__(key):
                pass
            else:
                existing_service.__dict__[key] = new_service.__getattribute__(key)

        return existing_service

    @staticmethod
    def find_service(
        new_service: DomainService,
        existing_services: List[DomainService],
        searching_type: FindServiceType
    ) -> Optional[DomainService]:
        """
        Осуществляет поиск новой услуги в существующих услугах в зависимости от переданного критерия поиска.
        """
        for service in existing_services:
            if not all([
                service.rfisc == new_service.rfisc,
                service.passenger_id == new_service.passenger_id,
                service.segment_id == new_service.segment_id,
            ]):
                continue

            if searching_type == FindServiceType.match_service:
                return service

            elif all((
                searching_type == FindServiceType.match_service_with_emd,
                service.emd == new_service.emd
            )):
                return service

            elif all((
                searching_type == FindServiceType.match_service_without_emd,
                not service.emd
            )):
                return service

            else:
                continue

        return None


class HdServiceStrategy(BaseStrategy):
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Union[Tuple[None, None], Tuple[DomainService, DomainService]]:
        if self.has_emd:
            raise UnableToMergeOrderError(
                message=f"Для стратегии HD не может быть emd. Услуга {new_service}"
            )
        existing_service: Optional[DomainService] = self.find_service(
            new_service=new_service,
            existing_services=existing_services,
            searching_type=FindServiceType.match_service
        )
        if not existing_service:
            return None, None

        if existing_service.status != ServiceStatus.HI.value:
            return existing_service, self.combine_data(existing_service=existing_service, new_service=new_service)
        else:
            return existing_service, existing_service


class HiServiceStrategy(BaseStrategy):
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Union[Tuple[None, None], Tuple[DomainService, DomainService]]:
        if new_service.emd:
            existing_service: Optional[DomainService] = self.find_service(
                new_service=new_service,
                existing_services=existing_services,
                searching_type=FindServiceType.match_service_with_emd
            )
            if existing_service:
                return existing_service, self.combine_data(existing_service=existing_service, new_service=new_service)

        existing_service: Optional[DomainService] = self.find_service(
            new_service=new_service,
            existing_services=existing_services,
            searching_type=FindServiceType.match_service
        )
        if not existing_service:
            return None, None

        elif existing_service.emd and not new_service.emd:
            merged_service = self.combine_data(existing_service=existing_service, new_service=new_service)
            merged_service.emd = existing_service.emd
            return existing_service, merged_service

        elif not existing_service.emd:
            return existing_service, self.combine_data(existing_service=existing_service, new_service=new_service)

        else:
            return None, None


class HnServiceStrategy(BaseStrategy):
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Tuple[None, None]:
        return None, None


class HkServiceStrategy(BaseStrategy):
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Union[Tuple[None, None], Tuple[DomainService, DomainService]]:
        if self.has_emd:
            UnableToMergeOrderError(
                message=f"Для стратегии HK не может быть emd. Услуга {new_service}"
            )
        existing_service: Optional[DomainService] = self.find_service(
            new_service=new_service,
            existing_services=existing_services,
            searching_type=FindServiceType.match_service_without_emd
        )
        if not existing_service:
            return None, None

        return existing_service, self.combine_data(existing_service=existing_service, new_service=new_service)


class XxServiceStrategy(BaseStrategy):
    def merge(
        self,
        new_service: DomainService,
        existing_services: List[DomainService]
    ) -> Union[Tuple[None, None], Tuple[DomainService, DomainService]]:

        existing_service: Optional[DomainService] = self.find_service(
            new_service=new_service,
            existing_services=existing_services,
            searching_type=FindServiceType.match_service
        )
        if not existing_service:
            return None, None

        return existing_service, self.combine_data(existing_service=existing_service, new_service=new_service)
