from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainSSR


from .base_merger import BaseOrderMerger


class MergeSpecialServices(BaseOrderMerger):
    """
    Слияние специальных услуг.
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        existing_ssrs: List[DomainSSR] = self.existing_order.data.ssrs
        new_ssrs: List[DomainSSR] = new_order.data.ssrs

        new_order.data.ssrs: List[DomainSSR] = self.__merge_ssrs__(existing_ssrs, new_ssrs)

        return new_order

    @staticmethod
    def __merge_ssrs__(
            existing_ssrs: List[DomainSSR],
            new_ssrs: List[DomainSSR]
    ) -> List[DomainSSR]:
        merged_ssrs: List[DomainSSR] = list()

        for new_ssr in new_ssrs:
            if new_ssr not in existing_ssrs:
                existing_ssrs.append(new_ssr)
            if new_ssr in existing_ssrs:
                existing_ssrs[existing_ssrs.index(new_ssr)] = new_ssr

        existing_ssrs.extend(merged_ssrs)

        return existing_ssrs
