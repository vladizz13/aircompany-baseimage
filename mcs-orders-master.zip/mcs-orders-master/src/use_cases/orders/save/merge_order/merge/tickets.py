from copy import deepcopy
from typing import Any, List, Dict
from domain import DomainOrder
from domain.order.data import DomainTicket
from domain.order.data.ticket import DomainMonetaryInfo, DomainTaxes

from .base_merger import BaseOrderMerger


class MergeTickets(BaseOrderMerger):
    """
    Склеиваем билеты
    """
    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        current_tickets: List[DomainTicket] = self.existing_order.data.tickets
        new_tickets: List[DomainTicket] = new_order.data.tickets

        current_tickets: List[DomainTicket] = self.merge_ticket_info(current_tickets, new_tickets)

        merged_tickets: List[DomainTicket] = self.merge_tickets(
            curr=current_tickets,
            new=new_tickets,
        )

        new_order.data.tickets = merged_tickets

        return new_order

    @staticmethod
    def merge_ticket_info(
            current_tickets: List[DomainTicket],
            new_tickets: List[DomainTicket]
    ) -> List[DomainTicket]:
        new_ticket_map: Dict[str, DomainTicket] = {ticket.ticket: ticket for ticket in new_tickets}

        for current_ticket in current_tickets:
            if current_ticket.ticket in new_ticket_map:
                new_ticket: DomainTicket = new_ticket_map[current_ticket.ticket]

                current_ticket.taxes.extend(new_ticket.taxes)
                current_ticket.monetary_info.extend(new_ticket.monetary_info)

                # Убираем дубликаты
                taxes_seen = list()
                monetary_info_seen = list()

                new_taxes: List[DomainTaxes] = list()
                new_monetary_info: List[DomainMonetaryInfo] = list()

                # В приоритете всегда таксы с owner
                current_ticket.taxes.sort(key=lambda x: (x.owner is None, x.owner))

                for tax in current_ticket.taxes:
                    tax_id = str(tax.coupon_id) + str(tax.code)
                    if tax_id in taxes_seen:
                        continue
                    taxes_seen.append(tax_id)
                    new_taxes.append(tax)

                for monetary_info in current_ticket.monetary_info:
                    monetary_info_id = str(monetary_info.coupon_id) + str(monetary_info.code)
                    if monetary_info_id in monetary_info_seen:
                        continue
                    monetary_info_seen.append(monetary_info_id)
                    new_monetary_info.append(monetary_info)

                new_ticket.taxes: List[DomainTaxes] = new_taxes
                new_ticket.monetary_info: List[DomainMonetaryInfo] = new_monetary_info

        return current_tickets

    @staticmethod
    def merge_tickets(
            curr: List[DomainTicket],
            new: List[DomainTicket],
    ) -> List[DomainTicket]:
        """
        Не удалять билеты, которых нет в новой версии брони.
        :param curr: билеты для текущей версии
        :param new: билеты для новой версии
        :return: Билеты
        """
        result = deepcopy(new)
        for item in curr:
            if item.ticket in [elem.ticket for elem in result]:
                # старый билет найден
                continue
            result.append(item)
        return result
