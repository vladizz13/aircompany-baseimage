from typing import Any

from domain import DomainOrder
from .base_merger import BaseOrderMerger


class MergeWaitingForRefund(BaseOrderMerger):
    """
    Слияние waiting_for_refund
    """

    def __init__(self, existing_order: DomainOrder):
        super().__init__(existing_order=existing_order)

    def merge(self, new_order: DomainOrder, request: Any) -> DomainOrder:
        new_order: DomainOrder = self.restore_waiting_for_refund(new_order)
        return new_order

    def restore_waiting_for_refund(self, new_order: DomainOrder) -> DomainOrder:
        """
        Восстанавливаем waiting_for_refund
        """
        if new_order.data.waiting_for_refund is None:
            new_order.data.waiting_for_refund = self.existing_order.data.waiting_for_refund
        return new_order
