from typing import Optional
from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain.types import TransactionSource
from domain import DomainOrder

from use_cases.orders.exceptions.save import (
    InvalidProviderSourceError,
    InvalidInputTransactionError,
)
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO


class MergeOrderRequest(BaseOrderRequest):

    def __init__(
            self,
            new_order: DomainOrder = None,
            existing_order: DomainOrder = None,
            received: Optional[float] = None,
            message_id: Optional[str] = None,
            provider: str = None,
            normalizer_dto: Optional[NormalizerDTO] = None
    ):
        super().__init__()
        self.new_order: DomainOrder = new_order
        self.existing_order: DomainOrder = existing_order
        self.received = received
        self.message_id = message_id
        self.provider = provider
        self.normalizer_dto = normalizer_dto

    def is_valid(self, *args, **kwargs) -> 'MergeOrderRequest':
        invalid_request = MergeOrderRequest()

        if not self.new_order or not isinstance(self.new_order, DomainOrder):
            invalid_request.add_error(InvalidInputTransactionError())

        if not self.existing_order or not isinstance(self.existing_order, DomainOrder):
            invalid_request.add_error(InvalidInputTransactionError())

        if self.provider not in TransactionSource._value2member_map_:
            invalid_request.add_error(InvalidProviderSourceError())

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize(self) -> dict:
        return {
            'new_order': self.new_order.serialize(),
            'existing_order': self.existing_order.serialize(),
            'received': self.received,
            'provider': self.provider,
            'message_id': self.message_id
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            new_order=DomainOrder.deserialize(data.get('new_order', dict())),
            existing_order=DomainOrder.deserialize(data.get('existing_order', dict())),
            provider=data.get('provider', None),
            received=data.get('received', None),
            message_id=data.get('message_id', None)
        )
