from domain import DomainOrder
from use_cases.orders.base_order_use_case import BaseOrderResponse


class MergeOrderResponse(BaseOrderResponse):

    def __init__(self, merged_order: DomainOrder = None):
        super().__init__(value=merged_order)
