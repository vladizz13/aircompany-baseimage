import copy
from typing import Optional
from adapter.sirena_adapter import SirenaInternalAdapter
from domain import DomainOrder
from libs.chain_of_responsibility.chain import InitChainUnit
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO
from use_cases.orders.save.merge_order.merge.contacts import MergeContacts
from use_cases.orders.save.merge_order.merge.coupon_state import SetCouponState
from use_cases.orders.save.merge_order.merge.coupons import MergeCoupons
from use_cases.orders.save.merge_order.merge.filter_offers import FilterOffers
from use_cases.orders.save.merge_order.merge.filter_passengers import FilterPassengers
from use_cases.orders.save.merge_order.merge.finalize import Finalize
from use_cases.orders.save.merge_order.merge.fops import MergeFops
from use_cases.orders.save.merge_order.merge.passengers import MergePassengers
from use_cases.orders.save.merge_order.merge.points import MergePoints
from use_cases.orders.save.merge_order.merge.pos_data import MergePosData
from use_cases.orders.save.merge_order.merge.price import MergePrice
from use_cases.orders.save.merge_order.merge.segments import MergeSegments
from use_cases.orders.save.merge_order.merge.services import MergeServices
from use_cases.orders.save.merge_order.merge.service_money import MergeServiceMoney
from use_cases.orders.save.merge_order.merge.special_services import MergeSpecialServices
from use_cases.orders.save.merge_order.merge.tickets import MergeTickets
from use_cases.orders.save.merge_order.merge.waiting_for_refund import MergeWaitingForRefund
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.exceptions.save import UnableToMergeOrderError
from .merge_request import MergeOrderRequest
from .merge_response import MergeOrderResponse
from libs.db_gateway import get_db_gateway
from domain.pd_changes import DomainPDChanges
from repositories.mongo.mongo_generic_repository import GenericMongoRepository


class MergeOrderUseCase(BaseOrderUseCase):

    def __init__(
            self,
            sirena_adapter: SirenaInternalAdapter,
    ):
        super().__init__()
        self.sirena_adapter = sirena_adapter
        self.normalizer_dto: Optional[NormalizerDTO] = None

    def __execute__(self, request: MergeOrderRequest, *args, **kwargs) -> MergeOrderResponse:
        try:
            merged_order: DomainOrder = self.merge_orders(
                new_order=request.new_order,
                existing_order=request.existing_order,
                request=request
            )
        except Exception as e:
            return MergeOrderResponse.build_from_exception(
                UnableToMergeOrderError(message=str(e), inner_exception=e)
            )
        return MergeOrderResponse(merged_order=merged_order)

    def merge_orders(
            self,
            new_order: DomainOrder,
            existing_order: DomainOrder,
            request: MergeOrderRequest
    ) -> DomainOrder:
        """
        Мерджим новый и существующий заказ
        """
        new_order_reference: DomainOrder = copy.deepcopy(new_order)

        chain = InitChainUnit()
        (
            # Порядок выполнения важен
            chain
            .set_next(MergeWaitingForRefund(existing_order=existing_order))
            .set_next(MergePosData(existing_order=existing_order))
            .set_next(MergeContacts(existing_order=existing_order))
            .set_next(MergeFops(existing_order=existing_order))
            .set_next(MergeSegments(existing_order=existing_order))
            .set_next(MergeServiceMoney(existing_order=existing_order))
            .set_next(MergeCoupons(
                existing_order=existing_order,
                new_order_reference=new_order_reference,
                normalizer_dto=request.normalizer_dto
            ))
            .set_next(MergePassengers(
                existing_order=existing_order,
                pd_changes_repo=GenericMongoRepository(gateway=get_db_gateway(), instance=DomainPDChanges)
            ))
            .set_next(MergeServices(existing_order=existing_order))
            .set_next(MergeTickets(existing_order=existing_order))
            .set_next(MergePoints(existing_order=existing_order))
            .set_next(MergePrice(existing_order=existing_order))
            .set_next(SetCouponState(
                existing_order=existing_order,
                new_order_reference=new_order_reference,
                sirena_adapter=self.sirena_adapter
            ))
            .set_next(FilterOffers(existing_order=existing_order))
            .set_next(FilterPassengers(existing_order=existing_order))
            .set_next(MergeSpecialServices(existing_order=existing_order))
            .set_next(Finalize(existing_order=existing_order))
        )
        chain.handle(new_order, request=request)
        return new_order
