from typing import Optional
from use_cases.orders.base_order_use_case import BaseOrderRequest
from domain.types import TransactionSource
from domain import DomainOrder

from use_cases.orders.exceptions.save import (
    InvalidProviderSourceError,
    InvalidInputTransactionError,
)
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO


class NormalizeOrderRequest(BaseOrderRequest):

    def __init__(
            self,
            order: DomainOrder = None,
            provider: str = None,
            received: Optional[float] = None,
            normalizer_dto: Optional[NormalizerDTO] = None
    ):
        super().__init__()
        self.order: DomainOrder = order
        self.provider = provider
        self.received = received
        self.normalizer_dto = normalizer_dto

    def is_valid(self, *args, **kwargs) -> 'NormalizeOrderRequest':
        invalid_request = NormalizeOrderRequest()

        if not self.order or not isinstance(self.order, DomainOrder):
            invalid_request.add_error(InvalidInputTransactionError())

        if self.provider not in TransactionSource._value2member_map_:
            invalid_request.add_error(InvalidProviderSourceError())

        if invalid_request.has_errors():
            return invalid_request
        return self

    def serialize(self) -> dict:
        return {
            'order': self.order.serialize(),
            'provider': self.provider,
        }

    @classmethod
    def deserialize(cls, data: dict):
        return cls(
            order=DomainOrder.deserialize(data.get('order', dict())),
            provider=data.get('provider', None),
        )
