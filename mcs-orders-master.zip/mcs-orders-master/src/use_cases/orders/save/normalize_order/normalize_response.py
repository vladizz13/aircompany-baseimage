from domain import DomainOrder
from use_cases.orders.base_order_use_case import BaseOrderResponse
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO


class NormalizeOrderResponse(BaseOrderResponse):

    def __init__(self, value: DomainOrder = None, normalizer_dto: NormalizerDTO = None):
        self.normalizer_dto: NormalizerDTO = normalizer_dto
        super().__init__(value=value)
