from typing import Optional

from adapter.monoapp import MonoAppAdapter
from adapter.sirena_adapter import SirenaInternalAdapter
from domain import DomainOrder
from libs.chain_of_responsibility.chain import InitChainUnit
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.coupon_status_normalizer import (
    CouponStatusSirenaGRSNormalizer
)
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.dates import DatesSirenaGRSNormalizer
from use_cases.orders.save.save_order.dto.normalizer_dto import NormalizerDTO
from use_cases.orders.save.normalize_order.normalizers.contacts import ContactsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.coupons import CouponsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.documents import DocumentsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.fops import FopsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.offers import OffersCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.passengers import PassengersCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.pos_data import PosDataCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.root_fields import RootFieldsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.segments import SegmentsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.services import ServiceCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.ssr import SSRCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.status import StatusCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.tickets import TicketsCommonNormalizer
from use_cases.orders.save.normalize_order.normalizers.waiting_for_refund import WaitingForRefundCommonNormalizer
from use_cases.orders.save.normalize_order.providers.sirena.normalizers.city_codes import CityCodesSirenaNormalizer
from use_cases.orders.save.normalize_order.providers.sirena.normalizers.dates import DatesSirenaNormalizer
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.filter_alien_copons import (
    FilterAlienCouponsSirenaGRSNormalizer
)
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.service_money import (
    ServiceMoneySirenaGRSNormalizer
)
from use_cases.orders.save.normalize_order.providers.sirena_grs.normalizers.timestamps import (
    TimestampsSirenaGRSNormalizer
)
from use_cases.orders.save.normalize_order.providers.tais.normalizers.departure_time import DepartureTimeTaisNormalizer
from use_cases.orders.save.normalize_order.providers.tais.normalizers.passenger_id import PassengerIDTaisNormalizer
from use_cases.orders.save.normalize_order.providers.tais.normalizers.status import ServiceStatusTaisNormalizer
from use_cases.orders.save.normalize_order.providers.tais.normalizers.dates import DatesTaisNormalizer
from use_cases.orders.base_order_use_case import BaseOrderUseCase
from use_cases.orders.exceptions.save import UnableToNormalizeOrderError
from .normalize_request import NormalizeOrderRequest
from .normalize_response import NormalizeOrderResponse


class NormalizeOrderUseCase(BaseOrderUseCase):

    def __init__(
            self,
            mono_app_adapter: MonoAppAdapter,
            sirena_adapter: SirenaInternalAdapter,
    ):
        super().__init__()

        self.sirena_adapter = sirena_adapter
        self.mono_app_adapter: MonoAppAdapter = mono_app_adapter

        self.normalizer_dto: Optional[NormalizerDTO] = None

    def __execute__(self, request: NormalizeOrderRequest, *args, **kwargs) -> NormalizeOrderResponse:
        try:
            normalized_order: DomainOrder = self.normalize_order(request.order, request)
        except Exception as e:
            return NormalizeOrderResponse.build_from_exception(
                UnableToNormalizeOrderError(message=str(e), inner_exception=e)
            )

        return NormalizeOrderResponse(value=normalized_order, normalizer_dto=self.normalizer_dto)

    def normalize_order(self, order: DomainOrder, request: NormalizeOrderRequest) -> DomainOrder:
        """
        Нормализация заказов
        """
        # Цепочка нормализаций
        chain = InitChainUnit()
        (
            chain
            # Common
            .set_next(RootFieldsCommonNormalizer())
            .set_next(PosDataCommonNormalizer())
            .set_next(SegmentsCommonNormalizer())
            .set_next(OffersCommonNormalizer())
            .set_next(ServiceCommonNormalizer())
            .set_next(TicketsCommonNormalizer())
            .set_next(PassengersCommonNormalizer())
            .set_next(DocumentsCommonNormalizer())
            .set_next(CouponsCommonNormalizer())
            .set_next(SSRCommonNormalizer())
            .set_next(WaitingForRefundCommonNormalizer())
            .set_next(FopsCommonNormalizer())
            .set_next(ContactsCommonNormalizer(created=request.received))
            .set_next(StatusCommonNormalizer())

            # Sirena
            .set_next(CityCodesSirenaNormalizer(mono_app_adapter=self.mono_app_adapter))
            .set_next(DatesSirenaNormalizer(mono_app_adapter=self.mono_app_adapter))

            # Tais
            .set_next(DatesTaisNormalizer(mono_app_adapter=self.mono_app_adapter))
            .set_next(DepartureTimeTaisNormalizer())
            .set_next(PassengerIDTaisNormalizer())
            .set_next(ServiceStatusTaisNormalizer())

            # SirenaGRS
            .set_next(DatesSirenaGRSNormalizer(mono_app_adapter=self.mono_app_adapter))
            .set_next(FilterAlienCouponsSirenaGRSNormalizer())
            .set_next(TimestampsSirenaGRSNormalizer())
            .set_next(ServiceMoneySirenaGRSNormalizer())
            .set_next(CouponStatusSirenaGRSNormalizer(
                sirena_adapter=self.sirena_adapter,
                created=request.received,
                normalizer_dto=request.normalizer_dto
            ))
        )
        # Выполняем все Common нормализации + нормализации по провайдеру
        chain.handle(order, request=request.provider)
        return order
