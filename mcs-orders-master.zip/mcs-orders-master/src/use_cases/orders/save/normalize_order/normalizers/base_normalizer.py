from abc import abstractmethod
from typing import Any, Optional, Union
from domain import DomainOrder
from libs.chain_of_responsibility.chain import AbstractChainHandler


class BaseOrderNormalizer(AbstractChainHandler):
    """
    Базовый нормализатор заказа
    Для добавления нового расширителя унаследоваться и реализовать
    логику в методе normalize

    Указать transaction_source
    >>> from domain.types import TransactionSource
    >>> transaction_source = TransactionSource.SIRENA.value
    """
    transaction_source: str = None

    def handle(self, order: DomainOrder, request: Any = None):
        if not self.skip(request):
            order = self.normalize(order, request)
        return super().handle(order, request)

    def skip(self, request: Any) -> bool:
        # Общая нормализация для любого провайдера
        if self.transaction_source is None:
            return False
        # Нормализация для конкретного провайдера
        if request is not None and self.transaction_source != request:
            return True
        return False

    @abstractmethod
    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:
        raise NotImplementedError()

    @staticmethod
    def convert_to_float(value: Optional[Union[str, int, float]]) -> Optional[float]:
        """
        Пробуем сконвертировать в float
        """
        if value is None:
            return None
        try:
            return float(value)
        except ValueError:
            return None
