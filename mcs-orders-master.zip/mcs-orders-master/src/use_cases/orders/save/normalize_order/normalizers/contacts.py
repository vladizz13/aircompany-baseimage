import logging
import re
from typing import Any, Union

import phonenumbers

from domain import DomainOrder
from domain.order.data import DomainContact
from domain.types import ContactType, MatchTypes
from .base_normalizer import BaseOrderNormalizer


class ContactsCommonNormalizer(BaseOrderNormalizer):
    """
    Нормализация данных контактов
    """

    logger = logging.getLogger('ContactsCommonNormalizer')

    def __init__(self, created: Union[int, float] = None):
        self.created = created
        self.email_pattern = r'([\w\-.]+)@([\w\-.]+)\.([\w]{2,15})'

    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:

        for i, contact in enumerate(order.data.contacts):
            order.data.contacts[i].created = self.created
            order.data.contacts[i].match_type = MatchTypes.AUTO.value

            if contact.type == ContactType.OTHER.value:
                continue
            elif contact.type == ContactType.PHONE.value:
                order.data.contacts[i] = self.normalize_phone(contact)

            elif contact.type == ContactType.MAIL.value:
                order.data.contacts[i] = self.normalize_email(contact)

        return order

    def normalize_phone(self, contact: DomainContact) -> DomainContact:
        """
        Нормализовать строку с номером телефона
        """
        if not contact.contact:
            return contact

        normalized_phone = phonenumbers.normalize_diallable_chars_only(contact.contact)
        if len(normalized_phone) > 10 and normalized_phone[0] not in ["+", "0", "8"]:
            normalized_phone = "+" + normalized_phone

        try:
            parsed_phone = phonenumbers.parse(normalized_phone, 'RU')
        except Exception:
            return contact

        if not phonenumbers.is_possible_number(parsed_phone):
            return contact

        contact.contact = phonenumbers.format_number(parsed_phone, phonenumbers.PhoneNumberFormat.E164)
        return contact

    def normalize_email(self, contact: DomainContact) -> DomainContact:
        """
        Нормализовать строку с e-mail адресом

        :param contact:
        :return:
        """
        if not contact.contact:
            return contact
        if '@' not in contact.contact:
            return contact

        prepared_email = contact.contact.strip().lower()
        email = re.search(self.email_pattern, prepared_email)
        if email:
            contact.contact = email.group()
        else:
            self.logger.warning(f'Detected unusual email address - {contact.contact}')
        return contact

    @classmethod
    def normalize_domain_contact(cls, contact: DomainContact) -> DomainContact:
        """
        Нормализация одного контакта не используя цепочку
        >>> normalized_contact: DomainContact = ContactsCommonNormalizer.normalize_domain_contact(contact)
        """
        instance = cls()
        if contact.type == ContactType.OTHER.value:
            return contact
        elif contact.type == ContactType.PHONE.value:
            return instance.normalize_phone(contact)
        elif contact.type == ContactType.MAIL.value:
            return instance.normalize_email(contact)
