from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainCoupon
from .base_normalizer import BaseOrderNormalizer


class CouponsCommonNormalizer(BaseOrderNormalizer):
    """
    Нормализация данных купона
    """

    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:
        coupons: List[DomainCoupon] = order.data.coupons
        for coupon in coupons:
            coupon.number = int(coupon.number) if coupon.number is not None else None
            coupon.segment_id = str(coupon.segment_id) if coupon.segment_id is not None else None
            coupon.passenger_id = str(coupon.passenger_id) if coupon.passenger_id is not None else None

            for key, value in coupon.coupon_money:
                coupon.coupon_money.__setattr__(key, int(float(value)) if value is not None else None)

        return order
