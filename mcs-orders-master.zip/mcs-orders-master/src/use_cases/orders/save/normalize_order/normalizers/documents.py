import logging

from typing import Any, List, Optional, AnyStr
from .base_normalizer import BaseOrderNormalizer
from domain import DomainOrder
from domain.order.data import DomainDocument
from domain.types import DocTypes
import re


class DocumentsCommonNormalizer(BaseOrderNormalizer):
    """
    Нормализация данных документов
    """

    logger = logging.getLogger('DocumentsCommonNormalizer')

    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:
        documents: List[DomainDocument] = order.data.documents
        for doc in documents:
            doc.passenger_id = str(doc.passenger_id)
            doc.doctype = self.normalize_doctype(doc.doctype)
        return order

    @staticmethod
    def normalize_doctype(doc_type: Optional[AnyStr]) -> Optional[AnyStr]:
        if not doc_type:
            return doc_type
        # Диапазон - кириллица, если документ в латинице - возвращаем его
        if not bool(re.search('[\u0400-\u04FF]', doc_type)):
            return doc_type.lower()
        # Переводим кириллицу в латиницу
        lat_doc_type = DocTypes.cyrillic_types_map.value.get(doc_type.upper())
        try:
            lat_doc_type = DocTypes[lat_doc_type].value
        except KeyError as e:
            DocumentsCommonNormalizer.logger.exception(e, extra={"tags": {"documents": doc_type}})
            raise KeyError(f"Invalid doc type: {doc_type}")
        return lat_doc_type
