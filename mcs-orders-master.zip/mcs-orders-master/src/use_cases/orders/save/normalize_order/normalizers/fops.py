from typing import Any, List
from domain import DomainOrder
from domain.order.data import DomainFop
from .base_normalizer import BaseOrderNormalizer


class FopsCommonNormalizer(BaseOrderNormalizer):
    """
    Нормализация данных fops
    """

    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:
        fops: List[DomainFop] = order.data.fops
        for fop in fops:
            fop.amount = self.convert_to_float(fop.amount)
        return order
