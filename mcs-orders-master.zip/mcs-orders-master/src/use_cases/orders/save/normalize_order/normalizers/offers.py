import logging
from typing import List, Any
from .base_normalizer import BaseOrderNormalizer
from domain import DomainOrder
from domain.order.data import DomainOffer


logger = logging.getLogger('transactions_booking_utils.offers')


class OffersCommonNormalizer(BaseOrderNormalizer):
    """
    Нормализация offers
    """

    def normalize(self, order: DomainOrder, request: Any) -> DomainOrder:
        offers:  List[DomainOffer] = order.data.offers  # noqa
        return order
